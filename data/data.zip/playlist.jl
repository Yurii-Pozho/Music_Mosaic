{"genre": "pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6gS3HhOiI17QNojjPuPzqc"}
{"genre": "rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6s5MoZzR70Qef7x4bVxDO1"}
{"genre": "rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7dowgSWOmvdpwNkGFMUs6e"}
{"genre": "urbano latino", "spotify_playlist_url": "https://open.spotify.com/playlist/1kfJj9rUlOGawu2U1U4oZn"}
{"genre": "hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6MXkE0uYF4XwU4VTtyrpfP"}
{"genre": "trap latino", "spotify_playlist_url": "https://open.spotify.com/playlist/7MIkj5EbBCaUutUBEfGpEJ"}
{"genre": "reggaeton", "spotify_playlist_url": "https://open.spotify.com/playlist/0VKCDh1qcRXjMfDhGEXihm"}
{"genre": "dance pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZIRxkFuqNPMnlY7vL54uK"}
{"genre": "pop rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5SrYLEPXnsfmK4ZuOCIKKm"}
{"genre": "modern rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5HufsVvMDoIPr9tGzoJpW0"}
{"genre": "pov: indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3ByKGRaNhQrtrvuGdjQ2Vf"}
{"genre": "musica mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/0Vv6NMPjPTWbdPybFlryM4"}
{"genre": "latin pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5tRvNV4dHaAbqPORml4YFS"}
{"genre": "classic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6NbtuNCQqvy9FXg1eYNqjJ"}
{"genre": "filmi", "spotify_playlist_url": "https://open.spotify.com/playlist/1uny7o4LNoe7C5qJJ8S1k1"}
{"genre": "permanent wave", "spotify_playlist_url": "https://open.spotify.com/playlist/4EYSGTuqe9cVfSVpX4gtGv"}
{"genre": "trap", "spotify_playlist_url": "https://open.spotify.com/playlist/60SHtDyagDjPnUpC7x1UD9"}
{"genre": "alternative metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0zJrEnj3O8CohOpFFUVSo9"}
{"genre": "k-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3T1Rft817cZ3pguTvaWaz3"}
{"genre": "r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/1rLnwJimWCmjp3f0mEbnkY"}
{"genre": "corrido", "spotify_playlist_url": "https://open.spotify.com/playlist/6UL8UnDWu9c95luN7S4wRs"}
{"genre": "canadian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4GdH9Ia0enMmulZlKOt9n4"}
{"genre": "norteno", "spotify_playlist_url": "https://open.spotify.com/playlist/2UITkS3qkO0x6bKVzKZrbS"}
{"genre": "sierreno", "spotify_playlist_url": "https://open.spotify.com/playlist/1ToiYTSneIiS6m4pYfrZrI"}
{"genre": "album rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3yj9YnQGTdnFuKbDyXGDi6"}
{"genre": "soft rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7ABVommvnBuEMEwF5tTxkW"}
{"genre": "pop dance", "spotify_playlist_url": "https://open.spotify.com/playlist/2HhaArHsOiofpUheCRPkLa"}
{"genre": "sad sierreno", "spotify_playlist_url": "https://open.spotify.com/playlist/5q9psMZx7aMShZPWwVFFum"}
{"genre": "edm", "spotify_playlist_url": "https://open.spotify.com/playlist/3pDxuMpz94eDs7WFqudTbZ"}
{"genre": "hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0yw5Q26eYIvaBediIFrYwN"}
{"genre": "contemporary country", "spotify_playlist_url": "https://open.spotify.com/playlist/0VZfpqcbBUWC6kpP1vVrvA"}
{"genre": "mellow gold", "spotify_playlist_url": "https://open.spotify.com/playlist/49vErWAk7BLsLccmRxngH3"}
{"genre": "uk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0OGpuF8rnCzlcjJLsdywny"}
{"genre": "melodic rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2V9SF7DMoOLEvxGVGT4uuU"}
{"genre": "modern bollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/2HibxdzVLGDPR5GIrm4cza"}
{"genre": "alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3dlw4x21qVajwZLPNHtS3u"}
{"genre": "banda", "spotify_playlist_url": "https://open.spotify.com/playlist/6kFjZNVsJZVRGtjZsHbi5U"}
{"genre": "post-grunge", "spotify_playlist_url": "https://open.spotify.com/playlist/60NgGlktCblheYPBSSUUXz"}
{"genre": "corridos tumbados", "spotify_playlist_url": "https://open.spotify.com/playlist/1CrWKL1wwHpcYQqLmQpHxH"}
{"genre": "sertanejo universitario", "spotify_playlist_url": "https://open.spotify.com/playlist/4JU3dwfdYvsBf0c4MOerz0"}
{"genre": "nu metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6eFAocA46YeKpvr0HY4DQJ"}
{"genre": "country", "spotify_playlist_url": "https://open.spotify.com/playlist/4mijVkpSXJziPiOrK7YX4M"}
{"genre": "art pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5oqAgQxfCjjD5ejU76a8V3"}
{"genre": "atl hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2NvIqZZ9VkCBIxrEbrwoM4"}
{"genre": "urban contemporary", "spotify_playlist_url": "https://open.spotify.com/playlist/07zF8MjQPsiYUXiAIGZ5TA"}
{"genre": "sertanejo", "spotify_playlist_url": "https://open.spotify.com/playlist/2EkYuzS8qUbRdqV5Bjnnin"}
{"genre": "southern hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/18jT9NMRZifv6cMtK2jWD4"}
{"genre": "singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/6gD9fCYGxsT9A8t3BHDVuj"}
{"genre": "reggaeton colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/6svSgLHdMo6N5iGPSnUkKv"}
{"genre": "arrocha", "spotify_playlist_url": "https://open.spotify.com/playlist/5b2Mfu6N64F4k11IVaZCdS"}
{"genre": "french hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1Wc17kLi2R2EsIACx5ElYt"}
{"genre": "colombian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2nl7TE1YytDEEfs4Ul6ALj"}
{"genre": "alt z", "spotify_playlist_url": "https://open.spotify.com/playlist/6TySxsLwRVYqEh7LZ6fyq8"}
{"genre": "country road", "spotify_playlist_url": "https://open.spotify.com/playlist/4fj8PNbbwGXBWHKodGQhfD"}
{"genre": "mexican pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4sghNjSZeUx5DFTADuPhPj"}
{"genre": "canadian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5e1PICDGQN7VplhLeKVATy"}
{"genre": "j-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3leFycE2a7uXZyuC6DQbdQ"}
{"genre": "indonesian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4VNawKxjIoJkE30Z9LbFzA"}
{"genre": "singer-songwriter pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5pzJVmW37XGUFynM2TQ0oO"}
{"genre": "ranchera", "spotify_playlist_url": "https://open.spotify.com/playlist/7bVLsTfYqQKkYOpUglYAp3"}
{"genre": "new wave pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6cZIwqYksHLjlRvhMMUizF"}
{"genre": "indietronica", "spotify_playlist_url": "https://open.spotify.com/playlist/0yqVOsxA2U4P260ad60QuU"}
{"genre": "german hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0N2gkh3nggtCtksCU2cSty"}
{"genre": "pop urbaine", "spotify_playlist_url": "https://open.spotify.com/playlist/21Le5iw1j6zgOMBtxioYfR"}
{"genre": "rock en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/0xZkDM0jIfrFATSeaGt9Ms"}
{"genre": "latin alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/6PBjVS6WmDRbFXYe39j8hN"}
{"genre": "gangster rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2tzFkp6VPJPeAhFe3b5uHk"}
{"genre": "soul", "spotify_playlist_url": "https://open.spotify.com/playlist/1YUIw9n6voqxPzawnEf3A2"}
{"genre": "k-pop boy group", "spotify_playlist_url": "https://open.spotify.com/playlist/7jGzify69eicmfL77zOGbm"}
{"genre": "latin arena pop", "spotify_playlist_url": "https://open.spotify.com/playlist/59qMoqvlNat6Knc0feSWJn"}
{"genre": "chicago rap", "spotify_playlist_url": "https://open.spotify.com/playlist/71hJ9e25Ub4XZwiE1FZAjI"}
{"genre": "italian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1otEUipmOvjOGGqvEHHxEy"}
{"genre": "heartland rock", "spotify_playlist_url": "https://open.spotify.com/playlist/73X32zjxrkOSaroGsaCJKx"}
{"genre": "k-pop girl group", "spotify_playlist_url": "https://open.spotify.com/playlist/64KEXfUapxhkmiqKDsBrbN"}
{"genre": "agronejo", "spotify_playlist_url": "https://open.spotify.com/playlist/1FujEQEuhDasegDbxsZQdB"}
{"genre": "modern country pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1AmdZJ5lBBbe6SX1MyAst9"}
{"genre": "electro house", "spotify_playlist_url": "https://open.spotify.com/playlist/4luNnGhISZdURbFcCl2dB6"}
{"genre": "latin hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/31pfQ67BktLUcQ9n5VGnDI"}
{"genre": "canadian contemporary r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/5wJb9tgSkHYu8lIXzallgA"}
{"genre": "pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5prkai2xWcnqLxwORZSYbN"}
{"genre": "neo mellow", "spotify_playlist_url": "https://open.spotify.com/playlist/1u4LMI2YFyDRBtCJ00rbzm"}
{"genre": "pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1voR0tqN6ZFkQ9QABvbCkZ"}
{"genre": "latin rock", "spotify_playlist_url": "https://open.spotify.com/playlist/31YWtFP5V22xiYZ2og7HOy"}
{"genre": "punjabi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0a8gfAB5pIeR5x2ln5ARq0"}
{"genre": "rap metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6VKTnBP8zsyEmP1Sk7TvMm"}
{"genre": "trap argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/0t2kp4dTSFBUA8doPFtUuY"}
{"genre": "new romantic", "spotify_playlist_url": "https://open.spotify.com/playlist/4c8FDUUCm33WYC9xztAGYT"}
{"genre": "new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/1ydxatu4wrujF0H2hGU8IR"}
{"genre": "uk dance", "spotify_playlist_url": "https://open.spotify.com/playlist/5kDzf9eWk24U16EBkTDdpb"}
{"genre": "slap house", "spotify_playlist_url": "https://open.spotify.com/playlist/1TAxbbKCs6rlEQcrdVWYmW"}
{"genre": "modern alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3PMlHfN3H3GmOcTgEcGwJT"}
{"genre": "indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1aYiM4zLmBuFq0Fg6NQb6a"}
{"genre": "indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4XXr357Jej7eUBh7XPK8hb"}
{"genre": "house", "spotify_playlist_url": "https://open.spotify.com/playlist/6AzCASXpbvX5o3F8yaj1y0"}
{"genre": "conscious hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3IU0ZFCSvKNqASPNsWoPuj"}
{"genre": "modern country rock", "spotify_playlist_url": "https://open.spotify.com/playlist/01b3JSy4UfA2iiKodhAXse"}
{"genre": "east coast hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/61KJ6kPuE41yTp9SrHvWbZ"}
{"genre": "folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0TTsY3zQAYz6NppoHDR5MA"}
{"genre": "metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3pBfUFu8MkyiCYyZe849Ks"}
{"genre": "turkish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4oKodlbJBRKSssO8LhsisY"}
{"genre": "bedroom pop", "spotify_playlist_url": "https://open.spotify.com/playlist/339zjWDksACL7sNs2UehlX"}
{"genre": "desi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7JHxvhw9XPNKqtCt70xnAf"}
{"genre": "italian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5kMRm3YJv7ZyX1VTmVZpdN"}
{"genre": "hoerspiel", "spotify_playlist_url": "https://open.spotify.com/playlist/6XDdeW5toilpyJXBi0Plxl"}
{"genre": "afrobeats", "spotify_playlist_url": "https://open.spotify.com/playlist/1KEVi9iz4neinmHtysrz7A"}
{"genre": "adult standards", "spotify_playlist_url": "https://open.spotify.com/playlist/0FmeDxPXfsozPAyWv9uFjL"}
{"genre": "post-teen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/10FCW9lj0NdeoYI5VVvVtY"}
{"genre": "neo soul", "spotify_playlist_url": "https://open.spotify.com/playlist/2zxYQBTWiXgpQEyQggYSTm"}
{"genre": "sped up", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ot7SIZg72RfUphP7V6zqs"}
{"genre": "cloud rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1sIcT9bfCD4C53ZjKXWy7M"}
{"genre": "viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0tAsyMQoefUL8DWNn6xkAk"}
{"genre": "talent show", "spotify_playlist_url": "https://open.spotify.com/playlist/1lMgl0D1HZVvtq16pB13ew"}
{"genre": "spanish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/40auwv5lX0xeL2w7Kr6BoT"}
{"genre": "punk", "spotify_playlist_url": "https://open.spotify.com/playlist/17qQT0G3yFjOJ02wWZaNCw"}
{"genre": "alternative r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/0Hwb2a9DJdom4yoe5V41K9"}
{"genre": "grupera", "spotify_playlist_url": "https://open.spotify.com/playlist/1MBLuaTt9FmjgW3AVAlIKo"}
{"genre": "west coast rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3tSxvStT2zgdgPcTxLdI3g"}
{"genre": "opm", "spotify_playlist_url": "https://open.spotify.com/playlist/2LfEVQ7ETewcpbNa2IVsH7"}
{"genre": "boy band", "spotify_playlist_url": "https://open.spotify.com/playlist/5MqoSHN1RNzdKd5T1QCN8S"}
{"genre": "psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7mXRIC5bSB6ZWOEPNfP0hl"}
{"genre": "glam metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7yC6AO4CRgiFDjhYUkPUzX"}
{"genre": "stomp and holler", "spotify_playlist_url": "https://open.spotify.com/playlist/3zVZ3GsfiYp0vlVazHcDXI"}
{"genre": "desi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7hCUgCmtC02mQe4lUg5ZSs"}
{"genre": "ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/5prvXHLGfLtWJ7tB4W8Fvl"}
{"genre": "rage rap", "spotify_playlist_url": "https://open.spotify.com/playlist/54j0DPxOen62HcPCc2Pmoe"}
{"genre": "hip pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1btVAcL1TR8anpF72xgvjB"}
{"genre": "puerto rican pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0KPfijR82jvlPTnt3Hmu2Q"}
{"genre": "german pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4pCmObKUeRQFFsF2nXu9t8"}
{"genre": "miami hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4F2wv2RnXpmVW86K7Z2Es2"}
{"genre": "argentine rock", "spotify_playlist_url": "https://open.spotify.com/playlist/70yDbCeImYqhxCDRU0qXpd"}
{"genre": "sertanejo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1JsjFOxcEp912tK85VC98V"}
{"genre": "tropical", "spotify_playlist_url": "https://open.spotify.com/playlist/5pkSkAC6JTpIgg0zSQoWdF"}
{"genre": "glam rock", "spotify_playlist_url": "https://open.spotify.com/playlist/71LnSyxXMKcxgJSAhC1KDK"}
{"genre": "funk carioca", "spotify_playlist_url": "https://open.spotify.com/playlist/1aAckG2NI0cuL7QDKVeV2N"}
{"genre": "nigerian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7MwdQNmdKjQx3h1p3vP2eZ"}
{"genre": "argentine hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6tT2e2rcnpUrywDkmgSASj"}
{"genre": "dark trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1lEZC1rWlusGF0IC6JxR5V"}
{"genre": "latin viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6yZCXdIyG6jxAnWnm2wXKp"}
{"genre": "piano rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5rVVQKO7UFXkwpt7jF1Ne4"}
{"genre": "detroit hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7gIFgVQoSml3JocSRd2t4S"}
{"genre": "italian adult pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4APG0kwkbEt77VxOuqKCUl"}
{"genre": "country rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2yykv7TMUr4jPHPAE8Q3vW"}
{"genre": "underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6d99h91us5ozdlNDvaeyXn"}
{"genre": "mexican hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0zTflwpEJVMnCOSmExgS75"}
{"genre": "progressive electro house", "spotify_playlist_url": "https://open.spotify.com/playlist/6j9xPeEsHgCS1eZW0HsIsk"}
{"genre": "synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/71wpwg8KzRxx240DcJx2EE"}
{"genre": "metropopolis", "spotify_playlist_url": "https://open.spotify.com/playlist/70z5dMlsS9fPudWdQ9ebqP"}
{"genre": "garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4Wnjv0bnb6Y7Il7WhEJC3x"}
{"genre": "indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5Z5KHMrb3bNWGOZJ6y8gsL"}
{"genre": "vocal jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZazIXecBCVmTlbyKJHxOc"}
{"genre": "classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3HYK6ri0GkvRcM6GkKh0hJ"}
{"genre": "europop", "spotify_playlist_url": "https://open.spotify.com/playlist/4vuWieduKii4KZrUboVr9d"}
{"genre": "progressive house", "spotify_playlist_url": "https://open.spotify.com/playlist/3ApHTzZrOMqtDhnyiBSSci"}
{"genre": "art rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6PimpDQHW8sNtGfz1jDTAi"}
{"genre": "yacht rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1imbMwZYgwB2NCAVPkq5sZ"}
{"genre": "mpb", "spotify_playlist_url": "https://open.spotify.com/playlist/0Fr9ysvU9XjFBMl4Rhl755"}
{"genre": "pagode", "spotify_playlist_url": "https://open.spotify.com/playlist/2mL2d1k8Vxlf4P4q6JqcAv"}
{"genre": "tropical house", "spotify_playlist_url": "https://open.spotify.com/playlist/5Z4GsFxPRJiN9Qme2P9q6H"}
{"genre": "urbano espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/6gpELhsiYJyaL13srOlTMQ"}
{"genre": "chamber pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1UqeJ3nLHNDOlA6zwFkimJ"}
{"genre": "rap francais", "spotify_playlist_url": "https://open.spotify.com/playlist/0iWAjJOZQvLdbYeBDisvdT"}
{"genre": "dance rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3PgRe3aEtNXhWm9GOUgOdG"}
{"genre": "j-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/537P5gB83q9AmtDFdFNBLO"}
{"genre": "polish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1DXuK8SBX4BNVEkZ4ifHBJ"}
{"genre": "sleep", "spotify_playlist_url": "https://open.spotify.com/playlist/0cuaFpexE9V0zr3s7l6yjR"}
{"genre": "folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4JuKjgd76AZn2fUaeXNCuo"}
{"genre": "anime", "spotify_playlist_url": "https://open.spotify.com/playlist/5fSZTu6aISl80OPrmGu79j"}
{"genre": "trap brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/6u3BeKMf8CUZe4ab0HtNbT"}
{"genre": "disco", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZVSWcJIf7cvycEn9HUvps"}
{"genre": "pluggnb", "spotify_playlist_url": "https://open.spotify.com/playlist/5eUTjCgIZ8jNCpQRHbxltu"}
{"genre": "british soul", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ar1S6TuqmS0R2RV59AR1k"}
{"genre": "metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/71kedeh6L7P0equUL0vOqe"}
{"genre": "australian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/67qIuPZRX12l7yMpxBQpxs"}
{"genre": "uk hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ek92zIh4Sq5IVU9Mgv7d6"}
{"genre": "christian music", "spotify_playlist_url": "https://open.spotify.com/playlist/1b1BPM9hp5Q0eI7yuGTaot"}
{"genre": "gen z singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/5nUyv9wyZKjdUW1rk3smTo"}
{"genre": "electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/1BYospE2cLB28m3i84dcTV"}
{"genre": "big room", "spotify_playlist_url": "https://open.spotify.com/playlist/70E7wtl8eL3IG2kpaWok6E"}
{"genre": "forro", "spotify_playlist_url": "https://open.spotify.com/playlist/6aRR1ZmHR6ehjbhlsoctG1"}
{"genre": "swedish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6mvBNM74d828wcEy9Bpb46"}
{"genre": "classic oklahoma country", "spotify_playlist_url": "https://open.spotify.com/playlist/4swO9BLJdUIGuNJii0IXLI"}
{"genre": "reggaeton flow", "spotify_playlist_url": "https://open.spotify.com/playlist/2HZIaMnfPMDf24XjrNXaMt"}
{"genre": "pop nacional", "spotify_playlist_url": "https://open.spotify.com/playlist/4yf2dXdO6U7TVDXZMbm8nY"}
{"genre": "british invasion", "spotify_playlist_url": "https://open.spotify.com/playlist/4UptWIEPwIimCpCHayG4yZ"}
{"genre": "mexican rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5FI68jaboLczr9zIUVfQPW"}
{"genre": "indie soul", "spotify_playlist_url": "https://open.spotify.com/playlist/2I4WRSnG0wVgkbSasDUqKp"}
{"genre": "contemporary r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/1rlHnACGatHAOQrZ3WjEI3"}
{"genre": "folk-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1RWc3d424qgjr8HTwCVh6A"}
{"genre": "white noise", "spotify_playlist_url": "https://open.spotify.com/playlist/7j5QgrOCOptczCKI74BK39"}
{"genre": "pagode novo", "spotify_playlist_url": "https://open.spotify.com/playlist/3U903ICkXhjRoPgPrG4O1j"}
{"genre": "soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/2RmQ1WAONeEih0FWEK7CW5"}
{"genre": "funk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6JqQli6WY1G043Mihy3MBp"}
{"genre": "grunge", "spotify_playlist_url": "https://open.spotify.com/playlist/2PNaFf1DInEl8NJSdkE4F4"}
{"genre": "french pop", "spotify_playlist_url": "https://open.spotify.com/playlist/03csHhetcFo29YHV4Z9A3g"}
{"genre": "emo rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0Fz9zaKbug4gw1xTvmTUWI"}
{"genre": "salsa", "spotify_playlist_url": "https://open.spotify.com/playlist/58ELr3yC5uxg8QsQWD8Lmy"}
{"genre": "rain", "spotify_playlist_url": "https://open.spotify.com/playlist/4NVJ5W2V7pgadk3yXliHTD"}
{"genre": "r&b francais", "spotify_playlist_url": "https://open.spotify.com/playlist/2UOSW9qb7oKPK0myr9I7vE"}
{"genre": "lgbtq+ hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0njc7Pu7XGeU25wdaJRdLm"}
{"genre": "turkish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0aOQSNOuSE84kP4epEGVou"}
{"genre": "memphis hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1rmskknWn4KPtEC6PHh2Rd"}
{"genre": "mariachi", "spotify_playlist_url": "https://open.spotify.com/playlist/5eAqREKMQTvNSVE3R8oVEj"}
{"genre": "brostep", "spotify_playlist_url": "https://open.spotify.com/playlist/6dvgLyeXG3HLGqtMa8wAX0"}
{"genre": "classic soul", "spotify_playlist_url": "https://open.spotify.com/playlist/1eWqWLqf2wmssHJFvNLK2P"}
{"genre": "funk mtg", "spotify_playlist_url": "https://open.spotify.com/playlist/7qgTJhcHV88KAk7zILiOLL"}
{"genre": "trap triste", "spotify_playlist_url": "https://open.spotify.com/playlist/1uE60pEQpaIgUT3T7Voloi"}
{"genre": "dirty south rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3l6M4SAmRg9L0DlalK76H8"}
{"genre": "melodic metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4PsFYH9aJDNjy7iwkWag7S"}
{"genre": "blues rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2kISScyTs0we9kzH9MKEMb"}
{"genre": "alternative hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2kHQTJJWXc54i8mX8ndYdf"}
{"genre": "melancholia", "spotify_playlist_url": "https://open.spotify.com/playlist/6gB4lvhZqPfknvnw2iNwL6"}
{"genre": "pop soul", "spotify_playlist_url": "https://open.spotify.com/playlist/0ShRnc2cyEyxkLbtZC4Yim"}
{"genre": "brazilian gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/6Xxksk0PXng2x9zF30Yzg7"}
{"genre": "outlaw country", "spotify_playlist_url": "https://open.spotify.com/playlist/5D1IoXQGtdt84Mx8QvvSSY"}
{"genre": "orchestral soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/4a5OYJObN9YJPpfBuP2L22"}
{"genre": "dutch house", "spotify_playlist_url": "https://open.spotify.com/playlist/2A2qSpDa4K8gD55D7sDJe7"}
{"genre": "turkish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4t5PSWEsLQeZ4i90PEpW9i"}
{"genre": "queens hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0AxeQveEqk8X42sovBCls8"}
{"genre": "christian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3P1RRrVtaVLBTOvvNm8k8N"}
{"genre": "mandopop", "spotify_playlist_url": "https://open.spotify.com/playlist/4EIGwSoao5WkHd5YVP4CfG"}
{"genre": "lounge", "spotify_playlist_url": "https://open.spotify.com/playlist/7jk0EKyr4Lc4jc4XPE4ycL"}
{"genre": "worship", "spotify_playlist_url": "https://open.spotify.com/playlist/1auZ2gm318zSzLhrknJtVw"}
{"genre": "dfw rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6ze96fv5x3AklLyAqxPPv8"}
{"genre": "electronica", "spotify_playlist_url": "https://open.spotify.com/playlist/6I0NsYzfoj7yHXyvkZYoRx"}
{"genre": "pixel", "spotify_playlist_url": "https://open.spotify.com/playlist/0t85wrZwJdkmcL015OytYz"}
{"genre": "trap italiana", "spotify_playlist_url": "https://open.spotify.com/playlist/6AxIe6nptUOe8jJ4LeNptt"}
{"genre": "pop reggaeton", "spotify_playlist_url": "https://open.spotify.com/playlist/7dWozFDD5uTTmEFMcQtGZj"}
{"genre": "new orleans rap", "spotify_playlist_url": "https://open.spotify.com/playlist/41wq6c8ic47zFa4ixRZp6P"}
{"genre": "otacore", "spotify_playlist_url": "https://open.spotify.com/playlist/5UBQfw8fKxi6ADXxUdUT2K"}
{"genre": "rock-and-roll", "spotify_playlist_url": "https://open.spotify.com/playlist/34bhxCaWrYi4kF67mNYiXW"}
{"genre": "funk", "spotify_playlist_url": "https://open.spotify.com/playlist/0MBvtOIm5fuBbRHEltDY8A"}
{"genre": "quiet storm", "spotify_playlist_url": "https://open.spotify.com/playlist/66k6nBXFo6of5ckPWCuCSi"}
{"genre": "motown", "spotify_playlist_url": "https://open.spotify.com/playlist/28UOzZyORCx38D8dKe3fsq"}
{"genre": "japanese teen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6Wz5IiVGjSDWQmMlPxHcjg"}
{"genre": "brazilian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2CBOZqWolmSfOeXAo8mCFZ"}
{"genre": "gruperas inmortales", "spotify_playlist_url": "https://open.spotify.com/playlist/7fwQCsCDYxnmWtXUkETn3v"}
{"genre": "kleine hoerspiel", "spotify_playlist_url": "https://open.spotify.com/playlist/27XLynMa4krkiA9piuqyT1"}
{"genre": "indie poptimism", "spotify_playlist_url": "https://open.spotify.com/playlist/7nHgmv7uyIA1KHj6qTttjH"}
{"genre": "dream pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2A5zN7OTP4n64gEtsFEO2Z"}
{"genre": "rap conscient", "spotify_playlist_url": "https://open.spotify.com/playlist/3kYWjrbBEvI8n3bPI2ZRml"}
{"genre": "neo-synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/2U7wEb4EEDbiAs3CCOoUfn"}
{"genre": "funk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2v7uYvX2h5hNSukaqp9LCb"}
{"genre": "easy listening", "spotify_playlist_url": "https://open.spotify.com/playlist/47RSt6JBM6AbqBxtggW1Jk"}
{"genre": "bolero", "spotify_playlist_url": "https://open.spotify.com/playlist/40h91GpdbHja6VVsnetD0r"}
{"genre": "g funk", "spotify_playlist_url": "https://open.spotify.com/playlist/7c1Z3aCJLt7YisQQyXwypK"}
{"genre": "barbadian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4skZam98b2PwmuWxS8fAT5"}
{"genre": "progressive rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1sYzsb7P37XzNZoUR2GGdm"}
{"genre": "eurodance", "spotify_playlist_url": "https://open.spotify.com/playlist/4jw4G9J55p7tXV2xEAGUj4"}
{"genre": "hardcore hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0iMt55EhVZULr9oClWtyOX"}
{"genre": "bachata", "spotify_playlist_url": "https://open.spotify.com/playlist/5CllQE0jNYEbZWEjyhDD6J"}
{"genre": "australian dance", "spotify_playlist_url": "https://open.spotify.com/playlist/3iiCEjJsCfkP18Xfqv9fZi"}
{"genre": "neon pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/52NjfVJ2mAEaeOorFvrGvk"}
{"genre": "emo", "spotify_playlist_url": "https://open.spotify.com/playlist/4eC7Sa1Xcy33lKn53gfiZb"}
{"genre": "trap boricua", "spotify_playlist_url": "https://open.spotify.com/playlist/4fWARp37Pjz3rf3WvVIAFz"}
{"genre": "brazilian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3nExI3KhiOs9fFobjdHzfj"}
{"genre": "funk paulista", "spotify_playlist_url": "https://open.spotify.com/playlist/6YHx5ZIQqpfrxKEsw77EDU"}
{"genre": "pop venezolano", "spotify_playlist_url": "https://open.spotify.com/playlist/0dYg5qMtoE1qT37H7YBNLf"}
{"genre": "cantautor", "spotify_playlist_url": "https://open.spotify.com/playlist/2KMAWk6brKSc3lVAsRZIMH"}
{"genre": "chanson", "spotify_playlist_url": "https://open.spotify.com/playlist/6IyBSGUEuApnT6miXVlKLf"}
{"genre": "drift phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/19sgQqGAcGplazJZTXeLUG"}
{"genre": "florida rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5NELYHLIR9VEbXvj9h52vV"}
{"genre": "bedroom r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/2rYV2n4K0QRuE1rcWbsWMM"}
{"genre": "latin christian", "spotify_playlist_url": "https://open.spotify.com/playlist/2p0LqJK2o0uCq2COZJyhls"}
{"genre": "movie tunes", "spotify_playlist_url": "https://open.spotify.com/playlist/1gauLmjFqDP3iP7yKiJCHt"}
{"genre": "indonesian pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/69r1MJRmRHDdyMwVYnok2p"}
{"genre": "russian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/69d6UEZKkFtQNEDQyntv7S"}
{"genre": "spanish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3WLnRqmW5IZOATVCnNqZk5"}
{"genre": "cali rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4KxHxwmVq3Q7Gg9wkyOwzV"}
{"genre": "dancehall", "spotify_playlist_url": "https://open.spotify.com/playlist/4NWfwcqBdZ3wltgu3BESG7"}
{"genre": "brooklyn drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6cKDwODDI0Cxba36w964fK"}
{"genre": "trap queen", "spotify_playlist_url": "https://open.spotify.com/playlist/24lpzMRS776gtph07QO0AK"}
{"genre": "urbano chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/7tZuamhysdcbZWkGa3l72G"}
{"genre": "color noise", "spotify_playlist_url": "https://open.spotify.com/playlist/0CqBELlpt9OFtk9NybFIdm"}
{"genre": "children's music", "spotify_playlist_url": "https://open.spotify.com/playlist/3EBkMektqMgkilc2bOehLD"}
{"genre": "world worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5KopCY959BEZz4oWcG9yNS"}
{"genre": "urbano mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/3p1ydvi0RyHcDfIC1sfA3n"}
{"genre": "sheffield indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7oJElJ9V5z6jWiJEA4S6DM"}
{"genre": "classic texas country", "spotify_playlist_url": "https://open.spotify.com/playlist/4HbGCzaH6bTsF1FGAESEzG"}
{"genre": "escape room", "spotify_playlist_url": "https://open.spotify.com/playlist/1BwLE6QTlmYAtosuvJcgY7"}
{"genre": "modern indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0FkLYgMF09lmzytexAraKv"}
{"genre": "funk rj", "spotify_playlist_url": "https://open.spotify.com/playlist/4YyikjHPefH5dYGjgQ6zem"}
{"genre": "plugg", "spotify_playlist_url": "https://open.spotify.com/playlist/64APSYMq8SznNHfk8siTLw"}
{"genre": "anime rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0LUqgNyVlPVcZ34ODl30kv"}
{"genre": "merseybeat", "spotify_playlist_url": "https://open.spotify.com/playlist/2FE5Q5imNlAYRKubRHOuE8"}
{"genre": "reggae fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/0j92q9CkBFlHDpgcIURMd6"}
{"genre": "shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/5ydNNBQbwQJuhmcxyo8K1f"}
{"genre": "tamil hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7iXfcP5kZ4EPqSSmySAUtf"}
{"genre": "britpop", "spotify_playlist_url": "https://open.spotify.com/playlist/5H4y9vLqOhWGn0xsExGxKb"}
{"genre": "australian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0D5WxMvZQ7kZJCgF0xu2kJ"}
{"genre": "industrial metal", "spotify_playlist_url": "https://open.spotify.com/playlist/65Jejep3SssPpTW8RGELh6"}
{"genre": "baroque pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1e3sjciHZnhGYpaVYv6rO1"}
{"genre": "brooklyn indie", "spotify_playlist_url": "https://open.spotify.com/playlist/78MPGFVq0C4yrfvgxZKngM"}
{"genre": "pop argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/2dHEwheLsfq6X3AfIH1AnJ"}
{"genre": "r&b en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/4tzYxjoGLrGjrjp1x0Sggg"}
{"genre": "trance", "spotify_playlist_url": "https://open.spotify.com/playlist/5vBxJ3Y2DbAna3xBJpGz0z"}
{"genre": "turkish trap", "spotify_playlist_url": "https://open.spotify.com/playlist/5HmIKVhLNyi6CLopqdLJVU"}
{"genre": "thai pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3UgbkYQnqsue0LbbcUUCDN"}
{"genre": "lilith", "spotify_playlist_url": "https://open.spotify.com/playlist/7yNFFzl1njPs3ToiRrWU9w"}
{"genre": "indian instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/2hNgMUbA6cV6NaIbXhd2Bg"}
{"genre": "downtempo", "spotify_playlist_url": "https://open.spotify.com/playlist/5zxj55xrB53As97uvt5x8x"}
{"genre": "southern rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4T1ZiJC9fdryPOa47Pf3vl"}
{"genre": "sophisti-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/18LufJPENHQkScaoTPZLAm"}
{"genre": "punjabi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1z4ZrhexnvW94ekEDDQqeU"}
{"genre": "polish trap", "spotify_playlist_url": "https://open.spotify.com/playlist/78dAycV2sXjUhhhCrmgalT"}
{"genre": "socal pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/082daAvMUmkVEgkolt3wCw"}
{"genre": "candy pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1g2P36W1Dn9CYyegAm7Z4x"}
{"genre": "tamil pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1n837Vzu2Mtk4H1vBYA3m3"}
{"genre": "rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/5LNGaRZPGqluUQWQBY49WS"}
{"genre": "girl group", "spotify_playlist_url": "https://open.spotify.com/playlist/0vgSCZFzrE0eId4bKI1NNt"}
{"genre": "uk contemporary r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/5kdP7VQedYdDzhTvfovu0u"}
{"genre": "atl trap", "spotify_playlist_url": "https://open.spotify.com/playlist/3JqPLi8uM4ldiPdT3T6Oy8"}
{"genre": "old school thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/7Mb1RVFEVwS1kOeMpbCWbR"}
{"genre": "classic bollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/0JoynXyEsqFyxTn9NTZkFW"}
{"genre": "compositional ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/2nKOwEQWB8qDAG5Qcs0kWc"}
{"genre": "gym phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/39fjkMOK0mMK0XKNr18Xxc"}
{"genre": "north carolina hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3G9abO9U7dJa0kR4ZKhapR"}
{"genre": "dark r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/79hZVIvDOO2OMJnZQ3gzIV"}
{"genre": "country dawn", "spotify_playlist_url": "https://open.spotify.com/playlist/2qk8D3ZyEBXDwR02alzjXq"}
{"genre": "symphonic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7xy3Cy7QkWNgDjkntVvda8"}
{"genre": "tennessee hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0sDsNueIuqMP0aNLesjWMq"}
{"genre": "instrumental lullaby", "spotify_playlist_url": "https://open.spotify.com/playlist/5COOZ0qQHM3AhJnSF7ey9E"}
{"genre": "pittsburgh rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5hEnBDgbXhqEa2mUr4sFVU"}
{"genre": "thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3UQbqTKIxehTFCdFyjEQUn"}
{"genre": "afropop", "spotify_playlist_url": "https://open.spotify.com/playlist/5vpvuv9xaddqd00dzpxTzg"}
{"genre": "screamo", "spotify_playlist_url": "https://open.spotify.com/playlist/3yvVzKRxdUAc7vxWdwQfGS"}
{"genre": "canadian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4STQEZTDt5QijuCxmg3DpB"}
{"genre": "kindermusik", "spotify_playlist_url": "https://open.spotify.com/playlist/7iRtqaM0fu2Ip8GzzceQzF"}
{"genre": "melodic drill", "spotify_playlist_url": "https://open.spotify.com/playlist/54z9sCdnMoFNmWuxczmEYW"}
{"genre": "nyc rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6YiocLoaqYYGiAztoGspzh"}
{"genre": "modern blues rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2KmAVEfiJy17zDEZslvmSg"}
{"genre": "rock nacional brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/2VU7QQKSn6eIE2e9DY52dM"}
{"genre": "philly rap", "spotify_playlist_url": "https://open.spotify.com/playlist/46OzYiu5J1KvNDAwyY126g"}
{"genre": "afrofuturism", "spotify_playlist_url": "https://open.spotify.com/playlist/2w4rahctwfHuu3YFP8lcFl"}
{"genre": "healing hz", "spotify_playlist_url": "https://open.spotify.com/playlist/0PaPyYEZfzx2vpoPmjVYzY"}
{"genre": "cumbia pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1fcPcaUecENuGmupx6P6xw"}
{"genre": "rap latina", "spotify_playlist_url": "https://open.spotify.com/playlist/6JWSHUaK7oIekxggExyj6T"}
{"genre": "reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/0TcXdt4sbITbwCwwFbKYyd"}
{"genre": "madchester", "spotify_playlist_url": "https://open.spotify.com/playlist/4S0dEwHY1tHedrYTB6O1Yi"}
{"genre": "spanish pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6Z07gmQdxcSmwR1iVNK1Yk"}
{"genre": "k-rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0thomPcNswX7vGOyBvHxMQ"}
{"genre": "dutch hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6BXgKjKKHLt63XIEjs4WIx"}
{"genre": "trip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2wrc23l7JdQVcpPIcDGaed"}
{"genre": "la indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0C1hLm2vFuQgqMnjv31lBK"}
{"genre": "alternative dance", "spotify_playlist_url": "https://open.spotify.com/playlist/5LwcdWTCx2JoWeVVWOYsGj"}
{"genre": "v-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6TtiOm4Vf5wD8gPs1V4pQI"}
{"genre": "rap rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2xlyZ5SKttZHYxLU6o9mle"}
{"genre": "funk consciente", "spotify_playlist_url": "https://open.spotify.com/playlist/1pYXwb6K11YUZWvulG8LfM"}
{"genre": "indie anthem-folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ub3q1CU9YGXR2bkJ4wKwe"}
{"genre": "musica chihuahuense", "spotify_playlist_url": "https://open.spotify.com/playlist/3Atku5VuTdlJWziQIQYuxt"}
{"genre": "chill house", "spotify_playlist_url": "https://open.spotify.com/playlist/5JbAFiiJ3NkrymbL3pv23b"}
{"genre": "australian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6wYuYcsFOmTuWnYqEalOhk"}
{"genre": "azontobeats", "spotify_playlist_url": "https://open.spotify.com/playlist/0BFlqvOTWhikSH6YmnugCs"}
{"genre": "new americana", "spotify_playlist_url": "https://open.spotify.com/playlist/7uSlfH4blWi70SZAtqAWbe"}
{"genre": "tejano", "spotify_playlist_url": "https://open.spotify.com/playlist/6cFjgaI6dLy1cM0HTKQq8Z"}
{"genre": "korean ost", "spotify_playlist_url": "https://open.spotify.com/playlist/3IYiaXY49BlwvlBaFcFvbb"}
{"genre": "nova mpb", "spotify_playlist_url": "https://open.spotify.com/playlist/6csaLz3wHWP7Mdl3x2tmxk"}
{"genre": "dutch edm", "spotify_playlist_url": "https://open.spotify.com/playlist/0DX9WVEaDkEiax6hcVqdaL"}
{"genre": "j-division", "spotify_playlist_url": "https://open.spotify.com/playlist/1W1ZU2KC8ycl8BY7naUBlm"}
{"genre": "sertanejo tradicional", "spotify_playlist_url": "https://open.spotify.com/playlist/5yWEBJMpp4zuGt83GYOyHE"}
{"genre": "acoustic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7vgw73gZZ5gAIxK2emsSPU"}
{"genre": "aesthetic rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2OY7wFfc4FIedjHBF95f9t"}
{"genre": "pop flamenco", "spotify_playlist_url": "https://open.spotify.com/playlist/5eXtMliOlZWHMcDDRkANhL"}
{"genre": "cancion melodica", "spotify_playlist_url": "https://open.spotify.com/playlist/2dLBa2Id927DSbDX11R0h3"}
{"genre": "sigilkore", "spotify_playlist_url": "https://open.spotify.com/playlist/2EK7UnhMWzCVnrI4I0FN44"}
{"genre": "rap conciencia", "spotify_playlist_url": "https://open.spotify.com/playlist/6vfVdOzLUYpG9z9wE0Icjx"}
{"genre": "neo-psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/7qhZxfWGh9O2HWt3V7gpSA"}
{"genre": "dutch pop", "spotify_playlist_url": "https://open.spotify.com/playlist/56vsjg8uIptImNUVOyXi5d"}
{"genre": "adoracao", "spotify_playlist_url": "https://open.spotify.com/playlist/2F44c8g3v3EsAuPQvmHTIl"}
{"genre": "ska argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/0sS9Esh4m1MZjtLlGRIQmB"}
{"genre": "irish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2CBHXjkBbHfiKcKIHesfbC"}
{"genre": "classic italian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5KrDtqnhoJoY9d5RIYMXRP"}
{"genre": "indie pop rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6KO7rNq7jfMLQ5oQ8If6x9"}
{"genre": "pop r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/2BvxkVFgxGelSCrWV53I2o"}
{"genre": "groove metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5UYSZ8nVmn0iaIelrf9Oe8"}
{"genre": "power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1sy0OGu2TTXLTiZ7zMdcoB"}
{"genre": "lo-fi study", "spotify_playlist_url": "https://open.spotify.com/playlist/6KM2bexSz0CWtpMtrrA4iX"}
{"genre": "classic country pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6lOCvTH6vW5Jc7oyryNom4"}
{"genre": "danish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2d4TUfOahHzSBYo0zm8mnV"}
{"genre": "jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5EyFMotmvSfDAZ4hSdKrbx"}
{"genre": "industrial rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3YA1JuMxq4iJNRr1G4hilC"}
{"genre": "hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/7DrJ92Lc9UaVB1rKM2UGsg"}
{"genre": "axe", "spotify_playlist_url": "https://open.spotify.com/playlist/2ohTpPrJnqmuPYGlzwSPZe"}
{"genre": "phonk brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/6UaDlDppqi6m5rOhIRdeJT"}
{"genre": "pixie", "spotify_playlist_url": "https://open.spotify.com/playlist/79AOdu3ELUDHkDPJT1rXUt"}
{"genre": "bossa nova", "spotify_playlist_url": "https://open.spotify.com/playlist/62CfN1iGlw8MZDMht3P6I3"}
{"genre": "uk post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0PdixUwE2t9E4ehH6TaTyi"}
{"genre": "lo-fi indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6bLWoiHrkb8pP82YGCqCHi"}
{"genre": "cumbia sonidera", "spotify_playlist_url": "https://open.spotify.com/playlist/5vdpHqiubY4Vkr4nLUbWY1"}
{"genre": "southern soul", "spotify_playlist_url": "https://open.spotify.com/playlist/5Q3wLZoh8pyDIboX6XolLp"}
{"genre": "roots reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/0cT7S92xSEh5wjPSSifu8I"}
{"genre": "sad rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2uM2IvAqc6HZmEiRjJBF6Q"}
{"genre": "german techno", "spotify_playlist_url": "https://open.spotify.com/playlist/1x7cCTGSYF2xYu1hWiPQWk"}
{"genre": "lo-fi beats", "spotify_playlist_url": "https://open.spotify.com/playlist/5OzAgYmdiqJKWjGvX7cP4Q"}
{"genre": "sad lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/1uN3iCLmAXg6rmS86SJM7g"}
{"genre": "pop emo", "spotify_playlist_url": "https://open.spotify.com/playlist/3Gf8bbUuqd7zLFt4LrSLej"}
{"genre": "binaural", "spotify_playlist_url": "https://open.spotify.com/playlist/0bhejAZQ6fC8zVZU6wxkrh"}
{"genre": "german metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1Mcit79QvE6BdMXZ03eamN"}
{"genre": "cumbia villera", "spotify_playlist_url": "https://open.spotify.com/playlist/2ikWCh2wOfp5XtENdqaAQC"}
{"genre": "latin worship", "spotify_playlist_url": "https://open.spotify.com/playlist/6qubMJr7QEW6vCHogJU9u3"}
{"genre": "german dance", "spotify_playlist_url": "https://open.spotify.com/playlist/0ociygIFg7QypC1T9v1g7x"}
{"genre": "drill", "spotify_playlist_url": "https://open.spotify.com/playlist/4cEyA0ViSmUTFKF8i3agLU"}
{"genre": "pop edm", "spotify_playlist_url": "https://open.spotify.com/playlist/5OFsiAHgwlYHB6XLK0kJ4p"}
{"genre": "arab pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6qf2sOrwU08PIM4aMggZS5"}
{"genre": "brazilian reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/7v4hGOiOxpMW8fldbY63kd"}
{"genre": "broadway", "spotify_playlist_url": "https://open.spotify.com/playlist/1n5lZH4Z7y6R254fFzL04j"}
{"genre": "roots rock", "spotify_playlist_url": "https://open.spotify.com/playlist/70fcjVBboCf2RrKXEMMMxl"}
{"genre": "samba", "spotify_playlist_url": "https://open.spotify.com/playlist/3xh2sgnL4trGV8rlHTfjgv"}
{"genre": "tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/7HxEKL4NF7ZKakfTZiekTr"}
{"genre": "filter house", "spotify_playlist_url": "https://open.spotify.com/playlist/5oZMnQNApteFlWDTo0xrtb"}
{"genre": "video game music", "spotify_playlist_url": "https://open.spotify.com/playlist/3fMUb3gZXZ8ibcJb5zvy8r"}
{"genre": "neo-classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6Y3YErcNrY3sVJkq6y9GtT"}
{"genre": "jazz pop", "spotify_playlist_url": "https://open.spotify.com/playlist/04AQGSIBVHZn3OTzLLZjlz"}
{"genre": "show tunes", "spotify_playlist_url": "https://open.spotify.com/playlist/0Psnw0YWHuqAvVO8YhYJWF"}
{"genre": "rap canario", "spotify_playlist_url": "https://open.spotify.com/playlist/05DEKeFlMuXhfxk1CpjD7b"}
{"genre": "mollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/4cOnCdcml9OJO7LfXqWxPf"}
{"genre": "sufi", "spotify_playlist_url": "https://open.spotify.com/playlist/61rjzIILTnivihI046xLYP"}
{"genre": "swedish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3NfxAsLjZmCpQIlytSFiMB"}
{"genre": "turkish alt pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7u11wOJGQMZuMQufJB5hYG"}
{"genre": "hollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/0V1QibeEirHFpZ68S37kGy"}
{"genre": "spanish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0tcS9Y1tCt0Ffh2CdTXybt"}
{"genre": "nursery", "spotify_playlist_url": "https://open.spotify.com/playlist/0YzSTrNdO3mMpdrpJrYFYu"}
{"genre": "irish singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/67ljvMZzzG7KNJkCH7hY6z"}
{"genre": "electro latino", "spotify_playlist_url": "https://open.spotify.com/playlist/1sD9vBSHzNC8d30hT5Xg3m"}
{"genre": "shimmer pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1HxlHisjJGDQLJzg35NVIy"}
{"genre": "lullaby", "spotify_playlist_url": "https://open.spotify.com/playlist/1HF6J83A0lrauLpdJ9N4Nz"}
{"genre": "korean r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/2TJHOlrTUoLMHs9CTyxN9n"}
{"genre": "baton rouge rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0F7mtdFDNN5fqlDuxWG8TM"}
{"genre": "skate punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3RRuHMQvn4gPIfK802sqlb"}
{"genre": "grime", "spotify_playlist_url": "https://open.spotify.com/playlist/6tpwcBIh10DbSUksx3mRB5"}
{"genre": "country pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1kmPba3K0wZwyVJXktgJii"}
{"genre": "german rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4g8qRc8jVOv6bQc4ybb0rF"}
{"genre": "nigerian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/33VujNIodgRGBI4TUuB4mx"}
{"genre": "russian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3C24egLjqcCmIMgfztqI2r"}
{"genre": "noise pop", "spotify_playlist_url": "https://open.spotify.com/playlist/79vSZtZGJqNVs3KYInh42V"}
{"genre": "speed metal", "spotify_playlist_url": "https://open.spotify.com/playlist/76RB4cPFZIK8WBomKSEIlQ"}
{"genre": "canadian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/3m7nHC50zcjP8v1HRaDd8f"}
{"genre": "indonesian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5Wh14KMrdMwRzU4lU8Zc9z"}
{"genre": "rap marseille", "spotify_playlist_url": "https://open.spotify.com/playlist/5nMh3IcKI0h3bfeiwdoUrW"}
{"genre": "vallenato", "spotify_playlist_url": "https://open.spotify.com/playlist/3r3Yyzb9UUcuWpjd9Y0nfj"}
{"genre": "kentucky hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1jbjgJE4hBSSwfx5NjWc2j"}
{"genre": "ohio hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/56EJ8xSxox8qhQRuruKlo2"}
{"genre": "la pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7AqOmLV0JV4a3GpIU1qxbL"}
{"genre": "swedish trap pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6U6G6gOdXrrSIvQEsM4fsf"}
{"genre": "salsa puertorriquena", "spotify_playlist_url": "https://open.spotify.com/playlist/4bCkN6aIITHJ5ZQUjEUxB6"}
{"genre": "environmental", "spotify_playlist_url": "https://open.spotify.com/playlist/5p63jelsoTJGZy0mEzmu28"}
{"genre": "musica para ninos", "spotify_playlist_url": "https://open.spotify.com/playlist/3b0dNrX44ZCPCkNZ2LNrt9"}
{"genre": "french indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7pSUsof5crZi6c4k8Hun3q"}
{"genre": "hindi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/572Hmii6eSuDai46ZJXgIe"}
{"genre": "tollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/1pJbr3AF7AZtbMZBmyvBRn"}
{"genre": "ambient pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0yRTC25xu2jLehDX24gFmH"}
{"genre": "stutter house", "spotify_playlist_url": "https://open.spotify.com/playlist/6Jj24SmktCVUm5bKcTuerf"}
{"genre": "cloud rap francais", "spotify_playlist_url": "https://open.spotify.com/playlist/6YZRIE6bklyIzsXA5QhlA6"}
{"genre": "jazz blues", "spotify_playlist_url": "https://open.spotify.com/playlist/4ehHChcQBZTZ0kP9CkHdzc"}
{"genre": "background piano", "spotify_playlist_url": "https://open.spotify.com/playlist/66O4FigZBxS4Tz80TbZ9Zc"}
{"genre": "lagu jawa", "spotify_playlist_url": "https://open.spotify.com/playlist/0sj7X3mU67gtQXbsrjnpyP"}
{"genre": "florida drill", "spotify_playlist_url": "https://open.spotify.com/playlist/5BnmykWeS0YYxI7VH9lZjP"}
{"genre": "cuarteto", "spotify_playlist_url": "https://open.spotify.com/playlist/3yD30J9sFKpMe60dbvfrIs"}
{"genre": "dreamo", "spotify_playlist_url": "https://open.spotify.com/playlist/7j0Fio78ghmrM92FrgSSFR"}
{"genre": "turbo folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2o4kwAlkwGTYEijq94GsyS"}
{"genre": "pinoy hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4h1t1NUOA1LuIz8WW0w32H"}
{"genre": "czsk hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3d5jCAj8KI62xVo567NEGn"}
{"genre": "rap napoletano", "spotify_playlist_url": "https://open.spotify.com/playlist/0OCPvoUuknhRAe1x0HFI3C"}
{"genre": "chicago drill", "spotify_playlist_url": "https://open.spotify.com/playlist/3FeDgGoUiDRzSBXexOs3gZ"}
{"genre": "japanese singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/2XKIPP83gL3CAONT0n5ZmT"}
{"genre": "oxford indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1YvOWmrMWjSOmaXHo5RCnZ"}
{"genre": "new rave", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZlEqn2WSADG2wVMPhKHsd"}
{"genre": "french rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6uL4zN0tryTmOsrhcknaIS"}
{"genre": "swedish electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/33fyWhh6amFf9SQi1EILdm"}
{"genre": "classic j-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0dJjpfWSlJj9121L0WTUoU"}
{"genre": "polish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/40uOIq5lmbAApQTlleiVp0"}
{"genre": "drill francais", "spotify_playlist_url": "https://open.spotify.com/playlist/7ps4PEcNxt0xc1LN3rypdg"}
{"genre": "new jack swing", "spotify_playlist_url": "https://open.spotify.com/playlist/0zn8nuASKC0PISqD9mxCSV"}
{"genre": "canadian singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/2IBJxQyIykOBbtKZosjNvI"}
{"genre": "drill espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/0fsiAxyZJMMQ3TFa4b8enY"}
{"genre": "gym hardstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/3sxd4rKBG1cpSn15GcKFAG"}
{"genre": "indonesian singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/7aJrA9ExAuZLUr4OdXbwwv"}
{"genre": "dangdut", "spotify_playlist_url": "https://open.spotify.com/playlist/3xpkyLuyJI7bruUh1xtuea"}
{"genre": "swing", "spotify_playlist_url": "https://open.spotify.com/playlist/20CFvOMJgvNmysKxUH5GJV"}
{"genre": "deep house", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZRv1fFjjwpgAcosytT3bd"}
{"genre": "new french touch", "spotify_playlist_url": "https://open.spotify.com/playlist/7m1pFx600mZCOuIsOoEIZW"}
{"genre": "industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/77sv0mFP4YSZgApxcqjaOb"}
{"genre": "uk alternative pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5sD1aSVv0KWgbGHo8GYKMC"}
{"genre": "coverchill", "spotify_playlist_url": "https://open.spotify.com/playlist/2X35a4BVWpyP9BwcyRRhJD"}
{"genre": "hare krishna", "spotify_playlist_url": "https://open.spotify.com/playlist/0HlE2m9Pbvs9dnBwFhsxSE"}
{"genre": "complextro", "spotify_playlist_url": "https://open.spotify.com/playlist/3N0R1GcrhHAvCmSSMJumJT"}
{"genre": "kollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/3TlLFpN4RZW1ecTnWyWM0x"}
{"genre": "uk metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/65cw6LKvXQFFHR2iwNjZHY"}
{"genre": "baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/4vmfJ9pJfFyeo1s5Z0g9B7"}
{"genre": "el paso indie", "spotify_playlist_url": "https://open.spotify.com/playlist/47v4HO6aShu1jyLNudBinv"}
{"genre": "flamenco urbano", "spotify_playlist_url": "https://open.spotify.com/playlist/21XVVIqOYYoX4krT44mMiL"}
{"genre": "modern indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7yUfdsaiRYRGK8H2uMRkBv"}
{"genre": "country rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0vbiEQuSW4DIvyr169jPzg"}
{"genre": "early music", "spotify_playlist_url": "https://open.spotify.com/playlist/0K86fmE0c0SFgz9GpwhwLm"}
{"genre": "glitchcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0nAwOSVQ19qbswrjPdmQkq"}
{"genre": "cantopop", "spotify_playlist_url": "https://open.spotify.com/playlist/6h7Jr2zbuBSNKAzajJ7BvD"}
{"genre": "bachata dominicana", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZOErPbFr6wWQ687g0TQGB"}
{"genre": "modern folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4cF62RlGhLrHX5mEftPnKy"}
{"genre": "egyptian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7jkRZ5VDXwsJGw4AFcIiSq"}
{"genre": "mexican indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2UmyDZbUjnhE6tuhf8e9Wa"}
{"genre": "bubblegrunge", "spotify_playlist_url": "https://open.spotify.com/playlist/0JrzRKCHxv8xnuAvMk5Rnd"}
{"genre": "beatlesque", "spotify_playlist_url": "https://open.spotify.com/playlist/7DMAadYDfKZnsaZcDKFPK4"}
{"genre": "norwegian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5j9E5msjnYEL2PZLjRzfQy"}
{"genre": "meditation", "spotify_playlist_url": "https://open.spotify.com/playlist/1RJKluktWr9Dh7fXhhRkHV"}
{"genre": "symphonic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5sodadTxPhNX9LAxyd03DJ"}
{"genre": "arabesk", "spotify_playlist_url": "https://open.spotify.com/playlist/4Pgl4JWg99RspoFbmSjq6P"}
{"genre": "german drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6khrBfCWyR4y6bHTZt7Qo9"}
{"genre": "deep underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0LCQjuYkhJFBP3ZSpBmvHB"}
{"genre": "electronic trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2UZjomZ9r1O9gWyT3BLOZC"}
{"genre": "classic pakistani pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2ur6DACA2GqkuZyJVMtwsp"}
{"genre": "electric blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7EFp3Wiscy9r6DhBoOxmyT"}
{"genre": "weirdcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4ldvbvo0ioenUAurg0pzZk"}
{"genre": "late romantic era", "spotify_playlist_url": "https://open.spotify.com/playlist/7e68yBvjBB80O77iLiVt3l"}
{"genre": "chill r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/60FHIWc8xWDuaUyPMlhPFm"}
{"genre": "meme rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6Aq8qvliiLbYnxkUbse6DT"}
{"genre": "viral rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0JlicqX0XpVPjBfyriYDPP"}
{"genre": "japanese vgm", "spotify_playlist_url": "https://open.spotify.com/playlist/3qQ2SLHCdYskqH5tl0UuUf"}
{"genre": "funk ostentacao", "spotify_playlist_url": "https://open.spotify.com/playlist/47f23xvBayJUjEhAlUB7xS"}
{"genre": "trap funk", "spotify_playlist_url": "https://open.spotify.com/playlist/0rBCyHxFqc6AJ7QOvmGXJZ"}
{"genre": "arrochadeira", "spotify_playlist_url": "https://open.spotify.com/playlist/0huwyZvlFjrRcnw96wKEKj"}
{"genre": "indie r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/2xblssDewgd1AA5R7Lap6w"}
{"genre": "pop rock brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZIZY6WFbq8yAf7RCzFPrE"}
{"genre": "previa", "spotify_playlist_url": "https://open.spotify.com/playlist/0okY0eIRJ4vFIlZOwORthP"}
{"genre": "blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7qACZGMjyo64TdUdKAegjp"}
{"genre": "covertronica", "spotify_playlist_url": "https://open.spotify.com/playlist/4RhTDgamACZmaRxweHuzAn"}
{"genre": "pagode baiano", "spotify_playlist_url": "https://open.spotify.com/playlist/6huww36GD6XDSDtqJg2dip"}
{"genre": "indie rock italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/2HI25i8SnfTPr0mLiZRrP5"}
{"genre": "bhojpuri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4j5HXUC9WYP8GCptgON472"}
{"genre": "neue deutsche harte", "spotify_playlist_url": "https://open.spotify.com/playlist/6WeDF6IYytZmoiLZaSnhgp"}
{"genre": "scandipop", "spotify_playlist_url": "https://open.spotify.com/playlist/0IyFLwxEtAB5jszehTpWFJ"}
{"genre": "classic canadian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7kkQw6YiSBhHmKK1B9ePYq"}
{"genre": "meme", "spotify_playlist_url": "https://open.spotify.com/playlist/4mM1GFecLl0lDjwtM6c1YB"}
{"genre": "belgian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/3YjCK5F0D78d0WXHcwQ7tq"}
{"genre": "indonesian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/1aVMByzod7x5EWG4TiK9Fw"}
{"genre": "contemporary vocal jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3JvgYk6ZM1mwWViJpxphml"}
{"genre": "nu-cumbia", "spotify_playlist_url": "https://open.spotify.com/playlist/6dALa1NCsiiQtQrLGjFgaT"}
{"genre": "rap dominicano", "spotify_playlist_url": "https://open.spotify.com/playlist/2WfnBDeBCW7cPiFc1WkPuJ"}
{"genre": "anime score", "spotify_playlist_url": "https://open.spotify.com/playlist/2K3Gf8NozSaxXj5227J9tv"}
{"genre": "classic swedish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5sjIhYs9VdRLVRwQimhRq6"}
{"genre": "ambient lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/1lypTAoBRvdTAxlJ4c7P4w"}
{"genre": "swamp rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0c3XM6W62rmdSfWs7uzpRz"}
{"genre": "vocaloid", "spotify_playlist_url": "https://open.spotify.com/playlist/3gL0B5dJ4WPM0PmhRjqcQU"}
{"genre": "classical era", "spotify_playlist_url": "https://open.spotify.com/playlist/4HAbdPTjKgU8GUHRsaCxSU"}
{"genre": "pakistani hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0xHKr5eH5yHr55hPSbsWc0"}
{"genre": "australian psych", "spotify_playlist_url": "https://open.spotify.com/playlist/3qC7RPr0QzkFKAE1nuSAx4"}
{"genre": "australian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4Qqc4lX4i4A8uXD9SBQy7S"}
{"genre": "instrumental hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4cA3igNXbIWZ2pJYdxAdYr"}
{"genre": "c-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1xyLXFq8PsdtkBeTmWqRjQ"}
{"genre": "old school atlanta hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4wOOEE13DY5e2HvqXovmoE"}
{"genre": "indonesian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1N8MfJmmLQrd7MJBBS3Jjj"}
{"genre": "punk blues", "spotify_playlist_url": "https://open.spotify.com/playlist/0pUItxZh4LNpvkkM22kBTj"}
{"genre": "taiwan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/33blltDYieR1hn462m5JqR"}
{"genre": "power pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0BdTgPWKVq5tZmPFAVSN2J"}
{"genre": "schlager", "spotify_playlist_url": "https://open.spotify.com/playlist/5GtYXXydQZxdFlkIIvCHBW"}
{"genre": "chillhop", "spotify_playlist_url": "https://open.spotify.com/playlist/0cRVSi1eXiAYipZDgVU11c"}
{"genre": "russian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2NweJbjBo0jbtRgYOalUDO"}
{"genre": "nz pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6rZGKd5ndSUnGeJKuBhUej"}
{"genre": "gujarati pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6jYu6GE12efMHTPiMLU9ay"}
{"genre": "memphis soul", "spotify_playlist_url": "https://open.spotify.com/playlist/01NiS0JyBqiBNNSZIUP1Xt"}
{"genre": "musica popular colombiana", "spotify_playlist_url": "https://open.spotify.com/playlist/0Srh9dNBtSw4FRAHozAUqj"}
{"genre": "mambo chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/1a09PfpMhc1BoCtasZBoin"}
{"genre": "christian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0l4beRwx17QIjP7kTciYUk"}
{"genre": "classic indonesian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3EOChBm9EbFpOFs8hIVDcv"}
{"genre": "early romantic era", "spotify_playlist_url": "https://open.spotify.com/playlist/3Vt17G94M85heL0MgOePc6"}
{"genre": "edmonton indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0EmrOr9gdxrcM2y3khh72k"}
{"genre": "sacramento indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2aSAYJHZZvCgwVcdx7Z9Tc"}
{"genre": "jam band", "spotify_playlist_url": "https://open.spotify.com/playlist/1z1LfuAoQQDRKLOyVQvaRa"}
{"genre": "drum and bass", "spotify_playlist_url": "https://open.spotify.com/playlist/18b0DBiqVtRuj34OKPCgj6"}
{"genre": "melbourne bounce international", "spotify_playlist_url": "https://open.spotify.com/playlist/3hVFk3uqdqUey1yX2fzSXr"}
{"genre": "dutch rap pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3NxTF39nYRfSUx8Tc10nvA"}
{"genre": "dangdut koplo", "spotify_playlist_url": "https://open.spotify.com/playlist/073kz2Cl4k0SdcWzbpNQkn"}
{"genre": "turkish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/23w9QtY1mUO3j1sij0NORp"}
{"genre": "golden age hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4nV9ZoMXZcVsDukR994fMf"}
{"genre": "javanese dangdut", "spotify_playlist_url": "https://open.spotify.com/playlist/5mPtOfcLPTEwUVf8hgH0W7"}
{"genre": "post-punk argentina", "spotify_playlist_url": "https://open.spotify.com/playlist/2Hleh47rixMBxvNnqmx3hT"}
{"genre": "alternative emo", "spotify_playlist_url": "https://open.spotify.com/playlist/4RZ8ejso7uNp2Yz9DMqpVx"}
{"genre": "greek trap", "spotify_playlist_url": "https://open.spotify.com/playlist/38cq1JOTwmZbNcv3SwXuoa"}
{"genre": "post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/20cUBDEbmqhNmklStbkQvL"}
{"genre": "hamburg hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1TbWLNDzbjd4YlKXU2KaKL"}
{"genre": "soul blues", "spotify_playlist_url": "https://open.spotify.com/playlist/2KMDVWnnYTOUjqt8hH2xXC"}
{"genre": "pop rap brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/0Ud1B5OYxleiuspbBXZI2t"}
{"genre": "venezuelan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/48ZAg8gvBviwTPsXN4aIfG"}
{"genre": "j-pixie", "spotify_playlist_url": "https://open.spotify.com/playlist/5SWKs0Pa7zEtc1jVKmmFDs"}
{"genre": "cantautora mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/20K7P3XPAqGdC0P42EAY1j"}
{"genre": "deep euro house", "spotify_playlist_url": "https://open.spotify.com/playlist/36ElXYG8xeWVQFuZr0Puvy"}
{"genre": "pop lgbtq+ brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/5LbuqcNO4ieuVBhPGEhpem"}
{"genre": "bass house", "spotify_playlist_url": "https://open.spotify.com/playlist/5ITCoz5fDeGlbKyNmwKXoG"}
{"genre": "nouvelle chanson francaise", "spotify_playlist_url": "https://open.spotify.com/playlist/3oZK1D458xeFA0EVuAoesb"}
{"genre": "crunk", "spotify_playlist_url": "https://open.spotify.com/playlist/2bfQBLvjoloMK1VoWFDimL"}
{"genre": "electro", "spotify_playlist_url": "https://open.spotify.com/playlist/4oBAlPMMM8HqTd9ee6GiRr"}
{"genre": "operatic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2hfzjrxv05ynWI0LLxqpjq"}
{"genre": "spanish indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6s8I7kVZ8phbFuXcFJmaQV"}
{"genre": "celtic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/35Lg9T9VJjvAQRdetQGtKS"}
{"genre": "vietnamese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5wT8Nw3HVG9EBgnaZtos80"}
{"genre": "p-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6c56wSEQMu06HsOS78QODI"}
{"genre": "indie hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2AIGUJ4j4Bd5q8tUfurZnD"}
{"genre": "stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6rhKHVL7MpASDhCtuY3ISy"}
{"genre": "pop house", "spotify_playlist_url": "https://open.spotify.com/playlist/04ugFARyXFS9iQaiHjes6i"}
{"genre": "bubblegum pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6GLXp5kwSs0HRDnh6fqKKZ"}
{"genre": "argentine indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5Phw9uzB08eYDwX5gFRFVy"}
{"genre": "modern bhajan", "spotify_playlist_url": "https://open.spotify.com/playlist/1ALZFv5PavqL5oUjtXk8ld"}
{"genre": "new york drill", "spotify_playlist_url": "https://open.spotify.com/playlist/4I1H54YGRvkSKfII2XhSlB"}
{"genre": "red dirt", "spotify_playlist_url": "https://open.spotify.com/playlist/208eKWeHXifDir7qV5DQYB"}
{"genre": "irish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0aMVUw2FEVxBCFUZVxTt5u"}
{"genre": "danish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ye9vt7btK1lJgJ7zw6xRJ"}
{"genre": "progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/74RFwHMUEVXkqK2KeeIMPl"}
{"genre": "canadian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5gZ3OHKBftwK36rncggUxx"}
{"genre": "malaysian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/21vmnDNKEQfYgZvtOBEpf2"}
{"genre": "countrygaze", "spotify_playlist_url": "https://open.spotify.com/playlist/1xXSk37syopROCZAloc1Vc"}
{"genre": "indie garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7lCazMg1AalQrclLnSpn7v"}
{"genre": "etherpop", "spotify_playlist_url": "https://open.spotify.com/playlist/3eoGAwNztSSx7Pi6dC6GFn"}
{"genre": "ska", "spotify_playlist_url": "https://open.spotify.com/playlist/2aKMOs9FxzuCX6kdylLX94"}
{"genre": "bebop", "spotify_playlist_url": "https://open.spotify.com/playlist/55s8gstHcaCyfU47mQgLrB"}
{"genre": "funk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2R2YtEbMWrq5u7Pu3TLKRa"}
{"genre": "chilean rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5ALQKwz3D9lznT20eEIUTk"}
{"genre": "chinese viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/04mJ4eJ9jtVx0Ucuyuk1Tx"}
{"genre": "turkce drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6MEN9TKQR1RQXEAgtPAmav"}
{"genre": "australian electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/6TEh7sGZj65kb1wKoZMkSU"}
{"genre": "musica de fondo", "spotify_playlist_url": "https://open.spotify.com/playlist/33pnAlQ3n096s4W1XMnrNf"}
{"genre": "philly indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5bywGHY4NQKcTmGXAVsf3N"}
{"genre": "hip house", "spotify_playlist_url": "https://open.spotify.com/playlist/0CaVoV0ZC3aUxNSb8SoZVf"}
{"genre": "post-romantic era", "spotify_playlist_url": "https://open.spotify.com/playlist/1tkjrVDJx0MwmNsoV5lgPr"}
{"genre": "swedish gangsta rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6HO4BNXiFyRCFlgbnyPQkD"}
{"genre": "dancefloor dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/0R4q3eZSSoSCLq7jNYeF5t"}
{"genre": "comic", "spotify_playlist_url": "https://open.spotify.com/playlist/5yGDZPBsmXKUf3e22QHIh4"}
{"genre": "scenecore", "spotify_playlist_url": "https://open.spotify.com/playlist/7BDHGoqpPFu6tBfHnztPUn"}
{"genre": "piano cover", "spotify_playlist_url": "https://open.spotify.com/playlist/6yGAwVDOmgKVKM4XDLNoVR"}
{"genre": "rumba", "spotify_playlist_url": "https://open.spotify.com/playlist/3BfEgQqVomK4wv9cYD2k6o"}
{"genre": "electra", "spotify_playlist_url": "https://open.spotify.com/playlist/4vnhpAi5S0LSNQfzWSpkZs"}
{"genre": "korean pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6tc3J6NhFZJkw0n7ix0w5l"}
{"genre": "reggae rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0CktkOo3GxodXvz4fXJ5Ld"}
{"genre": "dance-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6c6EDGbcWdOSUvTaaUENyg"}
{"genre": "chill pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6NqeUZV00Bj7iKBNniWBpE"}
{"genre": "german alternative rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3jzFKphMRkD5TLxOXlucXT"}
{"genre": "canadian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4mw6VuwMrkxqVkkjrmkGAF"}
{"genre": "preschool children's music", "spotify_playlist_url": "https://open.spotify.com/playlist/6NGDDMCqCjNn7HOfnVWscz"}
{"genre": "moombahton", "spotify_playlist_url": "https://open.spotify.com/playlist/7iszolrnuUqc01LQaBqqII"}
{"genre": "tagalog rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4Hx6fdHGxv9nOZgZShbekL"}
{"genre": "background music", "spotify_playlist_url": "https://open.spotify.com/playlist/2JsqQdMbBC2hh7GjsEjKFg"}
{"genre": "funk bh", "spotify_playlist_url": "https://open.spotify.com/playlist/7EkuObU6WHy1QEBwyGZgYm"}
{"genre": "torch song", "spotify_playlist_url": "https://open.spotify.com/playlist/7MaOqNrbYKlp4LD81URIsG"}
{"genre": "indie surf", "spotify_playlist_url": "https://open.spotify.com/playlist/6nLRnyAmEOi7OeEddElTgo"}
{"genre": "italian underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6CtSs2O8jBtCyfW5Bjg8CB"}
{"genre": "pop romantico", "spotify_playlist_url": "https://open.spotify.com/playlist/5aT36SOb1mkA0tDDjXKlS0"}
{"genre": "dutch rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6GVUfirEB9jLZzk1lA7XZT"}
{"genre": "rome indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1zkGa0efUtOsXNKdbm1YhS"}
{"genre": "uk drill", "spotify_playlist_url": "https://open.spotify.com/playlist/685ydTa5UXcEU5NZbLJCy7"}
{"genre": "protopunk", "spotify_playlist_url": "https://open.spotify.com/playlist/252DtQnn5XzYtKs93VjCKE"}
{"genre": "shush", "spotify_playlist_url": "https://open.spotify.com/playlist/68BYCIfkX1MmxvPwz8JtvI"}
{"genre": "smooth jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4GMYsnPRt6GT3VARNJQeKt"}
{"genre": "j-poprock", "spotify_playlist_url": "https://open.spotify.com/playlist/0Grl1cS6EIySP2ORk0ygYr"}
{"genre": "old school hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6MjdCkcY5tUfadaakBRINy"}
{"genre": "ectofolk", "spotify_playlist_url": "https://open.spotify.com/playlist/3CeSXPzTodHH71ksqdXmS7"}
{"genre": "small room", "spotify_playlist_url": "https://open.spotify.com/playlist/2rPwi4IFhoc2r1MMvY0ZI5"}
{"genre": "turkish singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/4tenLyP9rbOA9oI4ZA2hwB"}
{"genre": "indonesian r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/1wwNDR9UGIIpkPkbVgWS1G"}
{"genre": "kentucky roots", "spotify_playlist_url": "https://open.spotify.com/playlist/5K1iPKk49VzQ7QFocqwgYx"}
{"genre": "turkish alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6jBRajLOpvvOZYDDAnfaPg"}
{"genre": "bedroom soul", "spotify_playlist_url": "https://open.spotify.com/playlist/5YhnF0wwxsNlZzyFbMpOzG"}
{"genre": "cartoon", "spotify_playlist_url": "https://open.spotify.com/playlist/47E4xm9bQeseKh6tSasQqG"}
{"genre": "modern salsa", "spotify_playlist_url": "https://open.spotify.com/playlist/01jM8RPDlNtIvBkOsRbdMR"}
{"genre": "writing", "spotify_playlist_url": "https://open.spotify.com/playlist/6AMYqzWEHpzHQspdGpBH5s"}
{"genre": "background jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ifye2q49cs6RDXTbQxJcq"}
{"genre": "lo-fi jazzhop", "spotify_playlist_url": "https://open.spotify.com/playlist/4Z6Tnnja5F2bkd8JhX6OC5"}
{"genre": "musica infantil", "spotify_playlist_url": "https://open.spotify.com/playlist/7m6BNUydeoHC8wFPKlxy5i"}
{"genre": "romanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/68oBTMg4kV2C1UXDAxOmeH"}
{"genre": "gauze pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6gaLUOiIgrnSFt2qmmUIMr"}
{"genre": "chillwave", "spotify_playlist_url": "https://open.spotify.com/playlist/5pDD5tz9aQULzowpuKMSep"}
{"genre": "deep ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/327irrZplP8A15mvzhraRl"}
{"genre": "norteno-sax", "spotify_playlist_url": "https://open.spotify.com/playlist/4Wi7kR0LDvvxbxosl10Hke"}
{"genre": "alternative pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5wXsLEgQ3EEJuNNCptHKeR"}
{"genre": "finnish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3rjPCrrCjMZwWDlAIRu44q"}
{"genre": "trova", "spotify_playlist_url": "https://open.spotify.com/playlist/6AsYWsnau4HpWHzxyNoA1a"}
{"genre": "desi trap", "spotify_playlist_url": "https://open.spotify.com/playlist/29HEXDlpRRd4bTTf6LoYeJ"}
{"genre": "dembow", "spotify_playlist_url": "https://open.spotify.com/playlist/6r9pKD3yNDbAm1iA0FhDM6"}
{"genre": "cumbia", "spotify_playlist_url": "https://open.spotify.com/playlist/0bWU5c6DF4sKYDGX2CX2Cr"}
{"genre": "speedrun", "spotify_playlist_url": "https://open.spotify.com/playlist/5T9buJg2Oo1S1Surr2cJrx"}
{"genre": "world", "spotify_playlist_url": "https://open.spotify.com/playlist/6woVbmGys7FH3bmiLcwKZm"}
{"genre": "norwegian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1W5VvMDlZm8pViaMFAcctc"}
{"genre": "perreo", "spotify_playlist_url": "https://open.spotify.com/playlist/3kKTNWq50Aysbs5ammCarH"}
{"genre": "reggaeton chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/7bavRpySiSuZLFPkglPRK5"}
{"genre": "aussietronica", "spotify_playlist_url": "https://open.spotify.com/playlist/6v4XJKL42tbcrzbN5bVyH9"}
{"genre": "classic schlager", "spotify_playlist_url": "https://open.spotify.com/playlist/4bMTSiI4AC7Mp0TCOMis7A"}
{"genre": "melbourne bounce", "spotify_playlist_url": "https://open.spotify.com/playlist/5juwTItf3H3eQuzrGiKwf9"}
{"genre": "rock cristiano", "spotify_playlist_url": "https://open.spotify.com/playlist/6xLA8mHVCxyHRW9Mxfn8Dy"}
{"genre": "finnish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1YGvJM20VrskrnSGuT0V2W"}
{"genre": "french indietronica", "spotify_playlist_url": "https://open.spotify.com/playlist/2himelMaFON7yDwQf9P8Kq"}
{"genre": "experimental pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0MS8uaf4VjVPDb5e8LJVpm"}
{"genre": "belgian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6BxDibVSpcABeoBBo1vToA"}
{"genre": "classic opm", "spotify_playlist_url": "https://open.spotify.com/playlist/3B084Cju5o7fea2KaVn3mS"}
{"genre": "jazz funk", "spotify_playlist_url": "https://open.spotify.com/playlist/3djem4UfHRQUBeOMxtpY3p"}
{"genre": "tecnobanda", "spotify_playlist_url": "https://open.spotify.com/playlist/5yBIfrNoe8gDDRkddgTm4d"}
{"genre": "japanese soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/1SDsQL5zFGmnZy4w7mk1ub"}
{"genre": "modern dream pop", "spotify_playlist_url": "https://open.spotify.com/playlist/202xgnWdtz9EQx5fvI400m"}
{"genre": "pinoy r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/4TUWhdsP6yM5qB4ogDgXpJ"}
{"genre": "czech hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2wslUCRwjUEjPkwUw1BTBQ"}
{"genre": "indie triste", "spotify_playlist_url": "https://open.spotify.com/playlist/1euhr12icBWvWTkNcQIvnY"}
{"genre": "south carolina hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/06wMSt5MVYSyl5RHaYZF0J"}
{"genre": "trap mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/0EMv4RJ77F0dSlGlhFRVbh"}
{"genre": "albanian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3ihgsFVkN3qG7KnEXoJMHf"}
{"genre": "boom bap espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/6fqRJtaRT3sx0FZrrzGLST"}
{"genre": "chutney", "spotify_playlist_url": "https://open.spotify.com/playlist/2PJuWfVaCmG9Bu3OlHFzfy"}
{"genre": "laiko", "spotify_playlist_url": "https://open.spotify.com/playlist/5NmSX3apChYsQj54LLufIV"}
{"genre": "sunshine pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4WGe8j09ND0yhNGN2LRuD7"}
{"genre": "birmingham metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1zBisMFE9VWtdXHzBxWD2d"}
{"genre": "german soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/0JC0SvamjkERHSSVifLM5N"}
{"genre": "disco house", "spotify_playlist_url": "https://open.spotify.com/playlist/7tW3eTmzzYNNyEmi9qHdQC"}
{"genre": "fvnky rimex", "spotify_playlist_url": "https://open.spotify.com/playlist/0Re6qLjokHfCHLgTmL9DeF"}
{"genre": "acid rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3H6YJ47QOQiC74hZNVUU2f"}
{"genre": "instrumental worship", "spotify_playlist_url": "https://open.spotify.com/playlist/4SR5G11OQyBa5WCPm24J1N"}
{"genre": "japanese alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4tpLmmkAvbRGzP3wMpYCdX"}
{"genre": "scottish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2CmS2oNTxIvQUSLeJfBIvP"}
{"genre": "corridos alternativos", "spotify_playlist_url": "https://open.spotify.com/playlist/7tt8E0lrPF9IoZ1gxM9Bn1"}
{"genre": "nashville sound", "spotify_playlist_url": "https://open.spotify.com/playlist/4ogqKBfmZLAiIUkpc8FPTz"}
{"genre": "modern alternative pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5yagbqWY6gDlqB893zjOmO"}
{"genre": "rap df", "spotify_playlist_url": "https://open.spotify.com/playlist/1OshzQCcmOiCmQM85RHAbV"}
{"genre": "velha guarda", "spotify_playlist_url": "https://open.spotify.com/playlist/6xQfoAD6GdXI4CWJWzTgdi"}
{"genre": "rap politico", "spotify_playlist_url": "https://open.spotify.com/playlist/22tWyViRQaeYzqY7m346k4"}
{"genre": "post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4350ojbUlkGhZ4bYKREy3A"}
{"genre": "cumbia 420", "spotify_playlist_url": "https://open.spotify.com/playlist/2YdbsDOPHs7jAo90MmfFjI"}
{"genre": "british singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/6lEM8mYvo3M5ntO3FAiIvt"}
{"genre": "bossa nova cover", "spotify_playlist_url": "https://open.spotify.com/playlist/6tAUaFl5FAzSh87nk6fbKW"}
{"genre": "social media pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0lXSqruCjvX1e7hw2KGvKw"}
{"genre": "brazilian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/5VJcwlSzgFtpClXb8xtXs6"}
{"genre": "scorecore", "spotify_playlist_url": "https://open.spotify.com/playlist/1v75VUwKR28oOd6Lf3C6JD"}
{"genre": "redneck", "spotify_playlist_url": "https://open.spotify.com/playlist/2KWsDttfIMjLq1rpyxTQX8"}
{"genre": "german baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/03zLen1gxr088za4E2yfG6"}
{"genre": "detroit trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1VSBIae39ufpI4NF4htItX"}
{"genre": "texas country", "spotify_playlist_url": "https://open.spotify.com/playlist/2R6Ej1e4rvxe1Dz1ySNzhi"}
{"genre": "greek pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0sqLM1ijAdKHSh2iHNv5He"}
{"genre": "british soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/7jcM11GE25u4XbhzuU7wYv"}
{"genre": "swedish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2VLJNrld3b2lqbb0N4mDZs"}
{"genre": "israeli pop", "spotify_playlist_url": "https://open.spotify.com/playlist/53x6LAhXxhWxhV2TAPgw4u"}
{"genre": "slowcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1YD7lXqICOb2LCQH5Q03RM"}
{"genre": "gaming edm", "spotify_playlist_url": "https://open.spotify.com/playlist/5kredHbbKjb6EUN5exsaQh"}
{"genre": "houston rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0pyHVjbjiyuutRjtP3hvNY"}
{"genre": "german romanticism", "spotify_playlist_url": "https://open.spotify.com/playlist/1JLrWsFDWyPiG9NIIn2zjO"}
{"genre": "nu jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/26PD3pjcSfPuKUDV1jgfX8"}
{"genre": "panamanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0nAbpWAj2ULBbTbdE463GO"}
{"genre": "new jersey rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4zRssuqXi9x60JgHq5oypS"}
{"genre": "epicore", "spotify_playlist_url": "https://open.spotify.com/playlist/6L5DYqEAWfLMEb6szUJpe4"}
{"genre": "r&b brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/6oJ7aTA1gwk4WaPTB4l5oo"}
{"genre": "slowed and reverb", "spotify_playlist_url": "https://open.spotify.com/playlist/44NzAKSh19KifXgIbe5FvL"}
{"genre": "czech pop", "spotify_playlist_url": "https://open.spotify.com/playlist/05657jnifBqpCQQLDpujE4"}
{"genre": "death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4ykSr52Ff3ysihmAO0z1Dw"}
{"genre": "arkansas country", "spotify_playlist_url": "https://open.spotify.com/playlist/58UKNHdZKjKa9q3gPPwSsC"}
{"genre": "chicano rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2Tc7Rt8asvPRsbBhe7vKDr"}
{"genre": "high vibe", "spotify_playlist_url": "https://open.spotify.com/playlist/6GTqoouUghFknnAozSCGnj"}
{"genre": "swedish trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2ID0zU2K42h2pRR6yZqmDB"}
{"genre": "political hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1JG2BtWHQA3XMqun2bsB2k"}
{"genre": "j-rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7x1NTWOVz2GiQ4lrGbpH4e"}
{"genre": "uk funky", "spotify_playlist_url": "https://open.spotify.com/playlist/4lK54lu5nxD3iMlCXMIQwx"}
{"genre": "albanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6YCBZeDU7lFUw0WomT7uCj"}
{"genre": "mexican rock-and-roll", "spotify_playlist_url": "https://open.spotify.com/playlist/1GSjqBHH85Hv1aoHd0qfRG"}
{"genre": "black americana", "spotify_playlist_url": "https://open.spotify.com/playlist/7aC9044BJHzFWWAX18Bo95"}
{"genre": "ghazal", "spotify_playlist_url": "https://open.spotify.com/playlist/47ZfWnbCNyu7r1qiYSdPq6"}
{"genre": "modern southern rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2lZsuDl0JRkpDmZO9Poor1"}
{"genre": "indian singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/7EmimsoK6aeXpavDhI5SgO"}
{"genre": "japanese emo", "spotify_playlist_url": "https://open.spotify.com/playlist/1XtPFaH9uCg92IUh349zfu"}
{"genre": "indian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6sW7pp87N2Ms8TlarV8l6T"}
{"genre": "indonesian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0nZzCtNFQXFphtO7c06SnG"}
{"genre": "deboxe", "spotify_playlist_url": "https://open.spotify.com/playlist/78TLUFd48rbQUWBKzHesDS"}
{"genre": "french synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/767e9eYAfk4bApi2vMIK32"}
{"genre": "russian dance", "spotify_playlist_url": "https://open.spotify.com/playlist/0UOoeghqStZk0brm8Ozz5L"}
{"genre": "gothic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5If0ljSv0MPkrJJr9t75mY"}
{"genre": "lo-fi cover", "spotify_playlist_url": "https://open.spotify.com/playlist/1GNpGs1XlJhH1ByOFhYfcN"}
{"genre": "post-disco", "spotify_playlist_url": "https://open.spotify.com/playlist/5iKvDdecBJSQ5Qg46MN135"}
{"genre": "greek hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0NcAnGFICl7Oj202HLzPpf"}
{"genre": "rap genovese", "spotify_playlist_url": "https://open.spotify.com/playlist/2BOlbck6FW1kya9hMP1HFP"}
{"genre": "trap chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/187WTgmHaJtn3BZy5jphdb"}
{"genre": "reggaeton mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/1khWImyWMu0aMBZezW0pey"}
{"genre": "cumbia chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/4DxBnbmJesJ6kIOrB7My9b"}
{"genre": "italian indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0Mu1FW9n1ca5nGoYi54x9i"}
{"genre": "kentucky indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0gGvbAcQBdLWdEiayXBg7R"}
{"genre": "nyc pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4CfyHGpt8qPlLXlstcE2Wh"}
{"genre": "uk alternative hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1KJB07h1cyZlw6I6sHAide"}
{"genre": "bronx drill", "spotify_playlist_url": "https://open.spotify.com/playlist/4b6QNIix3G6y2Ylsj2gC73"}
{"genre": "italo dance", "spotify_playlist_url": "https://open.spotify.com/playlist/3IExr8qtJzsRF1vICyPux3"}
{"genre": "salsa colombiana", "spotify_playlist_url": "https://open.spotify.com/playlist/2QVsIulY60RZs8u18nPccL"}
{"genre": "euphoric hardstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/7kUeKVMrA3eMZNP4p8HKVi"}
{"genre": "christian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3l8CtYFuLlRkrh6zCBODwp"}
{"genre": "canadian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5OcvKHhsBhDH7rSq7ZrhUK"}
{"genre": "polish viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5b0iTcDchorEjIxvQHZqvY"}
{"genre": "musica sonorense", "spotify_playlist_url": "https://open.spotify.com/playlist/0c2IQc7M4bF374vgumpl6t"}
{"genre": "brill building pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1afcjkK4GbaOpct5MpecCQ"}
{"genre": "modern blues", "spotify_playlist_url": "https://open.spotify.com/playlist/73Jxzf17MpBz7xI7iker8R"}
{"genre": "rawstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/1EICh4qNolTgW5VnUDpXg7"}
{"genre": "afroswing", "spotify_playlist_url": "https://open.spotify.com/playlist/5cxxxlEnpCUjwB3YdHMYEd"}
{"genre": "oakland hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4Uewmd4GsCYQXttOgHS0Bi"}
{"genre": "hard rock brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/67CFxN2tAcaedpUbwrQu7f"}
{"genre": "grupero romantico", "spotify_playlist_url": "https://open.spotify.com/playlist/3Zg3EpfSWqezkcQdxse8sk"}
{"genre": "phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/3qxSuTNp8RQ3QAnsQkMan4"}
{"genre": "modern power pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0h0nzdXjZTmo4k32f24pVt"}
{"genre": "rap calme", "spotify_playlist_url": "https://open.spotify.com/playlist/6fCJ2iyUhivh8ghIqBQ9Nr"}
{"genre": "rock urbano mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/0qvqjbdnqFkCeR3F361ppB"}
{"genre": "british blues", "spotify_playlist_url": "https://open.spotify.com/playlist/5gYoPWpfoYkFxdS7a15WBO"}
{"genre": "hardcore punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4H6GLDvB0kzoCyavxb1Z4B"}
{"genre": "anime lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/73KqelVOge5J7pIo7b87SV"}
{"genre": "hungarian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1wwnwY4WnbBfQ77U3r4ccj"}
{"genre": "russian alt pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3NPyEuRqag5aATW5ckpX0J"}
{"genre": "rap belge", "spotify_playlist_url": "https://open.spotify.com/playlist/7J5CvtYwIKDFhE2wlBkPUu"}
{"genre": "chicago indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0DsF1mb3M7yhJM6MUXR6fL"}
{"genre": "lo-fi sleep", "spotify_playlist_url": "https://open.spotify.com/playlist/2A63BXH1J4xWU5mMSMhZAO"}
{"genre": "german cloud rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1rL1br6e5ksgcTIkgRLEiF"}
{"genre": "cumbia peruana", "spotify_playlist_url": "https://open.spotify.com/playlist/10h6jCdDn1SWi4cL7zRMnT"}
{"genre": "indie game soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/74xxbuuHJujl204kaRgsLk"}
{"genre": "spanish new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/1pujdlFcV8pY03jkhbkmvN"}
{"genre": "stomp and flutter", "spotify_playlist_url": "https://open.spotify.com/playlist/2fdUlsRORMQ1sM1SEPjDlE"}
{"genre": "bossbeat", "spotify_playlist_url": "https://open.spotify.com/playlist/4fLlQp5Kscoo3483KIB0zB"}
{"genre": "minimal techno", "spotify_playlist_url": "https://open.spotify.com/playlist/68uxlFAvnITCyQs0U8qr6n"}
{"genre": "alternative country", "spotify_playlist_url": "https://open.spotify.com/playlist/5BmMjQp8OwPGdg7OOINCHm"}
{"genre": "gothic symphonic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/61BVo2kYujeavfw38gf5rm"}
{"genre": "banda jalisciense", "spotify_playlist_url": "https://open.spotify.com/playlist/6Q0lnbcxTFNpDJSNGkRHbL"}
{"genre": "minnesota hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZPBThiaZ0jSMPerPHpMwd"}
{"genre": "latin talent show", "spotify_playlist_url": "https://open.spotify.com/playlist/1L1Hmf2PkeZbiiQbgD93hC"}
{"genre": "frauenrap", "spotify_playlist_url": "https://open.spotify.com/playlist/4OnbZkownuQYWGsJ3pvWxf"}
{"genre": "early modern classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4PVpbcs9oa63FhDWREEJMt"}
{"genre": "asmr", "spotify_playlist_url": "https://open.spotify.com/playlist/5fuOMOhKpRjdcuquIHWW15"}
{"genre": "acoustic cover", "spotify_playlist_url": "https://open.spotify.com/playlist/4RwmETtdwq1lIekmQ0auFL"}
{"genre": "afrofuturismo brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/7GcKmMlvh7g2yx3AgRwZLA"}
{"genre": "zolo", "spotify_playlist_url": "https://open.spotify.com/playlist/1HDK9LHAXjMQEbEhh9Lbfa"}
{"genre": "nu disco", "spotify_playlist_url": "https://open.spotify.com/playlist/0SSA0QK7yBpyZngyAYsp6w"}
{"genre": "indonesian pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/63XcNlx6B8Ilew6hsGPr82"}
{"genre": "afro r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/5Cu4Lk5ihrwbaack2h4bIT"}
{"genre": "hi-nrg", "spotify_playlist_url": "https://open.spotify.com/playlist/3Bf2Oreyh9819D3Mgf3tnK"}
{"genre": "lo-fi chill", "spotify_playlist_url": "https://open.spotify.com/playlist/12bxvDyycP9jNYaYKK57DO"}
{"genre": "anadolu rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1VT5zGqqy4CSw6zArZoZgF"}
{"genre": "duranguense", "spotify_playlist_url": "https://open.spotify.com/playlist/4WRxxd7MJ2doyQgJ7QHjKa"}
{"genre": "dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZYFF9tPuPq2YNMRNhQZJt"}
{"genre": "trancecore", "spotify_playlist_url": "https://open.spotify.com/playlist/3GL4HNVOg9IqD5jxVpSRp7"}
{"genre": "dutch trance", "spotify_playlist_url": "https://open.spotify.com/playlist/2BPocNoK7QF8mRuTdRd2Ph"}
{"genre": "christian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/19MzV9T4UTnjZdQEWL3xFe"}
{"genre": "jazz rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7nhthR622V6o8iiPhvPgXK"}
{"genre": "persian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/37jBmq9ayLUSajI8ogTdGa"}
{"genre": "rock gospel brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/0oa0FjnSdQjWzBIhl4GEqy"}
{"genre": "pop electronico", "spotify_playlist_url": "https://open.spotify.com/playlist/5Kp6a88KudsUrg1FosSUdr"}
{"genre": "finnish dance pop", "spotify_playlist_url": "https://open.spotify.com/playlist/18sKpIGOaFlR5256AqCh2E"}
{"genre": "supergroup", "spotify_playlist_url": "https://open.spotify.com/playlist/1s2jrVIrwTByHfgArNRd4F"}
{"genre": "deep groove house", "spotify_playlist_url": "https://open.spotify.com/playlist/7FAkb5HaFNBqFFVVGFvMTE"}
{"genre": "classic hardstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/6JyqZHLr7ACv0AVqpYrXfj"}
{"genre": "modern hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2derYIaJKEEwMLCcEOYEcI"}
{"genre": "ocean", "spotify_playlist_url": "https://open.spotify.com/playlist/6wjgSakJqeH5n4Mc72Oc5P"}
{"genre": "haryanvi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6k5RyzytYMPoNFFZX6hSsL"}
{"genre": "belgian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/08m9824rPzzzSV8kUNqaJ7"}
{"genre": "contemporary post-bop", "spotify_playlist_url": "https://open.spotify.com/playlist/7MrgQuUqYHmEOQSYBWPSii"}
{"genre": "vietnamese melodic rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5r7iScQieYhKk1vit2T1SC"}
{"genre": "hip hop tuga", "spotify_playlist_url": "https://open.spotify.com/playlist/0x84YFPn4ct9Wvaix9icxJ"}
{"genre": "gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/6MCouSvvoujYQJyV5ifPox"}
{"genre": "shiver pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1FcWxTM72potsWHiPQKmZC"}
{"genre": "jazz trumpet", "spotify_playlist_url": "https://open.spotify.com/playlist/1KauhpfXtTbEgYVi4d5rsD"}
{"genre": "american metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2omkyD8BvE3JD7yxK2PEv0"}
{"genre": "canadian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/0x6JnrpfyrnhzXzMZXSGe7"}
{"genre": "water", "spotify_playlist_url": "https://open.spotify.com/playlist/51WjrD4DXN7XvmPciUip71"}
{"genre": "barnmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/7LkQdN3mSOphnFoJpsKeUJ"}
{"genre": "northern soul", "spotify_playlist_url": "https://open.spotify.com/playlist/5aqkOAOy9lUITs0XUJfJJa"}
{"genre": "argentine telepop", "spotify_playlist_url": "https://open.spotify.com/playlist/1CoY8DjYLjdcrwLVlL9Vri"}
{"genre": "deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3AnaNnUtgFvsTdx1OGr80h"}
{"genre": "pakistani pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6LCUot3Rae69MN9sZzBr3s"}
{"genre": "visual kei", "spotify_playlist_url": "https://open.spotify.com/playlist/2zxjp4qMAoiRr8xY1Uq1SW"}
{"genre": "stoner metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6C7kz6eR1Sf12ZBrzl7aD8"}
{"genre": "ukrainian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6S0frS33YQdbRp0JH93cut"}
{"genre": "doo-wop", "spotify_playlist_url": "https://open.spotify.com/playlist/1IhmjinFqRJffCiNI1NBPt"}
{"genre": "colombian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2X85h61mR38FQRhtCTrpkT"}
{"genre": "traprun", "spotify_playlist_url": "https://open.spotify.com/playlist/0cD79tL7mj2p4xTSrk1se3"}
{"genre": "melodic dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/0lLw4zuyAnF3H6LoeSngXb"}
{"genre": "seattle hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2JPri9wt0WCXMikD73KDpD"}
{"genre": "detroit rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3MuC7Uw1uy5rBppdjDF4OX"}
{"genre": "hindi indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4Mx67aqgClMsDfdtN0mmVC"}
{"genre": "ambient worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5W6bxdaey4mnoC1QVxg61t"}
{"genre": "piseiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3r6u8ciy6JcrdCDXMwtC0v"}
{"genre": "ska mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/7qshObBpTeNY6nyMtcXXCw"}
{"genre": "big beat", "spotify_playlist_url": "https://open.spotify.com/playlist/370tEYE4lZui1vrufdq7xy"}
{"genre": "canadian country", "spotify_playlist_url": "https://open.spotify.com/playlist/72nKBOJxfLUr3iuUUMn2nV"}
{"genre": "pinoy trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1FnSCQFzl8gXc0YGo3d1gf"}
{"genre": "vapor soul", "spotify_playlist_url": "https://open.spotify.com/playlist/5jpKrLqZrBe4Mm375dcaye"}
{"genre": "haryanvi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/64LawbJ4rIfpIX7LBllzlN"}
{"genre": "taiwan singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/6f3URcUAIeraG7jHhVq3C7"}
{"genre": "hardwave", "spotify_playlist_url": "https://open.spotify.com/playlist/6nd7e40rgwELwkLr9n7jBE"}
{"genre": "australian indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2a4AkEFVA2nSuddrYs5Xfr"}
{"genre": "folklore argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/4MEHK2ca0qSJhJJvLA0raB"}
{"genre": "partyschlager", "spotify_playlist_url": "https://open.spotify.com/playlist/4kO0iMQHG8HwbmkgBKIlOY"}
{"genre": "rock alternativo brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/552Xx5pWGNMm6olPM01Dzz"}
{"genre": "diva house", "spotify_playlist_url": "https://open.spotify.com/playlist/0kAFZCbHemKb8RxZhDPZbv"}
{"genre": "london rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2sAetSf2QJCdtJtEXi0MWR"}
{"genre": "argentine reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/2vk7YBjoVhFTgGBxlKcRPF"}
{"genre": "future garage", "spotify_playlist_url": "https://open.spotify.com/playlist/62T9WUAB2E7Xw6PmHRSlaQ"}
{"genre": "milan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6wxQuk8s6miAo3QMUxtY4K"}
{"genre": "intelligent dance music", "spotify_playlist_url": "https://open.spotify.com/playlist/3P9lEX8RzKkD3hNVvnoMc5"}
{"genre": "drumless hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1ri7gTMg2x0mXLA3X3RI5f"}
{"genre": "nwobhm", "spotify_playlist_url": "https://open.spotify.com/playlist/6uSkf3ARKkBhgf8bQE8NSN"}
{"genre": "charva", "spotify_playlist_url": "https://open.spotify.com/playlist/1uOliCs2FhdbQyrSljIbkm"}
{"genre": "cool jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3RtFvzIXD7ulUCXkWdIOWW"}
{"genre": "canadian pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2n39wrdsYsdsEUrzMRYVdo"}
{"genre": "indonesian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2opcyo5sS9GMhslQoYnrq8"}
{"genre": "indonesian folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5YBynNTezyhp8SIwyKYFXc"}
{"genre": "melodic death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7lGaIZyXooFl0HIxvBxlNY"}
{"genre": "j-pop boy group", "spotify_playlist_url": "https://open.spotify.com/playlist/1ymgn7ot4hxSvd9Qrc96HY"}
{"genre": "japanese electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/3QTAQ5biSQcxBD7dooJf4M"}
{"genre": "australian surf rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4vMgNE1HNtqzmGr8Qmto06"}
{"genre": "j-acoustic", "spotify_playlist_url": "https://open.spotify.com/playlist/1gdSSexTkGJtAXzZ4xsK5J"}
{"genre": "progressive bluegrass", "spotify_playlist_url": "https://open.spotify.com/playlist/2ychGMsKkWCqjgkgNHommE"}
{"genre": "corridos clasicos", "spotify_playlist_url": "https://open.spotify.com/playlist/68OUiC8q9Gj6eaCNKYnPcP"}
{"genre": "rif", "spotify_playlist_url": "https://open.spotify.com/playlist/0HphLqHgdLI5FsTHX3wCj3"}
{"genre": "turkce slow sarkilar", "spotify_playlist_url": "https://open.spotify.com/playlist/6YId5TJbwalucavwCbkZvI"}
{"genre": "canadian contemporary country", "spotify_playlist_url": "https://open.spotify.com/playlist/1Q21zPND8PRlf6boARmyX5"}
{"genre": "chicago bop", "spotify_playlist_url": "https://open.spotify.com/playlist/4nLmlafgbNrN49aqbsnhkm"}
{"genre": "middle earth", "spotify_playlist_url": "https://open.spotify.com/playlist/5oCnQo5S6M9850XBP8LTqS"}
{"genre": "swedish synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/3VgX2GJWjSN7rW70g70ZCf"}
{"genre": "hawaiian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0CqFlDgsIr4aEcUAbxbIsu"}
{"genre": "neoperreo", "spotify_playlist_url": "https://open.spotify.com/playlist/2hx0DYh5UMtd4dmhi6YBup"}
{"genre": "boston rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3nbCGvGDojsTWlcFKRBiBP"}
{"genre": "classic mandopop", "spotify_playlist_url": "https://open.spotify.com/playlist/1891EOiCVUivgiyS2L2XT9"}
{"genre": "soul jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/51YToRmnFC3U4iPj6LgHgF"}
{"genre": "rave funk", "spotify_playlist_url": "https://open.spotify.com/playlist/0Bx8EytO6xZ0O04CG0yM1X"}
{"genre": "seattle indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3QsEFfv09Vc3JMqf7MY8sN"}
{"genre": "vocal house", "spotify_playlist_url": "https://open.spotify.com/playlist/5r4gdnighI2ujQqfCwtHlU"}
{"genre": "russelater", "spotify_playlist_url": "https://open.spotify.com/playlist/2M8B32cPJrc5ez3oqdkFqC"}
{"genre": "cubaton", "spotify_playlist_url": "https://open.spotify.com/playlist/2aLVzwpdZekDdq6kh941ss"}
{"genre": "vapor twitch", "spotify_playlist_url": "https://open.spotify.com/playlist/4XyF8NB0VN7XR5rDHL2lMG"}
{"genre": "mainland chinese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7KmV0LJiGPgoQFKAOqgWxs"}
{"genre": "trap soul", "spotify_playlist_url": "https://open.spotify.com/playlist/2G0hc5WoKd28Zhwtpn48Mh"}
{"genre": "electronica argentina", "spotify_playlist_url": "https://open.spotify.com/playlist/128XwCk8V9NkrYS9kpaIOl"}
{"genre": "tropicalia", "spotify_playlist_url": "https://open.spotify.com/playlist/51yKz5fPHdl24jkxK0GXaC"}
{"genre": "manguebeat", "spotify_playlist_url": "https://open.spotify.com/playlist/1PMeCT6ELd8s6QQUjMTSAN"}
{"genre": "rock uruguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/4AdwCO0lBUKuqN6RHmfydz"}
{"genre": "rap espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/6PyV0jFaVWhEKdjscMtiAU"}
{"genre": "korean city pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7nUK6pM5Viwp3Ah6Ybh0ED"}
{"genre": "jazz saxophone", "spotify_playlist_url": "https://open.spotify.com/playlist/4VrV2cOsoGbmH7IwsHfc7z"}
{"genre": "moroccan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1hpVVlVuXSAO50dZOEATah"}
{"genre": "impressionism", "spotify_playlist_url": "https://open.spotify.com/playlist/5fOqzWOlWWGZlPI6NTUmct"}
{"genre": "nu gaze", "spotify_playlist_url": "https://open.spotify.com/playlist/2gUFVgxO2AeWSFSmg2kQvl"}
{"genre": "chill drill", "spotify_playlist_url": "https://open.spotify.com/playlist/7EPz5p65YLw2YTfKhFGGZx"}
{"genre": "urdu hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4dyCmfPRsW86vOMvDriX7n"}
{"genre": "traditional blues", "spotify_playlist_url": "https://open.spotify.com/playlist/4fPXonBYvsGcigbOEKFudk"}
{"genre": "dinner jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6KAn1uGwrupBX9KI6jOT5N"}
{"genre": "funk 150 bpm", "spotify_playlist_url": "https://open.spotify.com/playlist/1xeC9MJ6OC2ddKdtYQjxS4"}
{"genre": "jamaican dancehall", "spotify_playlist_url": "https://open.spotify.com/playlist/3hOKZkKbbvR05LZsde28i6"}
{"genre": "brighton indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6kntHMhgGR82iUBGGodqW5"}
{"genre": "spacegrunge", "spotify_playlist_url": "https://open.spotify.com/playlist/6lH9sM7yidlEBoxOcm2zij"}
{"genre": "musica bajacaliforniana", "spotify_playlist_url": "https://open.spotify.com/playlist/6MYuVzOxz491LoYW4E7fP3"}
{"genre": "suomi rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7aINHNJg40REiMEP6G2Zdq"}
{"genre": "comic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/62KNLpt0asiJcAw8hihPJq"}
{"genre": "swedish idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/70jdWG9sLb0vAWuAXuiDbX"}
{"genre": "alte", "spotify_playlist_url": "https://open.spotify.com/playlist/6YZspl7VU1iH7IIVZtbBrZ"}
{"genre": "japanese r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/7N35r1mrsCLe66LczBV7EQ"}
{"genre": "swedish alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/42I35nX6LVqu5PqNj8824b"}
{"genre": "psychedelic hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2IQajrWbgM5MH4kKFLe7AB"}
{"genre": "japanese chillhop", "spotify_playlist_url": "https://open.spotify.com/playlist/0LiL4uxTI4oq6hSvmCkVe0"}
{"genre": "roots worship", "spotify_playlist_url": "https://open.spotify.com/playlist/7iGdViGFlFJhmtjga5qhMx"}
{"genre": "experimental r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/6iuMCyOY42ujcbBKUT3Fku"}
{"genre": "uplifting trance", "spotify_playlist_url": "https://open.spotify.com/playlist/2bV5j3UH5k9rMxJywzTYKu"}
{"genre": "new age", "spotify_playlist_url": "https://open.spotify.com/playlist/3hDWEELdaUjBONwNB2jMGV"}
{"genre": "p funk", "spotify_playlist_url": "https://open.spotify.com/playlist/379ACI33mdyLmxPbNSlRRr"}
{"genre": "scam rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2zSN0pq9XyCP1Qi9mPoMlu"}
{"genre": "vallenato moderno", "spotify_playlist_url": "https://open.spotify.com/playlist/58RY7gj2eYkJEXUp9K0lH3"}
{"genre": "german indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4bpLvrAQpvWAZ9lJDDYfbl"}
{"genre": "new age piano", "spotify_playlist_url": "https://open.spotify.com/playlist/3z3YJH7rEJWuaVqggQaHnI"}
{"genre": "float house", "spotify_playlist_url": "https://open.spotify.com/playlist/4CvNSwKn7f9ngVLlP2Jr0O"}
{"genre": "sky room", "spotify_playlist_url": "https://open.spotify.com/playlist/0eEspHigzRe4qFl1W4lfRN"}
{"genre": "swedish indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1Z41nmNKq6E8nBQqRQheTZ"}
{"genre": "rock drums", "spotify_playlist_url": "https://open.spotify.com/playlist/3omUcNqpUCn8aaYgjlFyok"}
{"genre": "sound", "spotify_playlist_url": "https://open.spotify.com/playlist/0uhfs6RxB1VkLp17K35Ssh"}
{"genre": "levenslied", "spotify_playlist_url": "https://open.spotify.com/playlist/6ttzwuno3FKJSdGdtXM5IG"}
{"genre": "nueva cancion", "spotify_playlist_url": "https://open.spotify.com/playlist/4KQJeZBvV1unP9fIFwNtjP"}
{"genre": "russian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/13FUMh8s4eHh9QaTaiRLfE"}
{"genre": "bhajan", "spotify_playlist_url": "https://open.spotify.com/playlist/2JehmMfZgnbSe7e68JfElE"}
{"genre": "experimental hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3bjbpsbl2mzaqFJcyQNGjE"}
{"genre": "bolero mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/7skhVBoiTy8Po9UdfkJ4Gy"}
{"genre": "vancouver indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2BsP4wBGZt4mpY435CfQGR"}
{"genre": "arabic hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7zBydkoj9qpNmelxR9goHB"}
{"genre": "new jersey indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1dP8vfs0Vt1uNk8VbPVwWJ"}
{"genre": "nashville hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/050BEWm6WfYObpajbe14v3"}
{"genre": "ska punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3gCEWVVAL0dTb6g44qqvkN"}
{"genre": "rap cristiano", "spotify_playlist_url": "https://open.spotify.com/playlist/2HAQJtMJXSdgthjyE9TZOI"}
{"genre": "english indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5HyQ5GsKMRx7eTPoZyD7pu"}
{"genre": "naija worship", "spotify_playlist_url": "https://open.spotify.com/playlist/7jRgv5rTQRklfPfRIQ9h6I"}
{"genre": "uk americana", "spotify_playlist_url": "https://open.spotify.com/playlist/1fy3ClO9H8sOTy5ij9H5DC"}
{"genre": "neo-singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/0BhYpMRb8Y8Qu76nu7gFmh"}
{"genre": "modern j-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3EBtIGORBSFLiY8Ga7QmZB"}
{"genre": "south african pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2gCb5sPRAaufQVrfBOLgdN"}
{"genre": "lo-fi product", "spotify_playlist_url": "https://open.spotify.com/playlist/2ucuFoIFqmKn5VK1tyngBZ"}
{"genre": "rap maroc", "spotify_playlist_url": "https://open.spotify.com/playlist/7sACzP5ou82z6sqpBA7bKu"}
{"genre": "ambient folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7eKmP82luDpQR2hymWE1iJ"}
{"genre": "bass trap", "spotify_playlist_url": "https://open.spotify.com/playlist/28qL4DDUcphiGvSyJdW77W"}
{"genre": "classic kollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/4PLYw6CiiaPAIwAyHWhqBz"}
{"genre": "jazz piano", "spotify_playlist_url": "https://open.spotify.com/playlist/5KudWqpwRKdH5CY6yQ1nwA"}
{"genre": "rebel blues", "spotify_playlist_url": "https://open.spotify.com/playlist/44fli7rZ73DG4LU9AVKl8W"}
{"genre": "toronto indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1UPXWrG5mDHMbiBHSxmT7k"}
{"genre": "progressive trance", "spotify_playlist_url": "https://open.spotify.com/playlist/3LfgRDV6HceI9exDCtTJo3"}
{"genre": "tierra caliente", "spotify_playlist_url": "https://open.spotify.com/playlist/2XVUcZxcdc0hGXgaHL5iJW"}
{"genre": "muziek voor kinderen", "spotify_playlist_url": "https://open.spotify.com/playlist/07dKI0FazIH66pe9lpMKYA"}
{"genre": "dark pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2QYND559WzeB2urcTaOG0j"}
{"genre": "odia pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3QWL9assE9GwC3Tuxx9VDl"}
{"genre": "trap colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/17b7ZAhXeyNe2PWwgR3UBs"}
{"genre": "indie quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/2i2T2aO3SnyzstYOrLALW7"}
{"genre": "ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/6CIyPj34GTpAkNwoWToLNT"}
{"genre": "funk viral", "spotify_playlist_url": "https://open.spotify.com/playlist/6lulrwh852gB3WirPe1e4p"}
{"genre": "medieval rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3bJfKd60ASF6rRzlcTzF8T"}
{"genre": "teen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5VnHdgsAhzWNkd29Rv9ErH"}
{"genre": "folk brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/7uLxM93RjHpW2dYdtjZVBa"}
{"genre": "lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/3uzi1GRl4eTJYyQhGvDf7X"}
{"genre": "manele", "spotify_playlist_url": "https://open.spotify.com/playlist/66nTpHtBCHeUZpFhrpJN6F"}
{"genre": "instrumental rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4GpNjPNQcTI39mXe6ht1ud"}
{"genre": "trap baiano", "spotify_playlist_url": "https://open.spotify.com/playlist/5HUyLYZf5C8WLIn8VXLtq7"}
{"genre": "british folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1m7KQp2pFxqhVvXnde3nNe"}
{"genre": "rap baiano", "spotify_playlist_url": "https://open.spotify.com/playlist/1Wfx54pTW6GmYKD8IgnpTU"}
{"genre": "amapiano", "spotify_playlist_url": "https://open.spotify.com/playlist/7xgfzFRkpWzI55LljwwuhO"}
{"genre": "funk mandelao", "spotify_playlist_url": "https://open.spotify.com/playlist/1dXtLBMyIsFiuBlwoVmXg5"}
{"genre": "celtic", "spotify_playlist_url": "https://open.spotify.com/playlist/652MEBjQfhjqwfoKrlaUK6"}
{"genre": "tekk", "spotify_playlist_url": "https://open.spotify.com/playlist/7yNCersDJdYn5S4OgsNweg"}
{"genre": "turkish alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/2atTNlZQfTUpZcmRzf9xRb"}
{"genre": "german hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5M9OhWILZhUHrJZapQ7tSO"}
{"genre": "canadian latin", "spotify_playlist_url": "https://open.spotify.com/playlist/51DX7TssPZBQ3WEtBIQD56"}
{"genre": "bases de freestyle", "spotify_playlist_url": "https://open.spotify.com/playlist/75SDLCiU8CMpgeAJjsmZz5"}
{"genre": "minneapolis sound", "spotify_playlist_url": "https://open.spotify.com/playlist/15Sl0jYESB2NB7NMGx0Oge"}
{"genre": "bubblegum dance", "spotify_playlist_url": "https://open.spotify.com/playlist/2FYJ3kw41qQGBtIDhusO7L"}
{"genre": "funk das antigas", "spotify_playlist_url": "https://open.spotify.com/playlist/0igK9QIsRHR6PpMAoLRZJQ"}
{"genre": "jazz cover", "spotify_playlist_url": "https://open.spotify.com/playlist/29jWLNpz6Onym2WcQUSNRZ"}
{"genre": "british indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0ARblR7ZK5o8QPd3dNnjqr"}
{"genre": "alabama rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4E2D6vTTyXwvHzTygWJxEh"}
{"genre": "baltimore indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1Nk6Z3vICkStGHNHIDLfcQ"}
{"genre": "women's music", "spotify_playlist_url": "https://open.spotify.com/playlist/3X4MhznRfBJnatWERZHW73"}
{"genre": "old school rap francais", "spotify_playlist_url": "https://open.spotify.com/playlist/5Bf10lAe8u4oiayBSDlqDM"}
{"genre": "antiviral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6vGBafdEMRFhPiatbPLfjw"}
{"genre": "shamanic", "spotify_playlist_url": "https://open.spotify.com/playlist/2gmlwXEHmmvxTG6JZN5uBQ"}
{"genre": "basshall", "spotify_playlist_url": "https://open.spotify.com/playlist/5rPMSk9umM8sDDck6ZMADh"}
{"genre": "czech rock", "spotify_playlist_url": "https://open.spotify.com/playlist/44Jnkh0V8VTCk1hMcCID8Y"}
{"genre": "a cappella", "spotify_playlist_url": "https://open.spotify.com/playlist/5K5Bo0zrf3aoNvvDpGWxdK"}
{"genre": "deep tropical house", "spotify_playlist_url": "https://open.spotify.com/playlist/49W2BLxvDqnN3hsFLAIoqc"}
{"genre": "nasheed", "spotify_playlist_url": "https://open.spotify.com/playlist/4w35rvp0TynUWuQH8yL52d"}
{"genre": "japanese soul", "spotify_playlist_url": "https://open.spotify.com/playlist/1lXBwSS3n1W9kkwXPjSHEK"}
{"genre": "german trap", "spotify_playlist_url": "https://open.spotify.com/playlist/4hvpHorF4NBbh4XHXdeXYR"}
{"genre": "rkt", "spotify_playlist_url": "https://open.spotify.com/playlist/3VrPTHyM5DuNHzEZUWzsnt"}
{"genre": "brazilian ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/2UNqwQnjDTvppqW0gW3frK"}
{"genre": "zhongguo feng", "spotify_playlist_url": "https://open.spotify.com/playlist/7f7A3WaMDLcAHyTwxT5hK8"}
{"genre": "crank wave", "spotify_playlist_url": "https://open.spotify.com/playlist/5Tx66vHN6dPYSg0AfhrVoH"}
{"genre": "st louis rap", "spotify_playlist_url": "https://open.spotify.com/playlist/72Tt7drbZmRpxiyRFkrT7c"}
{"genre": "canzone d'autore", "spotify_playlist_url": "https://open.spotify.com/playlist/5gq8uMPUlfKETqFUxujLIP"}
{"genre": "trap catala", "spotify_playlist_url": "https://open.spotify.com/playlist/3thu60HX18eO30w3A8AOqX"}
{"genre": "athens indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4gukXiaMVSu9MMuGOJCTiv"}
{"genre": "australian house", "spotify_playlist_url": "https://open.spotify.com/playlist/6pt4hCDsGV4O1xEBGhaiLI"}
{"genre": "australian reggae fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/2tPZzJ3n0CO4JJpCuRhFTM"}
{"genre": "philly soul", "spotify_playlist_url": "https://open.spotify.com/playlist/6D3nMYU82Nkl2qgd3b2PrM"}
{"genre": "classic girl group", "spotify_playlist_url": "https://open.spotify.com/playlist/6TFuQZNFJiSZZILqBd1LnJ"}
{"genre": "boom bap", "spotify_playlist_url": "https://open.spotify.com/playlist/7dFWa0xrTjf6RaWa1N7PNQ"}
{"genre": "r&b argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/5jz6KkCpdRRqitBX9xa3ay"}
{"genre": "bow pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6kD1by03LqVcIK7FfQ23Ub"}
{"genre": "texas latin rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6sE2S8VQQgataxo2boLXIq"}
{"genre": "synthwave", "spotify_playlist_url": "https://open.spotify.com/playlist/2qlBFnzL6CPxqRwenjrX53"}
{"genre": "chill phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/1pkHHdvmo3uvqjXXcumTja"}
{"genre": "rap catala", "spotify_playlist_url": "https://open.spotify.com/playlist/1nkHFez6zemBRJZxY1ocjC"}
{"genre": "pinoy rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5JdttIYzORolkaZOiAmaDN"}
{"genre": "thai indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1LtPeF5aJyzljIKcH3VVV5"}
{"genre": "austropop", "spotify_playlist_url": "https://open.spotify.com/playlist/1yO5GSVqUyrslkhBcX6saj"}
{"genre": "azonto", "spotify_playlist_url": "https://open.spotify.com/playlist/2i8bdWfRsaWbyrwBEZauU2"}
{"genre": "karadeniz turkuleri", "spotify_playlist_url": "https://open.spotify.com/playlist/6nAOWmyYPXdqQtAJ8AdpwX"}
{"genre": "russian drain", "spotify_playlist_url": "https://open.spotify.com/playlist/1RGZMxRGRRqJTwP6px1d9D"}
{"genre": "indie viet", "spotify_playlist_url": "https://open.spotify.com/playlist/2mKeOh3TSHzA5XioOb0D2C"}
{"genre": "nu-metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0SYBSM50ldqqPQgxDhEspE"}
{"genre": "swedish singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/0JoAW036eAXnmlz2NrzW0E"}
{"genre": "hopebeat", "spotify_playlist_url": "https://open.spotify.com/playlist/3pENYVTMuevP3CLjzQkDpQ"}
{"genre": "gymcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4iJOZzUyARH8EpZngrkiBm"}
{"genre": "focus", "spotify_playlist_url": "https://open.spotify.com/playlist/6fzw3GiLktfRKczD6sl6mT"}
{"genre": "wonky", "spotify_playlist_url": "https://open.spotify.com/playlist/6GZZzXWc7QfecxM85804b7"}
{"genre": "swedish eurodance", "spotify_playlist_url": "https://open.spotify.com/playlist/3smhgA5tMEWCfjqB6WF54r"}
{"genre": "russian gangster rap", "spotify_playlist_url": "https://open.spotify.com/playlist/03k1nPwcKgYsdLtjccDtMM"}
{"genre": "taiwan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0m7Exsm8SA079gMp7eec04"}
{"genre": "synth funk", "spotify_playlist_url": "https://open.spotify.com/playlist/70XGi5LroLK2ZJH1MZyAlR"}
{"genre": "rap mineiro", "spotify_playlist_url": "https://open.spotify.com/playlist/0f3hOsmdLs0w8mbqtfz3Pk"}
{"genre": "rap algerien", "spotify_playlist_url": "https://open.spotify.com/playlist/30xIDBWMvRjMTGCssgd0hp"}
{"genre": "ye ye", "spotify_playlist_url": "https://open.spotify.com/playlist/0HjnliL7S56u2t2sFW8gG7"}
{"genre": "singaporean pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6u7iKVCWcYBfem5aY9SHF9"}
{"genre": "pinoy reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/4zC9gA0aRcK5KP0hANQmFy"}
{"genre": "art punk", "spotify_playlist_url": "https://open.spotify.com/playlist/180M35eDbTmmTCZWuJf6QO"}
{"genre": "batidao romantico", "spotify_playlist_url": "https://open.spotify.com/playlist/0y2K3aUSmblxNcVIVh3SSN"}
{"genre": "indiecoustica", "spotify_playlist_url": "https://open.spotify.com/playlist/4RCjZQTtM2pXauBjFNRcGQ"}
{"genre": "hypnagogic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7qnihFAxqOiKU63ZACcw0T"}
{"genre": "djent", "spotify_playlist_url": "https://open.spotify.com/playlist/6dRyRBIZl5acVd14h733T1"}
{"genre": "variete francaise", "spotify_playlist_url": "https://open.spotify.com/playlist/0MtjpTQ7m7V5cVJrUqoB8H"}
{"genre": "classify", "spotify_playlist_url": "https://open.spotify.com/playlist/6E9uHw2nQR9XPP4DGrBUcl"}
{"genre": "indonesian worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5WhrwlIOMIGBLH8AVhuvJF"}
{"genre": "greek drill", "spotify_playlist_url": "https://open.spotify.com/playlist/0lhbQQ7YzbK8iyifsXwiAK"}
{"genre": "g-house", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ndst9OYUnoYIIrIc8TaVR"}
{"genre": "turkish trap pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6O8py1VYpktcoAnKP3Qj0w"}
{"genre": "lebanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6rHNgj04KCZqwGnLdGIVEu"}
{"genre": "tamaulipas rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5U6sjzliZV1cOBEsICkBbO"}
{"genre": "polish alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ilk2BZa7OWZziZgcBAQlR"}
{"genre": "swedish drill", "spotify_playlist_url": "https://open.spotify.com/playlist/7DZuCNqo9DfOPX7RUOCIYQ"}
{"genre": "harlem renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/6iZqWDC417BZOeGrBRlfsR"}
{"genre": "uk doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5FJqBWsK43TUQp0Jqzj0w1"}
{"genre": "hard bop", "spotify_playlist_url": "https://open.spotify.com/playlist/3KIoIajdvsFRWMYN3T5Fa5"}
{"genre": "jazztronica", "spotify_playlist_url": "https://open.spotify.com/playlist/69OpOkQ8dkxZGn4If6ry6G"}
{"genre": "portuguese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1Rn01P3YPioy5QRQoo32Lv"}
{"genre": "classic soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/6oFOZ4cBewLRG3Vp07xmMI"}
{"genre": "italian baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZkJdeBYWOfQGP1mSz3622"}
{"genre": "westcoast flow", "spotify_playlist_url": "https://open.spotify.com/playlist/6nMzxeJrSkmE29iAcUjfSL"}
{"genre": "rap chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/7wUZUB0FCPHsfnspHVzP7s"}
{"genre": "rap geek", "spotify_playlist_url": "https://open.spotify.com/playlist/0aq7uwv3CYWNt4evMp7mYj"}
{"genre": "russian romanticism", "spotify_playlist_url": "https://open.spotify.com/playlist/0H0ATiQwF1sRnxntil28ZX"}
{"genre": "j-pop girl group", "spotify_playlist_url": "https://open.spotify.com/playlist/4NEjIXkms1uQGIgUI92DHL"}
{"genre": "new school turkce rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6JwEzg4dQvtHCqRZlOIgsZ"}
{"genre": "sleaze rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7BSMAQPtWQ8cLpwxE22kKA"}
{"genre": "brazilian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2MYwrfTz2d13WUqmKfg6ts"}
{"genre": "electronic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4bcSFTS3Cfc2l37m0pWAsV"}
{"genre": "chill abstract hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4U0qNcMhZxPKtKbrCjaZdF"}
{"genre": "jazz guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/4tH5CLOMXHah6ngcr3Z2Gu"}
{"genre": "rhythm game", "spotify_playlist_url": "https://open.spotify.com/playlist/2p7Kq3IMcBDLWSrFNUeNNC"}
{"genre": "proto-metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0Y1QS2ZQpff78Go92oKsZU"}
{"genre": "prog metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7B3rUVfCVpOmeezMZ5cJEk"}
{"genre": "bassline", "spotify_playlist_url": "https://open.spotify.com/playlist/6FOwXg5jZLFmTSokaSrPRb"}
{"genre": "retro soul", "spotify_playlist_url": "https://open.spotify.com/playlist/27Rk57RtVvXDePop2Toln0"}
{"genre": "jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/3GomZqnwKeecLnI3sOkoEq"}
{"genre": "latin afrobeat", "spotify_playlist_url": "https://open.spotify.com/playlist/1a24EyiWhu2ChuRM5Bfqfu"}
{"genre": "classic colombian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0GO4HceKLkcQHrMkSvy9tM"}
{"genre": "iskelma", "spotify_playlist_url": "https://open.spotify.com/playlist/1fZS0IY1MSY6PIyWktr0bx"}
{"genre": "proto-hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/79zqLVUohMiaACESaBfnBb"}
{"genre": "japanese classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3yNw8alWNruDeJemX6qKTj"}
{"genre": "electro swing", "spotify_playlist_url": "https://open.spotify.com/playlist/5oDNHd53EGh5BoiWGYIqH0"}
{"genre": "rock nacional", "spotify_playlist_url": "https://open.spotify.com/playlist/3ygLQ0p0Leod5w6KC1otBx"}
{"genre": "rap cearense", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZQWz04rXXSWX0cjRIUTfb"}
{"genre": "rock gaucho", "spotify_playlist_url": "https://open.spotify.com/playlist/0VodCRYRnBDynqIK02D9Tn"}
{"genre": "pop folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2zd6Wmq9sepWQFYWQAuyko"}
{"genre": "spanish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6GsfAMPH5NWV1LfJtGWrI8"}
{"genre": "australian children's music", "spotify_playlist_url": "https://open.spotify.com/playlist/3bp89ywbzSH01Sn5xuH2i6"}
{"genre": "rock kapak", "spotify_playlist_url": "https://open.spotify.com/playlist/7lG23ivpXWoHsTkMxN4ULo"}
{"genre": "cyberpunk", "spotify_playlist_url": "https://open.spotify.com/playlist/5qRiSivbLQ3QI5AH3Zsxg1"}
{"genre": "eau claire indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4GaHDvZWlZ7NtcGdIz7jvT"}
{"genre": "scottish singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/2r6lIp87MMXvjAfJRg7Rgo"}
{"genre": "lo-fi vgm", "spotify_playlist_url": "https://open.spotify.com/playlist/213ytvvMz8Fjj5cQ405EUX"}
{"genre": "chicha", "spotify_playlist_url": "https://open.spotify.com/playlist/1nJEcAFNHlbITIZ6vokLFi"}
{"genre": "french soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/7t1aXa1i7A4leCY06e8GKn"}
{"genre": "deep german hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1p4L83YzPEhIPZHF94bJ7z"}
{"genre": "classic city pop", "spotify_playlist_url": "https://open.spotify.com/playlist/76p6vBc8IZucg2PpBRVnva"}
{"genre": "salsa venezolana", "spotify_playlist_url": "https://open.spotify.com/playlist/5DRoVvG84sCnrZeQfTHr0p"}
{"genre": "hardcore techno", "spotify_playlist_url": "https://open.spotify.com/playlist/1PUbKeyQcEE5MgfdaJRsgw"}
{"genre": "classic russian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0ic2Xr1zG007z8Nduvazc4"}
{"genre": "ottawa rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5wxM3elzbLxczas9whcYyR"}
{"genre": "turkish deep house", "spotify_playlist_url": "https://open.spotify.com/playlist/0vIkzx3mKL65T3gR48Bph2"}
{"genre": "stomp pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7rQW0xSgtYDORMp35iKEGl"}
{"genre": "nintendocore", "spotify_playlist_url": "https://open.spotify.com/playlist/0oSBswMPV792Pth26EyI7N"}
{"genre": "boom bap brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3j5pi1O3eizTQp6Kc69srX"}
{"genre": "italo disco", "spotify_playlist_url": "https://open.spotify.com/playlist/3KqrijNkb21PAycB7ihAQG"}
{"genre": "ghanaian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6tJl39oFvuNfQdoM0FloAN"}
{"genre": "rap sardegna", "spotify_playlist_url": "https://open.spotify.com/playlist/4Qh3xgWrx3BOcg5TKjGw7y"}
{"genre": "lata", "spotify_playlist_url": "https://open.spotify.com/playlist/0ylNGJ6oQ43HQ9OE40syp4"}
{"genre": "latin jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3bhnRBlvTikmxpW50jBaIZ"}
{"genre": "swedish power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4vTdyEz1xpzPJ45jfFHWYl"}
{"genre": "anime rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5NzLRFeAwgtSwUg98g9i8n"}
{"genre": "hk-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5z1A6hdw1MJrmZzDusE4Q6"}
{"genre": "classic arab pop", "spotify_playlist_url": "https://open.spotify.com/playlist/45eeFNKr2ydPrFbFBIi9M1"}
{"genre": "rap underground espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/0Uhh3P5G0IYxqgySvKviHm"}
{"genre": "italian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/4lJcvL5WcpNky192UQRqLG"}
{"genre": "glitch hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3Cy2LdkFDxcwVd6wMWsGll"}
{"genre": "forro de favela", "spotify_playlist_url": "https://open.spotify.com/playlist/6rgJa4JpxjExztCelf11Fd"}
{"genre": "black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2xaw4stu1HBocKtPBllYME"}
{"genre": "filthstep", "spotify_playlist_url": "https://open.spotify.com/playlist/0osSe1116rhifh5KwidIGJ"}
{"genre": "spanish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2khJPxCAK41z7bhSqRsNEd"}
{"genre": "boston hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1qKT01W06KFPouzgMpoULZ"}
{"genre": "romanian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/0WmfzLNRVjDZ0mpvjTzkVy"}
{"genre": "cumbia santafesina", "spotify_playlist_url": "https://open.spotify.com/playlist/7sAJizlD5BDA6EiIaF3A22"}
{"genre": "german r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/4rkIxhozLZKLwSH2Fog0Mw"}
{"genre": "thai rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3HwPfR9P3OqlId9ADZCrrt"}
{"genre": "anthem emo", "spotify_playlist_url": "https://open.spotify.com/playlist/1dHm6fhlORhY2O1v6aO4fc"}
{"genre": "merengue", "spotify_playlist_url": "https://open.spotify.com/playlist/0wJXJueXiwCAA8EYPYZqOF"}
{"genre": "rock brasiliense", "spotify_playlist_url": "https://open.spotify.com/playlist/0vv1XTKVrCMJuY7BQwN8UE"}
{"genre": "banda sinaloense", "spotify_playlist_url": "https://open.spotify.com/playlist/24fVjXxvkbhI5PcQkzLnKU"}
{"genre": "french reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/47v1NcKNyzVdhTWdCtl8HE"}
{"genre": "trap carioca", "spotify_playlist_url": "https://open.spotify.com/playlist/2Sca9Wv1kLiQJ8ARmFyN5I"}
{"genre": "hands up", "spotify_playlist_url": "https://open.spotify.com/playlist/29l2v5sGaKTBwZd9I74CfA"}
{"genre": "german underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2IcKLRiUHpjhMMubZqderY"}
{"genre": "atlanta indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0TGIGqHl7lhNPKbbkjl4uJ"}
{"genre": "bitpop", "spotify_playlist_url": "https://open.spotify.com/playlist/5QV9DIzmUFiUiyBGWWAuGc"}
{"genre": "newcastle nsw indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0VJWJJx0htlHrSC1gjUpIj"}
{"genre": "christian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4LR7zJ6HkhAJFhQm4eTfqS"}
{"genre": "bandung indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2htmct6QRhvz7MdvqEl7Xc"}
{"genre": "chill breakcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6wnosjv0zXay7wCgWAa3TG"}
{"genre": "classic uk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1a8bmZL1UIDLb9XqSfgtws"}
{"genre": "flamenco", "spotify_playlist_url": "https://open.spotify.com/playlist/0Z6ypDDrXad1QMj5EapMEV"}
{"genre": "musica tlaxcalteca", "spotify_playlist_url": "https://open.spotify.com/playlist/1apHgiJVgkrRMDs077B0Uj"}
{"genre": "indie electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/41997GIfsUgMnsPLFiuLeS"}
{"genre": "deep disco house", "spotify_playlist_url": "https://open.spotify.com/playlist/3ShagP0yJAuPN8psJvAz2n"}
{"genre": "livetronica", "spotify_playlist_url": "https://open.spotify.com/playlist/7J9GDUnv2JMOvNK6xCKCE1"}
{"genre": "chicago punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1jO2KInTRF7Oebj7RyyazC"}
{"genre": "aussie drill", "spotify_playlist_url": "https://open.spotify.com/playlist/1Zmdt7w4HzEAW6IOLa1KKH"}
{"genre": "mahraganat", "spotify_playlist_url": "https://open.spotify.com/playlist/0giKVmGYwAYFSADewdBLzJ"}
{"genre": "pet calming", "spotify_playlist_url": "https://open.spotify.com/playlist/2GMM4p5RuHWAFfWPSXQJ9D"}
{"genre": "classic russian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/26C6ieZHP6osxOV3WKiiBm"}
{"genre": "pop violin", "spotify_playlist_url": "https://open.spotify.com/playlist/2UVYwW6BSENPhn2lxiIggj"}
{"genre": "nederpop", "spotify_playlist_url": "https://open.spotify.com/playlist/4jad2Rm1ff78yGzm3XTZKC"}
{"genre": "indie punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2owRoUVlHqTdJF3FmF5uwZ"}
{"genre": "reggaeton cristiano", "spotify_playlist_url": "https://open.spotify.com/playlist/21OgU7Hzo2AED3ooR9je2g"}
{"genre": "breakbeat", "spotify_playlist_url": "https://open.spotify.com/playlist/1yckyfEZtFkkq7UPXHbLwi"}
{"genre": "lo-fi rap", "spotify_playlist_url": "https://open.spotify.com/playlist/57ZSwCZ7iILUL4OQ7bnwTP"}
{"genre": "palm desert scene", "spotify_playlist_url": "https://open.spotify.com/playlist/5AnqtucIMghevunv9Pghfs"}
{"genre": "german punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6oQUxF3hVHxvfsRyOC0IE9"}
{"genre": "afghan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/562K7759REapjUDAJmEszO"}
{"genre": "folk punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2FY0iRROQx0marHTDB5ntD"}
{"genre": "argentine alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3PxIDoTKbpIulNiPjNev5s"}
{"genre": "finnish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/18oX7hhCoQ3AIQyBmtD6Fn"}
{"genre": "boston folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ga0J6eHpVeHcWDhRlUdIa"}
{"genre": "nordic soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/5d9dEMb9Ezh1HmFfBdSbU9"}
{"genre": "cumbia del sureste", "spotify_playlist_url": "https://open.spotify.com/playlist/5DH6UVRfPrrSsWerklXbgN"}
{"genre": "australian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/62Mjfl6ctnwHXAgiT6cQwI"}
{"genre": "desi emo rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0cHpDm16pCpH2LyvWVLaSg"}
{"genre": "violao", "spotify_playlist_url": "https://open.spotify.com/playlist/5cMga6Rfi407pGSXld2E7C"}
{"genre": "grave wave", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ndvcc1Qz9mNbQemnforB5"}
{"genre": "abstract hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6R9oHYFwTr01u6KsUW1vXb"}
{"genre": "israeli mediterranean", "spotify_playlist_url": "https://open.spotify.com/playlist/2PuF72PN1DvyJOZJSk5L9I"}
{"genre": "german pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3if1Yx0WjzvX38BG9ENRD9"}
{"genre": "lovers rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7KNEp9goFIQIuIwqFDFgTg"}
{"genre": "barnsagor", "spotify_playlist_url": "https://open.spotify.com/playlist/5VfLpPyTr7A2k9CdAzp0Mz"}
{"genre": "fantasy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Ny1iKKUSQteHqrGDyQrmT"}
{"genre": "melodic thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/6AhE0orn6B44XduPrHRuiz"}
{"genre": "mississippi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/649LrLH1LtlbjFzJUoHOge"}
{"genre": "german singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/7vVJyi5ArX0m0dvPZYWLJ1"}
{"genre": "lo-fi emo", "spotify_playlist_url": "https://open.spotify.com/playlist/3gDyXNhx15j4TSaddiiLq8"}
{"genre": "cumbia ranchera", "spotify_playlist_url": "https://open.spotify.com/playlist/1K8Y4kHYHfjt6ihSDuSMaw"}
{"genre": "future house", "spotify_playlist_url": "https://open.spotify.com/playlist/2u6y2dDw8lKwW389jYEMoN"}
{"genre": "anthem worship", "spotify_playlist_url": "https://open.spotify.com/playlist/0pcdBX3CHzyOFHeyu7RAQI"}
{"genre": "australian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0HPtrFbEfJh8xp12L2JJR0"}
{"genre": "thai indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1LkvG5mQgD9xiroaVR5PFl"}
{"genre": "dembow dominicano", "spotify_playlist_url": "https://open.spotify.com/playlist/5GOLXZSi2tv2noG4DYFEEw"}
{"genre": "icelandic indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1Jhwq1axwpxTbZd0jcFa1j"}
{"genre": "dark synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/4vn9Grkso2ofxHg8JIM1D2"}
{"genre": "upstate ny rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5AmVxPk3hf7Vk63IwyiSz1"}
{"genre": "acoustic opm", "spotify_playlist_url": "https://open.spotify.com/playlist/3pDfTmnPlLo7W0jO1HhllT"}
{"genre": "australian country", "spotify_playlist_url": "https://open.spotify.com/playlist/1hseduxVpn5p3ukaREgsSi"}
{"genre": "venezuelan rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5c8RLU4cABQz4E0AWFc22P"}
{"genre": "scream rap", "spotify_playlist_url": "https://open.spotify.com/playlist/26RcB9SST53vdYfYfMhpzf"}
{"genre": "morelos indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2DpOGCy31iLhNXbQJ9h5Za"}
{"genre": "bboy", "spotify_playlist_url": "https://open.spotify.com/playlist/4Pt1OE9gPOHcEsRDd1e2Jh"}
{"genre": "noise rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4wRu8Zs21gA3GxSbmYHqCq"}
{"genre": "narco rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1jQcMY96s1kWcGGbeZjQY1"}
{"genre": "sholawat", "spotify_playlist_url": "https://open.spotify.com/playlist/412mIpGY8KqTKSdVe4dt6e"}
{"genre": "manchester hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3nRBbrreRvAcb3qIdIM7Cq"}
{"genre": "future bass", "spotify_playlist_url": "https://open.spotify.com/playlist/0HL0ITC4buCPYJaJHqwbMm"}
{"genre": "organic electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1Cf8ZdtSkyItY3LKaiZnWD"}
{"genre": "pop nacional antigas", "spotify_playlist_url": "https://open.spotify.com/playlist/1tbOczjQP5g6oWMCc7oLQP"}
{"genre": "instrumental funk", "spotify_playlist_url": "https://open.spotify.com/playlist/1Ee9iZBp4eNLzR3F8Xf8VD"}
{"genre": "k-indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3P4E2aY9cPJSpu35WUxyFk"}
{"genre": "cumbia sonorense", "spotify_playlist_url": "https://open.spotify.com/playlist/343D6JcycIsM2fF7zaR9cC"}
{"genre": "carnaval", "spotify_playlist_url": "https://open.spotify.com/playlist/4b7GbUPm9ikbMF0G0finII"}
{"genre": "digital hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2fqbzU1sBBZ3gW61Q7qYhp"}
{"genre": "dutch indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2pSeH1YQCSICs2knjs7e5o"}
{"genre": "garage rock revival", "spotify_playlist_url": "https://open.spotify.com/playlist/3YAis1AJCEkSdFVMDdjskn"}
{"genre": "indie liguria", "spotify_playlist_url": "https://open.spotify.com/playlist/3N6f07zAIQH4yQ2IfJ1Yn7"}
{"genre": "christmas instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/61mWpz3ZqIBLOd3MxbjWFR"}
{"genre": "ghanaian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/77dWlkvz9QxTMVTTM6pUJn"}
{"genre": "trap venezolano", "spotify_playlist_url": "https://open.spotify.com/playlist/6TGv97F18XyaIiAqGs8Kh6"}
{"genre": "traphall", "spotify_playlist_url": "https://open.spotify.com/playlist/4mn661nDOTi0yboUpcsN8g"}
{"genre": "belgian dance", "spotify_playlist_url": "https://open.spotify.com/playlist/7LiSIthh02iaUmBElzs3J8"}
{"genre": "swedish melodeath", "spotify_playlist_url": "https://open.spotify.com/playlist/5t9JNFZ4IK0asQ2DqcCmbJ"}
{"genre": "kirtan", "spotify_playlist_url": "https://open.spotify.com/playlist/3eVTClqdypXLETw97iznv5"}
{"genre": "qawwali", "spotify_playlist_url": "https://open.spotify.com/playlist/6DEKx1zncvF5WovQK13IIk"}
{"genre": "cancion infantil latinoamericana", "spotify_playlist_url": "https://open.spotify.com/playlist/52NSoGCxxTdsQEuoSP9dTr"}
{"genre": "polish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/5c33S502HNpzP1AxJqS6La"}
{"genre": "reggae en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/672uAsamKiPJti4m4EdETY"}
{"genre": "detroit trap brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3qx5GEFYid9MdlDPMJZy8y"}
{"genre": "psychedelic soul", "spotify_playlist_url": "https://open.spotify.com/playlist/2bQ8L09OJhqy6aaEdeMtSi"}
{"genre": "kizomba", "spotify_playlist_url": "https://open.spotify.com/playlist/3v3hmXti8AEFWS30S8gT6Z"}
{"genre": "nerdcore brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/1iHqGq35jAzFcUJepCqcLy"}
{"genre": "canzone napoletana", "spotify_playlist_url": "https://open.spotify.com/playlist/3JQiRugE3VcHpSsx7TB5lr"}
{"genre": "neue neue deutsche welle", "spotify_playlist_url": "https://open.spotify.com/playlist/0fIScoj9B66LFjg0yz02Wp"}
{"genre": "chinese r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/2XXreCGINlOqm8wEn7WszA"}
{"genre": "thai hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0ic1I4rWzKchFqKE1HOWWH"}
{"genre": "uptempo hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3i1lMa8Zl2bAF1ExmFNTV0"}
{"genre": "indian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4TLNeT3ismlmHwRxOxP3Tc"}
{"genre": "modern reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/3B7t8HFv1PowgvPsLq6Qbf"}
{"genre": "happy hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/17TwTPITOWP0Ep9joASCrm"}
{"genre": "musica tradicional cubana", "spotify_playlist_url": "https://open.spotify.com/playlist/5elKpfFPejpmof8qyNkpRw"}
{"genre": "solo wave", "spotify_playlist_url": "https://open.spotify.com/playlist/0Z8zRVOCexCTYHKBVLX3qo"}
{"genre": "canadian soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/3k2Tj2Fu7Hu4tJcdFvpgUc"}
{"genre": "classic sierreno", "spotify_playlist_url": "https://open.spotify.com/playlist/0V15uQiYyGQWZHGnLw6wbQ"}
{"genre": "egyptian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2C1aQIm29aKkdT0PHXDr39"}
{"genre": "classic praise", "spotify_playlist_url": "https://open.spotify.com/playlist/2G4rXSKZosglqaXKjjVagl"}
{"genre": "asian american hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3WC66rd9N7tuZuGOSQuFsA"}
{"genre": "swedish pop rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0J5wtQ0UNsi3GsBqx7RsEb"}
{"genre": "turkish psych", "spotify_playlist_url": "https://open.spotify.com/playlist/3hihfADumZ3RhH627kV7Jm"}
{"genre": "veracruz indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7HCXj9DPiuYcfcSFwpNyhR"}
{"genre": "icelandic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3UqukV6w1sdKa4TSy04aPX"}
{"genre": "finnish power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/33KhDl0itx7zYyzuEhwDQA"}
{"genre": "indonesian reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/4r0FbEBsitpsLSznQocRrf"}
{"genre": "bubble trance", "spotify_playlist_url": "https://open.spotify.com/playlist/6LJOGOAWRYLxDPGirVxTO3"}
{"genre": "acoustic guitar cover", "spotify_playlist_url": "https://open.spotify.com/playlist/6vjOsh6JeWFudKpQsOkYNP"}
{"genre": "pop virale italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/5GHeUAdOq5tTdtDQm3kagL"}
{"genre": "rai", "spotify_playlist_url": "https://open.spotify.com/playlist/36qabOc2JEaHmVvSTPmTx6"}
{"genre": "danish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0MITgTVdGQEYvGl3zSonPE"}
{"genre": "liquid funk", "spotify_playlist_url": "https://open.spotify.com/playlist/5mu96o6F1pWzA5C9R8LAOm"}
{"genre": "turkish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2XWuLY8J7ViTQ7Gl3ZV9KV"}
{"genre": "tontipop", "spotify_playlist_url": "https://open.spotify.com/playlist/1xfanFjPCS1Ok3pcXYu1N6"}
{"genre": "dansband", "spotify_playlist_url": "https://open.spotify.com/playlist/6f4RjDLQ7stLq4zkeB3biB"}
{"genre": "pianissimo", "spotify_playlist_url": "https://open.spotify.com/playlist/3nN6qe9G9sTyORJ1KKyMaq"}
{"genre": "kayokyoku", "spotify_playlist_url": "https://open.spotify.com/playlist/3eYt9gyFTUOcqKoAW2gQWQ"}
{"genre": "singaporean mandopop", "spotify_playlist_url": "https://open.spotify.com/playlist/1eHbCJdm1FCG9r7CNaRIGl"}
{"genre": "bronx hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4diPkvLp8ZKMhERnlQjNe8"}
{"genre": "jazz trio", "spotify_playlist_url": "https://open.spotify.com/playlist/6Pixe6bdAwQIkLv4q85U7E"}
{"genre": "japanese punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6S3Z5EjcBkNyQRHptNbckp"}
{"genre": "dark clubbing", "spotify_playlist_url": "https://open.spotify.com/playlist/4Hy2WDRHQh3020nVdICxvh"}
{"genre": "electro-pop francais", "spotify_playlist_url": "https://open.spotify.com/playlist/2N3bqn8GZGY3WZqAMXENIf"}
{"genre": "egyptian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2htHbhNj5IBJDk651FeuWV"}
{"genre": "french shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/1zUlfEkaAo7zS5TWEuHXz2"}
{"genre": "drill italiana", "spotify_playlist_url": "https://open.spotify.com/playlist/1wrSDOT0XjCDAU1iwSy7eu"}
{"genre": "aggressive phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/3Fv3vd2eqb9rVvIJcJxEoU"}
{"genre": "uk dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/65UofZd1pC3HdvIXQzYC62"}
{"genre": "progressive metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2dNnJRyRUcwVBuAtBQTrQQ"}
{"genre": "french romanticism", "spotify_playlist_url": "https://open.spotify.com/playlist/3BZGhiDEQ4ubD6WcMKZawB"}
{"genre": "neo r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/6PYtLNuIDCA1TZoLSaBYm7"}
{"genre": "german house", "spotify_playlist_url": "https://open.spotify.com/playlist/6Y3Aw2aBg0fnPRFAxp8apo"}
{"genre": "electropowerpop", "spotify_playlist_url": "https://open.spotify.com/playlist/2STQEZpFAQHJqrT3UhRNIK"}
{"genre": "japanese alternative pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3rZO48bDFx49kd29IjEiHL"}
{"genre": "vegas indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1nc1awE848GMhuPJ4IHt86"}
{"genre": "austindie", "spotify_playlist_url": "https://open.spotify.com/playlist/30t7SqNFcol7qd79XWxrgh"}
{"genre": "uk reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/76KkfFSYNWSYHwnhRBxUDq"}
{"genre": "healing", "spotify_playlist_url": "https://open.spotify.com/playlist/44UhH06dKGdI3cqbst5jJ4"}
{"genre": "musica triste brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/47bikoA9qfXDT5VVhzsjy9"}
{"genre": "samba-enredo", "spotify_playlist_url": "https://open.spotify.com/playlist/50iRmXYSOEtDF1jzgYX3iW"}
{"genre": "afro soul", "spotify_playlist_url": "https://open.spotify.com/playlist/40jbkOIWkM57FnXTokMzU9"}
{"genre": "jovem guarda", "spotify_playlist_url": "https://open.spotify.com/playlist/3vWhIIVkzQlg7rwn2gbldL"}
{"genre": "gujarati garba", "spotify_playlist_url": "https://open.spotify.com/playlist/6Bo51YEb83mzNvPlK2pb5N"}
{"genre": "nightcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2HRSlLWvRjJ6mnxpn5Q99B"}
{"genre": "saskatchewan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2RQbcW330llRqm8BdqCO3c"}
{"genre": "swedish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3GZ4ki70GCmF8up0dcjAW4"}
{"genre": "hamburg electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/3OLnmWjHbXKRIiRNDNfntH"}
{"genre": "canadian americana", "spotify_playlist_url": "https://open.spotify.com/playlist/1UiJjWUShOuChiHEzF4w1x"}
{"genre": "umbanda", "spotify_playlist_url": "https://open.spotify.com/playlist/2sto3QLsWEIB8TLyoVaDbF"}
{"genre": "souldies", "spotify_playlist_url": "https://open.spotify.com/playlist/0dOLyEu9HJ8tKGq70qVup9"}
{"genre": "anti-folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1SXOzFKlMx7ODmxI1jnxux"}
{"genre": "riot grrrl", "spotify_playlist_url": "https://open.spotify.com/playlist/4VhHe5d6eNI3zzppwiDgWX"}
{"genre": "monterrey indie", "spotify_playlist_url": "https://open.spotify.com/playlist/38xSMDvCvAwSotbdT6K18V"}
{"genre": "mexican classic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7cI5TNKzisUNu7FmJwo4ej"}
{"genre": "new orleans jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0iMiZcvIy26MqHQln5kkrI"}
{"genre": "organic house", "spotify_playlist_url": "https://open.spotify.com/playlist/73NvmzII2ExqKUR9iliJdQ"}
{"genre": "dixieland", "spotify_playlist_url": "https://open.spotify.com/playlist/0DdxySdbk9CaxkZTzC8WFr"}
{"genre": "cosmic american", "spotify_playlist_url": "https://open.spotify.com/playlist/05y5YX2kQFi6J8B5ece5qy"}
{"genre": "rap feminino nacional", "spotify_playlist_url": "https://open.spotify.com/playlist/4Kx9ayuCPVZKDkxxM7wspD"}
{"genre": "british alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/05orH2qSCaMxEhFeaND3Yh"}
{"genre": "indonesian idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4uzL9YI3MXxUlORrCZAql2"}
{"genre": "jawaiian", "spotify_playlist_url": "https://open.spotify.com/playlist/7EIYnaUoJnYUIAvn2jzbAW"}
{"genre": "mariachi cristiano", "spotify_playlist_url": "https://open.spotify.com/playlist/2KQsYJA74IvrwonXugqzdy"}
{"genre": "classic cantopop", "spotify_playlist_url": "https://open.spotify.com/playlist/2CTX0IxBoq69Kq4trHCzAD"}
{"genre": "romantico", "spotify_playlist_url": "https://open.spotify.com/playlist/438mjqOPOjUa3aY1sOW50Q"}
{"genre": "german power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Nc6imqfPkI1PvvGGH8WS7"}
{"genre": "classic disco polo", "spotify_playlist_url": "https://open.spotify.com/playlist/1HwHGzGFWk5nhDkezPcOAK"}
{"genre": "musique pour enfants", "spotify_playlist_url": "https://open.spotify.com/playlist/3938nta3dDXu0lhuB4Szzh"}
{"genre": "swedish tropical house", "spotify_playlist_url": "https://open.spotify.com/playlist/4D7xfG82EyEq3BWglKNS6A"}
{"genre": "discofox", "spotify_playlist_url": "https://open.spotify.com/playlist/4BsMAg9t48Ga9I8Fyzlvrc"}
{"genre": "chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/5rTYOAAMiNdcnfgEQ3a6sc"}
{"genre": "j-metal", "spotify_playlist_url": "https://open.spotify.com/playlist/57Ehb6xWTjJUadbP8DDgyo"}
{"genre": "welsh rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1rYUoCN3Vc5KMfqsKvlVtv"}
{"genre": "bulgarian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/72tss1btQXuReBr6b4oKJQ"}
{"genre": "virginia hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6Mc6G3faDyfjX8U9HEoPSC"}
{"genre": "brega paraense", "spotify_playlist_url": "https://open.spotify.com/playlist/52tw6RvfXQJqEwbXPICg84"}
{"genre": "thai trap", "spotify_playlist_url": "https://open.spotify.com/playlist/7JGkki0GqCcZSMCq9sDU8l"}
{"genre": "grungegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/5eOvkYkMf6eMjyEQjldfiE"}
{"genre": "chicago hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2cXDt1ed25OJuZkDpEXAYp"}
{"genre": "sludge metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3kbzqWhOrhZFXME9PpL8dg"}
{"genre": "pacific islands pop", "spotify_playlist_url": "https://open.spotify.com/playlist/45anIT1Lg5xrUsgkznbwzm"}
{"genre": "south african rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1uEgUI0ouVrWVeSImmq6xh"}
{"genre": "swedish indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4MitOn8IVtRjmWWUiSHAQo"}
{"genre": "russian post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3rGqaAFnWBXfSlzQpiQAQh"}
{"genre": "smooth saxophone", "spotify_playlist_url": "https://open.spotify.com/playlist/16abo0oaXgiL8a1NU9ZPWQ"}
{"genre": "ukrainian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2TsSOQsGVFwKfOZLra0x4E"}
{"genre": "chicago soul", "spotify_playlist_url": "https://open.spotify.com/playlist/03CnmKGrRlG2dwJSH1Q1Tg"}
{"genre": "samba moderno", "spotify_playlist_url": "https://open.spotify.com/playlist/2CrjPGcldFQsIW044BLMrs"}
{"genre": "freestyle", "spotify_playlist_url": "https://open.spotify.com/playlist/3QuJzF7D2tot4yN1lqIVLn"}
{"genre": "american shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/4RtSMgqyvQLbKaBLBb9qHc"}
{"genre": "latin metal", "spotify_playlist_url": "https://open.spotify.com/playlist/79hARNnoeG5aL4cC0pJrJ8"}
{"genre": "german reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/0mUMdH557NL46xbRugrHlM"}
{"genre": "danish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1DqTDBqyLLsMCGvqvf3QLY"}
{"genre": "rock mineiro", "spotify_playlist_url": "https://open.spotify.com/playlist/2eNwpeMvk4NOvZWrPw4XIe"}
{"genre": "sound team", "spotify_playlist_url": "https://open.spotify.com/playlist/0uAOaUQNR7DsTVK457abcH"}
{"genre": "canadian electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/3PjSViYxygIzwIDO2dPkyW"}
{"genre": "drone", "spotify_playlist_url": "https://open.spotify.com/playlist/0HIfTbD7gaDP0rVPqSPNhX"}
{"genre": "regional mexicano femenil", "spotify_playlist_url": "https://open.spotify.com/playlist/3ynZpigXzs8kyw8V2mirs4"}
{"genre": "indian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/56gW8BV0CNYVMvkbQTy4f7"}
{"genre": "j-idol", "spotify_playlist_url": "https://open.spotify.com/playlist/73mIbBtGZZrvber2h9Y7Lu"}
{"genre": "okinawan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/064xurZvoAeKg63JmTAIDn"}
{"genre": "sandalwood", "spotify_playlist_url": "https://open.spotify.com/playlist/5cWMQfuIovWhCrnXC3szWn"}
{"genre": "scottish new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/549FJ3PFDdaLDTnX9WXwAK"}
{"genre": "indie jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6LgnHN3mGCfSTnYy7Cd81C"}
{"genre": "afrikaans", "spotify_playlist_url": "https://open.spotify.com/playlist/0x1RCBId9JUrDWjLPrlxX4"}
{"genre": "nz reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/5eVO31RjkfRfpa7B2Ex4hc"}
{"genre": "israeli rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5pY0dKBL7RzLorJfjzl6mo"}
{"genre": "oklahoma country", "spotify_playlist_url": "https://open.spotify.com/playlist/0HETxB01hJ6A6PHf8kzgr5"}
{"genre": "viking metal", "spotify_playlist_url": "https://open.spotify.com/playlist/21dqo7wC7PMnraXfbuapQ7"}
{"genre": "christian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/7dAAKYBOlPiG4pZxtrF3hx"}
{"genre": "brega", "spotify_playlist_url": "https://open.spotify.com/playlist/7eGVwau0N6LFe0tDGSgnfE"}
{"genre": "buffalo hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0uivlRLR2faPoiuYrimbxE"}
{"genre": "kazakh pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6dVwWlgvlxfKRVLkZqfFGd"}
{"genre": "chill lounge", "spotify_playlist_url": "https://open.spotify.com/playlist/03lYJ1JeE7DJJ43emp4TVO"}
{"genre": "belly dance", "spotify_playlist_url": "https://open.spotify.com/playlist/7nRoLyNA8m2l23FFjanoi4"}
{"genre": "minimal tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/3RWFXMd9ne5jj30u8ZTbEx"}
{"genre": "icelandic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2MQ2XXBKBPGbwLxkqvBLxn"}
{"genre": "classic indo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6OO8fOSbaM2OqY7o28PA0X"}
{"genre": "oakland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/105nvg8CWlvlQoN3HjeuF2"}
{"genre": "surf punk", "spotify_playlist_url": "https://open.spotify.com/playlist/78rpYOH1FWxbCRD962WlPw"}
{"genre": "australian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1MYuhqf2e1fJDlJRvkGfVz"}
{"genre": "brutal death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/20conlxRjnUqSRorkKq1l7"}
{"genre": "christian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0m8nZXx1Y6MU0JnYxREiVf"}
{"genre": "japanese vtuber", "spotify_playlist_url": "https://open.spotify.com/playlist/17KAkGia8BUy0QhVvT6iIp"}
{"genre": "south african hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4KLH6GGDeD0FFxjlz2ifeJ"}
{"genre": "rhode island rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3rO0S2HRXs5QvpLbTSeIcL"}
{"genre": "austrian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7uivlZOhfHotY1IiRFctsW"}
{"genre": "shaabi", "spotify_playlist_url": "https://open.spotify.com/playlist/4TJaPKWVQSS3XfecPldvhk"}
{"genre": "celtic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6PrgksnXDw8GYVs2JE3Kuq"}
{"genre": "salsa peruana", "spotify_playlist_url": "https://open.spotify.com/playlist/0RMEf2lXntVJFym0GMgbbk"}
{"genre": "tecnobrega", "spotify_playlist_url": "https://open.spotify.com/playlist/5D1woZsNamyX7HaGuDyCK1"}
{"genre": "indian lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/7C6kovLwB91Ywhv0LC9ozA"}
{"genre": "transpop", "spotify_playlist_url": "https://open.spotify.com/playlist/1sUevEmStQN4HnEmVOu43y"}
{"genre": "chillstep", "spotify_playlist_url": "https://open.spotify.com/playlist/22pjJtfW7sA4PiaruUB5yN"}
{"genre": "japanese trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2gWIQkhf1LF8McaXp1Y9Ed"}
{"genre": "egyptian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/2KYwHa3P14HIhvFakxj4lD"}
{"genre": "jersey club", "spotify_playlist_url": "https://open.spotify.com/playlist/0MwWDReLQ2CbFF4RNV7p2J"}
{"genre": "experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/13rgRSFVuyKQ0YtrZDJD6R"}
{"genre": "channel pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5Ts3jfNCNXUoNeDOEfhqv4"}
{"genre": "czech drill", "spotify_playlist_url": "https://open.spotify.com/playlist/12kZsrN8ItaPt5sI5r680Q"}
{"genre": "texas metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7acyCjTN8uUB6TSTqBxfPx"}
{"genre": "polish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4GYAqL5PGmNFqf1MuTYtwv"}
{"genre": "norwegian pop rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4TaUNytRspBtacAOATKvF3"}
{"genre": "indonesian lo-fi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5pm4B24vBqSjtwQvMJaUDU"}
{"genre": "samba de roda", "spotify_playlist_url": "https://open.spotify.com/playlist/07juLZ7NryVlDUDAsu0RZ7"}
{"genre": "sda a cappella", "spotify_playlist_url": "https://open.spotify.com/playlist/24cYFs1FS6sFEilI7wB2Gx"}
{"genre": "harlem hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0Iabo9lesGD48jAIjsyiDY"}
{"genre": "danish pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/21sN3UTzKhWo4jg5YNWEuK"}
{"genre": "canadian ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/76NdMW8Bc6zGErS8armzrF"}
{"genre": "russian emo rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1Of03fMRcavbNFOuElUEYm"}
{"genre": "pinoy city pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0zkpwLJhA8Mw3nAItjoLr5"}
{"genre": "slayer", "spotify_playlist_url": "https://open.spotify.com/playlist/5RSFiF5lKFazAm26oCvJO2"}
{"genre": "memphis phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/6aX4TX8M7l5Po8LgogfBYO"}
{"genre": "danspunk", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ew6UU6dhWHNs8f7qr9eA5"}
{"genre": "polish alternative rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1cddL8bN1CIRCz6RW8uxVX"}
{"genre": "uk pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/36ixGm7UcqjpBUEHmAY1R1"}
{"genre": "indie rock mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/7KSROI8I1NMYefNsb0TVlc"}
{"genre": "bhangra", "spotify_playlist_url": "https://open.spotify.com/playlist/5JQGQrj5NYeAgUvfw5IPp5"}
{"genre": "russian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7anhpPEbxHYyZEzZj7cZ5p"}
{"genre": "chill dream pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0HGczg4L8Tx36FK5Wktk0N"}
{"genre": "quran", "spotify_playlist_url": "https://open.spotify.com/playlist/2fGISxSz9tC1fkRX2qZdDW"}
{"genre": "classic turkish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6NVtU9wDVVEjDooOWjCFGU"}
{"genre": "dark techno", "spotify_playlist_url": "https://open.spotify.com/playlist/5ba2wVOCMBIf5jMl5lRsGY"}
{"genre": "gothenburg indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3FRB6984xpSb7nal9CtWH9"}
{"genre": "musica gaucha tradicionalista", "spotify_playlist_url": "https://open.spotify.com/playlist/63RZRRpDAXIsWgSpUbmMBX"}
{"genre": "boston indie", "spotify_playlist_url": "https://open.spotify.com/playlist/56BvRtTh50Awa4zOGC70o2"}
{"genre": "quebec indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4uRfUMUWYXOtFiSD4pFfbn"}
{"genre": "uk house", "spotify_playlist_url": "https://open.spotify.com/playlist/6MylRBnwQpJ7KlEnCQgSpd"}
{"genre": "psychedelic trance", "spotify_playlist_url": "https://open.spotify.com/playlist/2xaiaEMr3drIoAsn397mtX"}
{"genre": "neoclassical darkwave", "spotify_playlist_url": "https://open.spotify.com/playlist/1Z81LBzQBw2K5vfTpWzyVr"}
{"genre": "oc rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3yczgLoQTWStIgAm1Mr0xF"}
{"genre": "rave", "spotify_playlist_url": "https://open.spotify.com/playlist/4aId92f7OaneHjOx0emyjz"}
{"genre": "vapor pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6PKNQqVFKlj0RA4zv1sdhd"}
{"genre": "cdo indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1A9QDP74Qx4LBAtrsgmIYk"}
{"genre": "classic venezuelan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3frQnXFys0NQpGdzsANq1m"}
{"genre": "kazakh hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/08lTVqAFOUe8ceYAjWf5vU"}
{"genre": "guadalajara indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1VnqViluZQhxqcgWN1R8mR"}
{"genre": "german alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0PjlGObsM3O3lx4FRZNIYL"}
{"genre": "karadeniz pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4EOruafleTkYnL1IAaevvk"}
{"genre": "post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3G9lrZrzBwmQ1F3OvvvV6d"}
{"genre": "children's folk", "spotify_playlist_url": "https://open.spotify.com/playlist/76RZ7N9XkpYaE5Zvtt8lS8"}
{"genre": "polish drill", "spotify_playlist_url": "https://open.spotify.com/playlist/3hWzvzMYrXLwrlazz9CJx3"}
{"genre": "vaporwave", "spotify_playlist_url": "https://open.spotify.com/playlist/6R9NIMDGt0sK7k1EggBAhj"}
{"genre": "hungarian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1BPFKmeIcqzGOU43oA3rAg"}
{"genre": "alternative americana", "spotify_playlist_url": "https://open.spotify.com/playlist/3C2FLsEbuhOQ2lUDdc7IyF"}
{"genre": "hyphy", "spotify_playlist_url": "https://open.spotify.com/playlist/6ovzr8QuZNSVBiNI0uyS36"}
{"genre": "easycore", "spotify_playlist_url": "https://open.spotify.com/playlist/3RbRDy3iktE2Zf0AP6cCK3"}
{"genre": "new beat", "spotify_playlist_url": "https://open.spotify.com/playlist/3FYtlLBnRUa6zk77HtEwXo"}
{"genre": "indonesian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0x3CJjEE1PFDkzRtjxbrwq"}
{"genre": "instrumental grime", "spotify_playlist_url": "https://open.spotify.com/playlist/534dDLa6qUAXMp5paJfNbu"}
{"genre": "punk urbano", "spotify_playlist_url": "https://open.spotify.com/playlist/6Q8PsqsJG9adI3dZzXI4NC"}
{"genre": "reggae uruguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/4FJvGYgqWG7etqmqE655tN"}
{"genre": "khaliji", "spotify_playlist_url": "https://open.spotify.com/playlist/6QMBZIONDABjF1ZGDFwcSM"}
{"genre": "opera metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0vGEzqc4IQ59yiffuDz9jB"}
{"genre": "scottish indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0Gw9KRXYUosqIqSg11QCHS"}
{"genre": "ann arbor indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2GiU50Y6j2oioclfkqlcC4"}
{"genre": "study beats", "spotify_playlist_url": "https://open.spotify.com/playlist/7gMAoS3RpftL5PDiOu1ug0"}
{"genre": "vintage italian soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/3H2s2HGReZFS8HKHNutpXg"}
{"genre": "folk rock italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/4tXvolMJX9FQDMZaSVgA12"}
{"genre": "mexican pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3cVAl7O4S4qAqTRFTcwN8p"}
{"genre": "midwest emo", "spotify_playlist_url": "https://open.spotify.com/playlist/6hXmqavi8q0NJ5u6PRt0MG"}
{"genre": "cumbia paraguaya", "spotify_playlist_url": "https://open.spotify.com/playlist/7lCxOOLZRXDUXummk4xJIL"}
{"genre": "italian romanticism", "spotify_playlist_url": "https://open.spotify.com/playlist/0uFxobS0uJfFiTCkiG1J47"}
{"genre": "russian drill", "spotify_playlist_url": "https://open.spotify.com/playlist/7lRoT7GFNqADxLXa4Dw0RI"}
{"genre": "swedish hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1U7Vxyzrqtj2XlPrWoj5DC"}
{"genre": "romanian house", "spotify_playlist_url": "https://open.spotify.com/playlist/4DhmzKmnTZLClVZLPPHawZ"}
{"genre": "viral trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2A6Y6Pd9IBETbI1Rx0dw3h"}
{"genre": "liverpool indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6Lme4XrGrtLxfFdMTXZtsv"}
{"genre": "pinoy drill", "spotify_playlist_url": "https://open.spotify.com/playlist/12BpLC1kSywH93VCLkKd6I"}
{"genre": "bandinhas", "spotify_playlist_url": "https://open.spotify.com/playlist/6VBe6cQvmjbByAhWav0Qbq"}
{"genre": "experimental rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3iC8vhGrOS9XvvWBz85jfF"}
{"genre": "northern irish indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1fe9VfOKBZBwKQtblm4Ceq"}
{"genre": "bluegrass", "spotify_playlist_url": "https://open.spotify.com/playlist/5JJqX7mabvOf6x2SfHqnzU"}
{"genre": "jazz boom bap", "spotify_playlist_url": "https://open.spotify.com/playlist/4gV5tlVTMLPbFQqkd8LxWh"}
{"genre": "early us punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6i88VWYabg4ZArz3jVJ5c2"}
{"genre": "dub", "spotify_playlist_url": "https://open.spotify.com/playlist/1nAMu3VI1913Bl8P6joGdE"}
{"genre": "spectra", "spotify_playlist_url": "https://open.spotify.com/playlist/2WTTJ6Punvhns8Evgh2AC3"}
{"genre": "nashville singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/1KOBG9ii88HYjoO6ndXMho"}
{"genre": "drill chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/7hJRpzRRrmhbDN6bpsFWk9"}
{"genre": "classic danish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6uRm8wS0P52MoXspeFSJul"}
{"genre": "ambient guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/59Pr9qBrHMBhmlgWUkXUjh"}
{"genre": "piano blues", "spotify_playlist_url": "https://open.spotify.com/playlist/58hb46oJEDVQJxoew4Er8q"}
{"genre": "indian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4JtowPifE700fO0oqyMFSD"}
{"genre": "horror punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3PgVUwML7OiR7vkkFYrlj1"}
{"genre": "pinoy alternative rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5saZfqsqw3aREGp6oA1bs8"}
{"genre": "yugoslav rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7KuZSebZlQto9drDc7l5tE"}
{"genre": "turkish instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/5RlrJbvsNxoGvxAbXhzjYQ"}
{"genre": "folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5E9beuWK1DSrB7BLNqXqCD"}
{"genre": "melodic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/20iIYgQhyO7JlYOGsFYu0h"}
{"genre": "classic french pop", "spotify_playlist_url": "https://open.spotify.com/playlist/32oRpD9BYsQAGVvIDWKJnj"}
{"genre": "russian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/3Eqk8Q21vdcEw6PwYSXwnD"}
{"genre": "new jersey hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2wFmDMfr5WYkNfkYbA6E30"}
{"genre": "rune folk", "spotify_playlist_url": "https://open.spotify.com/playlist/43vEWQnhiRFtl8edALAc0x"}
{"genre": "french techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0eHVWJjMBIcxsdcgc6gtXt"}
{"genre": "technical death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2fFD2vCjvzLlNegSiITgXf"}
{"genre": "magyar trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1XGHn6PxRDzkelS4YVlhaU"}
{"genre": "indonesian viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6oDViKcW0pnol9cJVJ4aiy"}
{"genre": "rap underground argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/67YWfVGQFqsd0gy9sVpSxH"}
{"genre": "norwegian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1NJP3X0lK6XyEeKlI7m8Fb"}
{"genre": "dancehall queen", "spotify_playlist_url": "https://open.spotify.com/playlist/3pzSGkzUJDkkNvNBq1lrx0"}
{"genre": "gospel r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/6CBOBJn4M4ql1LHSdHhkbz"}
{"genre": "polish viral rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1pk59BcOiRwpMVttf3NVLK"}
{"genre": "south african house", "spotify_playlist_url": "https://open.spotify.com/playlist/6I1LKsxUEASQ3EkgmkCEry"}
{"genre": "icelandic classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3pyyIvUUnrPFSrZ9j7O5pq"}
{"genre": "viral afropop", "spotify_playlist_url": "https://open.spotify.com/playlist/6v6bVui4eQG1Av5Ri5f6w5"}
{"genre": "wave", "spotify_playlist_url": "https://open.spotify.com/playlist/4LMXDmIn72kgOz2tlneVG2"}
{"genre": "german metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4xuMjOPD5nNuJqxDLtvAo7"}
{"genre": "pop minang", "spotify_playlist_url": "https://open.spotify.com/playlist/4tICMiP4u7L3uHQtGT6kRZ"}
{"genre": "progressive groove metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5DXacEpgPNVZjnPQU6JiIi"}
{"genre": "deep turkish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4ML7JSFmkkJipKldJqZGbN"}
{"genre": "pink noise", "spotify_playlist_url": "https://open.spotify.com/playlist/1UhVTsmxTuHlzmtEwOWjg6"}
{"genre": "contemporary jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0M2STcvX62sBK5YuLTE076"}
{"genre": "classic house", "spotify_playlist_url": "https://open.spotify.com/playlist/2dzVUieQEga2NiLQT4uTR2"}
{"genre": "rhythm and blues", "spotify_playlist_url": "https://open.spotify.com/playlist/4uSZwUcMhCdfspqtWaQGwD"}
{"genre": "classic israeli pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7FjCHpdw02MoFqpy7d1DJJ"}
{"genre": "glee club", "spotify_playlist_url": "https://open.spotify.com/playlist/2IKefe4UNnh5F4QQ51yOz0"}
{"genre": "american folk revival", "spotify_playlist_url": "https://open.spotify.com/playlist/6YVEV28McmK71mOrvNmVzZ"}
{"genre": "kosovan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2VVXvoVHgohWTQAM4fhct6"}
{"genre": "rva drill", "spotify_playlist_url": "https://open.spotify.com/playlist/7K39HrYufzDKspzLYbss1I"}
{"genre": "atmosphere", "spotify_playlist_url": "https://open.spotify.com/playlist/486PMRN6a8m6RTO5ypNc9I"}
{"genre": "peruvian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2jOeUlyI9UeiGlPp6JYVAN"}
{"genre": "zhenskiy rep", "spotify_playlist_url": "https://open.spotify.com/playlist/4lCP4GdpJDW6u6vgUu3aGd"}
{"genre": "bc underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/62iU93fUNvuhYsmVAZGk8f"}
{"genre": "pinoy indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5166vpEenpiy4kVU9XafbS"}
{"genre": "uk dancehall", "spotify_playlist_url": "https://open.spotify.com/playlist/0vcUt06PMmyZUJ9BlAu1Xp"}
{"genre": "kurdish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6EC3lo1QkeoX9u0lV3NpWh"}
{"genre": "gaming dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/3fNf910W3Pn6kodHqV5YFM"}
{"genre": "danish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/50gbwtczrJEW7WRaI9077I"}
{"genre": "spanish folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0iFBtJuqERDcTtFuhqQGbG"}
{"genre": "pinoy singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/3hK3qpOKPXABcmy8ktlMaX"}
{"genre": "deep latin christian", "spotify_playlist_url": "https://open.spotify.com/playlist/4m1wSVoaReTpLfp76SfH8M"}
{"genre": "north carolina roots", "spotify_playlist_url": "https://open.spotify.com/playlist/566sn2RbqCdpyXpeO6iZyq"}
{"genre": "chill guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/4XhnpVMVwnL8e7EHxA2Rna"}
{"genre": "folktronica", "spotify_playlist_url": "https://open.spotify.com/playlist/6JPd0xG3fBmhUSlxsTfPyW"}
{"genre": "croatian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3VlYo96GLw7e1ceEDaZq0w"}
{"genre": "swedish soul", "spotify_playlist_url": "https://open.spotify.com/playlist/3BSDQ6LVGNSTf3Ty8ilFK5"}
{"genre": "bergamo indie", "spotify_playlist_url": "https://open.spotify.com/playlist/42bmY8XpPPDJh1pbyBcejd"}
{"genre": "lo-fi house", "spotify_playlist_url": "https://open.spotify.com/playlist/0RHJbt2wuy7LkUiIL8WdYE"}
{"genre": "puerto rican rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4EOv49pXM5JJ7BTaas6P9d"}
{"genre": "idol rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0koXwc1zC8xeYcwaATGQcI"}
{"genre": "idol", "spotify_playlist_url": "https://open.spotify.com/playlist/7y06Quhxd73Bu5l6GNJDYw"}
{"genre": "kolsche karneval", "spotify_playlist_url": "https://open.spotify.com/playlist/1BIzxJFojkeKpju3tfHgGI"}
{"genre": "rocksteady", "spotify_playlist_url": "https://open.spotify.com/playlist/5pyY6lntlity8qpik69gsD"}
{"genre": "acoustic blues", "spotify_playlist_url": "https://open.spotify.com/playlist/1wsiIqm8FwH4FPW68LBFCr"}
{"genre": "latinx alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/0TOn5GNhITcfhKiZRuQHV1"}
{"genre": "frenchcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3b9YnVCg1sEUoXlRwQvBV2"}
{"genre": "washington indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1QuMCblPgeS7gIaqGiQ2CU"}
{"genre": "soca", "spotify_playlist_url": "https://open.spotify.com/playlist/3n6YvqGNXChaeK48hiYzRz"}
{"genre": "auckland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5It7e74uGGgnm8KgGlnyxO"}
{"genre": "oyun havasi", "spotify_playlist_url": "https://open.spotify.com/playlist/1MKfFarIiLoOPKO0m60CRF"}
{"genre": "central asian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3xkaCFQB02mMRSMDSislJe"}
{"genre": "antideutsche", "spotify_playlist_url": "https://open.spotify.com/playlist/1C95qjZfG2de7TjBsedFzZ"}
{"genre": "christian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/432O6ZucUUusfi3KpPf7VP"}
{"genre": "chiptune", "spotify_playlist_url": "https://open.spotify.com/playlist/1LFNDgI96e297dxed2dZZa"}
{"genre": "spanish modern rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6n2KfHmhzxgfssyfKwnk6d"}
{"genre": "post-minimalism", "spotify_playlist_url": "https://open.spotify.com/playlist/6MEINfTsX47SmVv3JLvQwm"}
{"genre": "rap uliczny", "spotify_playlist_url": "https://open.spotify.com/playlist/0xJ8SgqYzJC79eu4JmfXN7"}
{"genre": "nederlandse hardstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/0oaRihpf0Vq2jbsk0tnOPD"}
{"genre": "gothenburg metal", "spotify_playlist_url": "https://open.spotify.com/playlist/18DLKGkmiAelCa1fE0WhCp"}
{"genre": "icelandic experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/3lLXYcLaUynh40EobqkiV7"}
{"genre": "kabarett", "spotify_playlist_url": "https://open.spotify.com/playlist/7ptDZTQFdaqA519GUfff8k"}
{"genre": "latin classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7KHzvfzU7SVFsooG7EhsQZ"}
{"genre": "ghanaian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/5oxwyXwuzlbI3wpQASvxzF"}
{"genre": "deep pop edm", "spotify_playlist_url": "https://open.spotify.com/playlist/5ouQTmehX3Fu4L3JmMsTo3"}
{"genre": "jangle pop", "spotify_playlist_url": "https://open.spotify.com/playlist/31vdE2ocXKz1Zmd7jrUqWO"}
{"genre": "calming instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/64rpUcla6sbXJFkaOAq1qu"}
{"genre": "ethereal wave", "spotify_playlist_url": "https://open.spotify.com/playlist/54eDlcyhSBrHMt6dbHyFWp"}
{"genre": "emo rap italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/518nIGwtzomegRteO67NXk"}
{"genre": "polish underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0RTY8qHkDwxKLsrUUbPQ71"}
{"genre": "musica aragonesa", "spotify_playlist_url": "https://open.spotify.com/playlist/3wa7yvWcZv5Sv6pxZvIN2U"}
{"genre": "turkish edm", "spotify_playlist_url": "https://open.spotify.com/playlist/6kTzDCR055zwKksH44tCyF"}
{"genre": "balkan trap", "spotify_playlist_url": "https://open.spotify.com/playlist/3SvVSF8Ex8YyCjjaW9bojd"}
{"genre": "gothic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/14bpCLkVLcFmPMzGVXI7tN"}
{"genre": "classic peruvian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3eHaYovxdLWA7ix5R2Iy40"}
{"genre": "italian opera", "spotify_playlist_url": "https://open.spotify.com/playlist/5LNeUSji65Sd0n6qxl84bh"}
{"genre": "gospel antigas", "spotify_playlist_url": "https://open.spotify.com/playlist/1sbrmzh83rDkpMTLYXzLdg"}
{"genre": "celtic punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5RoP1jxkqFRRiN0KhxjFp6"}
{"genre": "irish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5VedI2ZC26yEKJ8JTA7OuW"}
{"genre": "dream plugg", "spotify_playlist_url": "https://open.spotify.com/playlist/6xkJhwQJihGRfSxZ3cS5H0"}
{"genre": "classical drill", "spotify_playlist_url": "https://open.spotify.com/playlist/0PeBDaA3WDU5bDOPNFdPeN"}
{"genre": "rock andaluz", "spotify_playlist_url": "https://open.spotify.com/playlist/7KR20I77teoASrTYZHDCXJ"}
{"genre": "focus beats", "spotify_playlist_url": "https://open.spotify.com/playlist/4s0siSTRtglRvQKxpWJ6pM"}
{"genre": "j-indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZvU7A9di2xjWA5b8Z9x3u"}
{"genre": "rap boricua", "spotify_playlist_url": "https://open.spotify.com/playlist/69sEB8S1P3TnrFvVVSYZOD"}
{"genre": "indonesian city pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6VEITKpUHdcyuj01oxD4xC"}
{"genre": "afrobeat", "spotify_playlist_url": "https://open.spotify.com/playlist/2LxpkqYcJkFGJxBbDsvveK"}
{"genre": "rap uruguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/2snnzc6loGGiQ6gitdUggi"}
{"genre": "pop teen brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/6CQHwTCpNh8suN7AWQzCcB"}
{"genre": "dark plugg", "spotify_playlist_url": "https://open.spotify.com/playlist/5Dq1xQnRQEIlSbfRsyoxy1"}
{"genre": "idol kayo", "spotify_playlist_url": "https://open.spotify.com/playlist/2EeZha8FGL1avV9fYqBy2K"}
{"genre": "kiwi rock", "spotify_playlist_url": "https://open.spotify.com/playlist/36VbduhjU89A2hn4364aba"}
{"genre": "maga rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1M96F75vfbxKp93vQxb3HX"}
{"genre": "pop chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/29qGA62efPsgLp6kblUPSg"}
{"genre": "chinese indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0wYpNflDnwSC3OZqdrQCBt"}
{"genre": "brain waves", "spotify_playlist_url": "https://open.spotify.com/playlist/56jIKC6ujc2VuT8p8Q8EIx"}
{"genre": "argentine heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5WLL1Lse5Juik9bTGbj1f1"}
{"genre": "chinese singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/59TtFc8U1gqn3hcQd1nBoV"}
{"genre": "arab electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/19Xxt5xhpzYMi9z4grHrnb"}
{"genre": "chihuahua indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0fhqtFBItgAOH9OO6rLuaX"}
{"genre": "progressive post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4tzo97AF7cGmRpYnnMosHP"}
{"genre": "microhouse", "spotify_playlist_url": "https://open.spotify.com/playlist/6FbDQuTcGT0IoZCtsbCISv"}
{"genre": "portland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5qOzPfuSBMWu4XEFEuMnvR"}
{"genre": "comedy rap", "spotify_playlist_url": "https://open.spotify.com/playlist/53dW6Z6TQYQElWRkcI0Bsh"}
{"genre": "samba-jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZnLAsxcy0c9BqUtNBjMCz"}
{"genre": "classic garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/34eD5NULhGL1L8yyIM3wwj"}
{"genre": "game mood", "spotify_playlist_url": "https://open.spotify.com/playlist/1l4otzwhS8LnLsWKducSxa"}
{"genre": "portland hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4km1u4CDqjbRX4Z8kAQail"}
{"genre": "ukrainian viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5mfYEZ678jSqX3VkLfO0rE"}
{"genre": "belgian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1OXxQpaCXYbPe3lYjUdcuq"}
{"genre": "russian grime", "spotify_playlist_url": "https://open.spotify.com/playlist/3MM7Ruf9IwTT3OWWjDIlng"}
{"genre": "chilean indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4I49J6EQBbt7X4lLTg2WiQ"}
{"genre": "french opera", "spotify_playlist_url": "https://open.spotify.com/playlist/0AOzKluE1BrzvAAGnoV66A"}
{"genre": "anime phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/3jsBX2P36Xj2fnq4TfSqHA"}
{"genre": "glitchbreak", "spotify_playlist_url": "https://open.spotify.com/playlist/5aPKPDrqsxBQSST33NOsFw"}
{"genre": "west bengali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3vtZXD4r0laZm8MgRUUTC2"}
{"genre": "rock catala", "spotify_playlist_url": "https://open.spotify.com/playlist/047iNw5YrSgTaRG2yTaTYV"}
{"genre": "neue deutsche welle", "spotify_playlist_url": "https://open.spotify.com/playlist/21g0BS05MXlBswYAY2ZuYd"}
{"genre": "fourth world", "spotify_playlist_url": "https://open.spotify.com/playlist/334HQUev7fUfGPdNWg73Xa"}
{"genre": "native american traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/68rmL0aONaVZnsaa3v9aec"}
{"genre": "music box", "spotify_playlist_url": "https://open.spotify.com/playlist/0mKxo1d7Rshs6q4BrCEL5I"}
{"genre": "bgm", "spotify_playlist_url": "https://open.spotify.com/playlist/3qmXZHBleLLE52bE1XYAfM"}
{"genre": "samba paulista", "spotify_playlist_url": "https://open.spotify.com/playlist/5SViJo1WxEsxfO8y3Sd8yY"}
{"genre": "viking folk", "spotify_playlist_url": "https://open.spotify.com/playlist/08gr00aRmFbRxf6DI6kSXM"}
{"genre": "neomelodici", "spotify_playlist_url": "https://open.spotify.com/playlist/6647V02cNn9NzfJeaM0baS"}
{"genre": "comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/4PDKZIGNpydaoI7pZuxyh7"}
{"genre": "chicago house", "spotify_playlist_url": "https://open.spotify.com/playlist/6Wel9lJLvOpiZHBJNF19jn"}
{"genre": "tropical alternativo", "spotify_playlist_url": "https://open.spotify.com/playlist/5fp3JHTkuroJ4jwocc64nU"}
{"genre": "vietnamese trap", "spotify_playlist_url": "https://open.spotify.com/playlist/5GgeLstLaU0EeYEJa3NlFO"}
{"genre": "musica angolana", "spotify_playlist_url": "https://open.spotify.com/playlist/2diUVDFxNHNzERh89Ud1PO"}
{"genre": "samba-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2lyeF035NuygelMAPmGs5Y"}
{"genre": "brega romantico", "spotify_playlist_url": "https://open.spotify.com/playlist/3k1aIY9ATvM4X6PvEYW7V1"}
{"genre": "korean instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/2zoo13IlfY1VrvdX9NfePC"}
{"genre": "halloween", "spotify_playlist_url": "https://open.spotify.com/playlist/3c4jETt4Inrxg7nN4bWehP"}
{"genre": "trap pesado", "spotify_playlist_url": "https://open.spotify.com/playlist/3G4WM2M9DJkEy2RXn5sCq2"}
{"genre": "theme", "spotify_playlist_url": "https://open.spotify.com/playlist/38KAIcOl7fuUVC3LP9vn6F"}
{"genre": "persian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/63NyygAMIKSxy6LRG0eT5i"}
{"genre": "rap underground mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/5ZnzanI9mpeinOWV4rqNr1"}
{"genre": "narodna muzika", "spotify_playlist_url": "https://open.spotify.com/playlist/38aij8mk37WZtI9qH7PIHl"}
{"genre": "swedish indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4RAPHABokGFKIujJvYgPkS"}
{"genre": "trap dominicano", "spotify_playlist_url": "https://open.spotify.com/playlist/7lJ1swS4ihi86snpTCWJSV"}
{"genre": "contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3w6Xp6CzaJEhZgCQR6tqGb"}
{"genre": "southern americana", "spotify_playlist_url": "https://open.spotify.com/playlist/74lUBySWkWlasy8qCmtXAP"}
{"genre": "fotbollslatar", "spotify_playlist_url": "https://open.spotify.com/playlist/2pmUHfzCVyrWGCUkmF4xah"}
{"genre": "texas blues", "spotify_playlist_url": "https://open.spotify.com/playlist/3x4eZnKeTjOEUvl21X1j67"}
{"genre": "huzunlu sarkilar", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ek20wpQqKamII0X4lPhpA"}
{"genre": "malayalam pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2pO8ymNNHcGPSq5Uhverc2"}
{"genre": "electrofox", "spotify_playlist_url": "https://open.spotify.com/playlist/3oBf8kc02esfPC3PUuSZks"}
{"genre": "partido alto", "spotify_playlist_url": "https://open.spotify.com/playlist/035YZGOcXSUMc2ZaOVd7NQ"}
{"genre": "rap nacional antigo", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZFIXdKI7atDSvPG9oWKuK"}
{"genre": "italian pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2lRquSJcjNvHMjlEl8zLbg"}
{"genre": "murcia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2BPyOhw2SGnWTvkwa2IwJv"}
{"genre": "german trance", "spotify_playlist_url": "https://open.spotify.com/playlist/0WiZH08R0qTR5134dWr54G"}
{"genre": "reggae tuga", "spotify_playlist_url": "https://open.spotify.com/playlist/1WnFoROuRDgngEYyU1D2rI"}
{"genre": "concepcion indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0HXfd4OQMYSyRD5Fc6mHqM"}
{"genre": "canadian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/72tMdtrWPl1PXHYk3Y0gRf"}
{"genre": "pop quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/7HGA0EtEFyFOySfH2j9LGm"}
{"genre": "uk melodic rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7iUYGZURZOX9qhZbICjihp"}
{"genre": "piano worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5lVuY5dJVBbAYLA0L9KJix"}
{"genre": "new jersey punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1vFKPl9m36U5Yx4UAZFaAr"}
{"genre": "instrumental post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7m4SvnJOObW34xVsLdXx30"}
{"genre": "nordic house", "spotify_playlist_url": "https://open.spotify.com/playlist/0gdPJDXUHuVod0WX0DEZpx"}
{"genre": "australian alternative pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7JEBOiPat4SDUDjcGgc4YP"}
{"genre": "dutch metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0f2OuB5CtLhR811C1epsFr"}
{"genre": "volkspop", "spotify_playlist_url": "https://open.spotify.com/playlist/73AbntsjRDiGcI0WsI8rjd"}
{"genre": "kavkaz", "spotify_playlist_url": "https://open.spotify.com/playlist/5QkHBZpNmTjFpKbBL5eN0W"}
{"genre": "polish indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5BIwaSlscQM2LmYTV8VtZ9"}
{"genre": "no beat", "spotify_playlist_url": "https://open.spotify.com/playlist/2EgB8Zv5VQcRUQFmWkaFcy"}
{"genre": "japanese new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/769n3pN0Z2qOcbHFL67STK"}
{"genre": "cologne indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4kzjbngQoKb5EcguDEhplf"}
{"genre": "new jersey underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/422wMcRPB4OzleL2G6goAJ"}
{"genre": "reggae do maranhao", "spotify_playlist_url": "https://open.spotify.com/playlist/2YRdRgBOGXOk9wZWUit7pI"}
{"genre": "french tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/0mAuWjb7YCXDfP1oaVTSDk"}
{"genre": "minimal melodic techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0O5O7OKpXKZkWUBRVFAJ1g"}
{"genre": "japanese pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1K9zy18wivsvVc42LDcQnA"}
{"genre": "lagu timur", "spotify_playlist_url": "https://open.spotify.com/playlist/0S6mwmMZjJwmPm6Mtt20Oa"}
{"genre": "slc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4fAU0MQfmzDQkMZ5pR0zY3"}
{"genre": "mizrahi", "spotify_playlist_url": "https://open.spotify.com/playlist/0SCBGl0HGDRkgg8YQmtCF4"}
{"genre": "musica costena", "spotify_playlist_url": "https://open.spotify.com/playlist/3TgrDupMYLUWDWseF3oHgs"}
{"genre": "entehno", "spotify_playlist_url": "https://open.spotify.com/playlist/4zc2XMFDiVk2Y2RdV7HBeF"}
{"genre": "lustrum", "spotify_playlist_url": "https://open.spotify.com/playlist/1z4JkNqD4UHNWMTfIOKZBe"}
{"genre": "balkan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6BIS9zOW7eMTURxORLJi2g"}
{"genre": "hip hop quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/773SD6gBu3yZrbUyBu3DG4"}
{"genre": "cowboy western", "spotify_playlist_url": "https://open.spotify.com/playlist/7DbE34FMEbrWv8GhU9NeH0"}
{"genre": "uk experimental electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/7nC4B9gtrOBQ7aT1J7FiOt"}
{"genre": "malaysian mandopop", "spotify_playlist_url": "https://open.spotify.com/playlist/18IducTdBJ0zea33VOACTN"}
{"genre": "welsh metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0K0Nr4kOt76ScRRAJtE43R"}
{"genre": "reggae cristao", "spotify_playlist_url": "https://open.spotify.com/playlist/4BPmThDHR47PaOqWnG3igj"}
{"genre": "indonesian emo", "spotify_playlist_url": "https://open.spotify.com/playlist/4umpvMoqfoNM3DbdkMA8SB"}
{"genre": "metallic hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5SZlQCSNQoEmUc7lMMAX59"}
{"genre": "belgian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1W3Jws5GbVKXSS35HmMKnQ"}
{"genre": "rochester mn indie", "spotify_playlist_url": "https://open.spotify.com/playlist/01Ree04AniSfuk5RVKIBUr"}
{"genre": "liedermacher", "spotify_playlist_url": "https://open.spotify.com/playlist/2CUoWOcTZtUfKD1DeRFFcK"}
{"genre": "victoria bc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3tAVd6GDlJaoyH0BxYCakQ"}
{"genre": "japanese viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0pXSOiNK2pCoGc7X0SZ24b"}
{"genre": "bay area indie", "spotify_playlist_url": "https://open.spotify.com/playlist/20uxYbOiSyqlO3IsHSbeK5"}
{"genre": "trap peruano", "spotify_playlist_url": "https://open.spotify.com/playlist/4d0kql6PcewUsvEgS60q2v"}
{"genre": "ska chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/7AWU30giFff2HhHrApuFGz"}
{"genre": "marathi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0VgyqskAG7vnQto157aNWc"}
{"genre": "trap antillais", "spotify_playlist_url": "https://open.spotify.com/playlist/0xnpiHFeCrlMrXeuvOKXqg"}
{"genre": "laboratorio", "spotify_playlist_url": "https://open.spotify.com/playlist/1qDYupZn3TPJIDFR1tzETe"}
{"genre": "chillsynth", "spotify_playlist_url": "https://open.spotify.com/playlist/6oWtD6La5xHpdSGJXb1FnN"}
{"genre": "minimalism", "spotify_playlist_url": "https://open.spotify.com/playlist/7fENFDTpoFZTZN84EAyUhY"}
{"genre": "chalga", "spotify_playlist_url": "https://open.spotify.com/playlist/0f2i8kH0oavRf1HcumJ7kF"}
{"genre": "dutch cabaret", "spotify_playlist_url": "https://open.spotify.com/playlist/4DODYWjfOmrnzvGVfeusIs"}
{"genre": "brega funk", "spotify_playlist_url": "https://open.spotify.com/playlist/2s2ntVO9pqBxQy2q9CD7ov"}
{"genre": "chicago blues", "spotify_playlist_url": "https://open.spotify.com/playlist/0mOE2PzIQc6LljRmTSJsGy"}
{"genre": "hungarian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4HwajiqdbPNfRcd0BcD2zc"}
{"genre": "trap tuga", "spotify_playlist_url": "https://open.spotify.com/playlist/7t4tzhzcgMECBO6RaUEYiD"}
{"genre": "barnemusikk", "spotify_playlist_url": "https://open.spotify.com/playlist/4GVEkhIuT06BqEpbHNgSjt"}
{"genre": "birmingham grime", "spotify_playlist_url": "https://open.spotify.com/playlist/6bRM5H6H9bkPMq3r6QRO1S"}
{"genre": "parody", "spotify_playlist_url": "https://open.spotify.com/playlist/640z0C8610y24rsEpqQYQA"}
{"genre": "nuevo folklore mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/1YlQnXnGXy3oUayr7CunWv"}
{"genre": "rap tunisien", "spotify_playlist_url": "https://open.spotify.com/playlist/0C3BNlIKF3301e2f7cBnhq"}
{"genre": "future rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5u8tbxvQvJtevUBqXAwJFs"}
{"genre": "jamaican hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3TrVU2j0y1Og2K9wJC7Mh5"}
{"genre": "mantra", "spotify_playlist_url": "https://open.spotify.com/playlist/0vWBxXexiRvWBnfTwswJQH"}
{"genre": "classic iskelma", "spotify_playlist_url": "https://open.spotify.com/playlist/5dGp6sdifJFkl9eZA3WaKx"}
{"genre": "new weird america", "spotify_playlist_url": "https://open.spotify.com/playlist/7yFrafoJ9eCQDnwPrBVGWH"}
{"genre": "colombian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5e17Q4c5YyPNfFk1Fe3IwE"}
{"genre": "brazilian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0GhyufHLiAxUoRloo1mZM1"}
{"genre": "big band", "spotify_playlist_url": "https://open.spotify.com/playlist/2cjIvuw4VVOQSeUAZfNiqY"}
{"genre": "japanese old school hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6YsPOwWFDeraCgnUg98Cca"}
{"genre": "kermis", "spotify_playlist_url": "https://open.spotify.com/playlist/1rJAAbDgTJhgw7WDRjYmm2"}
{"genre": "dong-yo", "spotify_playlist_url": "https://open.spotify.com/playlist/20lnyPyAJmQD2HbHYyObOp"}
{"genre": "diy emo", "spotify_playlist_url": "https://open.spotify.com/playlist/6Sk80JvC6Isqyf1Bs01r9j"}
{"genre": "plug brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/1L4oR1zq82mNqf5ssaMjNu"}
{"genre": "uk garage", "spotify_playlist_url": "https://open.spotify.com/playlist/62PxpGVt45pYZ8O66VVZWP"}
{"genre": "italian soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/3iUx0accVO1EwlLPg1u7Dh"}
{"genre": "australian indigenous music", "spotify_playlist_url": "https://open.spotify.com/playlist/6B9CpGm9IBQJzncRCPw0dG"}
{"genre": "deathgrind", "spotify_playlist_url": "https://open.spotify.com/playlist/06ZkXzaIiW3gWbdnQW0bYn"}
{"genre": "neo classical metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6IzFj8GilAEayVRo4jBfM0"}
{"genre": "taiwan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5BicL5AIoYYtnKzLo8IEhf"}
{"genre": "neoclassicism", "spotify_playlist_url": "https://open.spotify.com/playlist/1qJiG40Pdhyt3Mxslpk41M"}
{"genre": "ambeat", "spotify_playlist_url": "https://open.spotify.com/playlist/4BNdtoAweEyMunEAPyH754"}
{"genre": "peruvian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1BBBrRBb66heRlQ9UPdhQ3"}
{"genre": "south african gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/3VKGShOBz2FYrORLpgwTRe"}
{"genre": "swedish country", "spotify_playlist_url": "https://open.spotify.com/playlist/4StF9VDinlQNwMPcWhAfjz"}
{"genre": "symphonic deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZabhuUR9u23fPqnORS5sk"}
{"genre": "lagu melayu", "spotify_playlist_url": "https://open.spotify.com/playlist/51SbeDACNjwd4GtTeeQodt"}
{"genre": "thai folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/03cTd9Ykgkot8M1rA48CP9"}
{"genre": "shanty", "spotify_playlist_url": "https://open.spotify.com/playlist/65o8CHGJHdl6kvNdF66XjX"}
{"genre": "scandinavian r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/6rKNApKAQaPnemPiI8dIJj"}
{"genre": "kwaito", "spotify_playlist_url": "https://open.spotify.com/playlist/20RJLH7bkXLWkHdvrdcszw"}
{"genre": "australian indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0Ssz7lY65e8egtETVJF2Q6"}
{"genre": "east coast reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/0LQq55SqGRhP3aULqBhKdO"}
{"genre": "emoplugg", "spotify_playlist_url": "https://open.spotify.com/playlist/0assY927mdLXpwVVgnRAPQ"}
{"genre": "finnish trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2qIykQqS2iwSA4lkVUR48b"}
{"genre": "indonesian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2FXemjCXofbSNrPVODowoR"}
{"genre": "rock baiano", "spotify_playlist_url": "https://open.spotify.com/playlist/0049OsctYNaJ5swOwvPVls"}
{"genre": "brisbane indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7GrVgeOVSntOJRJrzecUl3"}
{"genre": "greek underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2zrc4XH6zCkuYIHjs3DM5F"}
{"genre": "musica tamaulipeca", "spotify_playlist_url": "https://open.spotify.com/playlist/01sbKFUaWM4B5LArZ5leFr"}
{"genre": "british children's music", "spotify_playlist_url": "https://open.spotify.com/playlist/6CXOnBtD2z6rNI9G6APj8X"}
{"genre": "progressive deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/69bfEySBI2rIRQbBJ1f383"}
{"genre": "arab alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/7eWAz7khBGqJI3uEvG9Eac"}
{"genre": "melodic techno", "spotify_playlist_url": "https://open.spotify.com/playlist/5dO10mMFIZL1rUZTI3k4fZ"}
{"genre": "pinoy pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5xADUgvmwvVgYpPEceBoxu"}
{"genre": "swancore", "spotify_playlist_url": "https://open.spotify.com/playlist/2NAM4VUbbZi2t1y3TfJsvH"}
{"genre": "gregorian dance", "spotify_playlist_url": "https://open.spotify.com/playlist/0MqHxVPXSBnVvIdp5arLVy"}
{"genre": "assamese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1lzyGq6cCB13RuBcf8oJVH"}
{"genre": "future funk", "spotify_playlist_url": "https://open.spotify.com/playlist/7t0fe3aPR0OoVQQi6VDkeC"}
{"genre": "electro jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/293CDKWmDYutJjtVGJaq3L"}
{"genre": "grime brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/1RdPQlKd1vo46KG08yLyiM"}
{"genre": "guaracha", "spotify_playlist_url": "https://open.spotify.com/playlist/23VIA3teQnK7eZha7EDQjr"}
{"genre": "romanian rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5xxIhwNhCZlkyFKpA8hxRj"}
{"genre": "czsk emo rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4izm3QhYxFaqBOrYVf0YAJ"}
{"genre": "wrestling", "spotify_playlist_url": "https://open.spotify.com/playlist/4SHiHmOhFaUjBiCN9kj2qM"}
{"genre": "deep comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/6A74Q1YeY82b4l3zwYFFfm"}
{"genre": "uk contemporary jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5PbFpGjcgYEyyJvl6Z2wt4"}
{"genre": "latin viral rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0eoW0DceOCQoyWLMqBO496"}
{"genre": "strut", "spotify_playlist_url": "https://open.spotify.com/playlist/6FmYzrcSK2ftufgHXOeqlY"}
{"genre": "bergen indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5zhUixQhwpUGFOEf63hZVb"}
{"genre": "tagalog worship", "spotify_playlist_url": "https://open.spotify.com/playlist/2uoIbc4ps6iwqwobnHdDwg"}
{"genre": "country gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/7DZDNqoxWp3uIgwTMHdBN6"}
{"genre": "dark cabaret", "spotify_playlist_url": "https://open.spotify.com/playlist/1Ewzf0JLvLiLBOYTZRxFHP"}
{"genre": "folclore salteno", "spotify_playlist_url": "https://open.spotify.com/playlist/4xrXe1xRIsfgcVzDayZb9j"}
{"genre": "progressive psytrance", "spotify_playlist_url": "https://open.spotify.com/playlist/4rmUSS4GQxpHjuZPf6eiSz"}
{"genre": "dark wave", "spotify_playlist_url": "https://open.spotify.com/playlist/4ac3WdJSdYTu4MeN4MWzEX"}
{"genre": "ska revival", "spotify_playlist_url": "https://open.spotify.com/playlist/4wGggyxDGqchn47ZFITV5b"}
{"genre": "corridos belicos", "spotify_playlist_url": "https://open.spotify.com/playlist/3SNhZoECnpoR8pY89d0S6x"}
{"genre": "new comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/7y6c38VZYmqMEFcLflCxy1"}
{"genre": "russian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/4dS5aqiN32iHnEfPI9XuDu"}
{"genre": "ecuadorian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6nYabBtp0o1uD7Tzr95P0m"}
{"genre": "roda de samba", "spotify_playlist_url": "https://open.spotify.com/playlist/0Udp8KmLYp6OLj7HbBQHKt"}
{"genre": "fado", "spotify_playlist_url": "https://open.spotify.com/playlist/5yLmmznzjfw9EnWo1MFtdL"}
{"genre": "post-screamo", "spotify_playlist_url": "https://open.spotify.com/playlist/0XeSjSOh2uwuysKcBqboqD"}
{"genre": "vintage french electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/2xnB7TJO3T8yTGwrRI98IO"}
{"genre": "carnaval cadiz", "spotify_playlist_url": "https://open.spotify.com/playlist/32A24OgW1EDnuhfs1jwCcL"}
{"genre": "pastoral", "spotify_playlist_url": "https://open.spotify.com/playlist/51fo3JEZp5ZBxb42IPnKOc"}
{"genre": "acoustic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0FaMPDrv7VDRvfoPX9cNy9"}
{"genre": "rock independant francais", "spotify_playlist_url": "https://open.spotify.com/playlist/752p1W4kvVSsrbESrs6iX3"}
{"genre": "texas pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6b1lscdaMR50HSUSLSqNPK"}
{"genre": "alternative roots rock", "spotify_playlist_url": "https://open.spotify.com/playlist/46zaMGzDdLfisrtepPsZsO"}
{"genre": "japanese post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0NhxURiKUiHF89xVByijkI"}
{"genre": "nova musica pernambucana", "spotify_playlist_url": "https://open.spotify.com/playlist/5gkYWQYeSyGJyca144YRw4"}
{"genre": "slovak hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7ajQKzORUThQQYgmGOhIHK"}
{"genre": "musica sinaloense", "spotify_playlist_url": "https://open.spotify.com/playlist/4tkYWV6jijgAeBYuwaqhaw"}
{"genre": "comedy rock", "spotify_playlist_url": "https://open.spotify.com/playlist/72L14B7jz0mAKlF8jdxPlW"}
{"genre": "colombian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6DgTRbBowIyrHkubIMBuVS"}
{"genre": "volksmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/7m1mFRaRjFbQswDVSLTIka"}
{"genre": "belo horizonte indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5VVIPbgaEaK3s41D9pMP5v"}
{"genre": "ostrock", "spotify_playlist_url": "https://open.spotify.com/playlist/7MVsQrHg0heIs7DiltoSdP"}
{"genre": "israeli hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4jOC3uCUvnhMUINXi8CS3T"}
{"genre": "vbs", "spotify_playlist_url": "https://open.spotify.com/playlist/3QgaxpHrzybYfCNCIRswhF"}
{"genre": "xtra raw", "spotify_playlist_url": "https://open.spotify.com/playlist/7oe7qiYLUxsfhZXlT6AIiS"}
{"genre": "musica per bambini", "spotify_playlist_url": "https://open.spotify.com/playlist/5yCcGn665DF9QdmQBor5hB"}
{"genre": "louvor", "spotify_playlist_url": "https://open.spotify.com/playlist/1gT67GuBr4HCKNNhhq6Gnc"}
{"genre": "french jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0sbP0IrO1mrNWiKvuPzDRt"}
{"genre": "hard bass", "spotify_playlist_url": "https://open.spotify.com/playlist/4IDhGicVEt669oWrlCWNUu"}
{"genre": "world devotional", "spotify_playlist_url": "https://open.spotify.com/playlist/105I9WQNZIff3AehjOt8uF"}
{"genre": "industrial hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5oNLeNpkqvL9VqIndPrMVp"}
{"genre": "russian hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/5YzvReYSHL8Vm1VHaSMr0X"}
{"genre": "japanese metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7uYRzhR9AcsXvPj89OYX9d"}
{"genre": "german oi", "spotify_playlist_url": "https://open.spotify.com/playlist/6kDLosKVoIVUmWOwiqY8iw"}
{"genre": "nepali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5bKFENhHRI9jVVZbOxWlD7"}
{"genre": "sinhala pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5gXiJkxddq1pSBsHFQR0gl"}
{"genre": "darksynth", "spotify_playlist_url": "https://open.spotify.com/playlist/7mr4rvyCkgD2fuNdPGYQw9"}
{"genre": "korean indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/11i3s3ZVQ0lUEwsA7MFRVf"}
{"genre": "gregorian chant", "spotify_playlist_url": "https://open.spotify.com/playlist/4FVeqntRIKNOhiVVAx0EZM"}
{"genre": "mambo", "spotify_playlist_url": "https://open.spotify.com/playlist/7pBdTAU2WIt4hx9jL9LKqo"}
{"genre": "deep talent show", "spotify_playlist_url": "https://open.spotify.com/playlist/4JKxumLa2EhDCRrKR72cjI"}
{"genre": "miami bass", "spotify_playlist_url": "https://open.spotify.com/playlist/6eYnoJVvfS5mnh53jWRcVC"}
{"genre": "vietnamese singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/2W8qlNiQFfQJTE6Tj2EIdU"}
{"genre": "classic thai pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0IfFM151rkWcM2k2vomHpg"}
{"genre": "argentine punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7JEemACfnGRp8PLv7wniws"}
{"genre": "samba reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/3FtcTxEpZYngPJLn93Irpv"}
{"genre": "turkish soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/5sSUx1Z8LMMPNY6JtWRQ6r"}
{"genre": "musica andina", "spotify_playlist_url": "https://open.spotify.com/playlist/5iTCp7UPV9Wh4WcT65UadN"}
{"genre": "chinese idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/29W4FPNZsBNek3jA5zKfBh"}
{"genre": "kansas city hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1WIVtDezBpq9HtQ74knR84"}
{"genre": "steampunk", "spotify_playlist_url": "https://open.spotify.com/playlist/7yh29dEvCaEWoTKOiGEK0h"}
{"genre": "experimental ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/1EZksekNRKhPgFNfE6x9pt"}
{"genre": "deathgrass", "spotify_playlist_url": "https://open.spotify.com/playlist/3NDB9BZNcG5K3vgdUPncbT"}
{"genre": "drain", "spotify_playlist_url": "https://open.spotify.com/playlist/1gdxF4FolxtfDph2f3jY12"}
{"genre": "russian viral rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3VKeOhZ2pYJnpJGokFZLJQ"}
{"genre": "j-ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/6ae4jidwa2VozFtzg7DumZ"}
{"genre": "banjo", "spotify_playlist_url": "https://open.spotify.com/playlist/6xIivwu6v2453oCCJk6Wxo"}
{"genre": "cancion infantil mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/1OwnSnDXG1Zn32RV7AMIGA"}
{"genre": "solfeggio product", "spotify_playlist_url": "https://open.spotify.com/playlist/6cygHm6eiwKnnHEJMWqGsm"}
{"genre": "slamming deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3wipiDq6FmTeBHtyj60y3x"}
{"genre": "classic polish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4mAsd6ureHB80hRk5b4Ni4"}
{"genre": "turkce kadin rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0kZ1wslMrw89kqzywLPtQc"}
{"genre": "norwegian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0pRwuHngeEzhd8U0mbZLoQ"}
{"genre": "jungle", "spotify_playlist_url": "https://open.spotify.com/playlist/35Ezi6bCni1zwVOW2rOWDj"}
{"genre": "ecm-style jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6sykPPFmdBMiAQud3Dnmt6"}
{"genre": "abstract beats", "spotify_playlist_url": "https://open.spotify.com/playlist/59xLrarTtVR6GxK8aHETod"}
{"genre": "cello", "spotify_playlist_url": "https://open.spotify.com/playlist/5LvhXeidSF2c8IbGm53pYt"}
{"genre": "ukrainian phonk", "spotify_playlist_url": "https://open.spotify.com/playlist/5EkCWmDPdcM95kbE35PFVp"}
{"genre": "saxophone house", "spotify_playlist_url": "https://open.spotify.com/playlist/4WUJmtopxr1ZWzHRyAr18C"}
{"genre": "south african trap", "spotify_playlist_url": "https://open.spotify.com/playlist/43sN5RaFc8vfqheu5Je3gy"}
{"genre": "nottingham hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7aZwQ2AfYB26031fLdyL5w"}
{"genre": "reggae cover", "spotify_playlist_url": "https://open.spotify.com/playlist/7ASBfGIVXJlhAll8NQQ3SH"}
{"genre": "old school bassline", "spotify_playlist_url": "https://open.spotify.com/playlist/3Lp89wmns5SSt3U8wYWcK3"}
{"genre": "polish alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/76e35fRM2OVKekQGqb8BuL"}
{"genre": "rock quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/5PU59fME6qieTTZZkomRbr"}
{"genre": "indonesian ska", "spotify_playlist_url": "https://open.spotify.com/playlist/3neYAWnvRzRv4ywFAtXXhU"}
{"genre": "australian r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/78wsjymwVf1xFMm5qJgrRk"}
{"genre": "emo mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/4yn120cVWRqpXwovvl3gGQ"}
{"genre": "islamic recitation", "spotify_playlist_url": "https://open.spotify.com/playlist/63rahDKdDo5xjhy0DsIafA"}
{"genre": "english baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/5qnzjtTyEBVPQjs6ZEVIYF"}
{"genre": "uk tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/2dJiqY6e5cvgwc0GCkHX8W"}
{"genre": "australian post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1FVDUHQtMQJG35Ym31BnDr"}
{"genre": "synthesizer", "spotify_playlist_url": "https://open.spotify.com/playlist/4MANho5BvtFfkQQ7C42iON"}
{"genre": "deep new americana", "spotify_playlist_url": "https://open.spotify.com/playlist/0J8pO9hK5KnAFWaLE3oTfK"}
{"genre": "russian underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5ovk8OVeq4zRZulOaajcQt"}
{"genre": "dark rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7BIohhHm3WSs2i2U5Atns6"}
{"genre": "dark post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1yvV2FiUMqxDe2rfwHzAC9"}
{"genre": "old school dancehall", "spotify_playlist_url": "https://open.spotify.com/playlist/69jZqaBhTVQXMepSKTK2YI"}
{"genre": "doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2SMuSQrwplaFYop8lMjzXA"}
{"genre": "musica poblana", "spotify_playlist_url": "https://open.spotify.com/playlist/6tmV8GH4QCo3Of0tEwQu0m"}
{"genre": "italian tenor", "spotify_playlist_url": "https://open.spotify.com/playlist/0ooaHcudpw6SLf2CnaflRC"}
{"genre": "canadian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/2I60Jc6u9Wu0Qbtjwh6Oos"}
{"genre": "classical tenor", "spotify_playlist_url": "https://open.spotify.com/playlist/1cRwhvW7rLIu6j5jUpVLs3"}
{"genre": "swedish americana", "spotify_playlist_url": "https://open.spotify.com/playlist/5XyX3dS27WbXZLiWoJNsdM"}
{"genre": "swedish melodic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1nqvj06t4SEP57pxFuga0D"}
{"genre": "dangdut remix", "spotify_playlist_url": "https://open.spotify.com/playlist/3TlHGiNZLynpxVAd7sIqGW"}
{"genre": "crossover thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/2fVXuLB7TwG2Wl1GQq0bnc"}
{"genre": "russian rave", "spotify_playlist_url": "https://open.spotify.com/playlist/7kEE6AcLLvewkDzi1KYKzg"}
{"genre": "musica potosina", "spotify_playlist_url": "https://open.spotify.com/playlist/17CzstuiihayOksRwVdG5Q"}
{"genre": "sacramento hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6wqtv7FgqQNvVHvjTNwdvp"}
{"genre": "german indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1bx8VTvb9Thu8MWpnhuP6k"}
{"genre": "north east england indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4gU0NSaGgG6cbZJrMZjyIb"}
{"genre": "punk rock mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/3H7zYAP11JIviN8dwVACzL"}
{"genre": "psicodelia brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/3FwF0Ktz7l7BMIrFJ9kV5w"}
{"genre": "josei rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6p9AwjUwzzfT9ArQ3i2ogp"}
{"genre": "japanese instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/3Nd7gSpO4wcYP8G76NuE5I"}
{"genre": "bakersfield sound", "spotify_playlist_url": "https://open.spotify.com/playlist/1FHYDt4X8pKAUEv6hlaP0N"}
{"genre": "korean old school hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5VAMd4pUDoAW3dJS0FZyyo"}
{"genre": "korean talent show", "spotify_playlist_url": "https://open.spotify.com/playlist/0HDsBBxxbv2TkKpIZX2Ac0"}
{"genre": "chinese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0eoEJg0k4tV0Jw3gmTfRko"}
{"genre": "tex-mex", "spotify_playlist_url": "https://open.spotify.com/playlist/7jHrOWtneqPZJ29ndEaUHO"}
{"genre": "anime cv", "spotify_playlist_url": "https://open.spotify.com/playlist/3GREOE8CDxw4ber9ZOcxJG"}
{"genre": "city pop", "spotify_playlist_url": "https://open.spotify.com/playlist/01yyE63z3FdFIytTCRVUK9"}
{"genre": "deutschrock", "spotify_playlist_url": "https://open.spotify.com/playlist/6yawclJUE90zXVD6QVuZuQ"}
{"genre": "drill brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/35Cb4Lw5L04Qx1jfLHdvP5"}
{"genre": "kawaii metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5sLhmwkeZsqxUfx1871zjC"}
{"genre": "canadian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2C7ZlaZapi5PJTbg3H48kZ"}
{"genre": "groove gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/3X17g0Hchnzn3RCjJla4jJ"}
{"genre": "jewish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6CwZnd7cgbJzStHKhbUbnX"}
{"genre": "orgcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6IovjBTXeMtrEqJjd8vrla"}
{"genre": "classic belgian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/37RWjxq3PTEw5YRoRfkFQm"}
{"genre": "brazilian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/08nXOyhmTz2IN8HqBtJIXa"}
{"genre": "ballet class", "spotify_playlist_url": "https://open.spotify.com/playlist/0HQGgNqnGE43URSB9W4Dy3"}
{"genre": "musica catalana", "spotify_playlist_url": "https://open.spotify.com/playlist/5Y51KuTG9GMPB96cq5OZEj"}
{"genre": "kindie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3afmDFMzh8zUvgbfluwOe1"}
{"genre": "musica neoleonesa", "spotify_playlist_url": "https://open.spotify.com/playlist/6B7pr3pQfaD3ONIwP3LOZG"}
{"genre": "indian fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/1PAga02b1YvwHS0r15ZFO8"}
{"genre": "carnatic", "spotify_playlist_url": "https://open.spotify.com/playlist/4lDX4W8iQAm0hTVV6TfGpp"}
{"genre": "popwave", "spotify_playlist_url": "https://open.spotify.com/playlist/4Tb0OWHFIYV7i7ohcF9dmM"}
{"genre": "nottingham indie", "spotify_playlist_url": "https://open.spotify.com/playlist/48mDWXE7pJuczyu4xEDoOM"}
{"genre": "psychedelic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/75MgjwXES1jwlJXcBVkrQh"}
{"genre": "battle rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3YiBYAadb18yWNjOZz1nN3"}
{"genre": "classic j-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ae8AzfvmxYfsMOIujPbUm"}
{"genre": "indonesian post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0WP043tSbyP4wmryLD5sDf"}
{"genre": "nightrun", "spotify_playlist_url": "https://open.spotify.com/playlist/2kDooijmZr5ZNFXF37OggB"}
{"genre": "albuquerque indie", "spotify_playlist_url": "https://open.spotify.com/playlist/407HWwYCxddvWkqGKybLkr"}
{"genre": "irish country", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZoVYWfvloSUP0sYwAk0Eg"}
{"genre": "portuguese rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6k201S3pA59wTeZ9NZ386Y"}
{"genre": "roots americana", "spotify_playlist_url": "https://open.spotify.com/playlist/1iWoJHBrst3QgMIW6kXHxb"}
{"genre": "brazilian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/70f3S3d60uyOdssfCZ9AEe"}
{"genre": "glam punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5VkFzduwXsWFeWKQogab01"}
{"genre": "brazilian emo", "spotify_playlist_url": "https://open.spotify.com/playlist/4529JKPn5nYRNB3e3JHJ3D"}
{"genre": "brit funk", "spotify_playlist_url": "https://open.spotify.com/playlist/4rAO16HPp9ZQZ4bvclqVWe"}
{"genre": "alabama indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1qZ6cyP2h2HwPSS0yAXvyb"}
{"genre": "western swing", "spotify_playlist_url": "https://open.spotify.com/playlist/4C4MIUXQzBPxXL4pb4iXb4"}
{"genre": "cumbia lagunera", "spotify_playlist_url": "https://open.spotify.com/playlist/2jCzTOAo6XqJLHUBFabse3"}
{"genre": "malaysian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0stxtqX5Sht12EZyYI2sjW"}
{"genre": "post-metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0Nwd3oKmp7LXz07qnjm5ic"}
{"genre": "french metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6WUkO8l7dwfRtklnzNToRw"}
{"genre": "classic norwegian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/77XtO891xN5zPjQ6hvZkbW"}
{"genre": "australian singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/6vSum4taH9WNA7QD6dEGUt"}
{"genre": "8d", "spotify_playlist_url": "https://open.spotify.com/playlist/2vLez030U00PBsuE2ug926"}
{"genre": "blackened deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5b8PZZmRcuOrqWYjLpJBZl"}
{"genre": "tololoche", "spotify_playlist_url": "https://open.spotify.com/playlist/6Bf56sWlUQN4lnTq9LJye0"}
{"genre": "classic persian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1MThleZUevCoZ72rYIRgRJ"}
{"genre": "flamenco fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/4Einuc4YSVyKxX8tiXXnDM"}
{"genre": "double drumming", "spotify_playlist_url": "https://open.spotify.com/playlist/5d14ZrDa5uxfbseFCO9KJI"}
{"genre": "brazilian soul", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZaBZfYeCQoWj4ToBFE7Wg"}
{"genre": "west coast reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/4p18ARuCBXP8qbpzMdEmIi"}
{"genre": "k-pop ballad", "spotify_playlist_url": "https://open.spotify.com/playlist/6WWiU8KPlDraBdf1tXifrS"}
{"genre": "manila sound", "spotify_playlist_url": "https://open.spotify.com/playlist/2pnop4rfcyjGCVBAvzRXqX"}
{"genre": "canadian children's music", "spotify_playlist_url": "https://open.spotify.com/playlist/6DRCAxWCNveFsISnkmlaSa"}
{"genre": "jazz quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/2uNqTsNVHLYx4F7NU3kghB"}
{"genre": "afro house", "spotify_playlist_url": "https://open.spotify.com/playlist/6JBXZSjISi9ugN1Q0Ku9cN"}
{"genre": "singaporean singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/4kSgy7KERZ8CIBSuZSwnXP"}
{"genre": "sertanejo gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/5A6le1sitmcZpF3eHQw5Lj"}
{"genre": "traditional country", "spotify_playlist_url": "https://open.spotify.com/playlist/7yV5vLKdCyBDi4MW0It39c"}
{"genre": "dabke", "spotify_playlist_url": "https://open.spotify.com/playlist/40luEHX58YMtrD3cHCqAew"}
{"genre": "lithuanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0jh60zPtx0PsQn8EfLWHw3"}
{"genre": "christian uplift", "spotify_playlist_url": "https://open.spotify.com/playlist/1MfuuCRndwqJIGz1yW8aHH"}
{"genre": "trop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/00YBGjcGpRh7simbP2jPga"}
{"genre": "flint hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/73iWcBhVWPCK0lRl6BjuAT"}
{"genre": "trot", "spotify_playlist_url": "https://open.spotify.com/playlist/0VOsr8ByGRlLwZSfB9lpQ8"}
{"genre": "rock alternativo espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/6Y9tU2Zb0Nj3uyvpZPUE9i"}
{"genre": "virginia metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4CX6IenmMGIHzvvld2066N"}
{"genre": "lds youth", "spotify_playlist_url": "https://open.spotify.com/playlist/1E7BcIB5KcUEgeivGlZKy1"}
{"genre": "chinese bgm", "spotify_playlist_url": "https://open.spotify.com/playlist/1Kcs9JPtTzFVgBhqnlmLM3"}
{"genre": "german viral rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7GdLrGCiNoYrQ2f8onhkkG"}
{"genre": "early avant garde", "spotify_playlist_url": "https://open.spotify.com/playlist/1hy3tWvAs4J5mgqPusP5O1"}
{"genre": "swedish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/066Ws83mBgawkpYWWvjmp6"}
{"genre": "cumbia andina mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/2Z2hiXnEJq2WSIQQMGfjtf"}
{"genre": "super eurobeat", "spotify_playlist_url": "https://open.spotify.com/playlist/7pH0jkvJ9Q5D6pnyR84G2s"}
{"genre": "novelty", "spotify_playlist_url": "https://open.spotify.com/playlist/6zeeSXGL4cJQ8pM7tsv42f"}
{"genre": "russian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6FxYPsQA6ZUzOHvwCpBzGC"}
{"genre": "witch house", "spotify_playlist_url": "https://open.spotify.com/playlist/0qRB6EMArr8xLzHOK7th7o"}
{"genre": "acoustic chill", "spotify_playlist_url": "https://open.spotify.com/playlist/7dJlO6VYlCSlfxued1pqso"}
{"genre": "african rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5eXcXox905vgCOp8bE4TJI"}
{"genre": "tribal house", "spotify_playlist_url": "https://open.spotify.com/playlist/28k2EefJC3hIfubtmcQrIW"}
{"genre": "space age pop", "spotify_playlist_url": "https://open.spotify.com/playlist/24TfZCTkkTn8vSMJXCkkQ8"}
{"genre": "uzbek pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5gGItAytSo8yWW6VVLTf12"}
{"genre": "finnish heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1UJTujbW6NmQ1xqzNcDaY7"}
{"genre": "popping", "spotify_playlist_url": "https://open.spotify.com/playlist/7b5Z7A669b6TjXQqk2Spto"}
{"genre": "glitch", "spotify_playlist_url": "https://open.spotify.com/playlist/27smuYGRZZl9q0BCwda8en"}
{"genre": "zouk", "spotify_playlist_url": "https://open.spotify.com/playlist/7mNGeqFpLOFebS0QrGXU2N"}
{"genre": "kawaii future bass", "spotify_playlist_url": "https://open.spotify.com/playlist/1L3GAiiBL5sBNbDEAMGMEA"}
{"genre": "musica alagoana", "spotify_playlist_url": "https://open.spotify.com/playlist/3xfMKzKtq7xNODln9zdPtO"}
{"genre": "louisiana blues", "spotify_playlist_url": "https://open.spotify.com/playlist/2fvTmmnb2UbU5TWvbMolPz"}
{"genre": "rap cristao", "spotify_playlist_url": "https://open.spotify.com/playlist/5pLrIA7efzz23RMrQUiMFt"}
{"genre": "hip-hop experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/5ZhhKHUMdcxbMXhFKEFVrP"}
{"genre": "norwegian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3JvxPwfz5njO7lzpAyoEWB"}
{"genre": "klubowe", "spotify_playlist_url": "https://open.spotify.com/playlist/2WV371HvB5U80xDFui1vwg"}
{"genre": "progressive jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/7MxCJx6LskBWTpzCscHs7a"}
{"genre": "5th wave emo", "spotify_playlist_url": "https://open.spotify.com/playlist/5jJRdxN4pD29Uhj0ZIRFPf"}
{"genre": "dansktop", "spotify_playlist_url": "https://open.spotify.com/playlist/6PpgydwSFoSDoRtFWTJgkJ"}
{"genre": "swiss pop", "spotify_playlist_url": "https://open.spotify.com/playlist/18cADc0sGSv5mLQlZzX0YO"}
{"genre": "himachali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0AXXFLaxI2f0DVZZzEyvxn"}
{"genre": "bongo flava", "spotify_playlist_url": "https://open.spotify.com/playlist/3kpbUKUNVhyyvGq7VQWYYs"}
{"genre": "deep chill", "spotify_playlist_url": "https://open.spotify.com/playlist/5ELJuzyWxmJSF24NtjZ5oH"}
{"genre": "musica coahuilense", "spotify_playlist_url": "https://open.spotify.com/playlist/2IypteLrsz7uuQHKuSs4qk"}
{"genre": "eurobeat", "spotify_playlist_url": "https://open.spotify.com/playlist/2FxGFGXJi4yawmWPH5ZYJP"}
{"genre": "braindance", "spotify_playlist_url": "https://open.spotify.com/playlist/0r1CgdiknCUXvmW7gunLBo"}
{"genre": "melodic hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1zpGcI2DcOjVa2vbtU98cO"}
{"genre": "latin funk", "spotify_playlist_url": "https://open.spotify.com/playlist/6v8bleGrMNjuFRykLAPFix"}
{"genre": "modern jazz piano", "spotify_playlist_url": "https://open.spotify.com/playlist/7fxBCO4CXLWl2mYNe8Jjg0"}
{"genre": "asbury park indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5qJZkdUplMT9P0E2NKsH9g"}
{"genre": "speed up brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3wC8duyhmNjjYZZDHEwQt9"}
{"genre": "rap anime", "spotify_playlist_url": "https://open.spotify.com/playlist/5WbVYO7Dthtlvrtl95bESo"}
{"genre": "czech folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1PQNGPYni1V1nFdLLyF6D5"}
{"genre": "trance brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3ofLiCvTC8YguAJ45fIqEC"}
{"genre": "pub rock", "spotify_playlist_url": "https://open.spotify.com/playlist/05hKvjsFjE7g3Pnk7Wxvwe"}
{"genre": "czech pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2WSMpzIwa56YZZwOk8xULn"}
{"genre": "australian underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3RnjdCOpB2uSOQlHin0YZr"}
{"genre": "slovak pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3RKFpCU8U1W4su54fdk6jF"}
{"genre": "lds", "spotify_playlist_url": "https://open.spotify.com/playlist/6PA6TCSmljI69KJ8Co6tVd"}
{"genre": "modern melodic hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2OhU63IZiP26GlbudgdfPU"}
{"genre": "salsa choke", "spotify_playlist_url": "https://open.spotify.com/playlist/0Evf0zY8yZLBDOXJCLERQi"}
{"genre": "relaxative", "spotify_playlist_url": "https://open.spotify.com/playlist/4mFbCjaAKxq9b4Cy9seDXk"}
{"genre": "south african pop dance", "spotify_playlist_url": "https://open.spotify.com/playlist/4F77ekCL0tJOFm6tWINkhf"}
{"genre": "birmingham hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3GjV4OJyXwksJjwVMuHpi2"}
{"genre": "ukrainian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/66CJdSRCY2xNA8FFRbF5Ia"}
{"genre": "australian americana", "spotify_playlist_url": "https://open.spotify.com/playlist/4cavePoqp7tBZ8FYfZaDlf"}
{"genre": "emo trap en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/4vHFUc9Gak6omVxBYkDLRv"}
{"genre": "shabad", "spotify_playlist_url": "https://open.spotify.com/playlist/2HizNyoSa1NdOX0r30vrXX"}
{"genre": "organic ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/4WT1Tpb9MAADzfXTohUWmm"}
{"genre": "thai folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4ysbROor6vDia1Vb0VfTQi"}
{"genre": "gabber", "spotify_playlist_url": "https://open.spotify.com/playlist/6X1FPMpA9bOtPJvIUvb1vh"}
{"genre": "bruneian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1iwTy2uKXpyBTGKbZ9Kgj5"}
{"genre": "acoustic punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4jr1tvvMa8bYtXGQZPFn3T"}
{"genre": "hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0S6rCiZ30gNEVxpsvtpKSQ"}
{"genre": "j-reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/5mgPPGnSCd1WPeN9BrVcaB"}
{"genre": "flute rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4MWPOsshMgyRmHmGj7cvQN"}
{"genre": "dreampunk", "spotify_playlist_url": "https://open.spotify.com/playlist/6Bwx1zt2m1T6AC1fTFBFAY"}
{"genre": "magyar alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/6KHw5aZWWsmRqpT7o290Mo"}
{"genre": "norwegian country", "spotify_playlist_url": "https://open.spotify.com/playlist/3OYcipXDDwzqMoNgfMf4az"}
{"genre": "maskandi", "spotify_playlist_url": "https://open.spotify.com/playlist/3OkMOVdIN9iKuN4NRKSeK0"}
{"genre": "banda carnavalera", "spotify_playlist_url": "https://open.spotify.com/playlist/7pQr2CwatdwF1hXPGCeD4t"}
{"genre": "afro drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6b7atlLkpIQtbZKiEwFRN1"}
{"genre": "mathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5IDUlMJWipaLZ8NZmaPB8E"}
{"genre": "zouk riddim", "spotify_playlist_url": "https://open.spotify.com/playlist/6vkcfCa0G2qHz5CogrViSl"}
{"genre": "groove room", "spotify_playlist_url": "https://open.spotify.com/playlist/1qMFUP4G7zCrrLaBDFArLt"}
{"genre": "israeli singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/7MDyqTQYlHkHfXuMzwlk68"}
{"genre": "nu gabber", "spotify_playlist_url": "https://open.spotify.com/playlist/71wCDhToKcAEgL4MhH96Er"}
{"genre": "australian garage punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1ni3hkYRNx5Sn9eX2igLSP"}
{"genre": "latin soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/7xYLH2Pb2n9rILuSADRfVK"}
{"genre": "cologne hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2X7eeN9XcQFINYJY7Irg3U"}
{"genre": "cante flamenco", "spotify_playlist_url": "https://open.spotify.com/playlist/7mDcvRe9hX5XN1wvQidtJO"}
{"genre": "bouncy house", "spotify_playlist_url": "https://open.spotify.com/playlist/6Hr3sYBBnLg65XUrCOICLZ"}
{"genre": "brazilian bass", "spotify_playlist_url": "https://open.spotify.com/playlist/1rhRPl3CJrszlIzllhvW25"}
{"genre": "san marcos tx indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4kemu1lYWY2BEKhldtq5Bp"}
{"genre": "dominican pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4GMCrTNjDoL2W3DzqIkbOn"}
{"genre": "deconstructed club", "spotify_playlist_url": "https://open.spotify.com/playlist/3uwJeZkSKE219OiTdOV0b0"}
{"genre": "japanese shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/38JPAkv9RrEuAgUWJlxBE3"}
{"genre": "azeri rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6raSpwYnvMoNwAPM19qJNO"}
{"genre": "tolkien metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6J8tjCIP7AQhdNLnddASJJ"}
{"genre": "shred", "spotify_playlist_url": "https://open.spotify.com/playlist/6i45Frf3x5Kfm0csZWJyy8"}
{"genre": "icelandic singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/22RO4cKwA1TgUrqjzl5uiW"}
{"genre": "talentschau", "spotify_playlist_url": "https://open.spotify.com/playlist/5gGfKxsP7MMDUkrDrIl116"}
{"genre": "rap lyonnais", "spotify_playlist_url": "https://open.spotify.com/playlist/6eA5u9ccVsxjn2iGAJ2Inq"}
{"genre": "classic czech pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0Ktfa2WckhbUbpdSfjl0wT"}
{"genre": "psychobilly", "spotify_playlist_url": "https://open.spotify.com/playlist/5O5sX3NAyXbfZgjjEHIeTy"}
{"genre": "indian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3fiYkXoS0nKeANVXh8agRA"}
{"genre": "country blues", "spotify_playlist_url": "https://open.spotify.com/playlist/5LpV4RS7WgWaDyKxu0W60r"}
{"genre": "tango", "spotify_playlist_url": "https://open.spotify.com/playlist/2rsR2gxPujqpU0JA6Ug6xg"}
{"genre": "hurdy-gurdy", "spotify_playlist_url": "https://open.spotify.com/playlist/7GllgsTN71VioHh4ksZnEm"}
{"genre": "tone", "spotify_playlist_url": "https://open.spotify.com/playlist/1NibfBr59fliv55zruqGLf"}
{"genre": "deep rai", "spotify_playlist_url": "https://open.spotify.com/playlist/5tyezvodUyCR9NhcffeDLP"}
{"genre": "math rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3ixDgyXZKaRCmNqesAo1pb"}
{"genre": "viet chill rap", "spotify_playlist_url": "https://open.spotify.com/playlist/72TDfcmK4FAKaBt5AXfGce"}
{"genre": "yodeling", "spotify_playlist_url": "https://open.spotify.com/playlist/2SMDVBkKqnZL9AoUWaZ2qs"}
{"genre": "malang indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5Drx60Dut5MBWhJbjhe0Z1"}
{"genre": "reggae gaucho", "spotify_playlist_url": "https://open.spotify.com/playlist/7fBbU8gprML02vFVjvjxxW"}
{"genre": "chilean hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/39BuoNZBKIXk0oIV6jp2Ep"}
{"genre": "swedish garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5AP63WH8Zqcm9PhRruSrXI"}
{"genre": "hyperpop francais", "spotify_playlist_url": "https://open.spotify.com/playlist/4HK4JqkFN777naoFtBEbw7"}
{"genre": "ukg revival", "spotify_playlist_url": "https://open.spotify.com/playlist/2obhhKQ1mPxskpJOHSiurg"}
{"genre": "symphonic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5HqaBtG1Clq1g28O0wKOAy"}
{"genre": "classic greek pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1pVzzHXNtFHgSkvvuGaraS"}
{"genre": "finnish melodeath", "spotify_playlist_url": "https://open.spotify.com/playlist/1h7iHbS21hpvGF5ZnzLN3Q"}
{"genre": "techno kayo", "spotify_playlist_url": "https://open.spotify.com/playlist/1qd1F8e02h6fDAKYlvHAoo"}
{"genre": "rap baixada fluminense", "spotify_playlist_url": "https://open.spotify.com/playlist/5Wbh8gxGHPtQIQK2AplA8i"}
{"genre": "shonen", "spotify_playlist_url": "https://open.spotify.com/playlist/7kW4Nu3Idy9APaKULvtIzk"}
{"genre": "electroclash", "spotify_playlist_url": "https://open.spotify.com/playlist/2lvWEEJ981sRN5GQzBvayl"}
{"genre": "karneval", "spotify_playlist_url": "https://open.spotify.com/playlist/6qgP9fe7CUMf9UFVpPUnW6"}
{"genre": "nashville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1vc3RFXIHHqgy1hp2aL5EK"}
{"genre": "zxc", "spotify_playlist_url": "https://open.spotify.com/playlist/3mOVijfpf6hU4gDCabCU5G"}
{"genre": "mande pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6riQjcCLhGDOkRaaWUmnKk"}
{"genre": "finnish alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1cxkt9NI4V0glkXJsY0eMo"}
{"genre": "ukrainian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4BXMH7TLydNEXR5awGJ65g"}
{"genre": "latintronica", "spotify_playlist_url": "https://open.spotify.com/playlist/4MrFNFcSkTQogqtxqELYCu"}
{"genre": "german hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/4FjuxEyTVpIG1xel4TiyhB"}
{"genre": "r&b italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/08RIk2wKqMNCSzEaZCcHhi"}
{"genre": "italian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0jd7I9PCsFKEGU7Kv1tsgJ"}
{"genre": "bosnian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6GivQQIY1f6pR7CdLpu6R4"}
{"genre": "lithuanian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/2HSt4RAoPw18TPri85TJEn"}
{"genre": "belarusian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6tVRgSyvGCIdn0y97I3mxH"}
{"genre": "lambadao", "spotify_playlist_url": "https://open.spotify.com/playlist/1teLnfl5F9DD1Ko5fLy8lG"}
{"genre": "praise", "spotify_playlist_url": "https://open.spotify.com/playlist/1VhcRgHXUhPHaAgCk2uB0U"}
{"genre": "papuri", "spotify_playlist_url": "https://open.spotify.com/playlist/1z6FaW8kU3JJ8KHkGsYYTv"}
{"genre": "ebm", "spotify_playlist_url": "https://open.spotify.com/playlist/2F3L73OLu8Gi52yvGnv4yb"}
{"genre": "brazilian boogie", "spotify_playlist_url": "https://open.spotify.com/playlist/44ddQ4g1xnn8o0SRo1hgPa"}
{"genre": "dutch tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/4hBx08ZvSe1OypE0PviYg0"}
{"genre": "circuit", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZIMiwF86xDzMZNE05pshX"}
{"genre": "punjabi lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/1DRdEDsIaKzHgWKsmfcFk0"}
{"genre": "christian lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/7ks7U4OenxbeU7G4PU4cO4"}
{"genre": "ukrainian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/43csA6NHJsLu6IHZViEQ5P"}
{"genre": "chamber psych", "spotify_playlist_url": "https://open.spotify.com/playlist/6rirvdbul7rDunT5SP5F4m"}
{"genre": "vocal harmony group", "spotify_playlist_url": "https://open.spotify.com/playlist/6IywiOKAoppQqNyugHBSMW"}
{"genre": "pakistani indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6THzRYh7cRGUHAxQjkqKT8"}
{"genre": "experimental classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7dsOzqgEOrtXP3GEZEgwgr"}
{"genre": "cumbia colombiana regia", "spotify_playlist_url": "https://open.spotify.com/playlist/2lOU9vGfLa9kw1vMUYM6z1"}
{"genre": "polish reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/6K2BkmRqPQggCGu81OCyAl"}
{"genre": "german worship", "spotify_playlist_url": "https://open.spotify.com/playlist/04goa2WnJSttcaWR9ZCkjQ"}
{"genre": "puirt-a-beul", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZfARpXfByItZ8QLMICf4C"}
{"genre": "fantasy", "spotify_playlist_url": "https://open.spotify.com/playlist/7yZS6e9IMeOkEzIydo1FYB"}
{"genre": "reading indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0vkWuT5Rcb1BXAChxggTO0"}
{"genre": "russian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5xa7wwrQ6oXuBaHJEpMUje"}
{"genre": "electro bailando", "spotify_playlist_url": "https://open.spotify.com/playlist/3Qb1SuXPEkMxqQB81haHqs"}
{"genre": "disco polo", "spotify_playlist_url": "https://open.spotify.com/playlist/0QCwzUc7HoviOaH0of0cII"}
{"genre": "seiyu", "spotify_playlist_url": "https://open.spotify.com/playlist/4SaTkQWZk7z8skVGhPPKYf"}
{"genre": "messianic praise", "spotify_playlist_url": "https://open.spotify.com/playlist/68qhIvxiXlOKgXJ2bidJW4"}
{"genre": "batak", "spotify_playlist_url": "https://open.spotify.com/playlist/6F8lx4JLdKD4rvUxywo0eO"}
{"genre": "indie catala", "spotify_playlist_url": "https://open.spotify.com/playlist/5TKXMbSNXIpHqO3Jxd9esh"}
{"genre": "dutch r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/2KIAFjtQXFdsWTWDdanyQP"}
{"genre": "turk sanat muzigi", "spotify_playlist_url": "https://open.spotify.com/playlist/5yFAOzV56em5BaM8Vnp6GS"}
{"genre": "perth indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0eYe2aHfXCo66nUqyLKkMM"}
{"genre": "chinese melodic rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2rMhjmx6ALZb8nfmQpOFa2"}
{"genre": "oktoberfest", "spotify_playlist_url": "https://open.spotify.com/playlist/4qBVIfsK0B5SadYeuCCoSZ"}
{"genre": "belarusian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/51YuSJZ2Lr2fdwq1Y0cnIl"}
{"genre": "fogo pentecostal", "spotify_playlist_url": "https://open.spotify.com/playlist/1Jsfl0NuEH9YUjNhOGVcis"}
{"genre": "ethnotronica", "spotify_playlist_url": "https://open.spotify.com/playlist/2lFT6elXscX6g0BnKrvnO6"}
{"genre": "polish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2UCsDf7DroMDIIL4SPIfO7"}
{"genre": "microtonal", "spotify_playlist_url": "https://open.spotify.com/playlist/01g27BmiXVR791t1A4zCOZ"}
{"genre": "cumbia ecuatoriana", "spotify_playlist_url": "https://open.spotify.com/playlist/1cvTdLpuq8sbNEHAATPcYL"}
{"genre": "anime piano", "spotify_playlist_url": "https://open.spotify.com/playlist/0KaPnh3dANNTOnqXlegsON"}
{"genre": "russian modern classical", "spotify_playlist_url": "https://open.spotify.com/playlist/15PzZ2MtRImGNPihcnPlJe"}
{"genre": "japanese piano", "spotify_playlist_url": "https://open.spotify.com/playlist/2pGRSENDZrRPtxsf7pSBhJ"}
{"genre": "swedish dancehall", "spotify_playlist_url": "https://open.spotify.com/playlist/6gXVFkNldt9IAzv1U5YSaj"}
{"genre": "swedish reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/7bjXSDjoTaZ8UiUf66U75i"}
{"genre": "austin americana", "spotify_playlist_url": "https://open.spotify.com/playlist/4m33gxxb6nOSVYMzB0Rm94"}
{"genre": "indie rockism", "spotify_playlist_url": "https://open.spotify.com/playlist/4NQpJ0cZK9CVp16Yq2bN54"}
{"genre": "euskal rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4fgHorklhTT5M7ANsHRtqr"}
{"genre": "rap antillais", "spotify_playlist_url": "https://open.spotify.com/playlist/4BuLTQu4yFpMRmIwK2tXvy"}
{"genre": "italian reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/7DgHqjwOkRvFHkTQqlXtTD"}
{"genre": "high-tech minimal", "spotify_playlist_url": "https://open.spotify.com/playlist/4WruPfNlvCeb0mhoqTgLFn"}
{"genre": "ambient house", "spotify_playlist_url": "https://open.spotify.com/playlist/6nwKOBp5s1ESz8zie6WBUf"}
{"genre": "world fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/0ECY6L3aZj4482LRSzr1C6"}
{"genre": "deep tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/6f9GZVPhkxURhgekuq4EVh"}
{"genre": "rap siciliano", "spotify_playlist_url": "https://open.spotify.com/playlist/0QSSoihqhZmWI3aOBff8oY"}
{"genre": "pop worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5YNMLIKV98cHxuMUka6Mlo"}
{"genre": "moldovan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6T5nV1CfYLMP7nbkQf4vNn"}
{"genre": "new italo disco", "spotify_playlist_url": "https://open.spotify.com/playlist/1gwTJk9CjWSuhL5GlNuejF"}
{"genre": "chill beats", "spotify_playlist_url": "https://open.spotify.com/playlist/7uLo8nwzm2LWLfgET15HCK"}
{"genre": "west end", "spotify_playlist_url": "https://open.spotify.com/playlist/6lPEbS2LRB6eSYqUVU3PdL"}
{"genre": "melodic deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6HZcdwcWYuzyIGgPSJWoxV"}
{"genre": "south african alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/2uNHP4lE72LZaqPCIVPhqo"}
{"genre": "syrian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/71AaHNo5ZV6AIh7kF65UTY"}
{"genre": "turkish modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/1jfoRuFq7k7f5ZBEaninHm"}
{"genre": "uk post-punk revival", "spotify_playlist_url": "https://open.spotify.com/playlist/4sFHOe1hDHoSURA28xL9SJ"}
{"genre": "instrumental soul", "spotify_playlist_url": "https://open.spotify.com/playlist/6EbIVsw2rb11ACHIlWXZFV"}
{"genre": "classic finnish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4SkgzC5qxNelXWo3zJsP5J"}
{"genre": "furry", "spotify_playlist_url": "https://open.spotify.com/playlist/7o9a21HReswib5OcWqGNFK"}
{"genre": "shatta", "spotify_playlist_url": "https://open.spotify.com/playlist/6ChuhvQWdtgZyoUfdOOg2e"}
{"genre": "musica gaucha", "spotify_playlist_url": "https://open.spotify.com/playlist/5I8SztKbck0OLJFFM8Pb9B"}
{"genre": "christian afrobeat", "spotify_playlist_url": "https://open.spotify.com/playlist/2dVHwR9NRScJP0Ss4G7t0B"}
{"genre": "workout product", "spotify_playlist_url": "https://open.spotify.com/playlist/6cDdh9kz3XoXieUAH6kdJq"}
{"genre": "indie extremena", "spotify_playlist_url": "https://open.spotify.com/playlist/7zekdC0ZlzBDImLpbbzQuJ"}
{"genre": "slovak rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3zpxddsh78h6Z38TeiKJqf"}
{"genre": "british jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0LCXuAqnGnHjIORznov5OB"}
{"genre": "russian punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0cFRjSgRG2OvJWz7TIdZiM"}
{"genre": "ragga jungle", "spotify_playlist_url": "https://open.spotify.com/playlist/1w8TCr2tpXhXXHLmYS5gkv"}
{"genre": "oldschool deutschrap", "spotify_playlist_url": "https://open.spotify.com/playlist/6pOiDioe7e3V3LdlQqjymf"}
{"genre": "no wave", "spotify_playlist_url": "https://open.spotify.com/playlist/2Mqy8KOD7dNPT9woyngrIz"}
{"genre": "orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/1CHbfeI1Ajoa99HnNPESDE"}
{"genre": "california hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5FOpN7ejzmMTtCgYWnrfB1"}
{"genre": "concurso de talentos argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/0ghAePzILlLiDPwmSVbGFQ"}
{"genre": "swiss indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5pz9R983fOY5AKNpEl7OJk"}
{"genre": "british power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3RXQ3Vu6OkKnehN0QE0H2F"}
{"genre": "tanzanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6utTDYmYQdoYmbQHBleJmZ"}
{"genre": "christelijk", "spotify_playlist_url": "https://open.spotify.com/playlist/2x7eAHtuG7U1DRK955G1es"}
{"genre": "surf music", "spotify_playlist_url": "https://open.spotify.com/playlist/25QwV1M9uzzG9L5KArdnXX"}
{"genre": "lithuanian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/33wFbAFX8W0IgVqEPpxqth"}
{"genre": "honky tonk", "spotify_playlist_url": "https://open.spotify.com/playlist/4nPH9l8L8OIkYnb0JSGsbW"}
{"genre": "jump up", "spotify_playlist_url": "https://open.spotify.com/playlist/11UvQwdCC7p4WoF9AyhIdq"}
{"genre": "rap romantico", "spotify_playlist_url": "https://open.spotify.com/playlist/70tbA3VypSVkRzvJWbYbfc"}
{"genre": "funktronica", "spotify_playlist_url": "https://open.spotify.com/playlist/7u5AZPIkUnl4iuQt63nclw"}
{"genre": "thai indie", "spotify_playlist_url": "https://open.spotify.com/playlist/65mUQOwcePZ9ZFyZyqhNiA"}
{"genre": "san diego rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZosaIZMTLyomdop952uRQ"}
{"genre": "j-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5BKfbWZ7WjiGwugYpbgdYp"}
{"genre": "smutny rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1sJVrPmlXuvhq2dO5mUclQ"}
{"genre": "atlanta metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5P1jRmNP0TDLtKX7bj372S"}
{"genre": "mundart", "spotify_playlist_url": "https://open.spotify.com/playlist/0jRf2cuzt0bLNhZZsLFiGg"}
{"genre": "metal cover", "spotify_playlist_url": "https://open.spotify.com/playlist/3vwNGdBeZuk4qH5rmcQMdr"}
{"genre": "finnish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ky7mnFOobBYJMFnNtLN8O"}
{"genre": "leicester indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4H8Sh5efiQCWU3fOuygWUu"}
{"genre": "apostolic worship", "spotify_playlist_url": "https://open.spotify.com/playlist/7pXG3dPQbQ62gGRb9cH4jV"}
{"genre": "montreal indie", "spotify_playlist_url": "https://open.spotify.com/playlist/37oFD4hWQa1RBG9xSi39R6"}
{"genre": "chanson paillarde", "spotify_playlist_url": "https://open.spotify.com/playlist/51hvZ5rlul5LLkfLDZFjm3"}
{"genre": "sevdah", "spotify_playlist_url": "https://open.spotify.com/playlist/6sAG5XykrIqqTHUCAmyZgr"}
{"genre": "gypsy jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6ye4xUHWNCBV1GNFQ4yNaj"}
{"genre": "hardvapour", "spotify_playlist_url": "https://open.spotify.com/playlist/3uxKTCL9tzfBk4waAP3u9F"}
{"genre": "boston metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0SPPpYO8YKg4Uaga2tEFaO"}
{"genre": "brega saudade", "spotify_playlist_url": "https://open.spotify.com/playlist/4rLIrvfZlqHUdU46iaUe6M"}
{"genre": "timba", "spotify_playlist_url": "https://open.spotify.com/playlist/0dVrcSQJwNj9Klq3mP6MKn"}
{"genre": "delta blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7lMW2Hpzs18nh4kmGOs2rB"}
{"genre": "speed up turkce", "spotify_playlist_url": "https://open.spotify.com/playlist/3EVIId7wC6mMqfgabmnGov"}
{"genre": "pinoy idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0h1fhuuIYAYjxlvNxyG1Vp"}
{"genre": "musica cristiana guatemalteca", "spotify_playlist_url": "https://open.spotify.com/playlist/2z4sCERkuDhZ1heXEErFKq"}
{"genre": "pirate", "spotify_playlist_url": "https://open.spotify.com/playlist/009ddWL6yPxpgfLY76Z6x2"}
{"genre": "funky house", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZwOZItEvdtWZuTVFQfwJs"}
{"genre": "scottish indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5HintVVklsFbeTTlQFqmlw"}
{"genre": "techno", "spotify_playlist_url": "https://open.spotify.com/playlist/50kZecUV5pY2SuJv3Ie0vy"}
{"genre": "southern gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/42VLdSKVnvCM4uNWUQMbZP"}
{"genre": "dariacore", "spotify_playlist_url": "https://open.spotify.com/playlist/1kzrhvGo2KYTfa7Wdhb8mI"}
{"genre": "russian witch house", "spotify_playlist_url": "https://open.spotify.com/playlist/0DOeyrnYXB29X4ur5fbYjF"}
{"genre": "baglama", "spotify_playlist_url": "https://open.spotify.com/playlist/4b1bpJSbQCFhWMAMxnX1Ua"}
{"genre": "classic bhangra", "spotify_playlist_url": "https://open.spotify.com/playlist/7HprIEFoBD1U8U1RfYGagL"}
{"genre": "britpop revival", "spotify_playlist_url": "https://open.spotify.com/playlist/6jOp6WuIpRNcUXOVDrIqTm"}
{"genre": "pinoy indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1tdKpVPufVvIxBpVwNmZNm"}
{"genre": "khaleeji iraqi", "spotify_playlist_url": "https://open.spotify.com/playlist/7oDabKiKmedjlCG29ZHZsg"}
{"genre": "hawaiian", "spotify_playlist_url": "https://open.spotify.com/playlist/2cmBKubFYRJ8QfvqJibiTS"}
{"genre": "czech classical", "spotify_playlist_url": "https://open.spotify.com/playlist/1mPHwr7prt7gRHkb7li9SQ"}
{"genre": "free jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3nxdNdIA45HbkTwzlqZjQ0"}
{"genre": "acid house", "spotify_playlist_url": "https://open.spotify.com/playlist/17buGP6jTSgqYoV4NwkMdX"}
{"genre": "neo-traditional bluegrass", "spotify_playlist_url": "https://open.spotify.com/playlist/6tLZeHeJuat5gr4ygTW4Fc"}
{"genre": "trap beats", "spotify_playlist_url": "https://open.spotify.com/playlist/0VKu9BTDhgTrFjfBxsJ7PN"}
{"genre": "huayno", "spotify_playlist_url": "https://open.spotify.com/playlist/3OJrXUVldQpDZBfEnZACyE"}
{"genre": "shibuya-kei", "spotify_playlist_url": "https://open.spotify.com/playlist/7sFEcvv5RLUs1DECRJDKRI"}
{"genre": "denpa-kei", "spotify_playlist_url": "https://open.spotify.com/playlist/29LrWuDu53MLQ1eJgG5cy6"}
{"genre": "atlanta bass", "spotify_playlist_url": "https://open.spotify.com/playlist/04GMg3dGzp0chi0l2jRg8R"}
{"genre": "french death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6jFV4GfPYaxmcEfcigCPww"}
{"genre": "norwegian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7mCKps5qkrTMtPHr8Gvt7V"}
{"genre": "comedie musicale", "spotify_playlist_url": "https://open.spotify.com/playlist/00jq3BcNQsct8nHbaC5Utr"}
{"genre": "deathstep", "spotify_playlist_url": "https://open.spotify.com/playlist/0muM3KbvGflibIopOxuKVa"}
{"genre": "nz hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1hDdmYxsuVfuyVGKz1mkcI"}
{"genre": "adventista", "spotify_playlist_url": "https://open.spotify.com/playlist/7kDOjv4aQuo4lFBDq9F6Rw"}
{"genre": "japanese drill", "spotify_playlist_url": "https://open.spotify.com/playlist/1FBS3VQRk124WZulDPEX1A"}
{"genre": "finnish edm", "spotify_playlist_url": "https://open.spotify.com/playlist/4PRZ9KAdx0LySGaCA45AtW"}
{"genre": "barcadi", "spotify_playlist_url": "https://open.spotify.com/playlist/4kCmUkI9OGP1dguP3PMtQ0"}
{"genre": "cocuk sarkilari", "spotify_playlist_url": "https://open.spotify.com/playlist/18R3qeUAGv24F7ZGZlCR6W"}
{"genre": "underground power pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5gKcYetENCc1TBkgcTiOA8"}
{"genre": "indonesian indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6DMNNb9U6Ptmb8dez874N7"}
{"genre": "funk melody", "spotify_playlist_url": "https://open.spotify.com/playlist/3dI8uN2meX1IvAYwqVcmwW"}
{"genre": "deep minimal techno", "spotify_playlist_url": "https://open.spotify.com/playlist/1YmxunYK08uhl32fuZqqDF"}
{"genre": "atmospheric black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7mgpndQpa9o8U7iC9xb6ZK"}
{"genre": "musica llanera", "spotify_playlist_url": "https://open.spotify.com/playlist/14R3X4pqwNcREUaHLR8ijq"}
{"genre": "nasyid", "spotify_playlist_url": "https://open.spotify.com/playlist/3AfX07kXd9Kw2cfRhcMbuR"}
{"genre": "polish old school hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6aX6hpDdfZa2zVfEv82Yzr"}
{"genre": "southern metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1RRGICI1qR25Mc2jjagj65"}
{"genre": "lesen", "spotify_playlist_url": "https://open.spotify.com/playlist/5lhSLZIxNEpC4uttsZZdrN"}
{"genre": "classic punjabi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5LESZghBqSzHNi5DR7f3A5"}
{"genre": "jacksonville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/57Ek0UGrOmJlazSSjcazrB"}
{"genre": "japanese pop rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5tYWEzHdJKuFot5aqdDKx6"}
{"genre": "cantautora argentina", "spotify_playlist_url": "https://open.spotify.com/playlist/0zfoaCIbMIVfNPgIY54hlN"}
{"genre": "garhwali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3GGwtbCsGjnsAj3mAQX1fi"}
{"genre": "carnatic vocal", "spotify_playlist_url": "https://open.spotify.com/playlist/4c0FH7ppMiVUJ8DB5zbfZg"}
{"genre": "norwegian singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/1yGp52FjuZ5je8qPZlt1JJ"}
{"genre": "nederreggae", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZO9vaSNCeyPKovoNLL8ov"}
{"genre": "rap francais nouvelle vague", "spotify_playlist_url": "https://open.spotify.com/playlist/2k8s1T3zBIerxsGyA3cFeV"}
{"genre": "venezuelan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5HhzMmDUZoNjKa5GBpV6WV"}
{"genre": "german ska", "spotify_playlist_url": "https://open.spotify.com/playlist/1KB8oaMf9c3Bipe15Kuo1S"}
{"genre": "canadian old school hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2G7aAKvWj1lPSvfb1DhOpB"}
{"genre": "nueva ola chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/3u6gu0XiX7FSpKP6F9CyVx"}
{"genre": "k-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1uFmFdP4khly2qaImrnOz0"}
{"genre": "punk 'n' roll", "spotify_playlist_url": "https://open.spotify.com/playlist/5UjR1zckvh7hglsfF1Bgdm"}
{"genre": "minneapolis indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5q7BEgu84UFNBDKrbIGcRc"}
{"genre": "handpan", "spotify_playlist_url": "https://open.spotify.com/playlist/3H9BwCqSvhqLxl6gyePHAE"}
{"genre": "canadian celtic", "spotify_playlist_url": "https://open.spotify.com/playlist/3xEJhFDLGO8n5MYNE8vjjg"}
{"genre": "yogyakarta indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4rIqIjgskuOmJnaX2Z8Fzx"}
{"genre": "hyperpop en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/67WXwFxh6c7BJujM1zvn25"}
{"genre": "pakistani folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4L1EM7qJVxlMg06KVPB8CW"}
{"genre": "irish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7yawHmXHreTbNJ9wu1UBs7"}
{"genre": "japanese indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7LyM6X4Il9BReHH6MMEjyz"}
{"genre": "chaotic hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4k8zipt68CH9xab4B07JRI"}
{"genre": "classic malaysian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4qjJwcyJI5k3kUnGkyNyTx"}
{"genre": "harmonica blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7dzvfePcNOcoMPQCJR5OUX"}
{"genre": "jamgrass", "spotify_playlist_url": "https://open.spotify.com/playlist/7jWcNgwiB7CYcp1aH7Qihg"}
{"genre": "us power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6D23SO4WGAG8Md0yNLSKHP"}
{"genre": "bangla pop", "spotify_playlist_url": "https://open.spotify.com/playlist/44EBmsbBkN77OkwLNVvYGe"}
{"genre": "trap cristao", "spotify_playlist_url": "https://open.spotify.com/playlist/58YRfR5mNZGK7nwIEKayTf"}
{"genre": "vintage jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4UUXB0Mz6E3VbmRdbi2o5P"}
{"genre": "malayalam hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0fUhZu1asF2EgEPctPsC8v"}
{"genre": "poezja spiewana", "spotify_playlist_url": "https://open.spotify.com/playlist/00FZVMPSdHdGJkL9vHlGHS"}
{"genre": "rap montrealais", "spotify_playlist_url": "https://open.spotify.com/playlist/44KYQhtliTmBgCLjYHNfVv"}
{"genre": "boston punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5Z8S9q8xXxOzQCdKBXx8Is"}
{"genre": "jazz house", "spotify_playlist_url": "https://open.spotify.com/playlist/4L9GKyeqZOi5rHUoqDZd6z"}
{"genre": "fingerstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/4ErdfOdFfbDdISqqgv23GV"}
{"genre": "baltimore hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4HD6HdYhcJq2GO8BvJjz30"}
{"genre": "drone metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2KR8vprLTSBgSCk2dI2wTj"}
{"genre": "musica nayarita", "spotify_playlist_url": "https://open.spotify.com/playlist/04G3LVD83zLWhVGunErVDi"}
{"genre": "indonesian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/789X4OqEY89gjusg454KS3"}
{"genre": "german ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/3I9Qej7viaxaK9IUOtrhal"}
{"genre": "folklore ecuatoriano", "spotify_playlist_url": "https://open.spotify.com/playlist/61SGkW9FkioyT880cxk73k"}
{"genre": "riddim", "spotify_playlist_url": "https://open.spotify.com/playlist/6m6Q3yt8RDMkc4krOx1s4V"}
{"genre": "japanese screamo", "spotify_playlist_url": "https://open.spotify.com/playlist/0PU2LSTswSlnKO879AQH2c"}
{"genre": "indiana hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7baltA60dF3DOgo0GoXgJm"}
{"genre": "nepali indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3EzrWswzL4Gvltx7R84V58"}
{"genre": "fluxwork", "spotify_playlist_url": "https://open.spotify.com/playlist/1iAyidkrH72ukfG3BSHTqL"}
{"genre": "indonesian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/6QMjif9wWV6jQqFk8WQWFv"}
{"genre": "futurepop", "spotify_playlist_url": "https://open.spotify.com/playlist/5kLBrUOkzY9M7hbXfNE98t"}
{"genre": "estonian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6XdW7adQLpt3o3gIJqE9XW"}
{"genre": "neurofunk", "spotify_playlist_url": "https://open.spotify.com/playlist/4Pbi9IXKK2lD9VnHO2wGxO"}
{"genre": "vlaamse kinderliedje", "spotify_playlist_url": "https://open.spotify.com/playlist/2iNMbY6EAsgBYiCc6TSgvA"}
{"genre": "michigan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1PRwQWddlF6zWt808V29CP"}
{"genre": "classic dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/6RXirPTvDSUPoh0y2Gpnse"}
{"genre": "french psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/6J5kK4nUeKrVSGA63WVn5K"}
{"genre": "psychill", "spotify_playlist_url": "https://open.spotify.com/playlist/1JqHnsfMUxosj0lbrhnbaC"}
{"genre": "czech punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1IlJGpU4HqNpfuJ0E879Dm"}
{"genre": "russian viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7lyDbz4Yb4gFJUwx8ktTMS"}
{"genre": "american contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3s00Mk6mFgMAm71StxpLM3"}
{"genre": "burmese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2FT7VePCW7ScsRA25KuenF"}
{"genre": "russian folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7xC9HFUYnU5o27DOQ2QFz8"}
{"genre": "twee pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7d2SVTeNkqvMEcGXq40ZX7"}
{"genre": "rai algerien", "spotify_playlist_url": "https://open.spotify.com/playlist/5an1f0ElTPQH6D4QnBHkou"}
{"genre": "chinderlieder", "spotify_playlist_url": "https://open.spotify.com/playlist/6BgFgiPTSv1S3guy1ImK3e"}
{"genre": "vietnamese idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6YpdvZ6EMGDRtzI7V9UCV0"}
{"genre": "pittsburgh indie", "spotify_playlist_url": "https://open.spotify.com/playlist/653Lbg7qjivjRiaAQjVVi4"}
{"genre": "sovietwave", "spotify_playlist_url": "https://open.spotify.com/playlist/4WQXurIqquq1yIaIbxWsSa"}
{"genre": "symphonic power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/07K0fnv9a9jclwEojIFMha"}
{"genre": "bristol indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6i6Y1J0QeCy1nnBL59MShA"}
{"genre": "australian talent show", "spotify_playlist_url": "https://open.spotify.com/playlist/4HxnIDtqnU3BPh4yVWZg2b"}
{"genre": "speed plug brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/21aOvw0hMVZE5NrOTXiH1B"}
{"genre": "new orleans blues", "spotify_playlist_url": "https://open.spotify.com/playlist/39s493vky2Qtmh3yVP2Pv6"}
{"genre": "futuristic swag", "spotify_playlist_url": "https://open.spotify.com/playlist/5Q5r9dFetZWkQ3hSro5d8e"}
{"genre": "manchester indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3iu3MWlcWJi7gBoO8J0pwd"}
{"genre": "mexican edm", "spotify_playlist_url": "https://open.spotify.com/playlist/5OxjA7vwawfL8r1bdCdp2W"}
{"genre": "geek folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1seOHL268P6y7zwViyNyNR"}
{"genre": "skansk musik", "spotify_playlist_url": "https://open.spotify.com/playlist/2kJkzpnVACN1eaJhMRC5jJ"}
{"genre": "scottish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/3AQTZnaOC1qKOfUZXV81qH"}
{"genre": "kompa", "spotify_playlist_url": "https://open.spotify.com/playlist/3PaPHA9RLxiGJogAoMqHZp"}
{"genre": "malian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/1I74KKNpwBvNUE5ZSKkVHe"}
{"genre": "substep", "spotify_playlist_url": "https://open.spotify.com/playlist/7yCJscn49YPaEC1S1nQfcj"}
{"genre": "rumba congolaise", "spotify_playlist_url": "https://open.spotify.com/playlist/0FAawgV5Q1GvVrWlqBCxDS"}
{"genre": "classic bangla pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5dGF6rhQja0vlPM2w90775"}
{"genre": "british modern classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4HozwtuUKoDxCR0GrX7o8L"}
{"genre": "classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/3GKQ9yeAYenQfMYg6tDZiw"}
{"genre": "kundalini", "spotify_playlist_url": "https://open.spotify.com/playlist/4iloCrylppBqk7CzSKXGq8"}
{"genre": "norwegian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7i0srFBdIZolSwzpLwAfaw"}
{"genre": "kurdish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3fMj6wrHTicYnfDzjGCmC0"}
{"genre": "gaita zuliana", "spotify_playlist_url": "https://open.spotify.com/playlist/3s9WQKVA4PGM3fE2XgT4TK"}
{"genre": "african gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/1eXBFopkxdOaCJzPM6ljsL"}
{"genre": "balkan beats", "spotify_playlist_url": "https://open.spotify.com/playlist/4NDzFx1QQw9nxSOk7PQJ4I"}
{"genre": "cumbia amazonica", "spotify_playlist_url": "https://open.spotify.com/playlist/0yewQ4T5uF7l9Fk5TzM4wu"}
{"genre": "wyoming roots", "spotify_playlist_url": "https://open.spotify.com/playlist/48weBBj0M7WB4i0YSh3w9i"}
{"genre": "latin house", "spotify_playlist_url": "https://open.spotify.com/playlist/4RAw5T49Kgd7BdsFsWe4qS"}
{"genre": "japanese dance pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0YAZmJwfOmlDyimcG7smQj"}
{"genre": "grand rapids indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1LvN6JVVsbJkS6aK1ApL0V"}
{"genre": "semarang indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6I1gNElYJetTzK8ATKvlD2"}
{"genre": "san diego indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5Y4PsNJu3Nxbhhf82H7otO"}
{"genre": "touhou", "spotify_playlist_url": "https://open.spotify.com/playlist/5CS6xvOkP4wcYjwTKoa3as"}
{"genre": "ndombolo", "spotify_playlist_url": "https://open.spotify.com/playlist/09ykXTAO83FasjXPxMsq1k"}
{"genre": "hinos ccb", "spotify_playlist_url": "https://open.spotify.com/playlist/5Uo0GX0o6AUKv1c9vYCKp5"}
{"genre": "electric bass", "spotify_playlist_url": "https://open.spotify.com/playlist/6cgvY9wIuV29oh36jxytWC"}
{"genre": "epa dunk", "spotify_playlist_url": "https://open.spotify.com/playlist/6kQjCM6fYGrb5hz9Cx93nd"}
{"genre": "cumbia salvadorena", "spotify_playlist_url": "https://open.spotify.com/playlist/7cMtcW2pIzy0f7Z1crBjer"}
{"genre": "dutch drill", "spotify_playlist_url": "https://open.spotify.com/playlist/5Rw1qXvtuH9uqPp8XJAQWN"}
{"genre": "dmv rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3ifLzTZj0ut6AZbJ6bwhF9"}
{"genre": "abstract", "spotify_playlist_url": "https://open.spotify.com/playlist/66hfhXEaNMA2NMncX5HatH"}
{"genre": "russian chanson", "spotify_playlist_url": "https://open.spotify.com/playlist/0Viab3SDH5ZGay1lCBhMzK"}
{"genre": "swedish progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3QwSD9T1GukGSbjQAzGYEr"}
{"genre": "rap regio", "spotify_playlist_url": "https://open.spotify.com/playlist/21pxfXxqyg6QApMa5OCNXd"}
{"genre": "serbian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4uq8JA2vTkMAFi1D72pzkl"}
{"genre": "medieval folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6lVPoAULOMj3SnCgOzkFYI"}
{"genre": "cumbia uruguaya", "spotify_playlist_url": "https://open.spotify.com/playlist/4zZQU9EV9Q3uH3wX23kCvA"}
{"genre": "enka", "spotify_playlist_url": "https://open.spotify.com/playlist/02oJlDen2RzezPOYqrM7LL"}
{"genre": "swiss rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5uM73LuSChLxZIKzTqvwUb"}
{"genre": "chill out", "spotify_playlist_url": "https://open.spotify.com/playlist/5PI1ISPDdvY2InHQ4ltty1"}
{"genre": "hong kong indie", "spotify_playlist_url": "https://open.spotify.com/playlist/03z0ld7Fs4mI1PfWTqRc06"}
{"genre": "bozlak", "spotify_playlist_url": "https://open.spotify.com/playlist/35qTca30VI81L6lzyZFLXH"}
{"genre": "japanese chill rap", "spotify_playlist_url": "https://open.spotify.com/playlist/15np3AD89wmZNE1pXavg8C"}
{"genre": "russian dance pop", "spotify_playlist_url": "https://open.spotify.com/playlist/01XFN44RI7293VZIugv49n"}
{"genre": "leipzig electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/5LAEfBsVtQOtofWiRIPnt2"}
{"genre": "horrorcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2mSnw4bt0AYQMAN1XxweBo"}
{"genre": "galante era", "spotify_playlist_url": "https://open.spotify.com/playlist/7h2YS1Asvv7C9XgCMYxAw9"}
{"genre": "croatian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1VShpIOwPInnO6AQbN0z46"}
{"genre": "nova musica carioca", "spotify_playlist_url": "https://open.spotify.com/playlist/2uAFt6Np8gyDSuPyKJKJjc"}
{"genre": "psychedelic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1QePwfTwgTHDxNTfycMOqE"}
{"genre": "21st century classical", "spotify_playlist_url": "https://open.spotify.com/playlist/2HUpNZLoYHe0Sa9dglqQOg"}
{"genre": "brazilian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3nSUnrG5uxrF31ZNPMJxEc"}
{"genre": "tempe indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6phPOApF7meRbGVLFmZ9hT"}
{"genre": "vintage tollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/1qFV1e7g15fkc4Qzj4kGIK"}
{"genre": "folclor colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/0XsYSjgy8rwnIKalWCm9d2"}
{"genre": "neo-traditional country", "spotify_playlist_url": "https://open.spotify.com/playlist/42xcPVnKaE1gu7PScFIG9H"}
{"genre": "nantes indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5ku4iF1rBKPRgqYOsPKNd9"}
{"genre": "rock piauiense", "spotify_playlist_url": "https://open.spotify.com/playlist/1obp3SejCuxjnpaVtetBwC"}
{"genre": "norske viser", "spotify_playlist_url": "https://open.spotify.com/playlist/1V7lZmDeHGwBEFT87tIxrX"}
{"genre": "experimental vocal", "spotify_playlist_url": "https://open.spotify.com/playlist/0nN0oPt34YcHQoqkfHHubG"}
{"genre": "south carolina indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2G4tTJeywI9gtpARu6ldA0"}
{"genre": "deathrash", "spotify_playlist_url": "https://open.spotify.com/playlist/2NS3BH63J1GcEbBNeThpVr"}
{"genre": "alternative pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2Xv4bSyicyKg82bTnj25DQ"}
{"genre": "american modern classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7tNbjeC7or10a1G9GPSvbN"}
{"genre": "african reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/2W9yslxwwXvdsX1gpLETYD"}
{"genre": "pagan black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3Vw1bgxfUE0mrBcqrlCS6V"}
{"genre": "palestinian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4vuNh0IZu34XU1vUjYMNtM"}
{"genre": "kleinkunst", "spotify_playlist_url": "https://open.spotify.com/playlist/7pAlGbjJukWzMU3NR4w9T4"}
{"genre": "sung poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/0I9SzuBlxQwyCqV8HahgjS"}
{"genre": "virgin islands reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/4QO5FPI0JxcUzJhGU4i8rI"}
{"genre": "paisley underground", "spotify_playlist_url": "https://open.spotify.com/playlist/66fhXV1IXx8X62kLr2xOfe"}
{"genre": "viet lo-fi", "spotify_playlist_url": "https://open.spotify.com/playlist/3Vy0xyJdPMRV5TYcVz7VFB"}
{"genre": "trova mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/6Mi7KrEnGZ5cWeVj2diIx6"}
{"genre": "springfield mo indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5J4MQ0qbxUsV5S9ssktICN"}
{"genre": "russian reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/5UgGwJxLX6i8u422mj1xmy"}
{"genre": "grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0w8NAczbvCnyPKNSFa47zY"}
{"genre": "alaska indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZVmXTFnNQdpKUjDADM5Iq"}
{"genre": "finnish drill", "spotify_playlist_url": "https://open.spotify.com/playlist/4AJ7AKAVHpeY9DRDEctqYy"}
{"genre": "christian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/39xz0DseGu9cHjy8C6Oy9T"}
{"genre": "italian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5Y6dfIMb1eCIWajCXzvGgd"}
{"genre": "folclore santiagueno", "spotify_playlist_url": "https://open.spotify.com/playlist/3kG5Lj4MeQlkDdMmXVWSh0"}
{"genre": "flamenco guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/0IqRtRiN7mb32cAmyt7G13"}
{"genre": "kompa gouyad", "spotify_playlist_url": "https://open.spotify.com/playlist/1tEGakxVI2xoDvcdICBLwb"}
{"genre": "jamtronica", "spotify_playlist_url": "https://open.spotify.com/playlist/76EUKJvEF2zPCLt0AuPvXT"}
{"genre": "ontario indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4SusZM5tzm2XFYzyWbY4Bk"}
{"genre": "japanese indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7lqV7lzog3hotsBkAVUJIl"}
{"genre": "canadian post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2wQtdyeWff2hxvQBfuJU0k"}
{"genre": "techengue", "spotify_playlist_url": "https://open.spotify.com/playlist/3icMRV3VgEKGtHHyi7Ux2O"}
{"genre": "tape club", "spotify_playlist_url": "https://open.spotify.com/playlist/6XBsrRzfps1YjRjUcUyaPF"}
{"genre": "anime latino", "spotify_playlist_url": "https://open.spotify.com/playlist/1HMUV9FmJk6ugG11QAKTTp"}
{"genre": "huapango", "spotify_playlist_url": "https://open.spotify.com/playlist/3nzu11NSu4oT9BX068iEZr"}
{"genre": "chinese electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/6d1TMThIMAnrw7zfkVBSuf"}
{"genre": "japanese folk", "spotify_playlist_url": "https://open.spotify.com/playlist/11BBxVtTjfsyGuQ5IjckSo"}
{"genre": "kenyan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0kDDReaApSTI0wI0kPOqhT"}
{"genre": "memphis blues", "spotify_playlist_url": "https://open.spotify.com/playlist/6T4DmAc9TqsUbfpaM8MZem"}
{"genre": "german punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0Gv9jIN3xFw6QdITBpAWHc"}
{"genre": "modern jazz trio", "spotify_playlist_url": "https://open.spotify.com/playlist/2dvBbBvx5xENN0yta6YVMZ"}
{"genre": "dark disco", "spotify_playlist_url": "https://open.spotify.com/playlist/7dGD97xXmJcdCKyNz5t96m"}
{"genre": "oc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/40Aam7nmhVhzt6jVtamMnV"}
{"genre": "folklore surero", "spotify_playlist_url": "https://open.spotify.com/playlist/3kznfCszuHhUojhZvXzdFC"}
{"genre": "jazz rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0tsrJG7x1oC1Td2MigYo8v"}
{"genre": "kingston on indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4PhVCYY5V1hdjkaL7LWcvE"}
{"genre": "thai viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/11tHE4G3GBYPIxPw3RNetv"}
{"genre": "malay rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4UlEZTuMDmn2fJZ3Fuyde5"}
{"genre": "bubblegum bass", "spotify_playlist_url": "https://open.spotify.com/playlist/4rpC86Mx9pl3zjqhWJjoHX"}
{"genre": "dutch americana", "spotify_playlist_url": "https://open.spotify.com/playlist/2udlgcqCb6IBRpLIkuVXxe"}
{"genre": "modern hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3bxLVrtXrWOpw37GYZqoCm"}
{"genre": "rap maromba", "spotify_playlist_url": "https://open.spotify.com/playlist/3v3wWmC2O341T1L2qZfW6L"}
{"genre": "brazilian house", "spotify_playlist_url": "https://open.spotify.com/playlist/258fthdJsWF17XxHpTaTtF"}
{"genre": "pop peruano", "spotify_playlist_url": "https://open.spotify.com/playlist/6dB2VXcVGIzYuleOsxLNqL"}
{"genre": "musica campechana", "spotify_playlist_url": "https://open.spotify.com/playlist/1WjsJm4vAgromSwRhQZKhZ"}
{"genre": "musica popular paraense", "spotify_playlist_url": "https://open.spotify.com/playlist/7eF49eqkrZG5wFtihgZePd"}
{"genre": "vintage schlager", "spotify_playlist_url": "https://open.spotify.com/playlist/5LX3gw3C7WWWzDDehyQZYF"}
{"genre": "melodic groove metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4J4aZLtiQzaVIWgyNKd1JX"}
{"genre": "azeri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4btmxVWpjsCzIN2nYQ9Bcc"}
{"genre": "aggrotech", "spotify_playlist_url": "https://open.spotify.com/playlist/710IY6IOVa3h64CvE0INWb"}
{"genre": "vgm remix", "spotify_playlist_url": "https://open.spotify.com/playlist/5mmfOiO0yv4gNE1Sv1mChY"}
{"genre": "musica oaxaquena", "spotify_playlist_url": "https://open.spotify.com/playlist/2SXT0olSeNDjLAqt4re2Rf"}
{"genre": "middle east hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7xeV0FH7AWgSwawrzmS0Mw"}
{"genre": "kannada hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/64mVfC7wBCcvPm5eYPnHVI"}
{"genre": "french movie tunes", "spotify_playlist_url": "https://open.spotify.com/playlist/4XtqklANeRcUs9OYeasbxD"}
{"genre": "italian tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/4aKWBf1qwNYn7j801LIBHr"}
{"genre": "dream trance", "spotify_playlist_url": "https://open.spotify.com/playlist/0m1icO5Ea5t8btM4xQ7mHT"}
{"genre": "boogaloo", "spotify_playlist_url": "https://open.spotify.com/playlist/3AGNffrwzLjTdSfVomZ30a"}
{"genre": "mod revival", "spotify_playlist_url": "https://open.spotify.com/playlist/3urA7iwGhdJZDHWic62XbG"}
{"genre": "raw techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6qkA0ua0YWWSlJ0hUWZ1RY"}
{"genre": "gaian doom", "spotify_playlist_url": "https://open.spotify.com/playlist/3YZfaVLmvcxIAgRH3asbhw"}
{"genre": "nu age", "spotify_playlist_url": "https://open.spotify.com/playlist/7yLE2whPjIEyndQJqTVqzX"}
{"genre": "salsa international", "spotify_playlist_url": "https://open.spotify.com/playlist/1OURZGZJg8RYmXmQQA4yDc"}
{"genre": "swedish metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/73wlrju5qMPbYENDR1CW92"}
{"genre": "collage pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0H5cCWHeoaua8EaRq3UVjh"}
{"genre": "arab trap", "spotify_playlist_url": "https://open.spotify.com/playlist/5gfxq5LS8ADzgAwowpc184"}
{"genre": "thai folk", "spotify_playlist_url": "https://open.spotify.com/playlist/15kbR2WyCZAGIn0bldZctI"}
{"genre": "horror synth", "spotify_playlist_url": "https://open.spotify.com/playlist/1a9b3aM6enStjH5hqmmVd0"}
{"genre": "champeta", "spotify_playlist_url": "https://open.spotify.com/playlist/0hj6krZD6CE8wxg9nmIswz"}
{"genre": "tallava", "spotify_playlist_url": "https://open.spotify.com/playlist/7fkkPyMLN0TkZmK7gjE6Yc"}
{"genre": "cuban alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/4yHRpNzpFRWeKS0WinqHtW"}
{"genre": "american post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0qxlFZHLZ3covDTbehMVIW"}
{"genre": "alberta country", "spotify_playlist_url": "https://open.spotify.com/playlist/5kYkybE1CkN3ShUzZA5n6A"}
{"genre": "classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/2d32hJkHO6816u3Iho8NMC"}
{"genre": "zespol dzieciecy", "spotify_playlist_url": "https://open.spotify.com/playlist/66IvXQyzUNEalJnbyvSb6d"}
{"genre": "copla", "spotify_playlist_url": "https://open.spotify.com/playlist/35riSvSCs6TV2nFjAgUZXD"}
{"genre": "kodomo no ongaku", "spotify_playlist_url": "https://open.spotify.com/playlist/36VHIeJMDuFuEKglNtyrAx"}
{"genre": "musica popular mineira", "spotify_playlist_url": "https://open.spotify.com/playlist/7dpfRH16qt19sTqBflvXH7"}
{"genre": "musica maranhense", "spotify_playlist_url": "https://open.spotify.com/playlist/1zZ74gVRdo7Irvd0UEt7uf"}
{"genre": "drift", "spotify_playlist_url": "https://open.spotify.com/playlist/3BIl3M2ZzbPmNiVqg4Cxpd"}
{"genre": "swiss hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0C6FPUvOGv3GEXpMaGxwpK"}
{"genre": "hokkaido indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5gq09EHjJ3FDzwtcfT9rQr"}
{"genre": "fremantle indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0LIRzPCFAI0uaKNyYMeWBq"}
{"genre": "bogor indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1fO9ZAL1ke9EzwHMSJtR4Z"}
{"genre": "early music ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/2uc2oq6wQ8ZLSPmPr4qtte"}
{"genre": "kurdish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3hwBD9fMDoggNLK38aAxsZ"}
{"genre": "uk post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/13iX2jp2aqqMlnF9j81MbY"}
{"genre": "chinese minyao", "spotify_playlist_url": "https://open.spotify.com/playlist/3YP86Xx0MYwRzAfshgzXTP"}
{"genre": "singing bowl", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZJrVBx0kgQylNraHErajp"}
{"genre": "danish alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3elrAXLuJ0nSNMSAhbDnqN"}
{"genre": "kenyan r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/0VcJJ9zxatSC7tMR0l2TfM"}
{"genre": "alternative ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/4o7TCoOT3h3CBBV8d4mc9s"}
{"genre": "folklore boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/3EnKUu6KTDlaIFT27E0hsf"}
{"genre": "soukous", "spotify_playlist_url": "https://open.spotify.com/playlist/4scdFEeqzm7Z5n0cJghVFD"}
{"genre": "huayno peruano", "spotify_playlist_url": "https://open.spotify.com/playlist/0iLKPeLW9dKq0daQ8wZDMM"}
{"genre": "blackgaze", "spotify_playlist_url": "https://open.spotify.com/playlist/0tb4mctI0W8DgwlQzPx2Hd"}
{"genre": "military rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5ODQ2snyLcC29R5kUVlbGI"}
{"genre": "cumbia surena", "spotify_playlist_url": "https://open.spotify.com/playlist/3CTDwtkWaW4MFPxYMBfwDA"}
{"genre": "psychedelic doom", "spotify_playlist_url": "https://open.spotify.com/playlist/1WoBse7KwMPGy9uIwoe5o7"}
{"genre": "south african jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0XRhBXYCpp2CBuISbi8dgr"}
{"genre": "musica juiz-forana", "spotify_playlist_url": "https://open.spotify.com/playlist/7L2TjFMaVJPczHZuf09iDG"}
{"genre": "instrumental bluegrass", "spotify_playlist_url": "https://open.spotify.com/playlist/6VOFPHsVHwKrKYTCxbVheA"}
{"genre": "neue volksmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/7qBLZYyI9CUH3rVqNQnl3o"}
{"genre": "chopped and screwed", "spotify_playlist_url": "https://open.spotify.com/playlist/3NIhmR1tCohyAk4ZFohWCp"}
{"genre": "norwegian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/19hokNIii4ydJVqttOkpXi"}
{"genre": "israeli folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1dIz3iZu36WJbgNWdmZIyi"}
{"genre": "instrumental math rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2chkIBpDgwkNgmkB1Viavs"}
{"genre": "fidget house", "spotify_playlist_url": "https://open.spotify.com/playlist/6vat2V2zBVw4cVQyp62EBQ"}
{"genre": "funky tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/7DMszOOe5DQPifzW4EHD7w"}
{"genre": "beach house", "spotify_playlist_url": "https://open.spotify.com/playlist/57SpJFKFiMmSLzOmOq2CaZ"}
{"genre": "malaysian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1LXDDX1G91YLmWJbgSdquu"}
{"genre": "german jazz rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5TQqMS1OBgLgi64wgDfgWB"}
{"genre": "taiwan idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3T7fgs4KaPs3HUbhHBizyb"}
{"genre": "uk desi rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1L8b3rshioVsle9aLhnOBn"}
{"genre": "oriental metal", "spotify_playlist_url": "https://open.spotify.com/playlist/489vrXrd6VEejJPJTROXwl"}
{"genre": "rajasthani pop", "spotify_playlist_url": "https://open.spotify.com/playlist/63Am0PGX5N7ZOxvuu6oTXv"}
{"genre": "ukrainian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/2PaajqPSi1xmO8Pkk8uJQV"}
{"genre": "electro dub", "spotify_playlist_url": "https://open.spotify.com/playlist/24sHQKaNzXX45rkgzzAiEj"}
{"genre": "japanese ska", "spotify_playlist_url": "https://open.spotify.com/playlist/2xAhznxb3sgTewpRkvidKU"}
{"genre": "irish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3rm5ycg2D4VayBq52p478N"}
{"genre": "jirai kei", "spotify_playlist_url": "https://open.spotify.com/playlist/5CEI3RTXF487Lu9KGk76pb"}
{"genre": "new tribe", "spotify_playlist_url": "https://open.spotify.com/playlist/0bW80mIdkzLcN8Z9YZ0KE7"}
{"genre": "lo-fi brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/33mIX3kzpt4p3BGv0b508d"}
{"genre": "turntablism", "spotify_playlist_url": "https://open.spotify.com/playlist/5ZkLWGmHP329LAyPnpvydQ"}
{"genre": "new england emo", "spotify_playlist_url": "https://open.spotify.com/playlist/5SfuVbeZFRwaXgZfXRd5So"}
{"genre": "latincore", "spotify_playlist_url": "https://open.spotify.com/playlist/212BIjWzEJVNkScamNoETN"}
{"genre": "jumpstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/0YLPrzWklBgy152fwVL0iT"}
{"genre": "hauntology", "spotify_playlist_url": "https://open.spotify.com/playlist/7yKED2Klt77liZOLVAwzma"}
{"genre": "zouglou", "spotify_playlist_url": "https://open.spotify.com/playlist/7kGA6YnBYlU3HplyYp9buA"}
{"genre": "igbo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0o5jBx4Az0Klnb2DXRsKzD"}
{"genre": "french indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4xsPUaS4EwvnxnOgU7AgOF"}
{"genre": "dreamgaze", "spotify_playlist_url": "https://open.spotify.com/playlist/1dOpDzDs3D7fQ43QUabPH0"}
{"genre": "arkansas hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1iyKq2x8WxddVIZNC4Uoh9"}
{"genre": "children's choir", "spotify_playlist_url": "https://open.spotify.com/playlist/7rAlDSQkUjL5aaGe5PQDd1"}
{"genre": "riddim dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/5JemXUnCO5ULaqdFJG6d67"}
{"genre": "olympia wa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4tUy7iRiYHzgerNzTAQjNg"}
{"genre": "korean singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/0F5v9iMoWvTJVQLrYIH5Xb"}
{"genre": "orthodox chant", "spotify_playlist_url": "https://open.spotify.com/playlist/1KZMCWImik3vA17zVLJ3c3"}
{"genre": "new delhi indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7kaTOk3XhLr5QIC7hZQ9fK"}
{"genre": "hong kong rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5OerOfpMHyskx0R7AQ2tYr"}
{"genre": "dc hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0DrrEFJAuUDG4PMJ0SP0oM"}
{"genre": "elektropunk", "spotify_playlist_url": "https://open.spotify.com/playlist/5YLBtpHPzN4KejDAjeGSBt"}
{"genre": "melbourne indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2V5cDE76iiL5Gm8vdbHePQ"}
{"genre": "rock viet", "spotify_playlist_url": "https://open.spotify.com/playlist/6qVh7Afbsv1raiNNAioHSs"}
{"genre": "viet remix", "spotify_playlist_url": "https://open.spotify.com/playlist/5PZu55kuQyZjNE43eQuuTB"}
{"genre": "chanson virale", "spotify_playlist_url": "https://open.spotify.com/playlist/6Ic0Ef0ztGNGTirOaWNCUB"}
{"genre": "north carolina indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2QecrVF3lRAI082RQiH5pd"}
{"genre": "luk thung", "spotify_playlist_url": "https://open.spotify.com/playlist/1rdqGPtCn0Tgdl5gjw8RkO"}
{"genre": "corridos cristianos", "spotify_playlist_url": "https://open.spotify.com/playlist/4BNaAjlRbUX7aUo4RdeVJ8"}
{"genre": "garage pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5vK4LD2FMuq92yLbkU1aeL"}
{"genre": "scottish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6JlPFzG76YouNrIG7zlaZo"}
{"genre": "hard motivation", "spotify_playlist_url": "https://open.spotify.com/playlist/7c5F5HnMg6HCmYQSV6cxc8"}
{"genre": "norwegian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0jB6UfkDXKDPt4Q5wYluty"}
{"genre": "bluegrass gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/2y2KkDXCURfqez8Uvh8dtY"}
{"genre": "motivation", "spotify_playlist_url": "https://open.spotify.com/playlist/5BBSSBa1Joklnlwpu0Np7L"}
{"genre": "electro trash", "spotify_playlist_url": "https://open.spotify.com/playlist/6TChfUHNG9wRr4bmIRJvNV"}
{"genre": "musica canaria", "spotify_playlist_url": "https://open.spotify.com/playlist/7ugNYbNvdp5fz9dWLxd0GT"}
{"genre": "russian ska", "spotify_playlist_url": "https://open.spotify.com/playlist/6HZZEMqGEsgkveYAGbjWCw"}
{"genre": "chanson quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/1LKnSH3ee7Lv4AU6cohnTO"}
{"genre": "instrumental acoustic guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/3Yxx0Sca9slhFdzbUZLlyR"}
{"genre": "progressive trance house", "spotify_playlist_url": "https://open.spotify.com/playlist/3JDDP1JjveG5kUAnEIQK1l"}
{"genre": "trinibad", "spotify_playlist_url": "https://open.spotify.com/playlist/0tqAfBZxbPFjeWwKFpfH9F"}
{"genre": "piratenmuziek", "spotify_playlist_url": "https://open.spotify.com/playlist/4SszPGbd85kgL72aptI3Cs"}
{"genre": "speed garage", "spotify_playlist_url": "https://open.spotify.com/playlist/74tAe4b6IqbWoEZPusHk5d"}
{"genre": "swedish heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7x9EiG52OyQd4MkoE7QKtp"}
{"genre": "clean comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/6nyFJksfTucl1yODVstEcL"}
{"genre": "japanese jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7xd0MAvjgkDntWn9v8uTDs"}
{"genre": "bolobedu house", "spotify_playlist_url": "https://open.spotify.com/playlist/7dUNJ7MzTkgLbtSd5smW9T"}
{"genre": "greek indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5UMnYHbk0p2Ng3lCiVosMZ"}
{"genre": "nyhc", "spotify_playlist_url": "https://open.spotify.com/playlist/7nircqacJ9I8CqYs9HdKtY"}
{"genre": "spanish synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/3i8QudYaXilRrGFzIw1Z4y"}
{"genre": "balearic", "spotify_playlist_url": "https://open.spotify.com/playlist/3FDQXSzsETVYzbrfOEEJnQ"}
{"genre": "reunion pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2AL1ODIUGH6VOz6jBdmzfw"}
{"genre": "doujin", "spotify_playlist_url": "https://open.spotify.com/playlist/5mFGx6JHA2RCwFasUx2a6R"}
{"genre": "hindustani classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7mQXEFCmWw09h5Mv4PcVfI"}
{"genre": "downtempo bass", "spotify_playlist_url": "https://open.spotify.com/playlist/1UOmuputKRhxDmuYDoaBsA"}
{"genre": "latin ska", "spotify_playlist_url": "https://open.spotify.com/playlist/7HSFHkTHpBbDuhTyP68zww"}
{"genre": "early synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/0xEa3FPeHUyc9SfstOUTGb"}
{"genre": "azeri traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/71YD8cHaPdQFArdFt4J2Uk"}
{"genre": "western americana", "spotify_playlist_url": "https://open.spotify.com/playlist/0wngtIMvcnsMdZbd9xukhI"}
{"genre": "hard industrial techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6LC1olQQ2lwUpbwCzWF8P7"}
{"genre": "bounce", "spotify_playlist_url": "https://open.spotify.com/playlist/332sHfXUaNawEwiK4brjaQ"}
{"genre": "hip hop timur", "spotify_playlist_url": "https://open.spotify.com/playlist/57XE8u2ZwaW9wpYGeZzQLf"}
{"genre": "classic portuguese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/196T2qP29EjWxI1x6oSiXa"}
{"genre": "peruvian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6PRBsvj0lJtG5CUIwCiGMc"}
{"genre": "auteur-compositeur-interprete quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/52imK8Ok1NBfMljKJK0sA9"}
{"genre": "shojo", "spotify_playlist_url": "https://open.spotify.com/playlist/32DAcSQMhxt8hkJq17h8Gw"}
{"genre": "oceania soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/22dHFD1MN2DKvlSCDUcnDl"}
{"genre": "minimal wave", "spotify_playlist_url": "https://open.spotify.com/playlist/61AMB6Oddyl1hEUBd9A9sc"}
{"genre": "belgian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/3PBhul1KmVf1JVSErEgypU"}
{"genre": "cuban rumba", "spotify_playlist_url": "https://open.spotify.com/playlist/5ad7yD03OEXgjFYaon4oCQ"}
{"genre": "cumbia editada", "spotify_playlist_url": "https://open.spotify.com/playlist/1ufC9zPc70THwEs2Dh3Dbc"}
{"genre": "indie platense", "spotify_playlist_url": "https://open.spotify.com/playlist/694iQTlPxanplkodduKMU3"}
{"genre": "classic nz pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0239bbtXcNjUVZ1CkChY4K"}
{"genre": "adoracion pentecostal", "spotify_playlist_url": "https://open.spotify.com/playlist/5S5CAYEvpIC514oVgAkIDK"}
{"genre": "deep smooth jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4pkdnCP0Wo9Yg9Mn0XGmC8"}
{"genre": "korean dream pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5JurKzRB8hvNgb62HpYjFB"}
{"genre": "brass band", "spotify_playlist_url": "https://open.spotify.com/playlist/4T8VmUjhJbhSZbI1VrTOm4"}
{"genre": "polish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4h57lcwyBn5d5qSP7MchDj"}
{"genre": "hel", "spotify_playlist_url": "https://open.spotify.com/playlist/5kZ8kGO9umgnkB3kICpTsI"}
{"genre": "florida death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2yAIbLXe1tpWjvYZiAVr4M"}
{"genre": "talentkonkurranse", "spotify_playlist_url": "https://open.spotify.com/playlist/2uHuU0pVMlBym5w670ZXYa"}
{"genre": "ambient idm", "spotify_playlist_url": "https://open.spotify.com/playlist/5haig3RZ6OcU4Cz6AukvXY"}
{"genre": "italian lounge", "spotify_playlist_url": "https://open.spotify.com/playlist/5B1jm08xXIhqiw8ufQlqR4"}
{"genre": "techno rave", "spotify_playlist_url": "https://open.spotify.com/playlist/0FQBLVXObEachBjozNnbpM"}
{"genre": "future bounce", "spotify_playlist_url": "https://open.spotify.com/playlist/0mf43n3zvTz6LwGaq2wQw5"}
{"genre": "acid techno", "spotify_playlist_url": "https://open.spotify.com/playlist/1f0ODk7IQYTRx3PxZlCeAy"}
{"genre": "ballroom", "spotify_playlist_url": "https://open.spotify.com/playlist/24FlJf5U7AJ1AnlUY99TZD"}
{"genre": "hong kong hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0AdCrGQY3vhJvKNUWeQGQy"}
{"genre": "queercore", "spotify_playlist_url": "https://open.spotify.com/playlist/7msivIljALwqTDOrrdJk9K"}
{"genre": "musica criolla", "spotify_playlist_url": "https://open.spotify.com/playlist/7nKjcrZCdbtM0PZc5hSau2"}
{"genre": "bornesange", "spotify_playlist_url": "https://open.spotify.com/playlist/6S5gl15J9q0DHwi8curRUi"}
{"genre": "classic k-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3VHoSzjyYpM4sVrfQqdHd5"}
{"genre": "musica instrumental cristiana", "spotify_playlist_url": "https://open.spotify.com/playlist/1qD4vvatdMhsiIgUld9eET"}
{"genre": "euskal musica", "spotify_playlist_url": "https://open.spotify.com/playlist/4fLE9MkUAcauwyK84mkhl8"}
{"genre": "musical advocacy", "spotify_playlist_url": "https://open.spotify.com/playlist/2YO2pH8igKZ9bMbJ2kJGB9"}
{"genre": "straight edge", "spotify_playlist_url": "https://open.spotify.com/playlist/2dtelHlOSYB0TvjT8Vi18m"}
{"genre": "opera", "spotify_playlist_url": "https://open.spotify.com/playlist/3WCKVCDPZFEosVBDwn9eIB"}
{"genre": "thai teen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2zI5GAcPPcGTknted3Qdji"}
{"genre": "cdmx indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5mIxXHkKnD6sq7Wcb4af2u"}
{"genre": "scottish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1MahKbTxPADS807KPwQkHy"}
{"genre": "freak folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4KgZ9ZN10RfjRxBYkj6tTK"}
{"genre": "progressive uplifting trance", "spotify_playlist_url": "https://open.spotify.com/playlist/7u6WmGIdrl2LFd73vZhBJQ"}
{"genre": "kawaii edm", "spotify_playlist_url": "https://open.spotify.com/playlist/6Y6bL0xU3C0F7QNNATnL6P"}
{"genre": "guitarra mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/5RTfxVbSrJFhZTCV6CwYW9"}
{"genre": "canto popular uruguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/0gGcEI0i8JLJwb01lk6zlK"}
{"genre": "french baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/0mrfzeghcUlwuaNTCdCFZx"}
{"genre": "cha-cha-cha", "spotify_playlist_url": "https://open.spotify.com/playlist/0TF0ssEBoKpdbIeIsSfXXX"}
{"genre": "utopian virtual", "spotify_playlist_url": "https://open.spotify.com/playlist/5Cz5zXo7uWHPnhVDgFdRws"}
{"genre": "dakke dak", "spotify_playlist_url": "https://open.spotify.com/playlist/0fmxVcIZCywEvv7zXPjFPA"}
{"genre": "danseband", "spotify_playlist_url": "https://open.spotify.com/playlist/071azGlUdxShlM0wSbBBeu"}
{"genre": "rap underground colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/2XZIfOWzpelqxVLkbBEHIP"}
{"genre": "channel islands indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5vc8iHgY8M9XyaKFOfWIil"}
{"genre": "orebro indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2qFLCUdUal6bSkQEXbf9Mh"}
{"genre": "experimental bass", "spotify_playlist_url": "https://open.spotify.com/playlist/55CFBhiiIM4k0rUYbLWWPU"}
{"genre": "french folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6X9nqrlhVwQT5EjQHRZxG7"}
{"genre": "chinese drama ost", "spotify_playlist_url": "https://open.spotify.com/playlist/7Dlr19bDtTlFFYTAvEG7k2"}
{"genre": "salsa cubana", "spotify_playlist_url": "https://open.spotify.com/playlist/0vnGFiPxIyWRWlWRrd3nul"}
{"genre": "acid jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7vyHBfRfPOT8Sxy87P5osJ"}
{"genre": "sudanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7JKrUr5pDqLDJu30nsSig4"}
{"genre": "southern soul blues", "spotify_playlist_url": "https://open.spotify.com/playlist/565XIzDbVMHSvsM6QCSUDl"}
{"genre": "power-pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5otIcGrLz05cFq5Erhbdml"}
{"genre": "cape town indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1ga7kXhbcB4tsOfpZqP7UX"}
{"genre": "brutal deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5cU8GY8cqeSTkgTXaYzo5z"}
{"genre": "progressive sludge", "spotify_playlist_url": "https://open.spotify.com/playlist/7yt4wc1wdEaGjVSHWGUu5d"}
{"genre": "nuevo folklore argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/3vjHLrBtmxbKOk01YJdr5O"}
{"genre": "philly drill", "spotify_playlist_url": "https://open.spotify.com/playlist/2kXx0qFNlA40wuKmKeZaJ7"}
{"genre": "classic progressive house", "spotify_playlist_url": "https://open.spotify.com/playlist/7sbU5WLJxjZeBzFCF1HSHX"}
{"genre": "comptine", "spotify_playlist_url": "https://open.spotify.com/playlist/1PJcHjQejGViKFWUhkEaGi"}
{"genre": "african-american classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3bPyMItEC0e3OU8asnzdn3"}
{"genre": "native american contemporary", "spotify_playlist_url": "https://open.spotify.com/playlist/0MWd2kxEaYwZ2REf6yD5fQ"}
{"genre": "doomgaze", "spotify_playlist_url": "https://open.spotify.com/playlist/71zxZgihOnOsQiXXlaT5YZ"}
{"genre": "black thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/6Ht0Dm6RMGxWbrtPOPCSKX"}
{"genre": "folklore peruano", "spotify_playlist_url": "https://open.spotify.com/playlist/0QbcHoXOyUvJK1oKSn5Vgy"}
{"genre": "dutch singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/3F5jb4Sa56oBP6ZiuKPk4z"}
{"genre": "chinese manyao", "spotify_playlist_url": "https://open.spotify.com/playlist/5mTsY0boKtT3YqTPcTCULR"}
{"genre": "louisville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1W0VdiGxj7w2zd5RVl0rvV"}
{"genre": "nerdcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3FCkQ1BaTrdiKHd80jWipu"}
{"genre": "london indie", "spotify_playlist_url": "https://open.spotify.com/playlist/68flNqi5a3bGzvTqpCkNZS"}
{"genre": "orlando indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1vUxtPeUN3892nFZca6yo6"}
{"genre": "zikir", "spotify_playlist_url": "https://open.spotify.com/playlist/2QusAPixVAakbqYcK087KN"}
{"genre": "brazilian thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7roO0fEOrwx0GdJlqB3gSH"}
{"genre": "brazilian punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/62ZdK92qdn11OQmpgvteAd"}
{"genre": "stride", "spotify_playlist_url": "https://open.spotify.com/playlist/0krnYjt6NxEOYruMsGzUqt"}
{"genre": "contemporary gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/2zZGboZ0y5BaMeNxzIdtoh"}
{"genre": "tech trance", "spotify_playlist_url": "https://open.spotify.com/playlist/2MYwy50KqxrZV0b1kLuI8O"}
{"genre": "harpsichord", "spotify_playlist_url": "https://open.spotify.com/playlist/4YPQUwpbUmIt9PbVNCn000"}
{"genre": "trap metal italiana", "spotify_playlist_url": "https://open.spotify.com/playlist/1QdpuPWvKE55QcNJZWAjSU"}
{"genre": "reggae catala", "spotify_playlist_url": "https://open.spotify.com/playlist/6JeKLouon03R3B5yaGJIVw"}
{"genre": "classic japanese jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3Oopu8NYhJVIgMrYDy9mit"}
{"genre": "turkce remix", "spotify_playlist_url": "https://open.spotify.com/playlist/6bVYXFAfDGQZ1sZYVVIleo"}
{"genre": "synth punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0Wz1UwyA2R1KMsEh1Tkpj3"}
{"genre": "musica andina chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/7w6EzKwGvdYLggZAaq9xw2"}
{"genre": "telugu folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5kBbiu7DuLPkn2GuElAUmK"}
{"genre": "neo-progressive", "spotify_playlist_url": "https://open.spotify.com/playlist/4dwu8FLKXg4J3LQ4yHdVfr"}
{"genre": "canzone genovese", "spotify_playlist_url": "https://open.spotify.com/playlist/02FLWh9kum0IQe7T2q9RSL"}
{"genre": "tin pan alley", "spotify_playlist_url": "https://open.spotify.com/playlist/22TWbFEbnhHv3CLCxOjoBW"}
{"genre": "japanese math rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0pxnL0EQc3EFMYtxxL1Fkj"}
{"genre": "italian power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/767v4hBm6bZAwHptya3LcP"}
{"genre": "jump blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7t1UY9ai9TGUxcKreODyxw"}
{"genre": "west coast trap", "spotify_playlist_url": "https://open.spotify.com/playlist/0BraqFvmohtWS1TKtBVi6B"}
{"genre": "calypso", "spotify_playlist_url": "https://open.spotify.com/playlist/1dQS6IpttEEWQXrxyS61pl"}
{"genre": "ethiopian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3Qr0VHtF0DP2GMTFj3XJx8"}
{"genre": "new england americana", "spotify_playlist_url": "https://open.spotify.com/playlist/2dKpmkhjtnpUnqY6kDB3Mv"}
{"genre": "renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/0evPZ6WIgSKYY2gnlfXIdA"}
{"genre": "morna", "spotify_playlist_url": "https://open.spotify.com/playlist/6khu4gXbpy8qG2GW1UWLlI"}
{"genre": "rabindra sangeet", "spotify_playlist_url": "https://open.spotify.com/playlist/4oec56GSvIipuViMLNko7O"}
{"genre": "avant-garde metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6JXgCuj9eBDcCMT6qkOMog"}
{"genre": "sgija", "spotify_playlist_url": "https://open.spotify.com/playlist/5FtrhztyLvH54xTr9KOHtp"}
{"genre": "gbvfi", "spotify_playlist_url": "https://open.spotify.com/playlist/1fymlByuu9HabrD0hty0td"}
{"genre": "desert blues", "spotify_playlist_url": "https://open.spotify.com/playlist/5tJJ32hMWvFhIPLrHRreNZ"}
{"genre": "musique urbaine kinshasa", "spotify_playlist_url": "https://open.spotify.com/playlist/2AKq0Z7RkcTnueNFramScl"}
{"genre": "german post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5FzQOFCqG92Ja7AvQJu31o"}
{"genre": "argentine ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/5dis2SNFMhfm5iD1UO24LU"}
{"genre": "mashup", "spotify_playlist_url": "https://open.spotify.com/playlist/7ifqnqwYf2PT1QazqZ4ekQ"}
{"genre": "afrobeat brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/37SN8bvRfyrY8cDd2GIluM"}
{"genre": "space ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/5MTGyQmulkcK6VjLlZyI0O"}
{"genre": "classic nepali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2vX9LrZiITOIYR671WhGFy"}
{"genre": "swiss metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6TDadUNwdzYI5gwc2AkQzW"}
{"genre": "rap motywacja", "spotify_playlist_url": "https://open.spotify.com/playlist/7v1g6rtKTLmVoVDDzFv9qP"}
{"genre": "modern ska punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5avOxmrNuQYBeSkfAzDzwo"}
{"genre": "arabic jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4NWpBUbftWMvjRB1AsRCOI"}
{"genre": "french worship", "spotify_playlist_url": "https://open.spotify.com/playlist/22eZWJypNyQmV4ut5JwWhW"}
{"genre": "welsh indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5yQ0TDwTMx5PwL1suz5PC2"}
{"genre": "anarcho-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1gyxfWb5nNDYEOC7oPN2Qk"}
{"genre": "antilliaanse rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1f0lQFiKVA5j6DwdmCfGCr"}
{"genre": "rebetiko", "spotify_playlist_url": "https://open.spotify.com/playlist/32IC3D0niv0cIISHsGtehW"}
{"genre": "spacewave", "spotify_playlist_url": "https://open.spotify.com/playlist/2xzvhh7pEpGPJOLSE3FcTo"}
{"genre": "japanese rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/5mzgXrKqCpgGzapB3IM5kM"}
{"genre": "glasgow indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0IlZZPBp9JopGyzbdWoECa"}
{"genre": "jazz trombone", "spotify_playlist_url": "https://open.spotify.com/playlist/5wZvX36s2lmD1q9PrdZVEW"}
{"genre": "dark hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0AnIhnMNUYVFYsXULFr9Y2"}
{"genre": "canadian indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5cJZSH78SbIbw5vdPia24j"}
{"genre": "sevillanas", "spotify_playlist_url": "https://open.spotify.com/playlist/3eM7CzQvStWUs8B9XJTGbM"}
{"genre": "hard alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/2DbQNCosMDvDew7dKFGEMa"}
{"genre": "toronto rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5dNwPmkdZFN0PBpWnke6pp"}
{"genre": "japanese jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/3vcdeM6ldGdBYp6mEKTAKQ"}
{"genre": "kasi rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2V54BYCd7X71tiQvU9cR0H"}
{"genre": "russian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2sgKS2XmIrYZo9K94cfVOi"}
{"genre": "asheville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3z2RllPfFPitffsorrPc0J"}
{"genre": "forro tradicional", "spotify_playlist_url": "https://open.spotify.com/playlist/3op82yklunVucRFcANaJFS"}
{"genre": "528hz", "spotify_playlist_url": "https://open.spotify.com/playlist/3qHTGXTTyexCin7nO1Wbv1"}
{"genre": "kabyle", "spotify_playlist_url": "https://open.spotify.com/playlist/6DyS2bEJ435oeiHVmfqNhA"}
{"genre": "german show tunes", "spotify_playlist_url": "https://open.spotify.com/playlist/5uvN9thjAYIR1H0xuvinAS"}
{"genre": "musik anak-anak", "spotify_playlist_url": "https://open.spotify.com/playlist/32uPxKFfDNzcRHWxYhvF6S"}
{"genre": "cowpunk", "spotify_playlist_url": "https://open.spotify.com/playlist/6VbtVCyMUz0eoiWGl2r6g7"}
{"genre": "kannada pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6ws5wdeFSSKS3eLgbsKdLQ"}
{"genre": "nu skool breaks", "spotify_playlist_url": "https://open.spotify.com/playlist/6BfYBqrSm30CXrqFwecv5d"}
{"genre": "necrotrap", "spotify_playlist_url": "https://open.spotify.com/playlist/5U9DKTJsoG7y7HYwjTtkZh"}
{"genre": "chanson humoristique", "spotify_playlist_url": "https://open.spotify.com/playlist/6NlCQl1pNpTIvrvFB5Xtj6"}
{"genre": "plugg francais", "spotify_playlist_url": "https://open.spotify.com/playlist/7u3qNsonN2H8rqAvT1vjIW"}
{"genre": "classical guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/0qJTEzbjENk61TtYeqFxfq"}
{"genre": "german jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/47quI8Re3ItWH8Rvn9HSvk"}
{"genre": "cedm", "spotify_playlist_url": "https://open.spotify.com/playlist/53Rj4icQg1wx38THnNcMA8"}
{"genre": "porro", "spotify_playlist_url": "https://open.spotify.com/playlist/17tvDMuDgyuAvBSwF7zk9s"}
{"genre": "plena uruguaya", "spotify_playlist_url": "https://open.spotify.com/playlist/72EP5quMvlSfHdz3xazcwq"}
{"genre": "trap maroc", "spotify_playlist_url": "https://open.spotify.com/playlist/4qkkm4FHv9GVZuEeJjcSuB"}
{"genre": "lo-fi latino", "spotify_playlist_url": "https://open.spotify.com/playlist/1nFxxcluywOmPZPBkRYBCy"}
{"genre": "rap angolano", "spotify_playlist_url": "https://open.spotify.com/playlist/6kDPp6vQPfTLewr6vXZYMC"}
{"genre": "musica nicaraguense", "spotify_playlist_url": "https://open.spotify.com/playlist/2JwhJFWVeyvt8SEQXgmzHM"}
{"genre": "carimbo", "spotify_playlist_url": "https://open.spotify.com/playlist/2nR1xiBvZgUdia07IH3kdL"}
{"genre": "melanesian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7ydUTeRPQkeBGmwOZtDvL2"}
{"genre": "taiwan punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0KFA1EhvZjMISnKhtzbSiE"}
{"genre": "balochi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0UJnA86zRo8KYLPRygkrxd"}
{"genre": "egg punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZoEx06KGNEh90aExmyMf0"}
{"genre": "estonian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2xCIMhNgOWQm1iWpOdg0w3"}
{"genre": "rogaland musikk", "spotify_playlist_url": "https://open.spotify.com/playlist/63icIb0bWfEa00IPqakdqq"}
{"genre": "popgaze", "spotify_playlist_url": "https://open.spotify.com/playlist/30FpFGBFN7Jlu4ElSv5vTE"}
{"genre": "italian folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/26advC90paRzW89GH6WeKU"}
{"genre": "danish modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2q8VWIvm8iU5OkP0ITRfVF"}
{"genre": "russian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6NLtxoSHgVwYSgaaqsh1ff"}
{"genre": "ecuadorian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2BjQpTFsjFXTHbJAfJbv6l"}
{"genre": "irish indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7BIh11WdlHdXCweFeyjmJ6"}
{"genre": "rap criolo", "spotify_playlist_url": "https://open.spotify.com/playlist/3WimcdcNdj9vhbL0jd5l0f"}
{"genre": "american post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/31bKM5kvlRZr6Hqnu2Sxfg"}
{"genre": "indie cordoba", "spotify_playlist_url": "https://open.spotify.com/playlist/4n4CW3ZIFtShPKBUfkPSsq"}
{"genre": "nordic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2tz3Xb2QirbFQFv6mTU5vh"}
{"genre": "socal indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2uGGrLVv2N0rO7plbireqP"}
{"genre": "metal mineiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3iAMvHfqcqv7St4MLQRq9u"}
{"genre": "fussball", "spotify_playlist_url": "https://open.spotify.com/playlist/5zBCYWc3g9sxUMqPHMvERG"}
{"genre": "anime drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6RKSFlHc8CVKV3h6xMkc7W"}
{"genre": "japanese jazztronica", "spotify_playlist_url": "https://open.spotify.com/playlist/0Uq6sBasJecSFwXoQxRtbt"}
{"genre": "nordic folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5pTlHziwBE6lzIvpBvjfnL"}
{"genre": "brazilian progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1kymVzLVYVIaSutk4cwaRX"}
{"genre": "vancouver punk", "spotify_playlist_url": "https://open.spotify.com/playlist/05Ru5TAWwKOeac8bbJ838T"}
{"genre": "oi", "spotify_playlist_url": "https://open.spotify.com/playlist/3mg8CrTTMG66HCzZroE6TD"}
{"genre": "children's story", "spotify_playlist_url": "https://open.spotify.com/playlist/7x8tFMSNTZ8a6ono0obeRr"}
{"genre": "arab folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3ltjxxS7B8B3QAkH7KQMgY"}
{"genre": "streektaal", "spotify_playlist_url": "https://open.spotify.com/playlist/1t5McH091F60IJwZilOBPk"}
{"genre": "bulgarian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/4D579AitDZxdDNJ5jfA582"}
{"genre": "belgian singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/0MV4KTW4H2ezI4pKMcFID7"}
{"genre": "queer country", "spotify_playlist_url": "https://open.spotify.com/playlist/5lAp13nSaA7eHafwqV5ilp"}
{"genre": "indie curitibano", "spotify_playlist_url": "https://open.spotify.com/playlist/2fs6wwDi3xEmYOAdOBeIpG"}
{"genre": "chinese indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0OIcuYsVfWtMnBTqLShcPS"}
{"genre": "kyrgyz hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6q2003E46GzEMdWlPjMYqY"}
{"genre": "italian progressive rock", "spotify_playlist_url": "https://open.spotify.com/playlist/68yWjo2Nhi5q74Q58yt1mU"}
{"genre": "cuatro venezolano", "spotify_playlist_url": "https://open.spotify.com/playlist/2J08xzhYyCicufClGGjqtf"}
{"genre": "vgm instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/3KX6z1klrH9RrmD4hvjlAl"}
{"genre": "seemannslieder", "spotify_playlist_url": "https://open.spotify.com/playlist/5Z5hPa3ArCFK7CXuO9slVN"}
{"genre": "suomirap", "spotify_playlist_url": "https://open.spotify.com/playlist/0ocYi6NbDWukYi59kxyepA"}
{"genre": "k-pop reality show", "spotify_playlist_url": "https://open.spotify.com/playlist/19xCJGwHkNsJkIweqKNPR4"}
{"genre": "rap italiano old school", "spotify_playlist_url": "https://open.spotify.com/playlist/0u6wf7vFBFTHOewgTUjTR8"}
{"genre": "finnish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/24b96cJDoOKjQBeHGCLoH5"}
{"genre": "underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4oaHLBPfa0FHBZqvCxpudp"}
{"genre": "hyperpop brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/3tnrTxpU6p3yD7lqLQ1HdA"}
{"genre": "mexican metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5RmdN1TuYgoPmnQmMYE9X6"}
{"genre": "musica sarda", "spotify_playlist_url": "https://open.spotify.com/playlist/1f87xeybOvZWBVXTQ3TmXo"}
{"genre": "men chika", "spotify_playlist_url": "https://open.spotify.com/playlist/3YjMQe6dZPhCAMwGIhzYU8"}
{"genre": "manso indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1Ph8pxls7GNLTFH7fcWxKh"}
{"genre": "russian indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0lipeA35UsWVs6MsUAZSiy"}
{"genre": "danish indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1yVDbtMMff20mrratUXuSc"}
{"genre": "kundiman", "spotify_playlist_url": "https://open.spotify.com/playlist/4P3mhIRDU6iwzs9uuVFsyE"}
{"genre": "dungeon synth", "spotify_playlist_url": "https://open.spotify.com/playlist/6kLG3oulPcD3Q2cOEuO4fV"}
{"genre": "sinhala indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0COe0ewDiqcRDrCB2BUUGM"}
{"genre": "frankfurt electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/20wI9KYEcMyhlyPdVMJmMA"}
{"genre": "nashville americana", "spotify_playlist_url": "https://open.spotify.com/playlist/34hqvaKy6jIvN2hNf1sKlq"}
{"genre": "malaysian tamil pop", "spotify_playlist_url": "https://open.spotify.com/playlist/66ZjA8mLNtofmFFwL1qXpf"}
{"genre": "balkan brass", "spotify_playlist_url": "https://open.spotify.com/playlist/1CwMgCvKbC3lzhwj0egsMF"}
{"genre": "metal guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/6F4vsDq9BtEpFrSNqh2e6f"}
{"genre": "polish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0LV0cIIM4nRjBdq0A0EBKn"}
{"genre": "hip hop cubano", "spotify_playlist_url": "https://open.spotify.com/playlist/57gf7owU4MnQhpddEvqq8r"}
{"genre": "mbalax", "spotify_playlist_url": "https://open.spotify.com/playlist/4GP1p5en4emjaN4LXqCanQ"}
{"genre": "boy pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5dMfpcHbPq5DwOuDk6qsht"}
{"genre": "tekno", "spotify_playlist_url": "https://open.spotify.com/playlist/033GcMtC2caWh6MHodT6SO"}
{"genre": "vintage dutch pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0gJKJk0RtLI3DTT9OOyMow"}
{"genre": "goregrind", "spotify_playlist_url": "https://open.spotify.com/playlist/7qAZ2MO6zbNkhilDEqpPfj"}
{"genre": "czsk viral pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1QSrkrMmfEX0V2bYLYSE4h"}
{"genre": "brazilian groove metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3EP7fmtL45NXEL0tpoO2ca"}
{"genre": "gainesville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0JA3x9RMwEyt03U59Bl7yJ"}
{"genre": "bolero cubano", "spotify_playlist_url": "https://open.spotify.com/playlist/3qoRkWaFtGQeEy3PS3VuFd"}
{"genre": "classic greek rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3yO7yAkgfetYQ2hpYb2AJX"}
{"genre": "latvian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/64uNwoWinoCtqoIRe4f3mb"}
{"genre": "ritmo kombina", "spotify_playlist_url": "https://open.spotify.com/playlist/4PBSdWriXBfKhpYtHVk7ZK"}
{"genre": "nz electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/5ClgIbl6XFwPUHKP2cXdqk"}
{"genre": "persian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/3yFDk1kERD9HMY3OlxEbrM"}
{"genre": "spanish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/2SkLB5UGwScR0IVAMX048A"}
{"genre": "dayton indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3EA1iYJw37b2uUJTZEDQS8"}
{"genre": "electro-industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZVLhUadGf0IkCOecGIgtf"}
{"genre": "irish indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0Yk4pcyhMTdt3M4oThvYD1"}
{"genre": "japanese power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/45zrIOyjGiR04qvOUBhltM"}
{"genre": "bayerischer rap", "spotify_playlist_url": "https://open.spotify.com/playlist/74DjsGDWyJRTJSLGLX4cAp"}
{"genre": "argentine indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1kmByJrppUuQigskkJmGgv"}
{"genre": "soulful house", "spotify_playlist_url": "https://open.spotify.com/playlist/5KloWVVDflJ495FWRbh0QE"}
{"genre": "turkce trap metal", "spotify_playlist_url": "https://open.spotify.com/playlist/25ggwZmMC245VCZxV9PTYQ"}
{"genre": "keroncong", "spotify_playlist_url": "https://open.spotify.com/playlist/7hNOYSiftr0KFWblJ6ccTi"}
{"genre": "progressive death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5sEfquPnHosqWquqi93Ffh"}
{"genre": "mallsoft", "spotify_playlist_url": "https://open.spotify.com/playlist/4MDvMFbmhNDSIDlJmy2RAj"}
{"genre": "elephant 6", "spotify_playlist_url": "https://open.spotify.com/playlist/1pCKc8Kc87BG4FdIGKaQ5v"}
{"genre": "israeli trap", "spotify_playlist_url": "https://open.spotify.com/playlist/3zE5pYwFbC6sSjMRjvhePx"}
{"genre": "bulgarian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4CEY5gI3L7e6VhdDKbNfRR"}
{"genre": "man's orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/6wKQSVUwtqy0SxtBEGQcDs"}
{"genre": "ulkucu sarkilar", "spotify_playlist_url": "https://open.spotify.com/playlist/4lLbuMCdRlia25u4RwuiXz"}
{"genre": "marathi traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/5wpajAJ7PjWmj78XU0fcve"}
{"genre": "avant-garde jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/72YNCrIywbtPaFgFSQNI6X"}
{"genre": "folklore paraguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/5l5denoQepuhub22UhwhSb"}
{"genre": "world chill", "spotify_playlist_url": "https://open.spotify.com/playlist/2BdFdt6mjGNmXAHogW2yNR"}
{"genre": "indie shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/3AZb0wfzzrRTjcaD2AqV1r"}
{"genre": "spanish invasion", "spotify_playlist_url": "https://open.spotify.com/playlist/1VNvyyyQvTlmRax4cicUK3"}
{"genre": "south african deep house", "spotify_playlist_url": "https://open.spotify.com/playlist/11IIVaqPY3mfMjbjJbrp2l"}
{"genre": "cambridgeshire indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5JfxQFSy5D3ZGNOFop4ElR"}
{"genre": "merengue tipico", "spotify_playlist_url": "https://open.spotify.com/playlist/4UyR0hBQFwyU4LTOGgssyb"}
{"genre": "bali indie", "spotify_playlist_url": "https://open.spotify.com/playlist/42by0jpew5CNgNsXS9rjkq"}
{"genre": "country quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/0H51A6nNghqfiLc9wm47xR"}
{"genre": "tropical tecladista", "spotify_playlist_url": "https://open.spotify.com/playlist/0SybMyAwkrYehO7lUOT2hJ"}
{"genre": "chicago pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0sCxbu4WgloqSoxM5WZhjd"}
{"genre": "ska jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4b6NJsrgYmVbDsOclVNDud"}
{"genre": "gothabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/0D4LNcafhpgsbS1zddHRyN"}
{"genre": "japanese celtic", "spotify_playlist_url": "https://open.spotify.com/playlist/5litsrvBZvqdKKbJNf3cod"}
{"genre": "cristiana para ninos", "spotify_playlist_url": "https://open.spotify.com/playlist/5uVMV5k5Km2owQurA1DVHX"}
{"genre": "nova canco", "spotify_playlist_url": "https://open.spotify.com/playlist/64N6k7HTURpuTrigQO5eaO"}
{"genre": "north carolina emo", "spotify_playlist_url": "https://open.spotify.com/playlist/6UhiAgqwwUoXo4JOrV104r"}
{"genre": "german boom bap", "spotify_playlist_url": "https://open.spotify.com/playlist/4yxukBJleJySko2vU8I3Mz"}
{"genre": "post-post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0m55vLjsDe1eh1MjdPufNH"}
{"genre": "t-pop girl group", "spotify_playlist_url": "https://open.spotify.com/playlist/6WFgrmagtAXNG2qKgJgSD9"}
{"genre": "drill and bass", "spotify_playlist_url": "https://open.spotify.com/playlist/5GJ4YKR60brIy8f4NECcHG"}
{"genre": "avant-garde", "spotify_playlist_url": "https://open.spotify.com/playlist/2pz31tSbwDrb4p9F8LrWhM"}
{"genre": "canadian house", "spotify_playlist_url": "https://open.spotify.com/playlist/1VUoju1Asynop6UWLSOTqM"}
{"genre": "jamaican ska", "spotify_playlist_url": "https://open.spotify.com/playlist/6yXBRWwY8Tq2RTB2XiR9l3"}
{"genre": "huayno popular", "spotify_playlist_url": "https://open.spotify.com/playlist/7nIarVloLxPcdqFB57urun"}
{"genre": "accordion", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZyQy6seivo6jkWyyTmwWs"}
{"genre": "louvores pentecostais", "spotify_playlist_url": "https://open.spotify.com/playlist/1oC4g0U51Xk1Xu9VeGqJqD"}
{"genre": "swedish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/5CkBV1eSxFpDKCjPhu5MGq"}
{"genre": "mega funk", "spotify_playlist_url": "https://open.spotify.com/playlist/0PO5azqKb7jDQA7cADHMow"}
{"genre": "belgian dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/1gCKEPHP1xQmIBMqw4aF9M"}
{"genre": "french dub", "spotify_playlist_url": "https://open.spotify.com/playlist/1voV4h6VlOXXGfPiHfhXOp"}
{"genre": "funky breaks", "spotify_playlist_url": "https://open.spotify.com/playlist/4r7k2gHiV5NG8ErBhXySbS"}
{"genre": "vietnamese bolero", "spotify_playlist_url": "https://open.spotify.com/playlist/29lodCEQR3cCLJdljJOBxy"}
{"genre": "slovak trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2NiqWkKEoSIOSjP7xtNE2F"}
{"genre": "vaqueiro", "spotify_playlist_url": "https://open.spotify.com/playlist/5zHKUkCKINqHTGL2OlrGW4"}
{"genre": "rosary", "spotify_playlist_url": "https://open.spotify.com/playlist/38h45JzHtrOjAJAtbiwNJ3"}
{"genre": "cueca chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/49QcZpXO2EejFb1vupJ6OG"}
{"genre": "new orleans funk", "spotify_playlist_url": "https://open.spotify.com/playlist/5PunWS8lpbtXO1j0jQHNzI"}
{"genre": "new wave of thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Hsvc32wLYcMdIhjHozOBK"}
{"genre": "latin tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/3bP1vgmYyNso0EoemyVMBE"}
{"genre": "classic anime", "spotify_playlist_url": "https://open.spotify.com/playlist/2rA7ZBdvhthR7mgRVkqH2g"}
{"genre": "cambodian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0NtMwPn4FbUPwWGIK4lsH7"}
{"genre": "christchurch indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0N2noG0NiLIch1l0E7UdQg"}
{"genre": "czech singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/16PKet2nwdj5UHMEsVvkS5"}
{"genre": "electronic djent", "spotify_playlist_url": "https://open.spotify.com/playlist/3KVK40I3oBqzCiEm8nR5SX"}
{"genre": "british orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/6Mo9RKaNJKLiaTwmEifJmh"}
{"genre": "japanese post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4rqvk7iY925j9XgWmyCKgF"}
{"genre": "danish indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0KffTRrFZAKlhoEhdUREpV"}
{"genre": "industrial pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3jYAVSY29Gc023JUj7cGTf"}
{"genre": "rap inde", "spotify_playlist_url": "https://open.spotify.com/playlist/1DZCrKzfHHOUX82taVwX0s"}
{"genre": "space rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0NMsSrtXFTtRieF0kkxZxT"}
{"genre": "sudanese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3KWpwEOky1WFzVkW3zTN9y"}
{"genre": "fallen angel", "spotify_playlist_url": "https://open.spotify.com/playlist/5Voot6Qf3OJX5KukZ1dn4n"}
{"genre": "early reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/687DQ3iw9bFLVtheLCvqba"}
{"genre": "folclor afrocolombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/1lfIJ8IDE8KkDiZkqdhmGj"}
{"genre": "family gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/6uEYJ1Ag6Hj6GlVMbNzh93"}
{"genre": "deep dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/5MB3Fi7uDmoOlZkyctKwNK"}
{"genre": "ethio-jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/1a8QWAogYxy8ULfcuI181A"}
{"genre": "belarusian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4SbkCOtqMhatjtiEBf0fOW"}
{"genre": "proto-techno", "spotify_playlist_url": "https://open.spotify.com/playlist/2Y4LlOD06D7xMYCoqUBHXT"}
{"genre": "congolese gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/2VyKqSUlw6R8BlKyDRTb2H"}
{"genre": "gengetone", "spotify_playlist_url": "https://open.spotify.com/playlist/3lHgFkRGIlkadH19CSE3yk"}
{"genre": "italian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/40C4RcHHLDxFUuBeMryCPw"}
{"genre": "hokkien pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2VG2vSR5cA2UOgHWwzRpP4"}
{"genre": "pop cristiano", "spotify_playlist_url": "https://open.spotify.com/playlist/5jLOB73NKyu4fBNruE0EC8"}
{"genre": "progressive power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/19WG6CV3V43ALyOvQFv5U8"}
{"genre": "dutch dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/4g8LVP5IHyzBhYplyf5sLU"}
{"genre": "tipico", "spotify_playlist_url": "https://open.spotify.com/playlist/4CsPbPD3uTarkMmj4QtJCK"}
{"genre": "medieval", "spotify_playlist_url": "https://open.spotify.com/playlist/6ckHBekHAoozIV6ISOmvq1"}
{"genre": "voidgaze", "spotify_playlist_url": "https://open.spotify.com/playlist/1wks5Mj1FjxJLHWbmqx7Qp"}
{"genre": "kizomba antigas", "spotify_playlist_url": "https://open.spotify.com/playlist/1XYC5jzSXfaiWGalqKYrcZ"}
{"genre": "experimental folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0CGco9gTEucsrVG65NV5yZ"}
{"genre": "full on", "spotify_playlist_url": "https://open.spotify.com/playlist/1PHIl1Zi6JSVHTTgXVVTFa"}
{"genre": "thai ost", "spotify_playlist_url": "https://open.spotify.com/playlist/3TSPcCQfHfv9ga1UTKeBTH"}
{"genre": "icelandic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZwsszHLVGTnNJRILoxkfm"}
{"genre": "swedish doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4OEl8ZiR5J1tfNVCfPugP5"}
{"genre": "greek metal", "spotify_playlist_url": "https://open.spotify.com/playlist/40SU6Jnb1f0fYjpN1bmhjP"}
{"genre": "folklore nuevo argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/6tkDudfPkHyBopqdFxQBxf"}
{"genre": "tamborazo", "spotify_playlist_url": "https://open.spotify.com/playlist/2iSGlKIWVcXLOFGhFO6uWJ"}
{"genre": "cincinnati rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5rY7IjKJrNuttmf9pyhQCH"}
{"genre": "mappila paattu", "spotify_playlist_url": "https://open.spotify.com/playlist/73rlZyf0V8gcDQF6TB1JMj"}
{"genre": "hard techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4Np94khIq8LGHOfmysON8v"}
{"genre": "classic finnish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0qm7fXxjgQ8pQc6WpRE3yD"}
{"genre": "folclore tucumano", "spotify_playlist_url": "https://open.spotify.com/playlist/5c81UwzYNYiV0qlSA9eQ8x"}
{"genre": "lds instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/4LMmTHb7UkNibXuX7hdYrT"}
{"genre": "bajki", "spotify_playlist_url": "https://open.spotify.com/playlist/2GdtwYYDxN65eReNI2hL90"}
{"genre": "romanian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/41CsfNQA2R4quZUDGK3xFH"}
{"genre": "post-doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6qfgxwWi0nedrduWtSUGiw"}
{"genre": "cumbia boliviana", "spotify_playlist_url": "https://open.spotify.com/playlist/3SwCXSJe5qaCRlxud8SDuU"}
{"genre": "son cubano", "spotify_playlist_url": "https://open.spotify.com/playlist/4xjjbNLvFXkiPRtPJ1JDDH"}
{"genre": "c86", "spotify_playlist_url": "https://open.spotify.com/playlist/1qpcTBjAx26Xiw6ZClVVGm"}
{"genre": "modern funk", "spotify_playlist_url": "https://open.spotify.com/playlist/3yFZlBn3cORhGoEfCHTdKk"}
{"genre": "irish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/7vtKvrXpzwYH31cDsCSL5z"}
{"genre": "indie dream pop", "spotify_playlist_url": "https://open.spotify.com/playlist/65dulZCpRQYycXzkRXiRLj"}
{"genre": "tamil worship", "spotify_playlist_url": "https://open.spotify.com/playlist/7uK5DYj7rEXdB83xED01Qr"}
{"genre": "neru", "spotify_playlist_url": "https://open.spotify.com/playlist/3mTv8YnTdrpfdmQRSiu1dx"}
{"genre": "persian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5B4I2Fm5KKx72aBld3dUIp"}
{"genre": "danish electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/32NHjtLnDaq2cH4ruoZ8pH"}
{"genre": "depressive black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4qpdGrwHTenL9t4m2nAbK5"}
{"genre": "norwegian folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7cuWy2JG47GHXDDsNrzSIa"}
{"genre": "old-time", "spotify_playlist_url": "https://open.spotify.com/playlist/6w2aSUJNW2QSTu3IwxzCXW"}
{"genre": "irish pub song", "spotify_playlist_url": "https://open.spotify.com/playlist/31kp3FbHcLyawjY5YWDkHb"}
{"genre": "autonomous black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2F0nBrOtCk2GBv4gSxbwt6"}
{"genre": "football", "spotify_playlist_url": "https://open.spotify.com/playlist/3kNWVqxt0cR2phbffWW78v"}
{"genre": "j-core", "spotify_playlist_url": "https://open.spotify.com/playlist/6EyM9BeEm0vZvSkQyGaLkN"}
{"genre": "dublin indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0hsjAeUWjYIr7sospfADJk"}
{"genre": "korean electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/5vIBFEypI86kgUNJJBCmbN"}
{"genre": "nz singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/4VfL2DMccZY34iNewTZKWZ"}
{"genre": "rap liegeois", "spotify_playlist_url": "https://open.spotify.com/playlist/3Z3XwVYP8GbKCyWdOIy8ug"}
{"genre": "instrumental djent", "spotify_playlist_url": "https://open.spotify.com/playlist/73fiuq4L8KLuDghQs9Bs7D"}
{"genre": "zamba", "spotify_playlist_url": "https://open.spotify.com/playlist/4BLHWGRsNFy6C64njAPdJ2"}
{"genre": "danish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2XFrsvPGbamN9w2C57a9hg"}
{"genre": "choral", "spotify_playlist_url": "https://open.spotify.com/playlist/1OMI0VoGeq1WEgeDEN2P52"}
{"genre": "pop ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/2iboRnpimzAlpZAbpIK7jt"}
{"genre": "downtempo deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5bNJ8LeBiHjPcsmumc9i3P"}
{"genre": "turkish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZJAsa6M7ro0Y5BoKV9R2x"}
{"genre": "puerto rican folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2Fk5nop80n0zvafa2zf6G0"}
{"genre": "coupe-decale", "spotify_playlist_url": "https://open.spotify.com/playlist/6gA990HYUuwO7HEyb0l4RD"}
{"genre": "traditional soul", "spotify_playlist_url": "https://open.spotify.com/playlist/7bFeIYoiVjcRVG7az4oPtK"}
{"genre": "australian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/33kqbVFZdUv4JuMUzFctmt"}
{"genre": "german heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6V610CI0YGTFiMWvm8fzeU"}
{"genre": "old west", "spotify_playlist_url": "https://open.spotify.com/playlist/5fEBnwOg3ZvXZVCG9uRXWX"}
{"genre": "ilahiler", "spotify_playlist_url": "https://open.spotify.com/playlist/2CokkRf7w8GTtZsWl9jV8d"}
{"genre": "crust punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1M4UmyNnokZRdeAmBEaftG"}
{"genre": "operetta", "spotify_playlist_url": "https://open.spotify.com/playlist/0F7i7LpeujWblHYMdonb0g"}
{"genre": "musica santomense", "spotify_playlist_url": "https://open.spotify.com/playlist/0E4FLbh9NOh3rV0mQVVvHW"}
{"genre": "classic sinhala pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3jf3D3t1AT3tuNLdbDLBfs"}
{"genre": "black punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1DcAt1K55Jaam0yRSN5VQ3"}
{"genre": "sydney indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3QHC3pILgEDrfF8GKslczN"}
{"genre": "phleng phuea chiwit", "spotify_playlist_url": "https://open.spotify.com/playlist/6GK8bZbsxV9FRchdMmeTN3"}
{"genre": "adoracion", "spotify_playlist_url": "https://open.spotify.com/playlist/4iIcSDqi069piXRq7Y5x1C"}
{"genre": "irish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5ppMC4JfzbAFlIVXLQHT2v"}
{"genre": "slovak punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3c0ylRbWiGjyROJSwmDHEA"}
{"genre": "semba", "spotify_playlist_url": "https://open.spotify.com/playlist/4nXjDD7cf9Ljrcjxo8iiir"}
{"genre": "commons", "spotify_playlist_url": "https://open.spotify.com/playlist/3CBfMoFYBPPtZNE3uRlmZi"}
{"genre": "okc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6mx4NyNKlKzqaDTqDbYyy4"}
{"genre": "zen", "spotify_playlist_url": "https://open.spotify.com/playlist/7y2Av5WgZgD7jSuQZu6M7n"}
{"genre": "musica ayacuchana", "spotify_playlist_url": "https://open.spotify.com/playlist/3NnhFai8X6CdYvP1Q1tOSE"}
{"genre": "finnish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3JICuz8Q3T8mtXBYNIxwcd"}
{"genre": "kc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/54cwyXraFoPlBsHdHFn27t"}
{"genre": "ska espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/4F2G9hHuRT4T6wWwELOhHI"}
{"genre": "yaoi", "spotify_playlist_url": "https://open.spotify.com/playlist/1eWtvA0Byu9Wu7LENK35Dp"}
{"genre": "hard trance", "spotify_playlist_url": "https://open.spotify.com/playlist/3S1y29gI6Wpchw9YCBHXM9"}
{"genre": "melodic hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/33jX0HQ4Ghh1RrEfZqFs1O"}
{"genre": "coral gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/5Uq68hKfqki0I8fJ3y7AHS"}
{"genre": "nz indie", "spotify_playlist_url": "https://open.spotify.com/playlist/30vAng8N6dO0Reg7mS1MFp"}
{"genre": "rap kreyol", "spotify_playlist_url": "https://open.spotify.com/playlist/3bGza7Mx5r2yTjbAqsB4v1"}
{"genre": "garage house", "spotify_playlist_url": "https://open.spotify.com/playlist/1QOMMQeQ9X79U3JtRZXy57"}
{"genre": "gqom", "spotify_playlist_url": "https://open.spotify.com/playlist/0V6rAUFWyVrTdxt701eZDh"}
{"genre": "jazz mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/2QItDAo6NrPbTLzYYg1j8s"}
{"genre": "uk dub", "spotify_playlist_url": "https://open.spotify.com/playlist/73BLB2ZMlXTieOIXEeOVDY"}
{"genre": "turin indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1jraqJZXXsiCwPb9Ykobhv"}
{"genre": "psychokore", "spotify_playlist_url": "https://open.spotify.com/playlist/2CzS8nY6QhnbTdO6zhSOua"}
{"genre": "indonesian indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZgGRRngNcunvsLOgBEJxL"}
{"genre": "svensk progg", "spotify_playlist_url": "https://open.spotify.com/playlist/6haN1TB4mI5bhBuxHSIQsp"}
{"genre": "thai pop rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3HKMeSxSvgQsZWN2hXmtKb"}
{"genre": "forro gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/2i62IT8MhgcxSXVpeq5ZT1"}
{"genre": "munich indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4x4klMCmllIPRwBRk1t5dQ"}
{"genre": "ugandan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0IWwKV3n1BCwhQYInEw8ef"}
{"genre": "kizomba cabo-verdiana", "spotify_playlist_url": "https://open.spotify.com/playlist/6U7XM4g22ccWDFS2xwJxbV"}
{"genre": "sichuanese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2ndBbRyLgo0vNL9SDNpVPy"}
{"genre": "modern old-time", "spotify_playlist_url": "https://open.spotify.com/playlist/2OuXPWzn1Ih8B8u9kPnh5g"}
{"genre": "canadian modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3JyntNJlx2qCSFZlol9fA6"}
{"genre": "musique guadeloupe", "spotify_playlist_url": "https://open.spotify.com/playlist/04ZPZ3SUOh8GvHakbwkkg1"}
{"genre": "swedish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5FVe9WkNb8luUlA4481SUW"}
{"genre": "cypriot pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5BrYh0kTLQjuxtraCU16e2"}
{"genre": "vancouver metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4ve4UMHBKvtSTCQrkdEihv"}
{"genre": "jazz clarinet", "spotify_playlist_url": "https://open.spotify.com/playlist/6CXa9mSWjMfcAp07TyU60l"}
{"genre": "finnish hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6o5FOjzzal4sPtjeonHloI"}
{"genre": "musica tabasquena", "spotify_playlist_url": "https://open.spotify.com/playlist/1RjbzvmW1Y1tDBt8PCiDqQ"}
{"genre": "audiophile vocal", "spotify_playlist_url": "https://open.spotify.com/playlist/2b3npHUEdwZfeLXj8JR1dh"}
{"genre": "modular synth", "spotify_playlist_url": "https://open.spotify.com/playlist/7GjzZST3g8PmSlD8PO0dDc"}
{"genre": "arunachal indie", "spotify_playlist_url": "https://open.spotify.com/playlist/52wcnfXAXtA611s1xs6xNH"}
{"genre": "slow game", "spotify_playlist_url": "https://open.spotify.com/playlist/0qxI6lRUwws4qXyriYiINB"}
{"genre": "polish blues", "spotify_playlist_url": "https://open.spotify.com/playlist/6GM80waFvLZoWUIAcFE9ZB"}
{"genre": "krautrock", "spotify_playlist_url": "https://open.spotify.com/playlist/3IttYEBZxFNRk0J6eZaHDd"}
{"genre": "nwocr", "spotify_playlist_url": "https://open.spotify.com/playlist/3uHhaeuWuy5wuL6WIAxaWV"}
{"genre": "nagpuri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/63ddQs8NL9YVw5dAbArCLQ"}
{"genre": "japanese underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3esumTS0Hg0r26nFSzm9vz"}
{"genre": "omaha indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6XPfsGUq0VQZQqaaJFIlPH"}
{"genre": "tunisian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5ytzcJ3FZhJGgQupUva1lT"}
{"genre": "vintage tango", "spotify_playlist_url": "https://open.spotify.com/playlist/2XOLY2xHGJ9usihj3VAJYS"}
{"genre": "folkmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/3cOxzJaR7I8ejYJfLUOx3f"}
{"genre": "palestinian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7iznfxFejfxYQgIjKo5Xyt"}
{"genre": "viola caipira", "spotify_playlist_url": "https://open.spotify.com/playlist/2iGD86hTlTtzdQmh3prGPr"}
{"genre": "dutch indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1v0tvgZsUlhoilou468HHW"}
{"genre": "korean underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0XeoMjDv09XMDKrfpJargo"}
{"genre": "outsider", "spotify_playlist_url": "https://open.spotify.com/playlist/5JFfeYhpP22w4FId5SqfF0"}
{"genre": "modern jungle", "spotify_playlist_url": "https://open.spotify.com/playlist/2GXoTvo5jfpD8h0qzAWvX0"}
{"genre": "musica para criancas", "spotify_playlist_url": "https://open.spotify.com/playlist/1xKqOfrHmrEHji2dFNOZrw"}
{"genre": "israeli indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0lKD2vCUwtVhp7wLhJoyWe"}
{"genre": "musica capixaba", "spotify_playlist_url": "https://open.spotify.com/playlist/0RS2azUaADBZ6gCOvSx8qs"}
{"genre": "symphonic death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5kdPHafCZx70YvDHkihSuT"}
{"genre": "connecticut hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2KHl9SZ2hSMhP3IC7f1aco"}
{"genre": "canadian garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/73V6wOBfxqKIuhvUJAGOXc"}
{"genre": "lagu sunda", "spotify_playlist_url": "https://open.spotify.com/playlist/2ALQhQTaGMcIhayym0beqS"}
{"genre": "musica jalisciense", "spotify_playlist_url": "https://open.spotify.com/playlist/3kgMtmgJJ0H5zGmB2q9WGm"}
{"genre": "kyushu indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4kwTjt7vJbeRnblAEobKbo"}
{"genre": "ukrainian folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4zdQRyM9Pyi1s2H5A5lnsI"}
{"genre": "rumeli turkuleri", "spotify_playlist_url": "https://open.spotify.com/playlist/1woJstwVhgJ0W2JvhsvaTq"}
{"genre": "library music", "spotify_playlist_url": "https://open.spotify.com/playlist/24azhjaYlJvkXF6xUKtnxp"}
{"genre": "modern uplift", "spotify_playlist_url": "https://open.spotify.com/playlist/08qLHWJM4s8TwWNCoVwFLg"}
{"genre": "midwest americana", "spotify_playlist_url": "https://open.spotify.com/playlist/35vbrIRrC2Yt071E4HL8Y4"}
{"genre": "german country", "spotify_playlist_url": "https://open.spotify.com/playlist/5ap6ICYu15SLUZ2WUdWUBA"}
{"genre": "musica sudcaliforniana", "spotify_playlist_url": "https://open.spotify.com/playlist/5aecqgzK5n0lzHq49O33JS"}
{"genre": "tulsa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7om0ntEtrOfsgzNzj65mqC"}
{"genre": "gypsy punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5OddLZaXByhRjd6UbnaB2s"}
{"genre": "vietnamese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3sEVkAftmt4GT4hheDpDsC"}
{"genre": "rock alternatif francais", "spotify_playlist_url": "https://open.spotify.com/playlist/3vjyDo80PnOOIAjaRLgQ41"}
{"genre": "dalarna indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7L4sllKmNY7c3HLWZunkwC"}
{"genre": "british contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/191fWkH2OE2jHsG0o2zxAP"}
{"genre": "miami indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7Cmn2Cj3tGonMFNq8VGjwB"}
{"genre": "outsider house", "spotify_playlist_url": "https://open.spotify.com/playlist/2B6gPUsTqEgz2W7W6gEOt3"}
{"genre": "draga", "spotify_playlist_url": "https://open.spotify.com/playlist/7suf8yqXe9PKVMMcOd2LQg"}
{"genre": "buffalo ny metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0Xnd1ETzdiJF6DTM9ORCtO"}
{"genre": "victorian britain", "spotify_playlist_url": "https://open.spotify.com/playlist/35phkNovnV5dsBwKpBHUuI"}
{"genre": "ukrainian post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2d0P0oRPgarSYL4eYYrpl2"}
{"genre": "oshare kei", "spotify_playlist_url": "https://open.spotify.com/playlist/477CYgQVNHk8Z76QbYjz01"}
{"genre": "swedish synth", "spotify_playlist_url": "https://open.spotify.com/playlist/4JVSAJQ38YCyCQvdOAGjI4"}
{"genre": "french punk", "spotify_playlist_url": "https://open.spotify.com/playlist/55zQD9JY29hERJC2iLmacZ"}
{"genre": "nephop", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZRohJVBnvbk6vLpojFYQj"}
{"genre": "heavy alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/6KCEBhb5eYhZfJQQBL6W3Q"}
{"genre": "deep german indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2louS5loLhAS2ysS3ciAcA"}
{"genre": "thai bl ost", "spotify_playlist_url": "https://open.spotify.com/playlist/7pkxaalwFqIjlL1rZXBe3S"}
{"genre": "symfonicky orchestr", "spotify_playlist_url": "https://open.spotify.com/playlist/1eXieDfUYsHEybjXNjJNfZ"}
{"genre": "rap capixaba", "spotify_playlist_url": "https://open.spotify.com/playlist/0iLibcnZSCyF4hOJQHkQHM"}
{"genre": "neue deutsche todeskunst", "spotify_playlist_url": "https://open.spotify.com/playlist/19g4JAc7ilM1LdOkb2zwVU"}
{"genre": "rock chapin", "spotify_playlist_url": "https://open.spotify.com/playlist/5XRjxXyGFJP5C2L1j9SyNC"}
{"genre": "brazilian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6aanKgTfkuFFjiP1YW9HBE"}
{"genre": "reggae peruano", "spotify_playlist_url": "https://open.spotify.com/playlist/6EvdyRPviF0kHCFqUmBnHe"}
{"genre": "modern goth", "spotify_playlist_url": "https://open.spotify.com/playlist/7nIyLU3pWFkevg3Kcer1ti"}
{"genre": "native american flute", "spotify_playlist_url": "https://open.spotify.com/playlist/5rQtlZ3zEXGxBm5ZpyNPPL"}
{"genre": "aussie emo", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZoecwlEBQTUVeG9AbAuHa"}
{"genre": "okinawan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6QpABgocYI5MBTYd9VTAa0"}
{"genre": "greek house", "spotify_playlist_url": "https://open.spotify.com/playlist/5OdDSF7xtSO7aE15YUecGm"}
{"genre": "dutch trap", "spotify_playlist_url": "https://open.spotify.com/playlist/0IdU45K5Xj2Y5uCYoeIBOZ"}
{"genre": "cover acustico", "spotify_playlist_url": "https://open.spotify.com/playlist/4JXOJ132JRGX7RGdJ9AtzE"}
{"genre": "classic icelandic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0vXJqihXL6TaC1df5Ev015"}
{"genre": "blaskapelle", "spotify_playlist_url": "https://open.spotify.com/playlist/1ODuLWN9mBdclo37ZgYUz1"}
{"genre": "hiplife", "spotify_playlist_url": "https://open.spotify.com/playlist/78cOU3Bnk7gqtnWRcxZvlJ"}
{"genre": "funana", "spotify_playlist_url": "https://open.spotify.com/playlist/2heQcYVOsKpYjaKfm3Tyfs"}
{"genre": "atlanta punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7HAemeH6qgoKySACL3ZUU2"}
{"genre": "uk worship", "spotify_playlist_url": "https://open.spotify.com/playlist/2MxKA7QOz7cY1HiaURHCFV"}
{"genre": "blasmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/03es0x1JNh66XhMmBD9AxS"}
{"genre": "granada indie", "spotify_playlist_url": "https://open.spotify.com/playlist/39NBwMJuLtBrOtISWj64Dg"}
{"genre": "mandolin", "spotify_playlist_url": "https://open.spotify.com/playlist/76roKwsb3rNacnWYupZEgb"}
{"genre": "zimdancehall", "spotify_playlist_url": "https://open.spotify.com/playlist/2K3BDsbnwwsJClbZqOQztK"}
{"genre": "hardtekk", "spotify_playlist_url": "https://open.spotify.com/playlist/489ivRjlG7G0Hbhan2ZUBn"}
{"genre": "swedish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1ng2topoxV6TEuDgm2Ai90"}
{"genre": "mestissatge", "spotify_playlist_url": "https://open.spotify.com/playlist/4mP5F204pWRtMTznnfHVhr"}
{"genre": "funk evangelico", "spotify_playlist_url": "https://open.spotify.com/playlist/7a1oABbPxSKFGu9UHx4oD9"}
{"genre": "salsa urbana", "spotify_playlist_url": "https://open.spotify.com/playlist/7EJiYcxL0iX886o8wEzsYg"}
{"genre": "musica madeirense", "spotify_playlist_url": "https://open.spotify.com/playlist/4jQqv6qtMOKg64k7tYBqzR"}
{"genre": "musica crista reformada", "spotify_playlist_url": "https://open.spotify.com/playlist/0HfTVNoI1ZDiyMDanHIOil"}
{"genre": "finnish indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6c1jaXKDRjxRN9X2NumZ3g"}
{"genre": "british country", "spotify_playlist_url": "https://open.spotify.com/playlist/45GY1sw2pj0LitunAGcMz6"}
{"genre": "tibetan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/02lAxUTKaWXNEtYAIEaZpP"}
{"genre": "bleep techno", "spotify_playlist_url": "https://open.spotify.com/playlist/74l4cXfulumPoQ7EyasgY8"}
{"genre": "trondersk musikk", "spotify_playlist_url": "https://open.spotify.com/playlist/15S4NfywNOYUorC4FzfPqW"}
{"genre": "atmospheric dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/0HoHL9NCEDRhXdcHl7jfqF"}
{"genre": "nordic post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3E6HUWCMr6NUqK6vOgQKod"}
{"genre": "dusseldorf electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/3Y0XUwYAtuk1dzWhLC8rPB"}
{"genre": "musiikkia lapsille", "spotify_playlist_url": "https://open.spotify.com/playlist/3GpkN7tZeJn4enj0fnVXzE"}
{"genre": "corrosion", "spotify_playlist_url": "https://open.spotify.com/playlist/5GgCJWob1ZqTc6JNtiQRBp"}
{"genre": "baiao", "spotify_playlist_url": "https://open.spotify.com/playlist/2whLuuxBLWqwEAtbXnGdIk"}
{"genre": "hungarian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/76cCPFZYhAISV0seUjoBHy"}
{"genre": "chinese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/6l6X13EYuQyuFBU6c6JRJM"}
{"genre": "beat italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/19ayJDtOtm2jjM4gTzGCfd"}
{"genre": "chamame", "spotify_playlist_url": "https://open.spotify.com/playlist/1hWRRO8uP8wgfyWoct4iAG"}
{"genre": "traditional folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5j3yYNLrqwPHmXzckFjOwW"}
{"genre": "persian melodic rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3QzbehysejEOZ7iPjQVmNG"}
{"genre": "canterbury scene", "spotify_playlist_url": "https://open.spotify.com/playlist/0cKGEchDZyIGPp7XulCZO4"}
{"genre": "pop costarricense", "spotify_playlist_url": "https://open.spotify.com/playlist/4dI3GRKhI01UFrxVw64TRg"}
{"genre": "croatian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1iFnviT7aGiPqpCpNT2hYy"}
{"genre": "musica tropical guatemalteca", "spotify_playlist_url": "https://open.spotify.com/playlist/6teNoO4vmGpsK5A1e5C06D"}
{"genre": "glitch pop", "spotify_playlist_url": "https://open.spotify.com/playlist/438VVpUapFpyqTrIEqTfwa"}
{"genre": "persian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/2pfNHK5P2G5YNNHZWVjUMP"}
{"genre": "rap paranaense", "spotify_playlist_url": "https://open.spotify.com/playlist/49vmN6VdGNxnBV02YPnEIV"}
{"genre": "duluth indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4uDweLoheknOlzPXJDEoh1"}
{"genre": "russian synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/154RoahggfPPg1RxygE1aA"}
{"genre": "samurai trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1kjv87IO9pfWr4WI5N5GL2"}
{"genre": "japanese vocal jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/04QZ4QK3XPrApbiFOIXJJG"}
{"genre": "grimewave", "spotify_playlist_url": "https://open.spotify.com/playlist/2nT30KPlGDd8vl9OIWTkJQ"}
{"genre": "russian trance", "spotify_playlist_url": "https://open.spotify.com/playlist/63LPoxJh7Vux6Oove5e5RW"}
{"genre": "trival", "spotify_playlist_url": "https://open.spotify.com/playlist/2yF75EnQd9BoJyqWrBnQQB"}
{"genre": "slovenian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2dfCXoa97rKRAg9WF8iQ3i"}
{"genre": "coco", "spotify_playlist_url": "https://open.spotify.com/playlist/167zi06RysrCJMuEz0M6XP"}
{"genre": "technical groove metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0PT8NnEbyqkuBITZXwei0N"}
{"genre": "austrian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5HAv8CH53gDzjRHw3s2TFD"}
{"genre": "swing italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/4CpRYvOQvDNuuTuO2qItpL"}
{"genre": "dark progressive house", "spotify_playlist_url": "https://open.spotify.com/playlist/49CisrDGk8SedCS99g0blP"}
{"genre": "scouse rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6dWBBpp1lebQAfwlMpnKfy"}
{"genre": "vaportrap", "spotify_playlist_url": "https://open.spotify.com/playlist/7o7kEPpjIe3yRRPbDFJSIR"}
{"genre": "hammond organ", "spotify_playlist_url": "https://open.spotify.com/playlist/0jroRKJ1TkA37bjmw3o6F1"}
{"genre": "maimouna", "spotify_playlist_url": "https://open.spotify.com/playlist/411LTLoWEppi7bG55d45XC"}
{"genre": "japanese contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3FK5Qrj27Y3jTRTsCRfRMI"}
{"genre": "dissonant death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3Ek4QdnTWKwhZ2hI1wfQwj"}
{"genre": "shimmer psych", "spotify_playlist_url": "https://open.spotify.com/playlist/1Q4lGxGOt6A6K9CdELz8jG"}
{"genre": "gothic americana", "spotify_playlist_url": "https://open.spotify.com/playlist/3s8q8jIapmc1VcZoG9HztR"}
{"genre": "experimental house", "spotify_playlist_url": "https://open.spotify.com/playlist/3DuxgqofnqkTigBNylYnve"}
{"genre": "deep adult standards", "spotify_playlist_url": "https://open.spotify.com/playlist/3N5lW1KhIBNZCa5x01ypla"}
{"genre": "japanese guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/0dWgFxR0ieemTbUe1nfLed"}
{"genre": "andean flute", "spotify_playlist_url": "https://open.spotify.com/playlist/0HpLtIPIu0BW0roCCEv0BS"}
{"genre": "marathi devotional", "spotify_playlist_url": "https://open.spotify.com/playlist/0qcFr7sptcLbUw1cbssor4"}
{"genre": "trio huasteco", "spotify_playlist_url": "https://open.spotify.com/playlist/1PDgMG37HPi6sOliSCO0GQ"}
{"genre": "austin hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5lr7bOFOEzL7I42C9uaBBm"}
{"genre": "mecha", "spotify_playlist_url": "https://open.spotify.com/playlist/32kBiwKxW9fEBsW43XF7dP"}
{"genre": "instrumental stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6CEUe0Nc4gTonVgMf5VDWO"}
{"genre": "pinoy alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2zoQWqkB0IHSABMyAqc7le"}
{"genre": "instrumental surf", "spotify_playlist_url": "https://open.spotify.com/playlist/28QheXSjeY6TmsCVFEHJnB"}
{"genre": "ghanaian gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/4OgjqkP9pt1HNq5eZwLmoZ"}
{"genre": "swamp pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2KOiyljP0uPAaPSjripotZ"}
{"genre": "brass band pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5W4WhpU7Kh07UlqYs4GtF7"}
{"genre": "haitian gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/4jxL2m66lGWk34OcPFXUHG"}
{"genre": "deep latin alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/0NhC7QKdjDqwq6qi70ZcNT"}
{"genre": "munich electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/0UlkQsu8up6NMjMrn2Ge48"}
{"genre": "432hz", "spotify_playlist_url": "https://open.spotify.com/playlist/5qQLE1iuD3CKOEXIb0fi7Z"}
{"genre": "kentucky punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1UolE09MPlJsiu4Qkd37vL"}
{"genre": "naat", "spotify_playlist_url": "https://open.spotify.com/playlist/6YuVMNonLhWi1sfudnUyZg"}
{"genre": "musica istmena", "spotify_playlist_url": "https://open.spotify.com/playlist/5yIGJGL7xNaqIMDX1lyBhK"}
{"genre": "german indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/53ORYkl8HFRtk3mm0t4pKD"}
{"genre": "telugu indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2vKQ6Ac1Pe7UnKLBQeB5kj"}
{"genre": "russian plugg", "spotify_playlist_url": "https://open.spotify.com/playlist/2NxU5PeN2WXEqjOrzOi1m1"}
{"genre": "neapolitan funk", "spotify_playlist_url": "https://open.spotify.com/playlist/3VccAjiWIggArBozHv1OZn"}
{"genre": "austrian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2pEF8qW6YyLXvEOflWiPTz"}
{"genre": "deep techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4oVXk7YCP6OUuRBAncQNQS"}
{"genre": "bath indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4n01jgud9nsl5RFVSuVKKb"}
{"genre": "icelandic electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1mGgbI8nhocQ7fhO9oWhbq"}
{"genre": "modern cello", "spotify_playlist_url": "https://open.spotify.com/playlist/2YV8gdvqTjwHFbED8er07E"}
{"genre": "eugene indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2J0d28Om9Lv9n9VC4QmjdL"}
{"genre": "plunderphonics", "spotify_playlist_url": "https://open.spotify.com/playlist/7mknhkyxBSQoGbmO6STTog"}
{"genre": "musica andina colombiana", "spotify_playlist_url": "https://open.spotify.com/playlist/0T8Dx6bhSlIwGwMdgqx9w7"}
{"genre": "spanish reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/1INVDvnPWXU4tJBxQzVhbe"}
{"genre": "dark jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6lMZE2UCxN6J7un54fIwAy"}
{"genre": "mongolian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/4NrJCQ3jxOl1fhMj0F9p2G"}
{"genre": "rennes indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7m6wlj8CXboEeoHPL5Sf8s"}
{"genre": "long island punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3GPYC8RKQqvwic7uRMwRWQ"}
{"genre": "christian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7m7jhomQZY5LM4GrWyMiut"}
{"genre": "kora", "spotify_playlist_url": "https://open.spotify.com/playlist/0Bkb5R26YzaX24j0rL1puy"}
{"genre": "jazz metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0gRjtLM7ocp0jndjkncxOf"}
{"genre": "canadian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/56AfuCaxyHLtpd3kZWQgay"}
{"genre": "spanish folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/48tTg9E77wOTUn8P66xenP"}
{"genre": "manitoba indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0ApbhEbGARjX0LGmI81jWi"}
{"genre": "balkan drill", "spotify_playlist_url": "https://open.spotify.com/playlist/7AYc8DXO2XO7bm4RH6WfqI"}
{"genre": "freeform hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/72P9BYdfc0XmY16sNnNpdi"}
{"genre": "technical thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/2zg2RD4bLpG41onEUg5RYO"}
{"genre": "48g", "spotify_playlist_url": "https://open.spotify.com/playlist/4GhzIuuhKmoxP4WMDukGhR"}
{"genre": "bass music", "spotify_playlist_url": "https://open.spotify.com/playlist/3fva5PDy3o8ewFmo0zHBLY"}
{"genre": "denton tx indie", "spotify_playlist_url": "https://open.spotify.com/playlist/01ChGD03RviMTi7OLvrxVG"}
{"genre": "nz children's music", "spotify_playlist_url": "https://open.spotify.com/playlist/5Pm8wEgXyNwyxrV8hXCZr9"}
{"genre": "drone folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2smdrEhX6cSfCspXoWF1XS"}
{"genre": "german thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/660Huir7rfthrl2FEo4sGL"}
{"genre": "zillertal", "spotify_playlist_url": "https://open.spotify.com/playlist/1fzcR3U9cUpJm92J14ThFS"}
{"genre": "latvian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6UNk3cgOY4fHzxNBXmSui9"}
{"genre": "greek downtempo", "spotify_playlist_url": "https://open.spotify.com/playlist/28qCNYcXyBvppVKPpZNfdd"}
{"genre": "eventyr", "spotify_playlist_url": "https://open.spotify.com/playlist/2IfQvbwOmPhvVhcZhMEXUl"}
{"genre": "emo punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7mGhICS65Y8036xSvdL5jN"}
{"genre": "russian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4Xmsi84ZemGTbWpN4ty8J5"}
{"genre": "retro metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZdTdH3hRFXGSUcw10OXYf"}
{"genre": "post-black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0BXtyZkCBonl5z9L4FbvBP"}
{"genre": "japanese blues", "spotify_playlist_url": "https://open.spotify.com/playlist/0x7Be1sfL0xp97cCQTuK9q"}
{"genre": "piedmont blues", "spotify_playlist_url": "https://open.spotify.com/playlist/2hBQIwJOWzLMWl10enb9uE"}
{"genre": "vintage hollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/0IeVWLiNFBT7uvVDXOVYuW"}
{"genre": "ambient psychill", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ai1OzIuu5d40Ce1UFl8IW"}
{"genre": "kentucky metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3Ql7BLoaArWWHZxNJdONp4"}
{"genre": "singeli", "spotify_playlist_url": "https://open.spotify.com/playlist/5XOIgM9rUSMgiM8CGfMLjg"}
{"genre": "choro", "spotify_playlist_url": "https://open.spotify.com/playlist/3Es2chZy6eQDXNi4eCDzPY"}
{"genre": "swiss house", "spotify_playlist_url": "https://open.spotify.com/playlist/3GrPSi790vyzZOp5KlrWex"}
{"genre": "nordnorsk musikk", "spotify_playlist_url": "https://open.spotify.com/playlist/4Nwu7l1nvV5a5ydeKJQkUo"}
{"genre": "nova musica paulista", "spotify_playlist_url": "https://open.spotify.com/playlist/5WNHSW7Y8P6th2aAW2PsqF"}
{"genre": "string duo", "spotify_playlist_url": "https://open.spotify.com/playlist/4Saga6gY5n6v8uKQflzihZ"}
{"genre": "indian underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4yjDnVbUOR0yT8TqV6UGZ5"}
{"genre": "nuevo flamenco", "spotify_playlist_url": "https://open.spotify.com/playlist/3MZY0MXbbyUKXPZ48AX8kU"}
{"genre": "armenian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7C4YA1mw3XW1fWcVqRQIvc"}
{"genre": "indy indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4zVQ8U68kvYzcN6Xb4yiNU"}
{"genre": "brazilian power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3l3PfTmx8jHrp0NeeEDkLt"}
{"genre": "musica indigena latinoamericana", "spotify_playlist_url": "https://open.spotify.com/playlist/3S3QryoGmumYB1YkvJNmoE"}
{"genre": "breakcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3OBvO6hmsS5BsYbciDddW7"}
{"genre": "new orleans soul", "spotify_playlist_url": "https://open.spotify.com/playlist/4mUdxCjluggErlGYq7E3jx"}
{"genre": "korean indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0AOmr6B5BlVubtXNOM5JfO"}
{"genre": "deathrock", "spotify_playlist_url": "https://open.spotify.com/playlist/0TvXLpy122QvbA0cBSkhxb"}
{"genre": "lagu bali", "spotify_playlist_url": "https://open.spotify.com/playlist/1dqR8owoT4vz61AMGMc0cA"}
{"genre": "classic dutch pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0bosE8y5GavdbMrDhEcSK7"}
{"genre": "jazz double bass", "spotify_playlist_url": "https://open.spotify.com/playlist/29BYlstSGlHGjaQk9bqNlY"}
{"genre": "modern enka", "spotify_playlist_url": "https://open.spotify.com/playlist/7seza3m5qG6QleGBNzhEqM"}
{"genre": "amharic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3cWG644N8CZjNIklVDPuzR"}
{"genre": "south african choral", "spotify_playlist_url": "https://open.spotify.com/playlist/27nN5LFsfA2HkilFH9fRCy"}
{"genre": "indie emo", "spotify_playlist_url": "https://open.spotify.com/playlist/0fgslmPIDxUJjaUNZpQsEY"}
{"genre": "russian trap metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0LrGZsH52We4H1lDNQQkQD"}
{"genre": "gothic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0xSpQ9AtQX8YjgYBVYHLll"}
{"genre": "emo trap italiana", "spotify_playlist_url": "https://open.spotify.com/playlist/0AFo791ONzlWZ73HnrJ8lD"}
{"genre": "musica baiana", "spotify_playlist_url": "https://open.spotify.com/playlist/66EO2XTAsVGNHIWDfwQx31"}
{"genre": "turkish metal", "spotify_playlist_url": "https://open.spotify.com/playlist/44bPq4GzXmjPqkVyGDpAo5"}
{"genre": "swing revival", "spotify_playlist_url": "https://open.spotify.com/playlist/14mCFCVqSNVJDVuFdwDOjs"}
{"genre": "deep christian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2JIjBQYWndDHEZNTNv5C9t"}
{"genre": "indonesian psychedelia", "spotify_playlist_url": "https://open.spotify.com/playlist/1Uw6qEQAeRsM7Dd82M2982"}
{"genre": "swedish house", "spotify_playlist_url": "https://open.spotify.com/playlist/5i7nNkeKMubSAhFDPhIeYv"}
{"genre": "rumba catalana", "spotify_playlist_url": "https://open.spotify.com/playlist/4s63F0tPbBZFctstOgQ6dB"}
{"genre": "jazz drums", "spotify_playlist_url": "https://open.spotify.com/playlist/347OhnWEkV9YCxJNWocQ7w"}
{"genre": "pittsburgh rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0tgPDhmWG9iaamzytuHJ00"}
{"genre": "musica eletronica gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/2yK8ebEZy4ZZuqwFODq9QQ"}
{"genre": "phoenix indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4tIeWe2IYZV2bG3Egkw6mG"}
{"genre": "spanish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0qBmyqsTcbWc8QnW8mKLek"}
{"genre": "charlotte nc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7eNu8ro1A6RDZwMPo3tCCT"}
{"genre": "darkstep", "spotify_playlist_url": "https://open.spotify.com/playlist/2oUR5RTzUhtwJypKmhuxdG"}
{"genre": "multidisciplinary", "spotify_playlist_url": "https://open.spotify.com/playlist/5OMIqj4ZIbO7KZZv3Q1prr"}
{"genre": "ambient post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0J2GQpfBHVY2qRaoBkQFO1"}
{"genre": "kaneka", "spotify_playlist_url": "https://open.spotify.com/playlist/1xSb1HgWR45RZcIZAC4Rq8"}
{"genre": "connecticut indie", "spotify_playlist_url": "https://open.spotify.com/playlist/57elLL2DHlR0zrTfPsOx7s"}
{"genre": "arab groove", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZsIEGkniMFdKLhMnIdk5X"}
{"genre": "charanga", "spotify_playlist_url": "https://open.spotify.com/playlist/4L18ziUY8P9SHL0dv0SpLX"}
{"genre": "kolkata indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0tNwwJQbHMES48ootJ1y1I"}
{"genre": "cantautor catala", "spotify_playlist_url": "https://open.spotify.com/playlist/0SljFhF4AFN2i1Ntyfq1st"}
{"genre": "tampa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0uGAwKwxPsuyNXulfbXNJp"}
{"genre": "dutch prog", "spotify_playlist_url": "https://open.spotify.com/playlist/72W6kffOpSoq0JocLRIHO3"}
{"genre": "geek rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2nuFDRMV9ePZJba5V94AJ8"}
{"genre": "seinen", "spotify_playlist_url": "https://open.spotify.com/playlist/1kwicosn87A9qgOAP0REZR"}
{"genre": "rhode island indie", "spotify_playlist_url": "https://open.spotify.com/playlist/41tRlkE8wyuONtruInGMvb"}
{"genre": "denver indie", "spotify_playlist_url": "https://open.spotify.com/playlist/03HwTZU40iEnWyRvOtR451"}
{"genre": "spanish noise pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3EY7xTU1vqV2Mow231iuZ4"}
{"genre": "german indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/12Mplc1KsXYz35MvysaJ02"}
{"genre": "virginia punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5Bkyd0BXBikpQah1jXqWYV"}
{"genre": "italian trance", "spotify_playlist_url": "https://open.spotify.com/playlist/3ckBFPOgYgKpF6P1QgBKXd"}
{"genre": "rap ivoire", "spotify_playlist_url": "https://open.spotify.com/playlist/3S5CflXChDW1V00nr5aqhk"}
{"genre": "vocal trance", "spotify_playlist_url": "https://open.spotify.com/playlist/4pkYvU2Gr39rQZ8JWzbdyc"}
{"genre": "jackin' house", "spotify_playlist_url": "https://open.spotify.com/playlist/3gjiYcI8PcYuztguDAdlLV"}
{"genre": "speed house", "spotify_playlist_url": "https://open.spotify.com/playlist/0axoic5r0fXvWONi5TKvse"}
{"genre": "indie valenciana", "spotify_playlist_url": "https://open.spotify.com/playlist/7bmbsNdDlNDr3LEDPt1JYK"}
{"genre": "warm drone", "spotify_playlist_url": "https://open.spotify.com/playlist/3maj6HHPJLHTNEm30OTkGd"}
{"genre": "villancicos", "spotify_playlist_url": "https://open.spotify.com/playlist/2RCHONozmen81t9iFSZ9xP"}
{"genre": "sepedi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3BW3cqDHqYSqC0B1a8xQcV"}
{"genre": "reggae maghreb", "spotify_playlist_url": "https://open.spotify.com/playlist/0t0Qv3Tj7sI4Th3T2zwhsj"}
{"genre": "igbo rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3T3uJTYjyJMUsm9y10xCaH"}
{"genre": "deep funk ostentacao", "spotify_playlist_url": "https://open.spotify.com/playlist/0VSDcgTOgN08cWVEkk4QBx"}
{"genre": "bard", "spotify_playlist_url": "https://open.spotify.com/playlist/7DQvyqAdgiGX09fZlo1JAj"}
{"genre": "swamp blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7hxOgWv1cdB6YnIpZxHG0O"}
{"genre": "vermont indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6Ejh1mnEuKQS1WiklGSRZd"}
{"genre": "musica feirense", "spotify_playlist_url": "https://open.spotify.com/playlist/71AA3D5B7W4Lm8uGG5GSO9"}
{"genre": "new mexico music", "spotify_playlist_url": "https://open.spotify.com/playlist/1Cvs6hwW3ac2JiTwiGlp6g"}
{"genre": "zilizopendwa", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZjTAVi7EIot1EPgaxoyO5"}
{"genre": "indie rock peruano", "spotify_playlist_url": "https://open.spotify.com/playlist/5VWangDzcQokrAcYlIvrL4"}
{"genre": "folklore chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/4Gr9r6eahRlkpflu763K1Q"}
{"genre": "deep soft rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3kmvXhorXrYxDH7cRkx3ZK"}
{"genre": "tamil devotional", "spotify_playlist_url": "https://open.spotify.com/playlist/3O3m8jxqqMXr0Iai69Xd1Y"}
{"genre": "korean trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1x5KJwBNPIy3bYltlNaNDK"}
{"genre": "japanese garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2gzxLFncxblaXSdVS8r4gA"}
{"genre": "belarusian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1ghBX7KDplRis0ISK7BHjq"}
{"genre": "musica quintanarroense", "spotify_playlist_url": "https://open.spotify.com/playlist/2WGSwDsQY9P0mrT4C7mjDp"}
{"genre": "british dance band", "spotify_playlist_url": "https://open.spotify.com/playlist/0siH6CPssx5JoGoqfz5ahx"}
{"genre": "jesus movement", "spotify_playlist_url": "https://open.spotify.com/playlist/6FPBJhg3fch0lcIL28Wpvg"}
{"genre": "deep norteno", "spotify_playlist_url": "https://open.spotify.com/playlist/3esSvKGfxhvtlpIjKE6ORD"}
{"genre": "alabama metal", "spotify_playlist_url": "https://open.spotify.com/playlist/19Mk3TNa4Gypv6LGMeklyS"}
{"genre": "galician rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0MGqujmWRe9njHpDUoIFGq"}
{"genre": "deep soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/6Pd01i30hTp25RltgY77HS"}
{"genre": "classic luk thung", "spotify_playlist_url": "https://open.spotify.com/playlist/5J6tUHPxVyzd4jRgIat5uc"}
{"genre": "indie siciliano", "spotify_playlist_url": "https://open.spotify.com/playlist/0UqZHLlya1q5Cd6xku9MuK"}
{"genre": "tatar pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3GY9leJtXKj3ztZiFNB4li"}
{"genre": "neo-pagan", "spotify_playlist_url": "https://open.spotify.com/playlist/0BKvOUdbAVUjMDmQtJ0bk8"}
{"genre": "leeds indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1y18nWKJAUmRUHT7sbLABU"}
{"genre": "cincinnati indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6tfBAhlKKQYI37j57lsrFs"}
{"genre": "oud", "spotify_playlist_url": "https://open.spotify.com/playlist/2QeOCpMQDMK4ZHfqT2pIc3"}
{"genre": "christian a cappella", "spotify_playlist_url": "https://open.spotify.com/playlist/0zfqVW6LOYYYPCwHNpbS4H"}
{"genre": "twoubadou", "spotify_playlist_url": "https://open.spotify.com/playlist/6hK7aZyA1YRe7UfqWaqLou"}
{"genre": "deep happy hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0nrHQMazFvwjMpg5esflnT"}
{"genre": "british black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3OBMtOkVBAydo8hxzubKJp"}
{"genre": "japanese dream pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0drfpBhQrViLsNkGtLLsc2"}
{"genre": "sambalpuri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/63vYFIQmxTKK0k5hrc2xsS"}
{"genre": "lapland metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2roNZbSQjCICekvwRQnAUz"}
{"genre": "hungarian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/2g646JKBsJaDrJkZ4JJwgl"}
{"genre": "musica afroperuana", "spotify_playlist_url": "https://open.spotify.com/playlist/3c8pTOYECLUWMqLppQTc1F"}
{"genre": "nueva trova chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/3wiVm06ALgGPmNv9HRHVJq"}
{"genre": "brisbane hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1zU9A3egIFexjJqvvAztak"}
{"genre": "hexd", "spotify_playlist_url": "https://open.spotify.com/playlist/13tIMuzJRaqONuJGUlJUt4"}
{"genre": "ambient techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4K8cqoXccxo7fPmBEqVKQm"}
{"genre": "funk capixaba", "spotify_playlist_url": "https://open.spotify.com/playlist/5s6WNpuQnEZUivQy8MGQwP"}
{"genre": "ai", "spotify_playlist_url": "https://open.spotify.com/playlist/3e0cmyYVSDVqZTFseCyg3y"}
{"genre": "vincy soca", "spotify_playlist_url": "https://open.spotify.com/playlist/656KRpxgsx2wpIX25EA4FP"}
{"genre": "paraguayan rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5ksPEzPh2fKmC8Qq26mrax"}
{"genre": "punk chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/36rXPmTzbFjBODt40ji0mC"}
{"genre": "kurdish remix", "spotify_playlist_url": "https://open.spotify.com/playlist/5vLkPTGIeKJXEiesWgr7Tw"}
{"genre": "slovenian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/0L3eiLJIekTa0Bqhv2RURF"}
{"genre": "kent indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2b7FC4wx5lphMB4FKrx6aC"}
{"genre": "canadian indigenous music", "spotify_playlist_url": "https://open.spotify.com/playlist/6auaeyb8nkpRdYdJ9UFxcO"}
{"genre": "persian underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2nMq9GWuVcUdHsmmY3hzb6"}
{"genre": "korean worship", "spotify_playlist_url": "https://open.spotify.com/playlist/7JPyMYqSoFAS2pKMOZomDO"}
{"genre": "jazz cubano", "spotify_playlist_url": "https://open.spotify.com/playlist/5t8Ohd3K05yxXPUmF3afO7"}
{"genre": "musica popular uruguaya", "spotify_playlist_url": "https://open.spotify.com/playlist/2nZxUVkTnE2dfocWtpr6nK"}
{"genre": "chant religieux", "spotify_playlist_url": "https://open.spotify.com/playlist/2ee3YapidNCKgzUrPR3BHq"}
{"genre": "bristol electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/12zyNBOOFIiVBjfcdTo0Gx"}
{"genre": "classic hungarian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4DIc6FvplSlgKjH67THmX7"}
{"genre": "straight-ahead jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3sKxsgPOnvZIPdmmoLvVtZ"}
{"genre": "polish indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/54kgZCCHhUPnQWU0T8aHb8"}
{"genre": "british death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0CxGe6CAsVFQ36LNkTA54T"}
{"genre": "telugu devotional", "spotify_playlist_url": "https://open.spotify.com/playlist/7sthD5x0s2G0XZNzVW40hX"}
{"genre": "neo metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2Wh7WpNxoec6eoJXv7QNDk"}
{"genre": "underground amapiano", "spotify_playlist_url": "https://open.spotify.com/playlist/60u9ZHJHOBYU7yPFB3fJX1"}
{"genre": "marimba orquesta", "spotify_playlist_url": "https://open.spotify.com/playlist/3kbQ9gfkcfLljiDMk9FnlC"}
{"genre": "cyber metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3tBFVR4AL91lnjtkPrfsPa"}
{"genre": "deep uplifting trance", "spotify_playlist_url": "https://open.spotify.com/playlist/6RjtOHtdpwfcdepnu8RxLp"}
{"genre": "dub techno", "spotify_playlist_url": "https://open.spotify.com/playlist/13Kst5O4iuiTXwJcbBTJ26"}
{"genre": "neurostep", "spotify_playlist_url": "https://open.spotify.com/playlist/3SKPT4J5y03Qn0u4iCtish"}
{"genre": "pinoy praise", "spotify_playlist_url": "https://open.spotify.com/playlist/3cUZkIPJ5rGYyRM31Uv5sh"}
{"genre": "portland punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1I4oTn6C426omLd0GOWnL3"}
{"genre": "new orleans indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6wjtBLMgpJPf9rvPsZHCD0"}
{"genre": "rare groove", "spotify_playlist_url": "https://open.spotify.com/playlist/0HAHULTlSQ3MlzO9e38PvI"}
{"genre": "acidcore", "spotify_playlist_url": "https://open.spotify.com/playlist/23TcHEHll7Ds78hkaiohPx"}
{"genre": "brazilian percussion", "spotify_playlist_url": "https://open.spotify.com/playlist/6odC8x54AS8rzUqHupqLDS"}
{"genre": "wu fam", "spotify_playlist_url": "https://open.spotify.com/playlist/6Av8FDU3F83KRoRs84EYX5"}
{"genre": "gyerekdalok", "spotify_playlist_url": "https://open.spotify.com/playlist/0EcNiIhWRMpV1Q3XDA7aep"}
{"genre": "hardstyle", "spotify_playlist_url": "https://open.spotify.com/playlist/49gROGYXXsoGl3DQxGcmdb"}
{"genre": "ghettotech", "spotify_playlist_url": "https://open.spotify.com/playlist/0zturCsng8jMo3Pf2EXufv"}
{"genre": "classic azeri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6anitOYhAbdI4ULWSel3Zf"}
{"genre": "spiritual hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0B3eNy1lyjAZhLgZXGBwbO"}
{"genre": "skramz", "spotify_playlist_url": "https://open.spotify.com/playlist/4byNu3ZWic9R7OgfT8jBFM"}
{"genre": "jazz worship", "spotify_playlist_url": "https://open.spotify.com/playlist/22V60MoCj7rBWKYUBKE0WK"}
{"genre": "lagu bugis", "spotify_playlist_url": "https://open.spotify.com/playlist/0kPKNYj7UGKveCz4kikG7Q"}
{"genre": "polish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3kheZGEwRSAPqiMqZL5heK"}
{"genre": "melodipop", "spotify_playlist_url": "https://open.spotify.com/playlist/2VJ1VzZ7u17bqCsBz0Vrwm"}
{"genre": "nice indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6JaSAyveY1kLiR9pLew571"}
{"genre": "vienna indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0rSYXMt7LzZgQdQuF3X4DK"}
{"genre": "louvor icm", "spotify_playlist_url": "https://open.spotify.com/playlist/0xTQBGbsRCabjI5MwUieJx"}
{"genre": "malayalam indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6CWjQWGgG9iSsMFiXoTcEy"}
{"genre": "sinhala rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3v9Zk1tfOXS0qvEf0HPouL"}
{"genre": "rap femenino mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/4wGi6sCxTGZiHhTYwBWEz4"}
{"genre": "dub reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/1cokzRjm0SxgXXjQaBPtEa"}
{"genre": "fort worth indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4B9jeYUnBAFF8eBoIv4ryd"}
{"genre": "hamburg indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6alRA0JMoSAhCILVd0GWvF"}
{"genre": "indie cristao", "spotify_playlist_url": "https://open.spotify.com/playlist/5Ly1Hq4HqgMOtjLjjzOgXO"}
{"genre": "waiata maori", "spotify_playlist_url": "https://open.spotify.com/playlist/1qLMlVunYKqw285SAjZEzJ"}
{"genre": "classic romanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6Lt6XBEvrrTu3StRRXH0wk"}
{"genre": "ohio indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5kqENVAiZLnPtB9sfXWcHw"}
{"genre": "australian ska", "spotify_playlist_url": "https://open.spotify.com/playlist/1S0CB3Z8Ft2rqf7bTqKhAJ"}
{"genre": "vintage swedish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5oCactm6pHarGVJwbE0yaO"}
{"genre": "harp", "spotify_playlist_url": "https://open.spotify.com/playlist/532PtpsJMVHeWcE0XOvUKp"}
{"genre": "portuguese indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6iwoiGbEuqmejpaGrxJWiT"}
{"genre": "hindustani vocal", "spotify_playlist_url": "https://open.spotify.com/playlist/0dI6Br6YSVopWFFeFiyaoC"}
{"genre": "griot", "spotify_playlist_url": "https://open.spotify.com/playlist/0VP6lq36hjAAEb6CZcuxQw"}
{"genre": "slack-key guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/3AcB5ov4dAX8jddis4Bafm"}
{"genre": "minimal dub", "spotify_playlist_url": "https://open.spotify.com/playlist/0Jq8uF3opTf9ZaIj0Bzgxg"}
{"genre": "musica mixteca", "spotify_playlist_url": "https://open.spotify.com/playlist/24ObnufTayPJtHqniYII9P"}
{"genre": "gospel drill", "spotify_playlist_url": "https://open.spotify.com/playlist/35QZco3h3UELAC2VsLmpSD"}
{"genre": "raboday", "spotify_playlist_url": "https://open.spotify.com/playlist/7KCqQrGmvOWbdFPf0stMbh"}
{"genre": "neotango", "spotify_playlist_url": "https://open.spotify.com/playlist/7DI0UfBobOhePEEMKpPY8o"}
{"genre": "taiwan campus folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6WUctoZjaabTMH16DrsnXZ"}
{"genre": "spanish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3jTCa2KKw5uBzOcQWs1560"}
{"genre": "german literature", "spotify_playlist_url": "https://open.spotify.com/playlist/69eKo1hKxQTZwMbrqrrATV"}
{"genre": "danish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4AppOssLEUy97dUJ4GZG7g"}
{"genre": "german opera", "spotify_playlist_url": "https://open.spotify.com/playlist/432KLdqgrRmDjWbJ8iFsns"}
{"genre": "koligeet", "spotify_playlist_url": "https://open.spotify.com/playlist/0o1QLc0vIBELSqrIEPXqQg"}
{"genre": "alberta hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7F1mFtJXRRa0OlUJwbDR1V"}
{"genre": "nz folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2310EYDUgACUuc0GbWJ0p6"}
{"genre": "campursari", "spotify_playlist_url": "https://open.spotify.com/playlist/7IBrHelDd9kUlUZ6eWawQL"}
{"genre": "welsh hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/41qFWSk78KgepYWUDgmJLC"}
{"genre": "pakistani rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4D6h4h29rGjq8k7anBIl1O"}
{"genre": "stockholm indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3l0YMxfwv5TR9My7rZgLPB"}
{"genre": "powerviolence", "spotify_playlist_url": "https://open.spotify.com/playlist/4SJlsd4gR9A8DTzRoMrFPl"}
{"genre": "dark folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0neTlrXKNSaFSz87D95j96"}
{"genre": "belarusian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3wZ3TCdTgkrlXxozMUivDq"}
{"genre": "chasidic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/75uAzOEJH0LyH5uDvOCOBJ"}
{"genre": "viral pop brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/1FQ0OCZYijohM9rb04pv4e"}
{"genre": "funk mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/4tuh0hKWxyrxLpEcjnaQmw"}
{"genre": "pennsylvania hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5X2e1EOcG56Dx7R2HlAtAQ"}
{"genre": "jordanian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1HtdKIjYZSKWMLwz4QSDFU"}
{"genre": "gothenburg hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5wRfHPzDRgRWi9Of9EEDEO"}
{"genre": "chinese classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/4X5NadJ9dnHyKd2vLILC7v"}
{"genre": "orquesta tipica", "spotify_playlist_url": "https://open.spotify.com/playlist/1DwMhGBKT5wOLMDhTxAKHY"}
{"genre": "uyghur pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4BWiY2jdyzUteEcVCLzmi7"}
{"genre": "taiwanese indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1VeXCbhw7LZfOlrwzCc3O9"}
{"genre": "sound art", "spotify_playlist_url": "https://open.spotify.com/playlist/7JWvFuSIklMeBelZettpB5"}
{"genre": "progressive doom", "spotify_playlist_url": "https://open.spotify.com/playlist/7H8Ak1DtWspFbNv6m1HVlW"}
{"genre": "lithuanian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0QMhgDcbW2yZVGV7VNSL0A"}
{"genre": "tinku", "spotify_playlist_url": "https://open.spotify.com/playlist/2yt6i9dVvhD3W8YgH2X6yJ"}
{"genre": "texas hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5GMyaejSXi6Q0rnNE6S6Mj"}
{"genre": "bangladeshi rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7yrj1xq9wOYCwUjwBAOQH1"}
{"genre": "charlottesville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5GNmniRYfLh3twHmc3T7vN"}
{"genre": "musiqi-ye zanan", "spotify_playlist_url": "https://open.spotify.com/playlist/1CcHwgoYEczFeNxHVkGZj5"}
{"genre": "kazakh indie", "spotify_playlist_url": "https://open.spotify.com/playlist/222s04YPSjyh3XlfdTBxAQ"}
{"genre": "schranz", "spotify_playlist_url": "https://open.spotify.com/playlist/0oVmOYzfm6lZehEnLSCCkj"}
{"genre": "punk euskera", "spotify_playlist_url": "https://open.spotify.com/playlist/24UeBVPHdmORN5JOPIZiuV"}
{"genre": "utah indie", "spotify_playlist_url": "https://open.spotify.com/playlist/44r8NmOIu2u46xFVWtNQoa"}
{"genre": "spa", "spotify_playlist_url": "https://open.spotify.com/playlist/0oRBlN7Dq4UxzVQl7q2bVO"}
{"genre": "beatboxing", "spotify_playlist_url": "https://open.spotify.com/playlist/3i2uukD1MQx9nLVauaHgnG"}
{"genre": "soviet synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/1cxhYjKkYJEvrI3fBy4ONX"}
{"genre": "bay area hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6hFP9HDRKTHHJgoGrhUGeu"}
{"genre": "western mass indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3HdWNB9xTtChlH7IZRkpzr"}
{"genre": "swedish stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5l5jOUgJm8gedEcYijsBcK"}
{"genre": "dunedin indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0l6PRP6mfP36xVpNCZHvLJ"}
{"genre": "nl folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3yP7LJ0wT19xpeIJxJ7GJF"}
{"genre": "melodic power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1zX5Zu0uGJDr9ZDxA5hKV9"}
{"genre": "beatdown", "spotify_playlist_url": "https://open.spotify.com/playlist/4uLg82FvdD0blplTBTmR59"}
{"genre": "miami metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6nMGFNdf9QNLJ8xz8NdZp6"}
{"genre": "novo rock gaucho", "spotify_playlist_url": "https://open.spotify.com/playlist/5FOv1bW24mnkT6X6kmUXwL"}
{"genre": "japanese heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5Zy6ZIVXhBE4nbmNhp8LLx"}
{"genre": "classic hungarian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2cIvk9rAmvHalsN9f1NeHJ"}
{"genre": "norwegian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/30wsH5DTqMPMvPpHsCtaau"}
{"genre": "guinean pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1nDSNgH9o8lPKZyRC9tAwR"}
{"genre": "pakistani electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/25WUrbL32sptDy2WqzfL87"}
{"genre": "guided meditation", "spotify_playlist_url": "https://open.spotify.com/playlist/3yGP9iTHnDBiMHdBxiNUaa"}
{"genre": "birmingham indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0u30dhCaWTOJQ8pH1uzDkZ"}
{"genre": "czech metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7HRSLTzbL56l8vneW3mR2w"}
{"genre": "cape verdean folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1TrGj5eL5I87g8sNGe0xTs"}
{"genre": "jazz organ", "spotify_playlist_url": "https://open.spotify.com/playlist/0cHdNZkYiOFuZSx5XBDmKd"}
{"genre": "cinematic post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7oNPNXqyCxty9nHMltU1pp"}
{"genre": "world meditation", "spotify_playlist_url": "https://open.spotify.com/playlist/1K5Q8BCOoB4ddGRzh9lryn"}
{"genre": "christian hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7l2qOZAyDLC2YH99jiBnT0"}
{"genre": "lexington ky indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4I9PfkVAq6KhX2IyOjUhyL"}
{"genre": "chinese talent show", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ar7fmPoKFxWbUV4YGAe84"}
{"genre": "vocaloid metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7HoucTIMv5vuyQDKHVUlBT"}
{"genre": "montenegrin pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5yY4Ijs7l0cLEftBaOL8X4"}
{"genre": "beats", "spotify_playlist_url": "https://open.spotify.com/playlist/1dOnoWJmZAhe8mRkMQxzut"}
{"genre": "detroit house", "spotify_playlist_url": "https://open.spotify.com/playlist/2H9lhkryk077kmxq8UOYkl"}
{"genre": "windsor on indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0QY6jIObQ6cOcRr30d0XT4"}
{"genre": "german tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/13ShpIGoaxmzJ2l0vM8U8q"}
{"genre": "histoire pour enfants", "spotify_playlist_url": "https://open.spotify.com/playlist/6BMz3GRTJ0ykYZzCtyFrcV"}
{"genre": "black 'n' roll", "spotify_playlist_url": "https://open.spotify.com/playlist/5CJdhmcEj0APTY8toFWfrf"}
{"genre": "taiwan rock", "spotify_playlist_url": "https://open.spotify.com/playlist/04oO8fvjG3alSM9OcEfT3y"}
{"genre": "rock keyboard", "spotify_playlist_url": "https://open.spotify.com/playlist/7KP8dP2U8gcJzlCinFo6mo"}
{"genre": "pop paraguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/4UnTwHRaNzvcCcfrQONEKq"}
{"genre": "czech country", "spotify_playlist_url": "https://open.spotify.com/playlist/4aSo2zrj9m9RzjNIwsTJod"}
{"genre": "footwork", "spotify_playlist_url": "https://open.spotify.com/playlist/2TGq3rEqYHLaHh8cFyg8vm"}
{"genre": "smooth soul", "spotify_playlist_url": "https://open.spotify.com/playlist/6pWUha4KRUldi2JQ2epLpF"}
{"genre": "west australian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZcmhA3Jydo599FFbUzn5i"}
{"genre": "chinese classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/2pxOA8NLXwZaCk09pjaerb"}
{"genre": "experimental jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2SrPXLwpNixB3uyGMZryAT"}
{"genre": "louisiana metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0TLvkyZa3zlTc4oEGNMROg"}
{"genre": "bouyon", "spotify_playlist_url": "https://open.spotify.com/playlist/6KcFLs8Ujk5HSyOiH7iCcC"}
{"genre": "new orleans americana", "spotify_playlist_url": "https://open.spotify.com/playlist/6CIENNuy8mm01lwYaVOjIb"}
{"genre": "ukrainian edm", "spotify_playlist_url": "https://open.spotify.com/playlist/3ig0J9VqBXJGDDMftK3l8c"}
{"genre": "bisaya rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0rcyvtwJZ7X49avts9SSBQ"}
{"genre": "dubsteppe", "spotify_playlist_url": "https://open.spotify.com/playlist/52znEJwTNgZg2n1T8C0WcV"}
{"genre": "tunantada", "spotify_playlist_url": "https://open.spotify.com/playlist/0ANQp5V5lrAtNcqZ4Pn0cG"}
{"genre": "telugu worship", "spotify_playlist_url": "https://open.spotify.com/playlist/739D9gljNHW1ZLcA9GHLgm"}
{"genre": "guatemalan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5gZbaD8ftLCQTOkbuCSpis"}
{"genre": "hamilton on indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3h3fQeu39Em88KEHF4zf6t"}
{"genre": "norsk lovsang", "spotify_playlist_url": "https://open.spotify.com/playlist/6uNsNfkG4lwlCdcN12erhu"}
{"genre": "hyperpop italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/023a2xH3vYQ4iMfHezxXAw"}
{"genre": "maine indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2AmQnO1A0WiWCPlulfq0w8"}
{"genre": "thai post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/23sK5QU3bFBFgw5X18X0QW"}
{"genre": "uk bass", "spotify_playlist_url": "https://open.spotify.com/playlist/0I8grtFFc4NxQ28GwWDCsW"}
{"genre": "musica paraibana", "spotify_playlist_url": "https://open.spotify.com/playlist/4RNt8R9JKHC2QpnbRoTzI3"}
{"genre": "progressive alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/6Mz4j5CTDBR3V369aRhLvw"}
{"genre": "musique militaire", "spotify_playlist_url": "https://open.spotify.com/playlist/18GSi8FlzkGjpX202M4AuG"}
{"genre": "tennessee metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7oGsbF2mIzJSpGiKIWPcYG"}
{"genre": "venda pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7dqmPaXfDJ3dqusIl7ESaL"}
{"genre": "indie napoletano", "spotify_playlist_url": "https://open.spotify.com/playlist/5HQuEkc6b8niI4AdsQMrh3"}
{"genre": "college a cappella", "spotify_playlist_url": "https://open.spotify.com/playlist/2A5eo4AGjzJfiLHNSvlr1x"}
{"genre": "melodic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6RsOx3WtvI9s7LOmoTvQQs"}
{"genre": "american grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5LyeSPswvFY0px093Wqm3v"}
{"genre": "polish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7wx58jJTsUZs2EIzNfGHth"}
{"genre": "bhojpuri folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1VeTIT7DWaGF0hRsWxyMHQ"}
{"genre": "exotica", "spotify_playlist_url": "https://open.spotify.com/playlist/7c2TdiTJw3RK9IRFAcW6NT"}
{"genre": "nz christian", "spotify_playlist_url": "https://open.spotify.com/playlist/6SigkrVfm6vJgg6fY2hpKo"}
{"genre": "scottish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/3DCgyRkANN3ESXgKmTceKO"}
{"genre": "truck-driving country", "spotify_playlist_url": "https://open.spotify.com/playlist/3Vdljk27QABnI9Ca5TefAj"}
{"genre": "synth prog", "spotify_playlist_url": "https://open.spotify.com/playlist/7jj90qK5vdE6iSvqG6qutP"}
{"genre": "musica guerrerense", "spotify_playlist_url": "https://open.spotify.com/playlist/2mQoDU39vnoPbMuZNU1jqD"}
{"genre": "bardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6TkBKzb8SP3wI1OGi871qn"}
{"genre": "comedia", "spotify_playlist_url": "https://open.spotify.com/playlist/3oXNPFl1SakoBnaFnGKbZC"}
{"genre": "experimental indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3Zzm2a9gHWa14qXjXZ3ZM3"}
{"genre": "epunk", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZFyvM37nlhYcbCEi99Rlu"}
{"genre": "gospel rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6aASwBqAt129rxQQbkKvKC"}
{"genre": "neo-rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/4JfJqAGa0SckbFgyE7Y1nJ"}
{"genre": "dancehall colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/6FyN2aDjKcSmuy3im6mz5H"}
{"genre": "kenyan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1aVAwfaaCHloeRDM6SNuqX"}
{"genre": "japanese indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4tENVTwOGCWu16Q7TtWbFp"}
{"genre": "neofolk", "spotify_playlist_url": "https://open.spotify.com/playlist/0L371MBdXN5thFTULwgUJS"}
{"genre": "folclore jujeno", "spotify_playlist_url": "https://open.spotify.com/playlist/0EYTpPWigiU1BEGKHVgkVN"}
{"genre": "icelandic hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/15pJWT8MLMla86nhINzNYr"}
{"genre": "hungarian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4vpfMnKhs2KHHrCPzfhh3Q"}
{"genre": "ghent indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6LZFCnSxdUJqXrruICbvXc"}
{"genre": "oulu metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4ug6sQX1AJOzv3bfxDp58g"}
{"genre": "dallas indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3NdAzHVxjhUdezXDcT0K8m"}
{"genre": "bouzouki", "spotify_playlist_url": "https://open.spotify.com/playlist/3FD61seVkp8ZlSde7haVlh"}
{"genre": "jazzy dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/7vppw6zi3RPkuHAOleV5VU"}
{"genre": "chinese audiophile", "spotify_playlist_url": "https://open.spotify.com/playlist/7FCVjVoaNjv3ZSl6RxySlz"}
{"genre": "power blues-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7f2DsDC8SQ14L8YOcYLOG6"}
{"genre": "polish electronica", "spotify_playlist_url": "https://open.spotify.com/playlist/4GKXtm314aU5k54qyleKIs"}
{"genre": "canadian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/6SYXRmFXeBduajHIzs2J4O"}
{"genre": "british comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/6N4OIZFag86xkAX8mtAdgs"}
{"genre": "afro house angolano", "spotify_playlist_url": "https://open.spotify.com/playlist/30CoWpJwxNexvxHTB7gTX3"}
{"genre": "musica cabo-verdiana", "spotify_playlist_url": "https://open.spotify.com/playlist/4NACq8ddk17JnMjHVdVASi"}
{"genre": "alt-idol", "spotify_playlist_url": "https://open.spotify.com/playlist/3GBjj2KSHCKvn4PpWFZwRe"}
{"genre": "schweizer rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7xONzzkvidW4GhBPWmrgD6"}
{"genre": "technical deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3IBzxeZiPQ0NMt7NA0Srgp"}
{"genre": "musica infantil catala", "spotify_playlist_url": "https://open.spotify.com/playlist/7N3i9JZpLjqtWIyPHkD8LM"}
{"genre": "anglican liturgy", "spotify_playlist_url": "https://open.spotify.com/playlist/7ubSHsr9JrBqoRPvyIQ74U"}
{"genre": "lampung indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5fXpNVUC5QymlxNrIivhxL"}
{"genre": "afghan rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6JjpCO9cUOTc4eZHPJEyYl"}
{"genre": "polish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/39v3x0pnnnKizjsCpvwd0p"}
{"genre": "sound effects", "spotify_playlist_url": "https://open.spotify.com/playlist/4Xw2kcuC3YkvtBYlhlWSsE"}
{"genre": "piano mpb", "spotify_playlist_url": "https://open.spotify.com/playlist/7GnFQMK9qCeEFN0BAxFvW7"}
{"genre": "scottish hush", "spotify_playlist_url": "https://open.spotify.com/playlist/42MeWMQ2ZDWlUmKQnFjweP"}
{"genre": "black comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/3JPfdKelScEwS01JZaiH8X"}
{"genre": "trance mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/5E2dx9KsudEf6PNFcgF3NK"}
{"genre": "polca paraguaya", "spotify_playlist_url": "https://open.spotify.com/playlist/0MEg5cLJNk8oIHkjrMCWCe"}
{"genre": "greek swing", "spotify_playlist_url": "https://open.spotify.com/playlist/428kqH5lzImD4NkPLoZSrv"}
{"genre": "japanese beats", "spotify_playlist_url": "https://open.spotify.com/playlist/4i6hHzvXWIGeCeGM0mJbPI"}
{"genre": "tamaulipas indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3AmA2Y3NnFBPj7P5izmZIk"}
{"genre": "cornetas y tambores", "spotify_playlist_url": "https://open.spotify.com/playlist/6B85dQKzhxzy3UJZ88L1fu"}
{"genre": "north moroccan rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0KZQoEVElDhH6wjQq38vbj"}
{"genre": "voetbal", "spotify_playlist_url": "https://open.spotify.com/playlist/1bEpG8skz0jZy0mzN9uaCu"}
{"genre": "indonesian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/20RjeezT8jhEhJSI6e90IY"}
{"genre": "brisbane punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7p0kJWBVE4VFrVW6zs25kC"}
{"genre": "background jazz product", "spotify_playlist_url": "https://open.spotify.com/playlist/5UvT2YrhYo6tUUGASRrUUl"}
{"genre": "malawian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0Nar1vUd0plNmYHqPPznaf"}
{"genre": "dub brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/6TscApvuF5633bG9Nd90vW"}
{"genre": "irish neo-traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/3hlXbOQHxy81Epj5j9ZAPE"}
{"genre": "italian gothic", "spotify_playlist_url": "https://open.spotify.com/playlist/2vjw5bRd08KtqzNvXoGeDD"}
{"genre": "italian gothic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2AC2tTYulJO3e4IQkPZndE"}
{"genre": "musica catarinense", "spotify_playlist_url": "https://open.spotify.com/playlist/3Yzyns9XiroQy5zuD8ZDbb"}
{"genre": "muzica etno", "spotify_playlist_url": "https://open.spotify.com/playlist/1m99ucWM6MaHokCPC5fGNq"}
{"genre": "spytrack", "spotify_playlist_url": "https://open.spotify.com/playlist/0UPeXaFOc7K38kB3tWrg37"}
{"genre": "zcc", "spotify_playlist_url": "https://open.spotify.com/playlist/4rohSjUJ1bDLU1JLCi6n7y"}
{"genre": "punk cover", "spotify_playlist_url": "https://open.spotify.com/playlist/6xV04IYvXayJc0eDrVFzxb"}
{"genre": "chinese worship", "spotify_playlist_url": "https://open.spotify.com/playlist/2blf5MBGY8yhdojrYgWsXB"}
{"genre": "png pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4e6BAhG2ginVll1DUg3WMi"}
{"genre": "spanish indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4bhPRYjwT2iUjeaKWHJZYa"}
{"genre": "syrian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/17bjjpImhGyDjpktAio6L1"}
{"genre": "guitarra andina", "spotify_playlist_url": "https://open.spotify.com/playlist/7F8Q0HfHeuuKuWM9UjBcU3"}
{"genre": "lagu aceh", "spotify_playlist_url": "https://open.spotify.com/playlist/78IYTCUA99H1rwKXjTYSCO"}
{"genre": "zambian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5ZDuKkHD8vQMIINeFsTTyu"}
{"genre": "gospel reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/2BVgScGR0GVf2FQCP1B0OY"}
{"genre": "lebanese indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0nARPYNjb8i5X0R1PYtian"}
{"genre": "tamil indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1MSuOTcT7Egw1GovayzGXm"}
{"genre": "ukulele", "spotify_playlist_url": "https://open.spotify.com/playlist/7gWXMsnp6meAp5LFCkUQ22"}
{"genre": "dutch moombahton", "spotify_playlist_url": "https://open.spotify.com/playlist/10LePyigDTDjghuJcNu92i"}
{"genre": "psychedelic folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1VOp0nh8VWTbhz1G0XnNGE"}
{"genre": "musica yucateca", "spotify_playlist_url": "https://open.spotify.com/playlist/4b1YHugUBM36zH1diLulcu"}
{"genre": "polynesian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0hg5dozYN1rvZP2k0udqgP"}
{"genre": "cartoni animati", "spotify_playlist_url": "https://open.spotify.com/playlist/2MUwK8zH1CtmRsUAqyzrL0"}
{"genre": "thall", "spotify_playlist_url": "https://open.spotify.com/playlist/1mfUIv1E5Q7Yc9A93jBl2Z"}
{"genre": "chakra", "spotify_playlist_url": "https://open.spotify.com/playlist/4mnzw6x7d1i0ek9pwdNYOO"}
{"genre": "charango", "spotify_playlist_url": "https://open.spotify.com/playlist/7z91neKtQAc0DnOyyHnr67"}
{"genre": "christian power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1QARasWas7RvvcCyiXEjlV"}
{"genre": "british choir", "spotify_playlist_url": "https://open.spotify.com/playlist/06Bclwc54xNjzibZZKl6KX"}
{"genre": "brazilian ska", "spotify_playlist_url": "https://open.spotify.com/playlist/0bgZ30O6JZuMkNXLcHmOK0"}
{"genre": "raggatek", "spotify_playlist_url": "https://open.spotify.com/playlist/4UPY78QrXrmlSAE722apfN"}
{"genre": "folklore venezolano", "spotify_playlist_url": "https://open.spotify.com/playlist/6kKNRaYd2zKj3f25SOjSjo"}
{"genre": "jain bhajan", "spotify_playlist_url": "https://open.spotify.com/playlist/4uvGPjmbSsmcdNhj14fo7W"}
{"genre": "slavic folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6pi3rdg7ArZGMT62FzattB"}
{"genre": "psychedelic punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0LPayzJtRwOpX4uVM18EjK"}
{"genre": "ok indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3OJiIetHH3ef9mwP8e3gH5"}
{"genre": "fan chant", "spotify_playlist_url": "https://open.spotify.com/playlist/1vop8KpVahupGKRDvAWDrr"}
{"genre": "detroit techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6eKMGlc0PX3mNLAJOFUDUB"}
{"genre": "austin metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0veZcaOzcGJYoPLTvxl7L6"}
{"genre": "austrian dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/4tMXl8E1wE42prbMi3LuwR"}
{"genre": "grebo", "spotify_playlist_url": "https://open.spotify.com/playlist/03gMxUW3FhkHIrMboQGUu6"}
{"genre": "bandoneon", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZdEVCj3XruQaXQuq0Hfrt"}
{"genre": "austrian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5zBqJ2TE7dQrLB4Sxq6NVQ"}
{"genre": "candomble", "spotify_playlist_url": "https://open.spotify.com/playlist/1FkKYGVDhApqNGoJPkBG9j"}
{"genre": "c-pop girl group", "spotify_playlist_url": "https://open.spotify.com/playlist/1La91OalQ5WK60xP7o28lJ"}
{"genre": "broken transmission", "spotify_playlist_url": "https://open.spotify.com/playlist/1qubOOGbin1gborc1nAMdJ"}
{"genre": "sunnlensk tonlist", "spotify_playlist_url": "https://open.spotify.com/playlist/4KVj0Tze02e7RrVH31jp0R"}
{"genre": "ramonescore", "spotify_playlist_url": "https://open.spotify.com/playlist/2v9nYMvQnYXxYFZ5vLE9d8"}
{"genre": "instrumental progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4KcMILB3MEuiqCtL03JvX8"}
{"genre": "musica bautista", "spotify_playlist_url": "https://open.spotify.com/playlist/4HQZD4l64PzfulJAncOXgF"}
{"genre": "sorani pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0V9yTHDVtWgzJShycRhcqH"}
{"genre": "north carolina metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4bHzKgawoIYIv79jMGS1pL"}
{"genre": "action rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3sG0wNAvyO3tqubkuSIJ5E"}
{"genre": "sci-fi metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6yTgfTX8WLMvrExyuNdjd1"}
{"genre": "mashcore", "spotify_playlist_url": "https://open.spotify.com/playlist/79VSRm21dxwN2QYdRkPU21"}
{"genre": "italo house", "spotify_playlist_url": "https://open.spotify.com/playlist/2MozR9FnRi9Sol52JfVvdH"}
{"genre": "belgian indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3D833et5AHcMcMApBSml5s"}
{"genre": "alpine yodeling", "spotify_playlist_url": "https://open.spotify.com/playlist/3iYTHHefhKZXKxsdyV2QY6"}
{"genre": "turkish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6FS4N9H4Kc4VSNGiK8vZPH"}
{"genre": "indie folk argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/4wEvh3ejiwFWq06ux3UIOS"}
{"genre": "deep acoustic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0i65yM4zM45UzL6X54UYBP"}
{"genre": "trinidadian reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/0vJjFo4hpIQXDbXdRjAvA3"}
{"genre": "lithuanian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/18fOS8FrEmjHMZKSt7VLqs"}
{"genre": "deep idm", "spotify_playlist_url": "https://open.spotify.com/playlist/3vvHiLqaof4wEAUoku9n7F"}
{"genre": "cameroonian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/70ncNURblCmX34p15Y47gm"}
{"genre": "er ge", "spotify_playlist_url": "https://open.spotify.com/playlist/6cpNMLQ7oDdFbATi9wYL7f"}
{"genre": "varmland rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3pbcFy76fduxG4ZOZ6Dzks"}
{"genre": "chinese folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2rovPgCyVZxrrqtnGz6bwD"}
{"genre": "afro-cuban percussion", "spotify_playlist_url": "https://open.spotify.com/playlist/2knr8HbdAH4SBQfaoItBkS"}
{"genre": "slam poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/02OGpAADCHQbMhxilfo320"}
{"genre": "samoan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6HvalHc8PipnY2SaarvTtA"}
{"genre": "musica evangelica instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/3ASdA5uOWObzjjp6PFw2Q5"}
{"genre": "bush ballad", "spotify_playlist_url": "https://open.spotify.com/playlist/5CsdQrrAgQycaViamtpJtb"}
{"genre": "atmospheric post-metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4TpeBpehkryLCrVHrI5NWW"}
{"genre": "newfoundland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2GA6waoTYbDuJM8c066jXu"}
{"genre": "halftime dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/6Ca1K6vxKnJovI06DkcIWb"}
{"genre": "romanian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/394romkiixjuorOHpRfcUY"}
{"genre": "marimba de guatemala", "spotify_playlist_url": "https://open.spotify.com/playlist/5G5wN8DF7PsZGlF1ZN4vMq"}
{"genre": "maithili", "spotify_playlist_url": "https://open.spotify.com/playlist/2PSdOdlzyKSWmIlpkUVai0"}
{"genre": "chamber folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5tnKbXTO7xMv4AP0N9PVmB"}
{"genre": "one-person band", "spotify_playlist_url": "https://open.spotify.com/playlist/4hdX1gS6iDhWw0ll0VBBxU"}
{"genre": "slam death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7rwgumFrTFr0hhSNrgALCj"}
{"genre": "nwothm", "spotify_playlist_url": "https://open.spotify.com/playlist/4eE8nsqOILpqGNPdC33B9X"}
{"genre": "punk melodico chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/37Rgp5vWKUX17diUSWfqba"}
{"genre": "kurdish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1g9OqYSE4vFrDjQdI6GXEy"}
{"genre": "rochester ny indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7xwsvwBrJ3VWWpTjKbmKqb"}
{"genre": "czech folk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/52xncL4Lvwl3I9D7V7PK1E"}
{"genre": "hard house", "spotify_playlist_url": "https://open.spotify.com/playlist/19VC4dfHWpoxgPGLQtqLxN"}
{"genre": "tanzanian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3YfigsJnohDGwyPrd7IpHE"}
{"genre": "xitsonga pop", "spotify_playlist_url": "https://open.spotify.com/playlist/23MUSPH44uYB10onXR9mRe"}
{"genre": "zambian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3AxsN9foojNcuPI9OXnVIB"}
{"genre": "armenian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2Wk6e4zTLTYFofSDgprBgB"}
{"genre": "spiritual jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0SqD0qT1oRc5jGj3k2Bchb"}
{"genre": "austin rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5YldS0c0E8rsJPCeXBzEvr"}
{"genre": "york indie", "spotify_playlist_url": "https://open.spotify.com/playlist/02NPFyGAScohVgMt3JN00H"}
{"genre": "idaho indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1oOXMFAHwOYCF8qfMw0BIm"}
{"genre": "gambian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0JfsBRbWFEg0JNUn0OkkVv"}
{"genre": "deep ragga", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZsmYjk67G0jXydOu9MzBG"}
{"genre": "muzica crestina", "spotify_playlist_url": "https://open.spotify.com/playlist/6XJgQSTu5zBacxob79gFu0"}
{"genre": "musica duranguense", "spotify_playlist_url": "https://open.spotify.com/playlist/2gje8QJLqOdYo59EEDCWWT"}
{"genre": "caucasian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/5iuNu2X3rOBHYqz0NlZ3Qj"}
{"genre": "carnaval limburg", "spotify_playlist_url": "https://open.spotify.com/playlist/3vTsUt7QC2e9OiTPAORaCZ"}
{"genre": "visor", "spotify_playlist_url": "https://open.spotify.com/playlist/1AbGDt8fm9fYWy5tYLmKf3"}
{"genre": "italian library music", "spotify_playlist_url": "https://open.spotify.com/playlist/5WSYYNXKVriJu31Pd4QJwk"}
{"genre": "quebec punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5vd5RRHykVvzcnZDXnRt2H"}
{"genre": "trap angolano", "spotify_playlist_url": "https://open.spotify.com/playlist/2M5mmDgqCgxxJzDqMNvsbJ"}
{"genre": "post-disco soul", "spotify_playlist_url": "https://open.spotify.com/playlist/4hq2AjEJsf1MbUHmokKrjY"}
{"genre": "oaxaca indie", "spotify_playlist_url": "https://open.spotify.com/playlist/786aRzqWPqbgaGKgKX0Rk5"}
{"genre": "boston hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/31G9F2wgbtKLVhnWrxN96b"}
{"genre": "danish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6kL5ZTbRK4ckbI9eobGbO8"}
{"genre": "greek fem rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1bKNhIGs1PB3kPZvhT09Vw"}
{"genre": "vogue", "spotify_playlist_url": "https://open.spotify.com/playlist/0K8vLLqK9tuNnCH41GbnES"}
{"genre": "rock en asturiano", "spotify_playlist_url": "https://open.spotify.com/playlist/33iTiNZMOCq4lB9KUZtpAf"}
{"genre": "bomba y plena", "spotify_playlist_url": "https://open.spotify.com/playlist/3yF1mecrspw7z57kLoHPGK"}
{"genre": "melbourne punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3Eoy7gxvTDmoEmT4fu6yt6"}
{"genre": "nuevo tango", "spotify_playlist_url": "https://open.spotify.com/playlist/51ZET8D7C1TIlpbFsREleh"}
{"genre": "german prog", "spotify_playlist_url": "https://open.spotify.com/playlist/5of4tnNbG6WtRB9w9LkPl4"}
{"genre": "psych gaze", "spotify_playlist_url": "https://open.spotify.com/playlist/5omKBcq3JfWMx8ctXFNpiq"}
{"genre": "corridos adictivos", "spotify_playlist_url": "https://open.spotify.com/playlist/2N317F3VFwN4h0UO63f7EY"}
{"genre": "tamazight", "spotify_playlist_url": "https://open.spotify.com/playlist/5r9UAnDHl2Jln9Q5nRuid8"}
{"genre": "modern progressive rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5qyy5b1YfKIAjTRxuwYnDT"}
{"genre": "british grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7hPv9n2p7juD8FpGxnvQpX"}
{"genre": "nordic contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3ajp7PXuC2xPYxCuetjcRH"}
{"genre": "vintage chanson", "spotify_playlist_url": "https://open.spotify.com/playlist/7HK1rSHqmljzL2E38Ih5ZP"}
{"genre": "dc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7eOMLhT2vHW3u8TahU9yvt"}
{"genre": "polish prog", "spotify_playlist_url": "https://open.spotify.com/playlist/2kOqWrWGa7WGJV7RGEG5nI"}
{"genre": "berlin school", "spotify_playlist_url": "https://open.spotify.com/playlist/2jgy57TEf9gpe5wRZ4cPDF"}
{"genre": "uk82", "spotify_playlist_url": "https://open.spotify.com/playlist/4pJ4ZEzj93WnpU4CUgVxH1"}
{"genre": "zim urban groove", "spotify_playlist_url": "https://open.spotify.com/playlist/54WupWz7dqaSAZvIv91ksb"}
{"genre": "moog", "spotify_playlist_url": "https://open.spotify.com/playlist/55Dp6vIPU1HBq6rVjvzdRT"}
{"genre": "marathi remix", "spotify_playlist_url": "https://open.spotify.com/playlist/1r9JFOFDpiz9cmHKIq9UZz"}
{"genre": "experimental electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ir5MP20VzC5Aj62CBd2xW"}
{"genre": "polish synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/5S3xWhvZFcXKOogUjkb8od"}
{"genre": "sinaloa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5V1Viq2gAWu0yHWLL9LaTf"}
{"genre": "death 'n' roll", "spotify_playlist_url": "https://open.spotify.com/playlist/6jQSjYwybMfty3IjUDjwYA"}
{"genre": "persian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/6xshBURkq0CF8JJcHJGYic"}
{"genre": "hungarian underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1OWRJAfbP0IrKgJYO4jlsE"}
{"genre": "ska catala", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZyeermhUwIuF91S800w89"}
{"genre": "blues latinoamericano", "spotify_playlist_url": "https://open.spotify.com/playlist/4vhXen2YUiOwfiuJQf1qcX"}
{"genre": "makossa", "spotify_playlist_url": "https://open.spotify.com/playlist/4N68ytC6eBFQsGr5nmE5rU"}
{"genre": "afro-funk", "spotify_playlist_url": "https://open.spotify.com/playlist/7LCDE62aZPVgyYtkFjyGA3"}
{"genre": "dansei seiyu", "spotify_playlist_url": "https://open.spotify.com/playlist/0N6QvAfo4DzWoUBn8x7Cof"}
{"genre": "southampton indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2yc1CImlSAwK9CLL5h8yF6"}
{"genre": "rockabilly en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/4Dyha25pIbrEfMawz52bYE"}
{"genre": "rock of gibraltar", "spotify_playlist_url": "https://open.spotify.com/playlist/6856pdRh7nl7CYwHHl6Bfh"}
{"genre": "technical melodic death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5fzhrCOhDEfDKBaK91RRii"}
{"genre": "sami", "spotify_playlist_url": "https://open.spotify.com/playlist/1P51RgWYRSviyIqo2zphV2"}
{"genre": "cleveland metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3LJucbwy2msKwooRQlVEwK"}
{"genre": "deep contemporary country", "spotify_playlist_url": "https://open.spotify.com/playlist/5TqoG1t47RTBqODKy6xjdK"}
{"genre": "british post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ccp38dYsbJlU0FvQjjadQ"}
{"genre": "jazz vibraphone", "spotify_playlist_url": "https://open.spotify.com/playlist/0YilhnE31LG93t2UQDMphK"}
{"genre": "baltic classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3L2EjCGqykpbr8L2izzTs5"}
{"genre": "korean drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6bzbflYnlDXfX2PhXpALNg"}
{"genre": "nz dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/0VfhfEmjd7hyk08RNDfo86"}
{"genre": "scottish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2ravsd7xzOqws3jYqVQv3v"}
{"genre": "canadian underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7tLRdtCzB4SZrBDf5Y39Hq"}
{"genre": "muzika l'yeladim", "spotify_playlist_url": "https://open.spotify.com/playlist/6IUydBH9TAZUlLqdDI1m5g"}
{"genre": "italian electronica", "spotify_playlist_url": "https://open.spotify.com/playlist/5HfYvpOL7nni7KiR9lEl4d"}
{"genre": "israelite hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7yc4NIWxmBbCXwp5Jxefpl"}
{"genre": "christmas product", "spotify_playlist_url": "https://open.spotify.com/playlist/0MxCys4nmIa6XRlJrCt9vJ"}
{"genre": "rosario indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2J5CjN02atjqOrAH5YnE5G"}
{"genre": "mewati pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6bpQdq6xBJk8FTI343gOqy"}
{"genre": "israeli jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6fVoPI4Kv0qs8fPoJ3xAp9"}
{"genre": "norwegian house", "spotify_playlist_url": "https://open.spotify.com/playlist/0IyGGlU8FNCbIpGzNOYOQR"}
{"genre": "gothic alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/5S4nocceN9d2bFLsBlD3Pt"}
{"genre": "tuareg guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/6GLGKlKKI6MNh5nXitwenw"}
{"genre": "asakaa", "spotify_playlist_url": "https://open.spotify.com/playlist/1qvXL1eYguekLrsEuOS6hW"}
{"genre": "musica popular amazonense", "spotify_playlist_url": "https://open.spotify.com/playlist/7BOmogQasErRhHqjUSKa1o"}
{"genre": "afrikaans hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5oe6lR8NLGIkh8QYs8IhI1"}
{"genre": "appalachian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3usSb6t1CsmU5AgNVfxnjQ"}
{"genre": "hardgroove", "spotify_playlist_url": "https://open.spotify.com/playlist/5ajKYOk2XIo7vNiQWhrLgT"}
{"genre": "scratch", "spotify_playlist_url": "https://open.spotify.com/playlist/4Rh3irkgUbhXel6LSPapwc"}
{"genre": "korean electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1jVq5hfumPrlKudzlaQ0Iy"}
{"genre": "flick hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0OsEPF4sygsCEU6RWd5TWl"}
{"genre": "slovenian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/63HyrhtfwY2TtzxwJY3wao"}
{"genre": "devon indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0VdvQpqCAfQWGEbMOBkWEr"}
{"genre": "israeli techno", "spotify_playlist_url": "https://open.spotify.com/playlist/7qZJbvzWIqM8WHJnedJzXX"}
{"genre": "accordeon", "spotify_playlist_url": "https://open.spotify.com/playlist/4v2etpAUyEX5sRicWn1IHC"}
{"genre": "malaysian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/42nObOhMR778AWFoUCkiXr"}
{"genre": "cosmic post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5GqyvPhYKB396WKpxn3fsQ"}
{"genre": "jazz catala", "spotify_playlist_url": "https://open.spotify.com/playlist/5bHs8IoVwwBRssDvGEYnwb"}
{"genre": "australian ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZcuWr2KzhRzpIEPIopriM"}
{"genre": "belgian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5mCxFsaNdhe4kn7pup1Z5n"}
{"genre": "music hall", "spotify_playlist_url": "https://open.spotify.com/playlist/4q7xAk1gn5lUI9X5YUXJXj"}
{"genre": "cruise", "spotify_playlist_url": "https://open.spotify.com/playlist/3xDCL8wfuezwx8CcAQ8L97"}
{"genre": "american primitive", "spotify_playlist_url": "https://open.spotify.com/playlist/2AunSeg1QuuoTzpgBLfIe2"}
{"genre": "norrlandsk hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7hAIuKrOHFR2bJx811NzAR"}
{"genre": "swahili gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/36OgYCDxrIDYw76eEAeMQM"}
{"genre": "korean superband", "spotify_playlist_url": "https://open.spotify.com/playlist/13bL7PwSrXJ09yfBcq1f4c"}
{"genre": "usbm", "spotify_playlist_url": "https://open.spotify.com/playlist/0RJFKia2RsWkIk6wseqOoN"}
{"genre": "marwadi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7GZFdA5y3HFFDgGltBf80w"}
{"genre": "malayalam madh", "spotify_playlist_url": "https://open.spotify.com/playlist/5v9XsPFpWuzqAZ7IC3goOZ"}
{"genre": "khayal", "spotify_playlist_url": "https://open.spotify.com/playlist/6VPguZgCEK4rHCeDTRpjQg"}
{"genre": "waiata mo tamariki", "spotify_playlist_url": "https://open.spotify.com/playlist/0Qp1COxDToQ1vsHHrBrMDB"}
{"genre": "russian ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/19TTQtvqRkqHiIwxdHCbhS"}
{"genre": "2-step", "spotify_playlist_url": "https://open.spotify.com/playlist/3YOSwaEFJsA3fbYH8lArkR"}
{"genre": "indian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/5fmra9ZqY7sZv7HLkPDXYm"}
{"genre": "uk christian rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7uiDWyPL9wjqAeu0xizq1f"}
{"genre": "italian renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/7b3qwPS9RTygJC5H8DPfGl"}
{"genre": "rap tico", "spotify_playlist_url": "https://open.spotify.com/playlist/1fjDuZGOYrXCcXMHakyPTX"}
{"genre": "classic korean pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3ExXGTiMvClWNT017QIUo2"}
{"genre": "fijian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7Jra6ipuy04OfcvYlcZwCS"}
{"genre": "martial industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/3rNs7l5F94njXt7oG8CiAc"}
{"genre": "new york death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4WxMV4V4hCgLitFXNcZXPO"}
{"genre": "dancehall chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/1lVBYFbzpNc3bhAeXPpY2R"}
{"genre": "detskie pesni", "spotify_playlist_url": "https://open.spotify.com/playlist/5bZgnlbw1A9ji57AHhNyjY"}
{"genre": "chamber orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/4jloEP0IHoUZUQHSDekeVG"}
{"genre": "subliminal product", "spotify_playlist_url": "https://open.spotify.com/playlist/51kogmxTfY04jR6LrOlcMp"}
{"genre": "musica portuguesa contemporanea", "spotify_playlist_url": "https://open.spotify.com/playlist/0rEVT4ZihSorrk2EwgmP63"}
{"genre": "tearout", "spotify_playlist_url": "https://open.spotify.com/playlist/02vo6uHTDJqqJAUZE3GzmK"}
{"genre": "emotional black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1hegXrmD7IwnAv8dPP5Wis"}
{"genre": "psicodelia chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/5DksV4kczRPRgu5E3GiH3p"}
{"genre": "cosmic death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5nCUGX8cVUBs1p0GLrNCmz"}
{"genre": "fictitious orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/7vWzKkx25Ypq6GaaCVN4KK"}
{"genre": "st louis drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6MbVsXtyoTaATUUXhwt74l"}
{"genre": "musique comorienne", "spotify_playlist_url": "https://open.spotify.com/playlist/4Cjw8xL6od1fUWcKJHCHxW"}
{"genre": "hungarian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0ILJS3YPBHOUQteHkaRVp6"}
{"genre": "chinese indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7mv3d734tlpipCOpjEfLMD"}
{"genre": "vinahouse", "spotify_playlist_url": "https://open.spotify.com/playlist/4qlCXySd7UBKKmq8FkhCVO"}
{"genre": "classical cello", "spotify_playlist_url": "https://open.spotify.com/playlist/5VS8ADThTyZdwv13jVip67"}
{"genre": "street punk espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/3h7fF8ZzUWCYL5lJWSuEfp"}
{"genre": "swiss trap", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZPDke7UK4y0Ms8I1ldDQG"}
{"genre": "bemani", "spotify_playlist_url": "https://open.spotify.com/playlist/4ivlJRUHZWiP25Fm2qN7Dv"}
{"genre": "rap metal espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/5TixDd5uNtIrG0mua54Bt5"}
{"genre": "orchestral performance", "spotify_playlist_url": "https://open.spotify.com/playlist/6JQVexIlcd8GRubSpP49t0"}
{"genre": "brazilian modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/1wQ6t8Bo3Th1vLzFKK0Veu"}
{"genre": "paidika tragoudia", "spotify_playlist_url": "https://open.spotify.com/playlist/1GwgjmxPgYMSaJlzj3cg0k"}
{"genre": "latmiya", "spotify_playlist_url": "https://open.spotify.com/playlist/38pB7h48pDluEPSFk7NuyF"}
{"genre": "batida", "spotify_playlist_url": "https://open.spotify.com/playlist/5wd5MOHVeiMLGLCL0UYDsK"}
{"genre": "puerto rican indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6RvOIQPUfQg7kGde06Wdas"}
{"genre": "sambass", "spotify_playlist_url": "https://open.spotify.com/playlist/3rtVTR62F5JRdaWabccLGH"}
{"genre": "hungarian classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/01mgpiIC0zDKNAVRouBWZk"}
{"genre": "folklore uruguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/1cwrDRcEeToEkkBZZapTVp"}
{"genre": "hindustani instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/3FkL35y5g0Vs6jMYo5vNYW"}
{"genre": "cook islands pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5Crcxm95FskXZEEGh38gaU"}
{"genre": "psalmen", "spotify_playlist_url": "https://open.spotify.com/playlist/5lSfl95m04C6z4DtJwpmwA"}
{"genre": "fake", "spotify_playlist_url": "https://open.spotify.com/playlist/69tQwg4PtwjL7IvXHd1Wyi"}
{"genre": "sitar", "spotify_playlist_url": "https://open.spotify.com/playlist/1xMEPivWgOG18SFCrgwEI9"}
{"genre": "greek contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/5P8tTd1cQWuX5toG2oVCh5"}
{"genre": "karaoke", "spotify_playlist_url": "https://open.spotify.com/playlist/0hxVmcfrIAuXXps0kX1aN5"}
{"genre": "ecuadorian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/59RfeSzecRYkS0lIGiqrSY"}
{"genre": "palestinian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/4cUsQ92zB5oNEz3NxAIEFA"}
{"genre": "israeli classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/0cgmdn2oo9pnVlJwdpQaT0"}
{"genre": "dominican indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4wbKWXROzlJdXbtqEUc6Lw"}
{"genre": "italian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2lZNE4nnjvCXWnMHa5kc8o"}
{"genre": "deep gothic post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0XnPl86ItWuB4Wcvb2qfC8"}
{"genre": "math pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2a0hVaTWH7F2cCRi8CKSzh"}
{"genre": "peruvian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/28m57W4UI4eetkNu9SvtX9"}
{"genre": "musica michoacana", "spotify_playlist_url": "https://open.spotify.com/playlist/5RF9QQP7ye1w2ijt4TzJDp"}
{"genre": "neo kyma", "spotify_playlist_url": "https://open.spotify.com/playlist/4wJ5XPnKuXtHqQr4Acj3s8"}
{"genre": "rap feminino chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/7N3YoXooGpspOBkakIGzs7"}
{"genre": "polyphony", "spotify_playlist_url": "https://open.spotify.com/playlist/4wj4OQkPDzlztExS1F1CH7"}
{"genre": "mumbai indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0P5sUv03BUhlHvbtQ9l96V"}
{"genre": "classic italian folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6gS6GzxIiIADmPTa4xYvcC"}
{"genre": "viking black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6PpCm99AoagOn6HoVIy3ZP"}
{"genre": "wassoulou", "spotify_playlist_url": "https://open.spotify.com/playlist/3UghX77JNTUrIEgvSpGSVr"}
{"genre": "south african underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/4es7qR688lDJ2NTZbVCmfK"}
{"genre": "ryukyu ongaku", "spotify_playlist_url": "https://open.spotify.com/playlist/6N8qENHslBLpLYVEOP9Ebw"}
{"genre": "rap chretien", "spotify_playlist_url": "https://open.spotify.com/playlist/2b5xbXrNNeqxpcqSpy7JLC"}
{"genre": "yugoslav new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/5jaGOpLsE7tSbE060h8U6C"}
{"genre": "jig and reel", "spotify_playlist_url": "https://open.spotify.com/playlist/13xIyn7asOWIcgTwTFw293"}
{"genre": "chaabi marocain", "spotify_playlist_url": "https://open.spotify.com/playlist/15Pf5vEi62OADJC7CLCmFq"}
{"genre": "breton folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2Q9yQfdM8baHqEn3tWn23K"}
{"genre": "quebec death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3ozgCnrW1PNZxpkVkazhtT"}
{"genre": "punk catala", "spotify_playlist_url": "https://open.spotify.com/playlist/3IEqWeu1yUOkPhAH9h2iyr"}
{"genre": "modern psychedelic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1A9Z4GYnYXZFrC1Gg4LWcw"}
{"genre": "chinese soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/1vH4G2PWCvespHrxCOI0oK"}
{"genre": "zim hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/25zL0DjNC6mr6qB3F5iSWK"}
{"genre": "tuna", "spotify_playlist_url": "https://open.spotify.com/playlist/2GvK28xdNdKftHJ2hL2lTm"}
{"genre": "musica nublensina", "spotify_playlist_url": "https://open.spotify.com/playlist/0gAxIT4vlDudz3WhfKYORr"}
{"genre": "south asian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0KVgAg6kRrMkzrDyNJlh1C"}
{"genre": "ukrainian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/3ocyo0QqyIpbwsmGrgpgyG"}
{"genre": "mongolian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2O6YbzA8puEzHJ7KgTBaud"}
{"genre": "crack rock steady", "spotify_playlist_url": "https://open.spotify.com/playlist/1DtpofkGb09zLXCzsmlQ8C"}
{"genre": "danzon", "spotify_playlist_url": "https://open.spotify.com/playlist/165RdkkDtXcCvEedWLZm5S"}
{"genre": "kumaoni pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6UTwynBmwaBs9m94kyPCZB"}
{"genre": "malayalam cover", "spotify_playlist_url": "https://open.spotify.com/playlist/0j3SOR3PRf99Gynbp1j6Zl"}
{"genre": "bomba", "spotify_playlist_url": "https://open.spotify.com/playlist/20FNlUMNgCIUo7EAYRkJwg"}
{"genre": "violao classico", "spotify_playlist_url": "https://open.spotify.com/playlist/5G2C23N21neMHfn68HHT1S"}
{"genre": "bangladeshi indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6UoFptna0FeYqzMeOR8SVr"}
{"genre": "newcastle indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0TfobunOqQzAmoQFi3s2xw"}
{"genre": "violin", "spotify_playlist_url": "https://open.spotify.com/playlist/5j7SUgBZJ8Ap4ih5nat46U"}
{"genre": "tassie indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3IVEI3gx9M2tzndvPZkvId"}
{"genre": "bagpipe", "spotify_playlist_url": "https://open.spotify.com/playlist/2mccXT3LnZ6OsuCzoyXKnS"}
{"genre": "graz indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1qQ39j0RpgAr9ewFJlZMSU"}
{"genre": "mpb gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/32op5KCRSPTvd4esQDUAum"}
{"genre": "australian indigenous hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1tZl3PJhwwZ8HMOUA9mtA7"}
{"genre": "sega mauricien", "spotify_playlist_url": "https://open.spotify.com/playlist/7BKzCGpmIAZeheQzxf9ufa"}
{"genre": "cumbia cristiana", "spotify_playlist_url": "https://open.spotify.com/playlist/4JnExwkvDUCa4ar2g3YxbI"}
{"genre": "rock curitibano", "spotify_playlist_url": "https://open.spotify.com/playlist/7yavyKYi8aAXvmRODL8IAm"}
{"genre": "deep dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/5wyZAEalS7giTBe54e1GfS"}
{"genre": "garage punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4jXVpI7UvXw8MlqR7Y9yv0"}
{"genre": "spanish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4eIEk9563Yr14VCgOjnJsv"}
{"genre": "balkan punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7jMAU8I3M9s8bFAUh8LQBe"}
{"genre": "ambient synth", "spotify_playlist_url": "https://open.spotify.com/playlist/6yNu0QzQfcGFFQrfVtogBA"}
{"genre": "french garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5iOc0x0rzYpvshIYzaa15A"}
{"genre": "warrington indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2M0K6YvLgC8q37kwASoHaM"}
{"genre": "khortha pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2pCES4XdIjKJKaKeFYrhzW"}
{"genre": "portland metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5lW8gmLYuDAADRlyqrZNXs"}
{"genre": "gospel singers", "spotify_playlist_url": "https://open.spotify.com/playlist/5uNencS97nBENMIyhtZguS"}
{"genre": "rva indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0fTqNJx6W3wp7f0wGtrVPX"}
{"genre": "uwielbienie", "spotify_playlist_url": "https://open.spotify.com/playlist/51bJSFM7fI5aoteuO0ZYUO"}
{"genre": "goralski", "spotify_playlist_url": "https://open.spotify.com/playlist/7hHlls8yvqASqyc7nTYVit"}
{"genre": "eritrean pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6zvmdD3Hz5q4AVqc6AUshA"}
{"genre": "slavic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6WYLegi5QthJ5ivzNnz4wM"}
{"genre": "taiwan instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/5ktUoxOwva0xzMLV6HrR2g"}
{"genre": "garage punk blues", "spotify_playlist_url": "https://open.spotify.com/playlist/0MIPIfJMv7GoAf8gAIsteU"}
{"genre": "vegan straight edge", "spotify_playlist_url": "https://open.spotify.com/playlist/2pni39gq7ITfQJmVacTtrM"}
{"genre": "mandible", "spotify_playlist_url": "https://open.spotify.com/playlist/6mLO13tVLO98kSfe3A6XJg"}
{"genre": "clap and tap", "spotify_playlist_url": "https://open.spotify.com/playlist/2txBERwbpo2voBtdwA8VGG"}
{"genre": "buffalo ny indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0IwWYZCm6MJHuzknIZHw7B"}
{"genre": "remix product", "spotify_playlist_url": "https://open.spotify.com/playlist/4xVyoTeHmAQ0yqz3D6GJx6"}
{"genre": "japanese boom bap", "spotify_playlist_url": "https://open.spotify.com/playlist/3WNsz4FbBBBHE9ED9D9KPW"}
{"genre": "christian dance", "spotify_playlist_url": "https://open.spotify.com/playlist/1gwP21GRuImodOMURpSXYs"}
{"genre": "kids hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1hgy2QVZ8otm9UkLaQnGpG"}
{"genre": "salsa cristiana", "spotify_playlist_url": "https://open.spotify.com/playlist/1FoP9qiYQV27ZwFNCP4N8z"}
{"genre": "deep disco", "spotify_playlist_url": "https://open.spotify.com/playlist/0qxjocA4xQxGG111X2bcSj"}
{"genre": "swedish hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/06nltIE2BZRD4KtSZ0Scnl"}
{"genre": "bahai", "spotify_playlist_url": "https://open.spotify.com/playlist/6HxkWVGjZV1rnLDZ7DYZig"}
{"genre": "musique pour enfant quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/2c8ynEyyWccPS7FTsB3dEC"}
{"genre": "ukrainian folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/75jsXvWR0WCWGbJCdyUhJa"}
{"genre": "macedonian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0X8BD5Y2hyyC6Vaccx0AoF"}
{"genre": "lafayette indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3UziAt6SZEbzRThnSMyU5K"}
{"genre": "igbo trap", "spotify_playlist_url": "https://open.spotify.com/playlist/5xL6QSBityjxBRs3UKXG9e"}
{"genre": "chhattisgarhi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3b6DlxxGF28XXmHeUI92ns"}
{"genre": "gulf hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/39DfjCVzK3pnszkIPeXN17"}
{"genre": "memphis americana", "spotify_playlist_url": "https://open.spotify.com/playlist/37qBQkNmniKSzKQSaF1gOw"}
{"genre": "bahamian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0rSWozhTVMRbDa6Afqn90f"}
{"genre": "shoegaze brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/0dCg4tpcWWDMxOy59wejGD"}
{"genre": "cavernous death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0d7494iI3NCBLj1q4draCg"}
{"genre": "new wave of glam metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3o7Cu2rwpygk6zJiCqE0Z7"}
{"genre": "finnish new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/6yjR6aJHgo1U4xZtCfnnpI"}
{"genre": "lldm", "spotify_playlist_url": "https://open.spotify.com/playlist/3uBMvagrQmxD0fFw5W6fOS"}
{"genre": "slushwave", "spotify_playlist_url": "https://open.spotify.com/playlist/4aJWAqjVDWFCttlpi3F4HA"}
{"genre": "modern swing", "spotify_playlist_url": "https://open.spotify.com/playlist/6OjkhYNqLUKiCCYJqTRo8J"}
{"genre": "serbian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/3LIj4qA2q73Sl3tHBd8hge"}
{"genre": "sanfona", "spotify_playlist_url": "https://open.spotify.com/playlist/29uSVHov0bnaDg60Q8fzM4"}
{"genre": "naija old school", "spotify_playlist_url": "https://open.spotify.com/playlist/5PFKw26uC3eJ4lJcRbPlf1"}
{"genre": "american 21st century classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6b88SJXqhpJ9MaBMDn98FV"}
{"genre": "west african jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0WRIEExyzsjtbPZsUOAURR"}
{"genre": "urban kiz", "spotify_playlist_url": "https://open.spotify.com/playlist/6jyOc2NX8pgHs0mDT4Df2c"}
{"genre": "japanese melodic punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4injc3ZPFFRB2dAMlo7wU3"}
{"genre": "punk rock italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/1VW51zSCemBe3pfa82c90F"}
{"genre": "british industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/2w6OEmFNpIydAbrB8m0DIX"}
{"genre": "deep progressive rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5D7ascA0846W8Ye1LACHQG"}
{"genre": "british experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/7yYi9aJirMqgnn5XlqOkZp"}
{"genre": "military band", "spotify_playlist_url": "https://open.spotify.com/playlist/0dHY01cuEZbyQ4Sy5x9qFd"}
{"genre": "wrock", "spotify_playlist_url": "https://open.spotify.com/playlist/3MAmofobV4T8ycrHSpTwn3"}
{"genre": "japanese hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/01j3k31n8pfn6hb6RMLUBk"}
{"genre": "rogaland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6zr430cWaouP1FW0YhGiyE"}
{"genre": "northeast indian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0dIVTAucTpWxQLgePj5QjW"}
{"genre": "magyar retro dance", "spotify_playlist_url": "https://open.spotify.com/playlist/6felxoq1MSnlYbMAXuMJyH"}
{"genre": "sheilat", "spotify_playlist_url": "https://open.spotify.com/playlist/4bmDe3jeZMBdjkuM6puaVL"}
{"genre": "detroit trap en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/71p5kU1kMytV6A1aJ0jW8a"}
{"genre": "dennery segment", "spotify_playlist_url": "https://open.spotify.com/playlist/0x1Qzxac0JYNxkRZLktFLt"}
{"genre": "swedish rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/27xmS6EueK1bODxW6rrdJ7"}
{"genre": "rap portuense", "spotify_playlist_url": "https://open.spotify.com/playlist/7vNJd1Kg4UrCwPK3nZryvq"}
{"genre": "kuduro", "spotify_playlist_url": "https://open.spotify.com/playlist/1BRJmIuTmwJPrwQdusX91F"}
{"genre": "detske pisnicky", "spotify_playlist_url": "https://open.spotify.com/playlist/5ggt9QATTOmCuRAPV3r7QF"}
{"genre": "deep big room", "spotify_playlist_url": "https://open.spotify.com/playlist/1VH3SvGCwNf06mibdpeR7I"}
{"genre": "japanese psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/1IjPgTmGRkdHg0VwuY0rvj"}
{"genre": "didgeridoo", "spotify_playlist_url": "https://open.spotify.com/playlist/4iQIoXKmKERiy2cwVYvvMo"}
{"genre": "irish rebel song", "spotify_playlist_url": "https://open.spotify.com/playlist/4YTLyNGigTUxRK2VOKBGPM"}
{"genre": "ambient trance", "spotify_playlist_url": "https://open.spotify.com/playlist/4lFah00zj4wCnxf1rquFRA"}
{"genre": "uppsala indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7izAx1uz2FZETjj2J9Qiet"}
{"genre": "mississippi indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2VkQG1bSHwwlnu7zOz6hYr"}
{"genre": "pop catracho", "spotify_playlist_url": "https://open.spotify.com/playlist/2gfI86zUHApvK6lV5yOLcG"}
{"genre": "faroese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2i2FDkvTFSKP0D68hXwqNm"}
{"genre": "rwandan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4pQsuD93z6mS3M8mB8ifD6"}
{"genre": "french black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2jqAkE36tKTG48IdPF1917"}
{"genre": "indonesian underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5Bcg4lfGVowGrrCV6WVW7n"}
{"genre": "japanese electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6w0py1uEgGI5cIxhIlnRaF"}
{"genre": "uk beatdown", "spotify_playlist_url": "https://open.spotify.com/playlist/0glh6jk9qJ2Ibuz3qbERLu"}
{"genre": "ukulele cover", "spotify_playlist_url": "https://open.spotify.com/playlist/5DYnlrlFQR9IecczHvfzaj"}
{"genre": "pornogrind", "spotify_playlist_url": "https://open.spotify.com/playlist/2RfePZozRa9gl4lmx4Oldv"}
{"genre": "new isolationism", "spotify_playlist_url": "https://open.spotify.com/playlist/3b97q4GnhWUw2oMm5OmC0w"}
{"genre": "norwegian americana", "spotify_playlist_url": "https://open.spotify.com/playlist/3iCft6V9x3v1KxFIu1gDfL"}
{"genre": "musica hondurena", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZQHY35pKT3qQjdBg6ARMY"}
{"genre": "trio batak", "spotify_playlist_url": "https://open.spotify.com/playlist/4iYWdcJhjLHD9iHCXqnv7z"}
{"genre": "jazz harp", "spotify_playlist_url": "https://open.spotify.com/playlist/0RMwdVc8npKTkImaMd0o3q"}
{"genre": "panpipe", "spotify_playlist_url": "https://open.spotify.com/playlist/5B3UjHWa4cJ3pYd8dIiOKy"}
{"genre": "cancoes infantis", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZV46mlclUvsB9j34zKZ2W"}
{"genre": "swiss folk", "spotify_playlist_url": "https://open.spotify.com/playlist/623xipOO67LZgslyiF58Mt"}
{"genre": "indonesian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0yaAn9ELCJ7WzLhYJ3DHNi"}
{"genre": "jazz brass", "spotify_playlist_url": "https://open.spotify.com/playlist/7m2b2nBy51rTT8kHKJ7HyK"}
{"genre": "louange", "spotify_playlist_url": "https://open.spotify.com/playlist/09XCT5qBhFP0GdHH8kaB3K"}
{"genre": "hmong pop", "spotify_playlist_url": "https://open.spotify.com/playlist/66cLrKqCfplW8X2I3PKfef"}
{"genre": "comedienne", "spotify_playlist_url": "https://open.spotify.com/playlist/1CruiEBwsHZTp8VYJppXPx"}
{"genre": "manipuri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6An7hnuZmNj0VBt80vz6Bj"}
{"genre": "sonora indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0HzeEyoLQcd9KCfda4yBoA"}
{"genre": "german black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7hu7BO4O7OSu0yoetxbKh7"}
{"genre": "argentine metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6rUKKXL8dj1grd1jrmpZ3G"}
{"genre": "south african soulful deep house", "spotify_playlist_url": "https://open.spotify.com/playlist/4CgnLs5P0WWC60Ja8a60qO"}
{"genre": "czsk reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/3fdYNisJVRz3Gsu8hs8BVt"}
{"genre": "polish folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4iy738QjI4zidzPOjhbLgp"}
{"genre": "solomon islands pop", "spotify_playlist_url": "https://open.spotify.com/playlist/54Pv4pq3UwpbH05O14Gu1X"}
{"genre": "concert band", "spotify_playlist_url": "https://open.spotify.com/playlist/5z0OFjAuMufpuiuKx7kFIc"}
{"genre": "drill beats", "spotify_playlist_url": "https://open.spotify.com/playlist/20Nyoxp7ti93U4ZU5kjiph"}
{"genre": "kansai indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5QJKxaICdwVlVkNO7piIcc"}
{"genre": "san antonio rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1mI8wSq10B1xcb3Tvejil9"}
{"genre": "svensk lovsang", "spotify_playlist_url": "https://open.spotify.com/playlist/5tAlOeh0paHbCx4KuSGyBn"}
{"genre": "hamburger schule", "spotify_playlist_url": "https://open.spotify.com/playlist/5TCT3htdio4Hik2pF12ky8"}
{"genre": "modern darkwave", "spotify_playlist_url": "https://open.spotify.com/playlist/7CxPO1s49f3QtaG7ZhUXf2"}
{"genre": "brazilian post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5pOUlWdNexlBRsBFJ6d507"}
{"genre": "musica jibara", "spotify_playlist_url": "https://open.spotify.com/playlist/2vXOV5GgsBZo0lJsqxI52K"}
{"genre": "guyanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7rLmihHHTsuYRMdBKfzgi1"}
{"genre": "derby indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2Lt8mZ8J2wfkOOvTswtT7e"}
{"genre": "norwegian punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/55tjSUI5gT2qRtjECLE1qf"}
{"genre": "spanish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/0iGGWpXCPFb1W6N32iAPmO"}
{"genre": "danish singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/5EdLPXxNnAvxoKXni4M5IN"}
{"genre": "spanish prog", "spotify_playlist_url": "https://open.spotify.com/playlist/2UOmTYokX462wwAMx687SQ"}
{"genre": "traditional british folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3Tqsr2oxmvcAecCQ4CKXyK"}
{"genre": "italian new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZmmpYXtwWs03mS0jgawYB"}
{"genre": "hindi worship", "spotify_playlist_url": "https://open.spotify.com/playlist/0X1DCauLa5DFA8iQPgt895"}
{"genre": "american melodeath", "spotify_playlist_url": "https://open.spotify.com/playlist/11ciXHI1eDFQiOyMznozgC"}
{"genre": "persian drill", "spotify_playlist_url": "https://open.spotify.com/playlist/3oLyxHplZlPZ3w43nQFajf"}
{"genre": "deep progressive trance", "spotify_playlist_url": "https://open.spotify.com/playlist/0kUfDiMQYGivJnakru5Vh0"}
{"genre": "worcester ma indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6QYRzbXYVmeIXkhjlJNyb1"}
{"genre": "telugu remix", "spotify_playlist_url": "https://open.spotify.com/playlist/0HQLygT9qQmatFKaKaQUJo"}
{"genre": "chain punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1wL2aedMQGgNz9UkNI9ryk"}
{"genre": "musica lombarda", "spotify_playlist_url": "https://open.spotify.com/playlist/08pphEZ3JVrZiQB6IlRYcS"}
{"genre": "jewish hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0fzLtBcW9USatoZ5U3b0Bc"}
{"genre": "cypriot hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/51dlZwYLzof3euhHmUpSEn"}
{"genre": "bulgarian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3VKkzhc2BBXqtDDKgA1L8E"}
{"genre": "swiss techno", "spotify_playlist_url": "https://open.spotify.com/playlist/5MScpF1soeUbcrlZk14uMo"}
{"genre": "ambient country", "spotify_playlist_url": "https://open.spotify.com/playlist/208ByvEuq0IyX67lXWdNYQ"}
{"genre": "swedish folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6tA81ejhPK3Df3xrDsHnIG"}
{"genre": "greek guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/5DOjUjlPPDjf6BOY7kiVX4"}
{"genre": "psybass", "spotify_playlist_url": "https://open.spotify.com/playlist/2G9uoCA4NEEL74QTh8pEde"}
{"genre": "vintage broadway", "spotify_playlist_url": "https://open.spotify.com/playlist/1Llq45WvEoSY0v12skZBl2"}
{"genre": "portuguese folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4sg2LK8vl8utC7ug4xPknT"}
{"genre": "flemish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2fiAtiIalythHfTVGJRJWM"}
{"genre": "swedish prog", "spotify_playlist_url": "https://open.spotify.com/playlist/7Knuekk6Ztk9rAqOqsuYn7"}
{"genre": "musicas espiritas", "spotify_playlist_url": "https://open.spotify.com/playlist/7uq0NF4OnW8uzih15y6PQk"}
{"genre": "jalsat", "spotify_playlist_url": "https://open.spotify.com/playlist/6mJFRVIkjz6fdhav9E0qLj"}
{"genre": "garage psych", "spotify_playlist_url": "https://open.spotify.com/playlist/1R6gkpoaA4kCNsTX2HAeDD"}
{"genre": "gospel italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/4XZcgk4PE457JoGZ3wewBJ"}
{"genre": "throat singing", "spotify_playlist_url": "https://open.spotify.com/playlist/06b02z4kjwrtG7aeJuUaEz"}
{"genre": "rap pernambucano", "spotify_playlist_url": "https://open.spotify.com/playlist/0U6I2Nkiv3NbSN4I7Ym7yF"}
{"genre": "japanese worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5yPsM2eJWlErqvHGN8ukpY"}
{"genre": "lancaster pa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2vnSy7bTDFfI6FN0AkLZiu"}
{"genre": "chinese jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3vnRXcNe4Twu2ceASnGOtJ"}
{"genre": "memphis indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4AQv9pyvgAUI44uTJuV8Og"}
{"genre": "neo-kraut", "spotify_playlist_url": "https://open.spotify.com/playlist/3latkPrUCKAReX6bA9cEBw"}
{"genre": "musica aguascalentense", "spotify_playlist_url": "https://open.spotify.com/playlist/7Fh0u1Wv41GsgM4kCw8Cxf"}
{"genre": "rusyn folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3lj2PgGP1bkQVnc7ioLosi"}
{"genre": "persian sad rap", "spotify_playlist_url": "https://open.spotify.com/playlist/703bHAXaUiMA90jlQyemQb"}
{"genre": "punta", "spotify_playlist_url": "https://open.spotify.com/playlist/0rApSgH1yXT0cr4hY3rlX8"}
{"genre": "sungura", "spotify_playlist_url": "https://open.spotify.com/playlist/4MJnJjLGEgrW0R4H9PVdAt"}
{"genre": "stateside dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/2wHDDpZj2N9zSDYLJQ52Jd"}
{"genre": "tucson indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5o1AJTX1chQYFF0xHVgL0f"}
{"genre": "slovenian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/04fctEzNDUahg7W7dhTnvb"}
{"genre": "punta rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1ew19In22xhtrdpohbzx6K"}
{"genre": "stomp and whittle", "spotify_playlist_url": "https://open.spotify.com/playlist/5BlFafrlExpf0KSlIOahrd"}
{"genre": "deep deep house", "spotify_playlist_url": "https://open.spotify.com/playlist/1EAfrcE5wTxdQ2bAu6vmmG"}
{"genre": "dronescape", "spotify_playlist_url": "https://open.spotify.com/playlist/1PxSVj3X9Ic9uzcicfqn7c"}
{"genre": "glitch beats", "spotify_playlist_url": "https://open.spotify.com/playlist/6s0bhopje9j3s2JiTHtLlx"}
{"genre": "plugg en espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/4iWNy2pQP264gRiOnVIZs5"}
{"genre": "euskal indie", "spotify_playlist_url": "https://open.spotify.com/playlist/10ZdPLIr6c2dFAALbRAFhG"}
{"genre": "muzica copii", "spotify_playlist_url": "https://open.spotify.com/playlist/6sMMBLsu29CEaOdSEvSapL"}
{"genre": "ambient black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1F4wNx9h2luKTSc1Tvx6fv"}
{"genre": "makina", "spotify_playlist_url": "https://open.spotify.com/playlist/0SIod8gUiCyiC8HzToRf2c"}
{"genre": "musica pitiusa", "spotify_playlist_url": "https://open.spotify.com/playlist/5F1vipfT6OWc9oNkGQqzl3"}
{"genre": "dub punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6ahLQVrRUieMfyUrOM6HKq"}
{"genre": "leipzig indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1Bq02QfRLJHEfGZGabm1hl"}
{"genre": "drill dominicano", "spotify_playlist_url": "https://open.spotify.com/playlist/7EoQ7i8NXQ2wTqVgIYxlHb"}
{"genre": "indian percussion", "spotify_playlist_url": "https://open.spotify.com/playlist/4a3VarAtSbgKDRDjfqhB93"}
{"genre": "festigal", "spotify_playlist_url": "https://open.spotify.com/playlist/5KQBeEusXD5IQ5NIjxek94"}
{"genre": "polish contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/0jniswZ8mF0KAGP07FKFel"}
{"genre": "german pagan metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1FmlTJhvVot4ctN0pThgMx"}
{"genre": "pittsburgh metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0VrLSdr3bRRpYyKHWJU04A"}
{"genre": "contrabass", "spotify_playlist_url": "https://open.spotify.com/playlist/17J6qYVEkvx42RNjjqwWLo"}
{"genre": "norwegian space disco", "spotify_playlist_url": "https://open.spotify.com/playlist/5QenrGMgQHb16phrb8aPLj"}
{"genre": "ukrainian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4owhU0gvE7w95wunf4SzST"}
{"genre": "kelowna bc indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7M46fyHKJg7TGS5J2OTB9I"}
{"genre": "folk black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2Aah9Z4XH3yjHhPjFOCwh5"}
{"genre": "bass trip", "spotify_playlist_url": "https://open.spotify.com/playlist/261tckgSRkJTTf8GbK8HH4"}
{"genre": "hungarian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/1F7iSW32d3WByKSeWzb7mb"}
{"genre": "moderne ludovky", "spotify_playlist_url": "https://open.spotify.com/playlist/67d8ZErWzL8JcN780RMiT8"}
{"genre": "mongolian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3CdYZdrHIJcTGK0ooV3ygU"}
{"genre": "indie electronica", "spotify_playlist_url": "https://open.spotify.com/playlist/53c317ocGcanb04Adxe8Es"}
{"genre": "malayalam worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5lhOdh5At1U70qKnL3V3zZ"}
{"genre": "lagu sasak", "spotify_playlist_url": "https://open.spotify.com/playlist/49KNl5r9iJkG8BYo8VlWxX"}
{"genre": "banda guanajuatense", "spotify_playlist_url": "https://open.spotify.com/playlist/0GbZPGLBvqOzN2qn3U8DKQ"}
{"genre": "english renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/2ikc7RM2cySIDipaP64KJq"}
{"genre": "light music", "spotify_playlist_url": "https://open.spotify.com/playlist/19Lk45ZXIYyC5ZGYqfTNCk"}
{"genre": "deep progressive house", "spotify_playlist_url": "https://open.spotify.com/playlist/7LcYmCAzj3ZFMc6mACdwP0"}
{"genre": "chicano punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2TKcfnqTPYu4pY4peMDQE6"}
{"genre": "guitarra clasica", "spotify_playlist_url": "https://open.spotify.com/playlist/609HOKG5EE7KHuK4NaDMqO"}
{"genre": "halifax indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2TV6sXrmiOVGcmGB7h3KBu"}
{"genre": "dancehall guyanaise", "spotify_playlist_url": "https://open.spotify.com/playlist/6J3skQbRjVeJObR2OUtQ47"}
{"genre": "lancashire indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3GTitzQCtoUcVkLKAY2J2G"}
{"genre": "columbus ohio indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0hVZOJCIKf8cLdeOPx52kF"}
{"genre": "oth indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3FqSsjOig3Q0MDEV90x4S2"}
{"genre": "cuento infantile", "spotify_playlist_url": "https://open.spotify.com/playlist/1TufwPOsgXigZyIUoh1GHj"}
{"genre": "kenyan drill", "spotify_playlist_url": "https://open.spotify.com/playlist/0mLDT7xPUSqpnDEoa5DFqw"}
{"genre": "baptist gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/38D801qxfI1GvZZHQG5q1W"}
{"genre": "czech indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2bXFADqEjwIUCoCgpSWrk0"}
{"genre": "jazz puertorriqueno", "spotify_playlist_url": "https://open.spotify.com/playlist/3m3J7ebPRLBnxM9NqL9D9P"}
{"genre": "singaporean electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/44OUX4g93g6SohAJSSpKJC"}
{"genre": "armenian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4C8m7u87Nck0PxnVJb0JjP"}
{"genre": "pashto pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2VwTK3cRlPYlC7ogDiwPsP"}
{"genre": "canadian psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2ixAwRgbvuIF9Fa0gnuC0u"}
{"genre": "detske pesnicky", "spotify_playlist_url": "https://open.spotify.com/playlist/6J3wznU8ajEV1PZYttkTzw"}
{"genre": "german dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/6R0fF4h0lHXU1xqcCzp9hd"}
{"genre": "northern irish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/53XJjU20RldmQHpuxGzGzw"}
{"genre": "trad quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/2SB4tyblu4sx1ZJ4A8xrXE"}
{"genre": "future ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/07Dm64w1XhUXaXDOtfXlNy"}
{"genre": "spanish rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/7n8jgo5lx7XUOQXC0Vaqu8"}
{"genre": "aarhus indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6tBMqR2dxCAe8PytK9cKcf"}
{"genre": "italian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3e8jdbusZjbMKWTv6Zv2GR"}
{"genre": "rap galego", "spotify_playlist_url": "https://open.spotify.com/playlist/6dVFOCFp6Hoa0pVPbmRm0q"}
{"genre": "swiss alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4HbPdWQOaZo2nokBecGMhb"}
{"genre": "solipsynthm", "spotify_playlist_url": "https://open.spotify.com/playlist/08LL9PQv1uQ11gPKj1CTvW"}
{"genre": "brazilian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/59m4dGWhNOmDno7HRVSMps"}
{"genre": "fast melodic punk", "spotify_playlist_url": "https://open.spotify.com/playlist/08cijle4wA9ijkgwYToaxe"}
{"genre": "libyan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/298IiSjgnmBCBH66gf21j2"}
{"genre": "american romanticism", "spotify_playlist_url": "https://open.spotify.com/playlist/3zx5G3PxVwdARrGTfwbXbw"}
{"genre": "northeast indian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3OB8R31OANTKUVPQOcgdkc"}
{"genre": "erotica", "spotify_playlist_url": "https://open.spotify.com/playlist/6SW3GOlCtAd3WjUWdXwyaS"}
{"genre": "atmospheric sludge", "spotify_playlist_url": "https://open.spotify.com/playlist/6gPuTJObMuO6PYBqTVhhGS"}
{"genre": "arabic instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/1ETZJ22QZBkO3WXLEGgRpf"}
{"genre": "swiss indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0hm17FJIGZ2AzX3QCExv9R"}
{"genre": "brazilian dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/3H0z2PNzgD8BqBbRUnkVy9"}
{"genre": "acid trance", "spotify_playlist_url": "https://open.spotify.com/playlist/0rSDQ760FMUfBOFSAlnC8M"}
{"genre": "rap metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6hM2WgnESO79i0NZVqncHV"}
{"genre": "bossa nova jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/68qffdP3LzsrDkrmrt0xKi"}
{"genre": "highlife", "spotify_playlist_url": "https://open.spotify.com/playlist/47IU2RY3QPp07RIcQ1vOOP"}
{"genre": "deep liquid", "spotify_playlist_url": "https://open.spotify.com/playlist/6BpJBq5EQ94Nm06ckgS9PM"}
{"genre": "psydub", "spotify_playlist_url": "https://open.spotify.com/playlist/2MtDhoqYmegOviJeKyoCxv"}
{"genre": "broken beat", "spotify_playlist_url": "https://open.spotify.com/playlist/1rnJHknpDL8e9EjJeI7d1V"}
{"genre": "old school hard trance", "spotify_playlist_url": "https://open.spotify.com/playlist/2GENetRkZ45yEbcuqdt4WE"}
{"genre": "power thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/6BR6crMXq9OQYVastamVDj"}
{"genre": "corsican folk", "spotify_playlist_url": "https://open.spotify.com/playlist/77nomJaQw67he2cnzHS6kj"}
{"genre": "deep soul house", "spotify_playlist_url": "https://open.spotify.com/playlist/6rKHYk07I03KxUuDGWj3Sp"}
{"genre": "musikkorps", "spotify_playlist_url": "https://open.spotify.com/playlist/7xbK3YEpiCfkISMiK26r2g"}
{"genre": "romanian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0T2aOQSexU1FB4aQQBSdQd"}
{"genre": "psalms", "spotify_playlist_url": "https://open.spotify.com/playlist/6womysPFEFvgnyyaVOIn0I"}
{"genre": "austin singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/4fcravOX9bIqlZMXgKqWV9"}
{"genre": "sega", "spotify_playlist_url": "https://open.spotify.com/playlist/4Y1O6mnzLe2uy7Kqx8fa5X"}
{"genre": "magyar mulatos", "spotify_playlist_url": "https://open.spotify.com/playlist/55v6fRnQDki7tGhsfpScvm"}
{"genre": "limerick indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3NjB4oamzRkLEKzAOATcVW"}
{"genre": "xhosa", "spotify_playlist_url": "https://open.spotify.com/playlist/1SPR7yk4kwmz09NovuUzKN"}
{"genre": "russian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6NkJ3xUlvc3i48yCNEoduj"}
{"genre": "zurich indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0jNHdwA4dCJkYmPBHlt4r2"}
{"genre": "minimal dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/3AvkIFxEK6Ay45wuqKuybJ"}
{"genre": "hungarian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6IbzEpJ0swzazw9HEFMKb7"}
{"genre": "indie psych-pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4n67kcUir3bjhaybRha2G1"}
{"genre": "greek rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4FGSq8L27DzNOAv63DbBSV"}
{"genre": "industrial techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4dKxJnBaUEkEarU8qT0AMN"}
{"genre": "mexican traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1kkrJvs739R8GjFMJPeZ2X"}
{"genre": "vintage italian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6H9GvG5RlcVaHNxDx9agE1"}
{"genre": "experimental synth", "spotify_playlist_url": "https://open.spotify.com/playlist/3JIOP9ciE3hb2cXTMOzBma"}
{"genre": "swiss singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/39fDLM4s1IyMlxDLLRFpkX"}
{"genre": "rasiya", "spotify_playlist_url": "https://open.spotify.com/playlist/5LLahGLkbdEZ70NLg77vsM"}
{"genre": "nitzhonot", "spotify_playlist_url": "https://open.spotify.com/playlist/4LfTA71lypx7XfDpvMZXae"}
{"genre": "gambian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6wnPPDhbZF7FtyfvNkpkLu"}
{"genre": "canadian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/46vWzFtJUqX1PZHoQswUuR"}
{"genre": "swiss reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/3BMqtY6C1ZQaS7LbanRysj"}
{"genre": "deep brazilian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4PRTrvutXqjv9Ec5CVO7w6"}
{"genre": "capoeira", "spotify_playlist_url": "https://open.spotify.com/playlist/0SuUJuDl8MFWN2lOU07EtW"}
{"genre": "metal gotico", "spotify_playlist_url": "https://open.spotify.com/playlist/0NEoudfcNeCkeULzX7co9e"}
{"genre": "finnish pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5AnKiIswDra20Mmmoe4aPs"}
{"genre": "deep liquid bass", "spotify_playlist_url": "https://open.spotify.com/playlist/6nOAxBntpTFNYIxO8DUEM4"}
{"genre": "kenyan alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/7MYsbfVbvmW4WbABxYFqE5"}
{"genre": "freakbeat", "spotify_playlist_url": "https://open.spotify.com/playlist/4XvaxZIdz8XNZqbckxbfYV"}
{"genre": "spirituals", "spotify_playlist_url": "https://open.spotify.com/playlist/7u9s8sobm0vJDxpdkhC3we"}
{"genre": "drone ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/7kXIjqEB0TfSe7sI8N6Ypy"}
{"genre": "orquestas de galicia", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZnW0zSnQH9pqqntocgUDX"}
{"genre": "irish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5NiqVWMIAbKPchF0UebEsC"}
{"genre": "mezmur", "spotify_playlist_url": "https://open.spotify.com/playlist/6RFAXWzgMsqIkfZBXoFi8C"}
{"genre": "punk tuga", "spotify_playlist_url": "https://open.spotify.com/playlist/1Rc2TBXWekRzcu21vwlYS2"}
{"genre": "french post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/00y5CS1HijU14hGpBeXfw8"}
{"genre": "experimental guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/3BK0gx0rvmoqDp691gtQZG"}
{"genre": "boogie-woogie", "spotify_playlist_url": "https://open.spotify.com/playlist/3VvwVEZaPYQfI8ZZbOCW5h"}
{"genre": "musica costarricense", "spotify_playlist_url": "https://open.spotify.com/playlist/20MbFTd6EIRLby7minxHBP"}
{"genre": "german dark minimal techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6S5zF06mFcNSd9JYYivCBM"}
{"genre": "singaporean hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3VnBB3I74dmWXRRlML5TVX"}
{"genre": "texas punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4SiVg5H07MzR76ON0qOEUw"}
{"genre": "forest psy", "spotify_playlist_url": "https://open.spotify.com/playlist/7615WtgKBqapPBpBB9lxUW"}
{"genre": "serialism", "spotify_playlist_url": "https://open.spotify.com/playlist/6L5r0Dapop0UDxN5ple8pT"}
{"genre": "reiki", "spotify_playlist_url": "https://open.spotify.com/playlist/3eFFWm7tiB8b90zD7fzUJv"}
{"genre": "gamecore", "spotify_playlist_url": "https://open.spotify.com/playlist/6pwwr0yjxNzMlY5Qr20cEm"}
{"genre": "erotik", "spotify_playlist_url": "https://open.spotify.com/playlist/4CMUF1K2xAkuqrxpwnINtr"}
{"genre": "swedish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/5Oal0SFrp5aZoXlEaD8PQ4"}
{"genre": "dirty texas rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6fDGduFLTXlvazu5XahC72"}
{"genre": "australian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/7kQSXw1ezgx6LowSSqyWsy"}
{"genre": "blackened screamo", "spotify_playlist_url": "https://open.spotify.com/playlist/4mJCRik4FVLtaSVccmBTzy"}
{"genre": "vintage cantonese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4uQKmfsrx5mLF1kcrJjASZ"}
{"genre": "french dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/3Dz0w0CGiJkHCpOKEISUeN"}
{"genre": "indie singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/2bufHEzNYhC6tl3zpvXG7l"}
{"genre": "cosmic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/57BiSOFDoNQ9Kw1sCx0qGZ"}
{"genre": "nordic ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/6fjFw9EBblcy8D3tWL16pC"}
{"genre": "musica potiguar", "spotify_playlist_url": "https://open.spotify.com/playlist/7LTsVsWICU2Z8i5DOTtzYm"}
{"genre": "russian dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/5MCVLiDmEoHxJmOK3HBfnt"}
{"genre": "popullore jugu", "spotify_playlist_url": "https://open.spotify.com/playlist/6VumQrccyGr0qwXLjAUdVW"}
{"genre": "technical black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0KHHHweoNFNfWbDgG04eMI"}
{"genre": "bansuri", "spotify_playlist_url": "https://open.spotify.com/playlist/44OUoml4AGGKm6L0OB4JxL"}
{"genre": "soul flow", "spotify_playlist_url": "https://open.spotify.com/playlist/3WZNkiRvWTSI1VwZn0Gw09"}
{"genre": "greek psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1TRSWLf7DyPgpmsyJXaYQT"}
{"genre": "klapa", "spotify_playlist_url": "https://open.spotify.com/playlist/24GT3KBxuEkuI6ATbiNBtg"}
{"genre": "electronica chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/3wRf1C9sLcfpsUorCGVKCq"}
{"genre": "birdsong", "spotify_playlist_url": "https://open.spotify.com/playlist/48Rh26zAS7cf7PCM2juNjF"}
{"genre": "reggae mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/5XsD9PUVe8NK5XwEX87gzx"}
{"genre": "puglia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0u7nZalGkBE06EwJQ9m48v"}
{"genre": "deep new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/2VPksLw01r3ehizbrMkXdF"}
{"genre": "somali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5hOHDErcdm4GjuOl37HMy1"}
{"genre": "brazilian tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/3zUYANulWztUKlnipQD8ZH"}
{"genre": "australian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/40JvmtDltgFju6fGoscWlJ"}
{"genre": "ukhc", "spotify_playlist_url": "https://open.spotify.com/playlist/7iF21JdLdqullZnsPXps0n"}
{"genre": "8-bit", "spotify_playlist_url": "https://open.spotify.com/playlist/0ORjwYMeNv9v441v6aHPa1"}
{"genre": "pop boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/1bsWqNpI1sJ9IxP7xYwJSS"}
{"genre": "indorock", "spotify_playlist_url": "https://open.spotify.com/playlist/7a30Vw8FqQLCDrBpteWj3H"}
{"genre": "uk stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6D5Jw413HjEVU0GBcNUoXT"}
{"genre": "south african country", "spotify_playlist_url": "https://open.spotify.com/playlist/1CKRS7bZY4KGSJ5qBc4T39"}
{"genre": "canadian indigenous hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6SW6yY3dGizTklZ4w3zqhN"}
{"genre": "indie folk italiano", "spotify_playlist_url": "https://open.spotify.com/playlist/70P9ZNqNAOSaKRHSOZ3tnW"}
{"genre": "bible", "spotify_playlist_url": "https://open.spotify.com/playlist/5Kg0nXuFU5d95KSFSN8k76"}
{"genre": "berlin minimal techno", "spotify_playlist_url": "https://open.spotify.com/playlist/77bvnztwYvanR3TJq6JSw8"}
{"genre": "minimal dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/13RHTjcb4k36bQu0SiYq3w"}
{"genre": "austro-german modernism", "spotify_playlist_url": "https://open.spotify.com/playlist/3ubtEnFuWe2aV4PcAuestW"}
{"genre": "deep metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3o0fl3nB08es8tf2Gqwda5"}
{"genre": "japanese experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0mAl3OKvTiSz5tiwlW8fUD"}
{"genre": "nz gangsta rap", "spotify_playlist_url": "https://open.spotify.com/playlist/5wQ32CYJDVlhtKS5oWxC1B"}
{"genre": "persian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/6sXOxwKABCj2seSKCNaQWj"}
{"genre": "irish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4DbSZoIbHauAhoZl2oAKmo"}
{"genre": "italian ska", "spotify_playlist_url": "https://open.spotify.com/playlist/06G0hSMWWxpR8nO0qzITLI"}
{"genre": "mbira", "spotify_playlist_url": "https://open.spotify.com/playlist/1LZ6UBJQTlYYhUUq7NA2tC"}
{"genre": "japanese girl punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1qpc4tP2OfO2KjPlKm9iO1"}
{"genre": "shamisen", "spotify_playlist_url": "https://open.spotify.com/playlist/535kYAMV6pRqLgCnOEqB08"}
{"genre": "focus trance", "spotify_playlist_url": "https://open.spotify.com/playlist/1N88gD04NZ5Q8RdDl27Cve"}
{"genre": "indie veneto", "spotify_playlist_url": "https://open.spotify.com/playlist/69qIq8nmr6NfFqS35bttxG"}
{"genre": "south african r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/3UhutiIcXo23ICdnsxBEFE"}
{"genre": "musica nortena chilena", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ft6Kv7kxPTTO74PQu4rIn"}
{"genre": "gypsy fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/2p6sVxmP69Qd9ysNCuMb7Y"}
{"genre": "kansas indie", "spotify_playlist_url": "https://open.spotify.com/playlist/546dyL0xeFMd4eDVT9bE7m"}
{"genre": "russian pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4uRGFgfCn1CLBqaeKgYbJb"}
{"genre": "purple sound", "spotify_playlist_url": "https://open.spotify.com/playlist/5ieddGiHAI6yCnafZgOT4m"}
{"genre": "dunedin sound", "spotify_playlist_url": "https://open.spotify.com/playlist/3Unp96l8Dn4AoRPskgXoqO"}
{"genre": "japanese edm", "spotify_playlist_url": "https://open.spotify.com/playlist/1uzXAb3u2OnBxawF9b2R1B"}
{"genre": "technical brutal death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Z9H0dv5ldWEmqk8lUTvqV"}
{"genre": "outer hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3fFELuQMAMXA3KvowSeQov"}
{"genre": "rap moldovenesc", "spotify_playlist_url": "https://open.spotify.com/playlist/6dpHLPzXjeKUFu3FEvOlgN"}
{"genre": "japanese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/4xcqsrLM9kK2oopGhZ9Fte"}
{"genre": "pinoy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/36twaQ7dgJjhqW3IEvfbTX"}
{"genre": "punjabi folk", "spotify_playlist_url": "https://open.spotify.com/playlist/68kxnt4QHyJ4cLONsi5VsX"}
{"genre": "edinburgh indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4iGZ5AAJS7EgbTQGEgok39"}
{"genre": "classic moroccan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2SoQc6bippmMyUTn1qditv"}
{"genre": "laulaja-lauluntekija", "spotify_playlist_url": "https://open.spotify.com/playlist/3HHF173MIu4NBRr3pbgXsB"}
{"genre": "uruguayan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6f7acaGPASiQ3TAEh6oLEU"}
{"genre": "kids dance party", "spotify_playlist_url": "https://open.spotify.com/playlist/5YR7tBihIt7vVZPrSGmQYt"}
{"genre": "erotic product", "spotify_playlist_url": "https://open.spotify.com/playlist/3k1UdQVzDtmhU085OTxjlh"}
{"genre": "surinamese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/27DZhqwvuoNKv6gZDVonz1"}
{"genre": "post-punk mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/73WXY1u7H7CKsA4njkdJDg"}
{"genre": "drill tuga", "spotify_playlist_url": "https://open.spotify.com/playlist/1L5MigE9vLvXw3IuRMqST9"}
{"genre": "belgian new wave", "spotify_playlist_url": "https://open.spotify.com/playlist/71INgJXyOMLjW7fexwLSvC"}
{"genre": "classic bulgarian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2NzorwaQxuxYumMTnfsFm1"}
{"genre": "joropo", "spotify_playlist_url": "https://open.spotify.com/playlist/0QoICgVqWMhcyZgmFTfWUZ"}
{"genre": "arkansas indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2KQne4laECtZ6uViV6BE6a"}
{"genre": "italian contemporary jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3gdJ34PX9drWzjgOjli4yu"}
{"genre": "west virginia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1XqFISoYLSOgqSOekdJbwX"}
{"genre": "jazz venezolano", "spotify_playlist_url": "https://open.spotify.com/playlist/136hER4CtHABIFZjI4FTm5"}
{"genre": "mizo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2gPfHsZq9cJiz0nJfB5YIf"}
{"genre": "southern china indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3yusk4RifBR0AXb6ZYwwyu"}
{"genre": "language", "spotify_playlist_url": "https://open.spotify.com/playlist/222ayS1WOFrZVmTeVOFhfd"}
{"genre": "destroy techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6nv9bEOb9PlCvhHthMKfwo"}
{"genre": "lezginka", "spotify_playlist_url": "https://open.spotify.com/playlist/6FkNnTm2YASOamCQuUqbWx"}
{"genre": "oberkrainer", "spotify_playlist_url": "https://open.spotify.com/playlist/6SXmwMKvXP69OpofTvWvdS"}
{"genre": "dancehall mauricien", "spotify_playlist_url": "https://open.spotify.com/playlist/6kZdqAAu0DeWGCtrU7Lu2V"}
{"genre": "stl indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4wGcW2wtIA1P22326Zx92z"}
{"genre": "dutch blues", "spotify_playlist_url": "https://open.spotify.com/playlist/50GKRGr7jwZY2ELJQ4F9NX"}
{"genre": "lund indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5yqIDJMkMc1KSGQFmkXxKx"}
{"genre": "pacific islands gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/0WQtakNFg4V8bkFG8S3taF"}
{"genre": "lagu sabahan", "spotify_playlist_url": "https://open.spotify.com/playlist/6suhLOSv1aTHZNzQ0JsCLk"}
{"genre": "indie pop rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6Q3NTkTC6sJDeLPYozbe1T"}
{"genre": "musica occitana", "spotify_playlist_url": "https://open.spotify.com/playlist/2x50uJHfR1OY7jK1lLFYgp"}
{"genre": "vlaamse rap", "spotify_playlist_url": "https://open.spotify.com/playlist/0UoWJA1BHOxBI6dsDDhwts"}
{"genre": "turkish reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/2hvyyGRqfKVFvowDHFLcVk"}
{"genre": "contemporary folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5lw0UguN3MakCpCgkxFGpM"}
{"genre": "spacesynth", "spotify_playlist_url": "https://open.spotify.com/playlist/2ACt3AX70sZp8hJbn88JTm"}
{"genre": "string folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2WOUj5obvjzJLxf3TASsnJ"}
{"genre": "powwow", "spotify_playlist_url": "https://open.spotify.com/playlist/5lbGsHhaPmrtQ05JdPPVR2"}
{"genre": "german melodeath", "spotify_playlist_url": "https://open.spotify.com/playlist/0PAO4fNA7RtDYLZjJw7XeP"}
{"genre": "minneapolis punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1yB0LY2uCnB5wAa1MQ6doR"}
{"genre": "wyoming indie", "spotify_playlist_url": "https://open.spotify.com/playlist/07wqzoWEwrVHJE7kopdDy2"}
{"genre": "deep neofolk", "spotify_playlist_url": "https://open.spotify.com/playlist/7gkQsGnpQRJewjCZuiZXDI"}
{"genre": "detroit indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3HF3TE8FU2U8IboXJd4PSi"}
{"genre": "country boogie", "spotify_playlist_url": "https://open.spotify.com/playlist/5au2CYTVy8KmBilpD2ofYl"}
{"genre": "east anglia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3fhwensaaYrPYio57Vpi0X"}
{"genre": "belgian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7feEEP4MNQEEuxh5oSDg1O"}
{"genre": "milwaukee hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3BQd5cKQFeLS3S3jdZI8eM"}
{"genre": "romanian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4Cw1wgE034owKiU6pyeHuw"}
{"genre": "canadian post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/58WrgIM3fXQiX0oOSQ9tFz"}
{"genre": "yoruba worship", "spotify_playlist_url": "https://open.spotify.com/playlist/4QTwi9BhTVG9Nbjo65HwZh"}
{"genre": "khmer hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0tE8TJtcqhSydcFA3xIrDh"}
{"genre": "dutch jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5Q2BgKWalZdUrg09hdnpCl"}
{"genre": "finnish progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1B8OWWOqc7hn1ajJpv4768"}
{"genre": "malagasy pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7GEdG8oe7aQZkDqTahfYUd"}
{"genre": "korean soundtrack", "spotify_playlist_url": "https://open.spotify.com/playlist/1kRWLtBz2L8PM8iTdvngqo"}
{"genre": "afro psych", "spotify_playlist_url": "https://open.spotify.com/playlist/3gImCITqUaAL5OYjfUbgug"}
{"genre": "vispop", "spotify_playlist_url": "https://open.spotify.com/playlist/0hkXwJmcwu7hABTyspKI9b"}
{"genre": "madrigal", "spotify_playlist_url": "https://open.spotify.com/playlist/5uQQu2RC80Ku5AjSpCtrJF"}
{"genre": "chill baile", "spotify_playlist_url": "https://open.spotify.com/playlist/0wu0GgZYI3a492oNpnpjBZ"}
{"genre": "drumfunk", "spotify_playlist_url": "https://open.spotify.com/playlist/5i3nz8m7XR6D7PUoIchxW8"}
{"genre": "spanish indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1JCf4NGHq2nC3CrtaGY9Go"}
{"genre": "experimental club", "spotify_playlist_url": "https://open.spotify.com/playlist/5T4YDWRog093Kqv01WcM9H"}
{"genre": "thrash core", "spotify_playlist_url": "https://open.spotify.com/playlist/77dtfNhJiUgk8aTEWQ7hsF"}
{"genre": "hardcore punk espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/3uDcb9aPKm610tkqbIw6fG"}
{"genre": "indie rock colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/30sjYS9DMjQNyYwfvu5uUU"}
{"genre": "norrbotten indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3YgOOU8IFF19aYPaEnHlrf"}
{"genre": "zydeco", "spotify_playlist_url": "https://open.spotify.com/playlist/1BsskTfK2Sfg5mJI1o4MGr"}
{"genre": "sierra leonean pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6SmJgfhwIM6OHefphfAvFM"}
{"genre": "christlicher rap", "spotify_playlist_url": "https://open.spotify.com/playlist/1X8tXB79P2aFcWVGkdiAYq"}
{"genre": "southeast asian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/60VqjFK8tIzmpc5Q1NTosK"}
{"genre": "bisrock", "spotify_playlist_url": "https://open.spotify.com/playlist/3EfPujnG5slz7UuLaGVHOh"}
{"genre": "german street punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5vmnpqCN7MSdpNMZMKij31"}
{"genre": "kyrgyz pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4Qge0wd8eVwYVDZN2XxsTn"}
{"genre": "russian shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/1jbdPIYUIGp7V47JBzI3V5"}
{"genre": "cantaditas", "spotify_playlist_url": "https://open.spotify.com/playlist/5VGQF5ilaoNOEl3HEI1TgT"}
{"genre": "japanese idm", "spotify_playlist_url": "https://open.spotify.com/playlist/3aLQdfUYOVRFlHhwJECabA"}
{"genre": "brazilian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/3j1YYS7Palpfb92qd9x7vl"}
{"genre": "little rock indie", "spotify_playlist_url": "https://open.spotify.com/playlist/79jec9Wnk9LUMfos4Jqo50"}
{"genre": "traditional scottish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3809gpnQFkEqra5RKFRhvu"}
{"genre": "salay", "spotify_playlist_url": "https://open.spotify.com/playlist/0TFl3Tevi22JWs1KWTXcAo"}
{"genre": "malawian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1UqPlv6ScS9FrO7D4o5rMq"}
{"genre": "belgian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1n4Q1wbXMA0f5bysyhPrUl"}
{"genre": "cologne electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/5KcfGqyKiDx3uLCpZsELKc"}
{"genre": "american choir", "spotify_playlist_url": "https://open.spotify.com/playlist/1qr0GHLhe4Um7KPc4xnBnv"}
{"genre": "venda rap", "spotify_playlist_url": "https://open.spotify.com/playlist/53iyHoUo4uZtoXfJGOjnqx"}
{"genre": "gamelan", "spotify_playlist_url": "https://open.spotify.com/playlist/6bpLPte0OZRWs4mZzu6C7f"}
{"genre": "swedish psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4kKTvW0AL08Gdvb3wbpfCY"}
{"genre": "tango cancion", "spotify_playlist_url": "https://open.spotify.com/playlist/1SePFx01lSsAZTvUM83kEE"}
{"genre": "british math rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4A25PQ7cmCfzglHhmU6dGW"}
{"genre": "musica mocambicana", "spotify_playlist_url": "https://open.spotify.com/playlist/6MUBwmuJ5e1kI1mAmHPHlT"}
{"genre": "purulia pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0202hdl7Vx4b7PcvqsJ6W4"}
{"genre": "progressive breaks", "spotify_playlist_url": "https://open.spotify.com/playlist/7HLEjm2fEZsErggSthuFmZ"}
{"genre": "argentine hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7Kg7DFSptkBEuol6EKr8f2"}
{"genre": "guitarra argentina", "spotify_playlist_url": "https://open.spotify.com/playlist/7AM6up7skBINcBMsC4hcdA"}
{"genre": "irish dance", "spotify_playlist_url": "https://open.spotify.com/playlist/2vx6eFsG12cuB7SfTHJWdz"}
{"genre": "punk colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/4TayytzbGoBJCmBTxRBIEx"}
{"genre": "new wave of osdm", "spotify_playlist_url": "https://open.spotify.com/playlist/0OrVo6kqzD8mEvgbIKMhlp"}
{"genre": "african electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6UjUqa407F8vrTz5gKg4Jd"}
{"genre": "north dakota indie", "spotify_playlist_url": "https://open.spotify.com/playlist/05dDF5E8vI9iPsPp2wBELq"}
{"genre": "minneapolis metal", "spotify_playlist_url": "https://open.spotify.com/playlist/073dfuUmS2YAw6hnlVS9ct"}
{"genre": "danish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/750qjatdMZy9qcRCIMJ0Bs"}
{"genre": "dark psytrance", "spotify_playlist_url": "https://open.spotify.com/playlist/4p7LvTTcCt83rvC5tXPVnR"}
{"genre": "baltic post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/11z91vLvIlX0IDmGeASMLz"}
{"genre": "panamanian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0qV4lbRat7UEfIvTotrdEs"}
{"genre": "deep ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/1GVL5ggzZBM5QAgosF60NB"}
{"genre": "denver metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5aBLOilVXfy3Xf5VrMowol"}
{"genre": "hengelliset laulut", "spotify_playlist_url": "https://open.spotify.com/playlist/6Aj2JlruKOsx7VrFYI90kF"}
{"genre": "trallpunk", "spotify_playlist_url": "https://open.spotify.com/playlist/29MNrHCLEseM6Wr0bpZ5lL"}
{"genre": "early music choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4FlcRYTkhAqOWkQi9C4dss"}
{"genre": "samba gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/06PUJCdk1px2oPNZC3mZDH"}
{"genre": "brazilian indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0NLw6Vs4WhPF1UF2ade0QR"}
{"genre": "dutch black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5PU0pmBgjF2zn1VKxJmiAL"}
{"genre": "chattanooga indie", "spotify_playlist_url": "https://open.spotify.com/playlist/36Yfu6Yj0paZUbDwC33oyn"}
{"genre": "navajo", "spotify_playlist_url": "https://open.spotify.com/playlist/5OZ4hR8hoRBNchtdKO8lyF"}
{"genre": "santali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1dNKmTbcIlIZVcLBPtznoZ"}
{"genre": "musique tahitienne", "spotify_playlist_url": "https://open.spotify.com/playlist/0b4lkZqMBUrVjMQTlLTSMK"}
{"genre": "german blues", "spotify_playlist_url": "https://open.spotify.com/playlist/5vHWuInWEuHAkjeWJAu3qz"}
{"genre": "mexican son", "spotify_playlist_url": "https://open.spotify.com/playlist/357u2T6QbgZU31lJ3RL5S9"}
{"genre": "nordic shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/4Yz8bWsqzuxjMW23terd5o"}
{"genre": "afrobeat fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/1qr8PNR6yELU28B1GS7t9y"}
{"genre": "indonesian trap", "spotify_playlist_url": "https://open.spotify.com/playlist/5MsLZjdd6tE7ehngN4IspS"}
{"genre": "yoga", "spotify_playlist_url": "https://open.spotify.com/playlist/5cZJI7DrZ3NIWWcbPIZeWt"}
{"genre": "uk noise rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3mIhbXZ9SxkUok4IxLBxZk"}
{"genre": "barbershop", "spotify_playlist_url": "https://open.spotify.com/playlist/2wyhLEyF9Oju6B2MeAdIrY"}
{"genre": "finnish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0VIFRdDKyTqPghiYUu191o"}
{"genre": "rap guarulhense", "spotify_playlist_url": "https://open.spotify.com/playlist/5wct9Or59d734Jg9HCJCnO"}
{"genre": "tunisian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/14QRHICDZzoWHzhU1aGbt7"}
{"genre": "psychedelic jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/1ldfnmvsvrKsgUpveEpkXz"}
{"genre": "sefardi", "spotify_playlist_url": "https://open.spotify.com/playlist/56tBvLdVfENitF87723bqz"}
{"genre": "irish drill", "spotify_playlist_url": "https://open.spotify.com/playlist/6CDATmLv64et9BPZMpUspM"}
{"genre": "italian mandolin", "spotify_playlist_url": "https://open.spotify.com/playlist/3VqKxrwJDUidueO1338pKR"}
{"genre": "classical harp", "spotify_playlist_url": "https://open.spotify.com/playlist/7kfw9INA5VHwDZ2C9YbA4Y"}
{"genre": "galego", "spotify_playlist_url": "https://open.spotify.com/playlist/035cW9UWTFa3Hzo6Ssao4x"}
{"genre": "pei indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3m2ghU6Q23fLCujGXeUO2r"}
{"genre": "myanmar indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0Hkzj6Zffp08IfPO32ztb1"}
{"genre": "canadian psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/47LhiUm1avz2fugpFxjw5Y"}
{"genre": "australian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/7ozIF2Sgxba6PB8VHTjsUC"}
{"genre": "traditional rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/38HIhRQM2qSIRTjUW00xwp"}
{"genre": "german electronica", "spotify_playlist_url": "https://open.spotify.com/playlist/3QZvuSCrACnSqpsEFaigEw"}
{"genre": "ney", "spotify_playlist_url": "https://open.spotify.com/playlist/1lJpIVTf08jy5MGQnLjhE2"}
{"genre": "house argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/3oWlrpGzB8SAslBk22W9lP"}
{"genre": "lithuanian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/35TkC5o2mnTjREHgS8coYY"}
{"genre": "deep southern trap", "spotify_playlist_url": "https://open.spotify.com/playlist/62XZJR8YQy4KpiarL64aHd"}
{"genre": "vlaamse cabaret", "spotify_playlist_url": "https://open.spotify.com/playlist/5NcfYoFq5Vdz2ESRcEfm0K"}
{"genre": "ottawa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7BFR05F5w1mWHYrnknDd4m"}
{"genre": "russian nu metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2Zbmyw9ZX9aEvLMoMwBjEM"}
{"genre": "khandeshi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2S47JUhSZ5m55SouSNYNI3"}
{"genre": "musique acadienne", "spotify_playlist_url": "https://open.spotify.com/playlist/3sj7RfY30P0ZOuzu69iAgt"}
{"genre": "ragtime", "spotify_playlist_url": "https://open.spotify.com/playlist/7BKZEIdyav6sz9B628eXSx"}
{"genre": "cabaret", "spotify_playlist_url": "https://open.spotify.com/playlist/60s3HASYRpcpczi7f6a6SC"}
{"genre": "vintage chinese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2cqL0s5H6viqXVDnfhp1nY"}
{"genre": "nohay", "spotify_playlist_url": "https://open.spotify.com/playlist/0VNb1aKSyKWBrf9hHM2ZJD"}
{"genre": "rock tico", "spotify_playlist_url": "https://open.spotify.com/playlist/6hlHOKDB7Jxpz2cg7Jevuq"}
{"genre": "banda peruana", "spotify_playlist_url": "https://open.spotify.com/playlist/0JCZPSxbQAfnWuO8GTaqaS"}
{"genre": "marimba mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/3iL6DO0YxEvjK2q0JYzzvH"}
{"genre": "american orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/27FDMsW1QJGy7TBLjvWqio"}
{"genre": "abstract idm", "spotify_playlist_url": "https://open.spotify.com/playlist/0iCuzAER8gjEjq9sdVkdx1"}
{"genre": "brazilian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/3IOfbuF67ilbd54avE0h4P"}
{"genre": "russian pixel", "spotify_playlist_url": "https://open.spotify.com/playlist/6A2fr8PrgywYmOgLT6Anzo"}
{"genre": "ny roots", "spotify_playlist_url": "https://open.spotify.com/playlist/2B97nCsJ1YtOYIbioQp81E"}
{"genre": "sasscore", "spotify_playlist_url": "https://open.spotify.com/playlist/3RYQeTHhHcEiT9wW3bDtrP"}
{"genre": "voidgrind", "spotify_playlist_url": "https://open.spotify.com/playlist/1gSozatCNUiBFpUTK0DqGz"}
{"genre": "assyrian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2cmFJoRcSPkSkD1yllBGwZ"}
{"genre": "malaysian tamil rap", "spotify_playlist_url": "https://open.spotify.com/playlist/7Hd3OcsaIeHyy1LGx5GqSZ"}
{"genre": "jazz violin", "spotify_playlist_url": "https://open.spotify.com/playlist/6qUVKIR00CpN0YBSKCeYFS"}
{"genre": "estonian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3rGaSnZjjAQsIqjOApHTQf"}
{"genre": "greenlandic pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5m9ErLc15dYYCGzvrcVy8q"}
{"genre": "japanese psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2P6Yw1Gs1lwVqGasW1y2xw"}
{"genre": "erhu", "spotify_playlist_url": "https://open.spotify.com/playlist/7uVfHvphUCmZCSgbGiOCgw"}
{"genre": "celtic harp", "spotify_playlist_url": "https://open.spotify.com/playlist/7iR72glWFGP5yjf38m6RZe"}
{"genre": "ruta destroy", "spotify_playlist_url": "https://open.spotify.com/playlist/4NABCyxEx5gqFjscEMWwAo"}
{"genre": "taiwan post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4oPolfh8FnsAavGG0gvIW1"}
{"genre": "belgian modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/3MZ3gpxfiXeyi8k5iEce0w"}
{"genre": "montana indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4JW72vPkXNyO4XW2pupOlY"}
{"genre": "euroska", "spotify_playlist_url": "https://open.spotify.com/playlist/3UE8m7Mm6mO3UKQnLBQ6li"}
{"genre": "neo-psicodelia brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/3l8LWCr0z7TSPwrFhJCqbJ"}
{"genre": "western saharan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/60AI6c3kybZCkWZl2ju3DF"}
{"genre": "pahadi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1EXLE0tUjX1kNxRdIS2V9I"}
{"genre": "musica calabrese", "spotify_playlist_url": "https://open.spotify.com/playlist/1rGoVVHRgZB6OTYA3zUbvO"}
{"genre": "deep melodic hard rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1Qt0QYaLL9W2yie17ACazC"}
{"genre": "luxembourgian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/32N5xfn5QZ7Vxc1Zm7nYlB"}
{"genre": "south african electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/7zTToZXXsogKivmPyIoYvg"}
{"genre": "finnish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6WxllqF4D8Gj8Veg1WBY0r"}
{"genre": "synthwave brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/5TQJIpSXVI5WEF3LeGhnko"}
{"genre": "turkish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2I9YaBNikRc9qAxiYnTDqn"}
{"genre": "vaudeville", "spotify_playlist_url": "https://open.spotify.com/playlist/0UYBXYXU6iAs0RJqnteZW7"}
{"genre": "portuguese metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5DcksqG6G4xJ9nu1t15wEQ"}
{"genre": "boogie", "spotify_playlist_url": "https://open.spotify.com/playlist/4vLb33ufLI6jjyGh4jpz9P"}
{"genre": "trap cristiano", "spotify_playlist_url": "https://open.spotify.com/playlist/7FRgynqDEOZK0i32hTQRWX"}
{"genre": "guidance", "spotify_playlist_url": "https://open.spotify.com/playlist/78WdKuEUr6gpUMpQpDeaYe"}
{"genre": "barnalog", "spotify_playlist_url": "https://open.spotify.com/playlist/7bKo0dC4z3WFAPzi60aBOZ"}
{"genre": "australian comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/1pPP4qxa52IibyFV6oTfJ1"}
{"genre": "slovak folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1P75I5LHfZM204ndEsgDjt"}
{"genre": "dutch musical", "spotify_playlist_url": "https://open.spotify.com/playlist/5sfogZ1svsx1EDDv7NKVlT"}
{"genre": "piano house", "spotify_playlist_url": "https://open.spotify.com/playlist/4JTbjpQmuLtfLzIkAH52Jt"}
{"genre": "deep german punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6u1BOHbo8LkTrBdzfiFEj9"}
{"genre": "psychedelic blues-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3s9zay08uorAo3wkp17zkm"}
{"genre": "gospel amapiano", "spotify_playlist_url": "https://open.spotify.com/playlist/3ylVXN6w3CEsnryOPYziCZ"}
{"genre": "new wave of speed metal", "spotify_playlist_url": "https://open.spotify.com/playlist/38pIgQXtIgI52lzt0J0Fnk"}
{"genre": "deep east coast hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0p1TGME5wvY7wMvWImiDfc"}
{"genre": "manitoba country", "spotify_playlist_url": "https://open.spotify.com/playlist/43W23zGmvcC07hP0OoWvdb"}
{"genre": "hip hop reunionnais", "spotify_playlist_url": "https://open.spotify.com/playlist/1w4WYFqdD5LUUXQgrFW5gF"}
{"genre": "friese muziek", "spotify_playlist_url": "https://open.spotify.com/playlist/20HRTITUogLdPSLtNjLiY6"}
{"genre": "caracas indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1gVrsEPrtazGUMxFv7xh1N"}
{"genre": "essex indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1E9VMI8GPercLcilqXLfLu"}
{"genre": "tzadik", "spotify_playlist_url": "https://open.spotify.com/playlist/5QlWCX597HERw4WITxAjcs"}
{"genre": "galician folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3qQsWDM8bFCBictfEk3mva"}
{"genre": "klezmer", "spotify_playlist_url": "https://open.spotify.com/playlist/2Rdu6yaflPFX3lfMewsxKA"}
{"genre": "musica mapuche", "spotify_playlist_url": "https://open.spotify.com/playlist/3WDYzCuTyq43OzWVOClBXk"}
{"genre": "jazz guitar trio", "spotify_playlist_url": "https://open.spotify.com/playlist/5vS964lftHRyZAbjVeH26b"}
{"genre": "german death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6eVnrJvLKljuBZXgfzke32"}
{"genre": "traditional reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/5BsjWwpsDp6nIjGWDlep8A"}
{"genre": "string band", "spotify_playlist_url": "https://open.spotify.com/playlist/1DV8BCntskEpuTae25lsNl"}
{"genre": "ambient dub techno", "spotify_playlist_url": "https://open.spotify.com/playlist/2uayyYqxhDjpRTbqPK19wQ"}
{"genre": "wisconsin indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2dX737aZqeaXYSk2UQcj2T"}
{"genre": "swedish post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7ouqnbBBJVTn2ekY2Us9rA"}
{"genre": "thai instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/1Ve019KZUUU4j6FmNt9B8a"}
{"genre": "adelaide indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7xrsyHt3RVeYJRSX5M4gzZ"}
{"genre": "new weird finland", "spotify_playlist_url": "https://open.spotify.com/playlist/079TX5SHluTLtqzwER0RLh"}
{"genre": "son cubano clasico", "spotify_playlist_url": "https://open.spotify.com/playlist/3yQOUOSyGIUsaoRMf3iSYA"}
{"genre": "georgian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/59lS3lYSVcgz02TmM2xkJc"}
{"genre": "dark electro", "spotify_playlist_url": "https://open.spotify.com/playlist/6E9jkAu1N93vNa0DZqVNmL"}
{"genre": "musica goiana", "spotify_playlist_url": "https://open.spotify.com/playlist/0JJUuA4qSz5vhiKSWzkIW8"}
{"genre": "humppa", "spotify_playlist_url": "https://open.spotify.com/playlist/1CSHnQ8COditvKcoC3Woyx"}
{"genre": "calgary indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3WZXxt7kTxNE2oyASosEm4"}
{"genre": "albany ny indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1WIMab1VyKqHklYNNBHcKt"}
{"genre": "uilleann pipes", "spotify_playlist_url": "https://open.spotify.com/playlist/71iQR4AeEIQgaiVsBJBghh"}
{"genre": "post-punk latinoamericano", "spotify_playlist_url": "https://open.spotify.com/playlist/4upEmOBYcHnD0utzBsThAD"}
{"genre": "technical grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7AgkLDw5vKf1VED9Fw3DgX"}
{"genre": "musica indigena mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/3xLa6kUGYYgAvV5a8nB96H"}
{"genre": "polish hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5eWxTPyskEqSRgBMVgNFLa"}
{"genre": "fo jing", "spotify_playlist_url": "https://open.spotify.com/playlist/4Svlg7olD7nlAaE9j93K5m"}
{"genre": "musica mallorquina", "spotify_playlist_url": "https://open.spotify.com/playlist/0MIsNJdNUrokjdGGOvlBrd"}
{"genre": "lo star", "spotify_playlist_url": "https://open.spotify.com/playlist/11VtEIEQN30XWjYbmLXrT6"}
{"genre": "judaica", "spotify_playlist_url": "https://open.spotify.com/playlist/57Y2FWpsh8Rw8nrPFatqCY"}
{"genre": "chinese instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/4gexXSDuDHS3FgLpRseBDL"}
{"genre": "nz metal", "spotify_playlist_url": "https://open.spotify.com/playlist/05pbh0KetX5jvbbMBbmfQg"}
{"genre": "chicago mexican", "spotify_playlist_url": "https://open.spotify.com/playlist/6ckha2t3BQgM1vFTtBGZ4N"}
{"genre": "euskal reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/19V77ntG0X9Py7dXHL6Bzt"}
{"genre": "deep funk house", "spotify_playlist_url": "https://open.spotify.com/playlist/5RTEY09kQp3iPys9IcVZwL"}
{"genre": "indonesian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5IlnOFlCzdzJwn6UZX5ZqD"}
{"genre": "circus", "spotify_playlist_url": "https://open.spotify.com/playlist/0b1oW8iHQORobRdjHeYeRC"}
{"genre": "austrian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/37On3yaaDFnjKAx93eXHrd"}
{"genre": "speedcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0PScKDOlpRri7jiwVxB1qQ"}
{"genre": "portuguese techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0CTd4Z6oTkyeVD394QZ5cw"}
{"genre": "joseon pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6WrINwVridztoRz2Vq7iIo"}
{"genre": "georgian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/4OPpxiOt8TWZl02rSdRygL"}
{"genre": "indonesian emo rap", "spotify_playlist_url": "https://open.spotify.com/playlist/63VNJboa7qyn6gMcDMuU77"}
{"genre": "finnish progressive rock", "spotify_playlist_url": "https://open.spotify.com/playlist/26rQLpFzrmqS9ZvfBsLUZm"}
{"genre": "cleveland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0KYs41G2Vgje90CUmbxqbs"}
{"genre": "deep flow", "spotify_playlist_url": "https://open.spotify.com/playlist/6hQguJ4qzRrrkII3Kj0106"}
{"genre": "talentos brasileiros", "spotify_playlist_url": "https://open.spotify.com/playlist/2BeLGTqy54PhX1YT1jTts9"}
{"genre": "cybergrind", "spotify_playlist_url": "https://open.spotify.com/playlist/7LQOkJtfzEjj7aUQqz41w2"}
{"genre": "grunge pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7uGtuTM65i6r8zxYuD7Kwp"}
{"genre": "norwegian contemporary jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5WRoxnhGdORynDlAbDMxFg"}
{"genre": "psybreaks", "spotify_playlist_url": "https://open.spotify.com/playlist/5S5M72txHB2OjrBop5AYC4"}
{"genre": "african percussion", "spotify_playlist_url": "https://open.spotify.com/playlist/23e4SXJoxyNtQ3s2mSb5dx"}
{"genre": "folklore veracruzano", "spotify_playlist_url": "https://open.spotify.com/playlist/2GJg3GhMmDjsldc2PZkEyw"}
{"genre": "gothic post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4o0EmpttDzyFOpMpDvDDXR"}
{"genre": "szanty", "spotify_playlist_url": "https://open.spotify.com/playlist/6HwS9JJsya66GMP23r4VP7"}
{"genre": "polish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2EIFvjN0Z1AYk4rtCBo0JK"}
{"genre": "sinogaze", "spotify_playlist_url": "https://open.spotify.com/playlist/1mKUj2azsDUhgk7bONBZ3y"}
{"genre": "ukrainian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/61Aq31tAfvFqfFY0IYffZv"}
{"genre": "forro manauara", "spotify_playlist_url": "https://open.spotify.com/playlist/1KEkhbwh9el79SK5AsyjLP"}
{"genre": "blues-rock guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/2VkWOPUqwKkeBWMqcFx0L6"}
{"genre": "byzantine", "spotify_playlist_url": "https://open.spotify.com/playlist/6LeXGKgnoXSoP3J2rdgO5H"}
{"genre": "metal colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/7JOa2IKHuNQdLS7qJHZn17"}
{"genre": "rap tuga underground", "spotify_playlist_url": "https://open.spotify.com/playlist/4gfHmDnWsC0r6wwvv9ilni"}
{"genre": "finnish reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/1htrcOgeBDoRSY5QvBW1YW"}
{"genre": "underground boom bap", "spotify_playlist_url": "https://open.spotify.com/playlist/4VEipwQG8RLftlMICd1tYJ"}
{"genre": "tijuana indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4FDyoGuEDFctON8TbzhvsC"}
{"genre": "macedonian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5Cd841xSo27lwJ6Qa555Lo"}
{"genre": "old school highlife", "spotify_playlist_url": "https://open.spotify.com/playlist/5rtMeX8LhfQCuhRTvWR13P"}
{"genre": "atmospheric doom", "spotify_playlist_url": "https://open.spotify.com/playlist/6mDBTlpxmqfCQXQalGJOxe"}
{"genre": "georgian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6pckSTzsS5DMpLFE0G4xRh"}
{"genre": "taiwan electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6SJYnl1cN2w1vGOQFZIBYq"}
{"genre": "classic danish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4n4AQMO9DUYVE1ARtMe1Id"}
{"genre": "rap congolais", "spotify_playlist_url": "https://open.spotify.com/playlist/1syRvSx9StOtgyKalJUSXx"}
{"genre": "hip hop galsen", "spotify_playlist_url": "https://open.spotify.com/playlist/6VXHtKNSbRIGUwzUlijp1t"}
{"genre": "epic doom", "spotify_playlist_url": "https://open.spotify.com/playlist/2THvXynGgYNp2AfoUmqcZ4"}
{"genre": "french folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4DhvRzyECHRaUL64HLGVvK"}
{"genre": "experimental techno", "spotify_playlist_url": "https://open.spotify.com/playlist/7mMkzbc7EHjOtaLiW0O3ya"}
{"genre": "talentkonkurrence", "spotify_playlist_url": "https://open.spotify.com/playlist/6k6r5MC3SdPxmpEGv91qVF"}
{"genre": "mexican tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/6YVlYohc2LjtPtIF6b70Xb"}
{"genre": "folklore cuyano", "spotify_playlist_url": "https://open.spotify.com/playlist/4QfKDPRKBpVOpVJYQXtMuD"}
{"genre": "russian heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6RbitIahJYtBPf5nRGSgFY"}
{"genre": "palestinian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/4TfWrzrgfgNxjeOim18ZSy"}
{"genre": "isle of wight indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2n2wYLNi6ZeYvyII2JpLKT"}
{"genre": "latvian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3y7GFNHSVQoII6mOYTvJaO"}
{"genre": "lagu karo", "spotify_playlist_url": "https://open.spotify.com/playlist/3UENNqTZntCPXIL3tlm5Ok"}
{"genre": "electronicore", "spotify_playlist_url": "https://open.spotify.com/playlist/3Ma38ruHiz5DzF1Pb4sY1Y"}
{"genre": "washboard", "spotify_playlist_url": "https://open.spotify.com/playlist/6DfuxmEBhz2MdUmfSG5xu3"}
{"genre": "australian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/2nFuScPV8hjI2hVOpJsHvN"}
{"genre": "crossover prog", "spotify_playlist_url": "https://open.spotify.com/playlist/4dbAsOHzPJISKcPaiwvXwR"}
{"genre": "ukrainian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0pMKDfaAuedXTWShF7Uk7F"}
{"genre": "therapy", "spotify_playlist_url": "https://open.spotify.com/playlist/6k7Tv57wY0l9lrPGhYfrw7"}
{"genre": "finnish soul", "spotify_playlist_url": "https://open.spotify.com/playlist/70P0tTdAfXkHX7gqIl8qdA"}
{"genre": "atlantic canada hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4ejtAuKEfG1fLSDPjWm0WG"}
{"genre": "neo-crust", "spotify_playlist_url": "https://open.spotify.com/playlist/7jJ2VqsOJsd2hmsHLSOedD"}
{"genre": "cork indie", "spotify_playlist_url": "https://open.spotify.com/playlist/38FIwOi1TIzIysdMGrGQ3t"}
{"genre": "marching band", "spotify_playlist_url": "https://open.spotify.com/playlist/5b7iuK1KtA1Ml7JrYpOUGr"}
{"genre": "experimental indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7bqLyNAboQ3L7RxCXP2X3S"}
{"genre": "canadian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1GqhHpCewFOcxp53xEHmJI"}
{"genre": "blackened crust", "spotify_playlist_url": "https://open.spotify.com/playlist/3v8IgyYwcCBPSbyxoHKnx2"}
{"genre": "street band", "spotify_playlist_url": "https://open.spotify.com/playlist/5pdfrA4R7XwGfVCTgOu6f3"}
{"genre": "electronica venezuela", "spotify_playlist_url": "https://open.spotify.com/playlist/5OCtB3WnqAJr00FCAcBM84"}
{"genre": "darbuka", "spotify_playlist_url": "https://open.spotify.com/playlist/2OFa2z1OevsPmCJMKz3dCs"}
{"genre": "italian post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5sJm6lyAmTT8HiUQ6Q5mJT"}
{"genre": "kashmiri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2B2QQYHbX4eTnmz2qjaPfT"}
{"genre": "rap ecuatoriano", "spotify_playlist_url": "https://open.spotify.com/playlist/5d8hp3Esh1XFESlcndQbVy"}
{"genre": "norwegian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6fWI3chpTbEN1kC7FCy0yk"}
{"genre": "noise punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4yoqzwRy09GCMseMU2ud0g"}
{"genre": "cameroonian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6xugQyPfve7lSCKxJkfELo"}
{"genre": "barockinterpreten", "spotify_playlist_url": "https://open.spotify.com/playlist/3S85Y5ObnzTB7tp2V2ypqA"}
{"genre": "bmore", "spotify_playlist_url": "https://open.spotify.com/playlist/0BucwX8Ux9HWxDYgbI445d"}
{"genre": "west-vlaamse hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7zMCAnsRpDwtuKP0GjmLDr"}
{"genre": "euskal metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1iLekEU5MMII393Pnk1yEt"}
{"genre": "tanzlmusi", "spotify_playlist_url": "https://open.spotify.com/playlist/18A3UbVyw5LS83fK0U5kqk"}
{"genre": "mallet", "spotify_playlist_url": "https://open.spotify.com/playlist/2mopMxdpnuOqtkWEWvBJfT"}
{"genre": "maluku pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0F2fCebkcSBbgUKB7zEqpK"}
{"genre": "neo-trad metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4lPm47P0NUPUdaKpaSOSTX"}
{"genre": "bolivian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0MCtzZcGOBSiXSpLxipORS"}
{"genre": "junior songfestival", "spotify_playlist_url": "https://open.spotify.com/playlist/1dSOtAiMosLW5kyLkKlObJ"}
{"genre": "progressive thrash", "spotify_playlist_url": "https://open.spotify.com/playlist/0YHogJbqA5TrygAp2KAXjn"}
{"genre": "bisaya indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4U8rCEbvM6wuegEVUZ87M7"}
{"genre": "pasodobles", "spotify_playlist_url": "https://open.spotify.com/playlist/2zuQnlTbp8h0ZW6VPk0SOs"}
{"genre": "hard minimal techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0rwgjCaNEDtCetLhy8UUG5"}
{"genre": "gnawa", "spotify_playlist_url": "https://open.spotify.com/playlist/6mamWhhdPEd5y5IfHmCXUC"}
{"genre": "jazz orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/5eKFlGWniCD4d70sY7tXGa"}
{"genre": "umea hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4XgY9WBQzM4pr0UDmTJ69q"}
{"genre": "finlandssvenska musik", "spotify_playlist_url": "https://open.spotify.com/playlist/1tMMOjnFvzARz0bvIZ3p2w"}
{"genre": "emocore", "spotify_playlist_url": "https://open.spotify.com/playlist/0Z63t6kvtlrh1hAakGtVaO"}
{"genre": "ilocano pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5mG2LqSHK4uvemoRMXpaQu"}
{"genre": "belarusian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1aFsZw4oKkoLIikHiyOSbg"}
{"genre": "norwegian gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/6hWs4VVmmsbWnFCqlDkr4d"}
{"genre": "lagu tarling", "spotify_playlist_url": "https://open.spotify.com/playlist/6G0LJl6u6SVoDoGIaPoQrj"}
{"genre": "korean shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/4v5KD4M6FjBqWn5Re3hjTl"}
{"genre": "rock progressif francais", "spotify_playlist_url": "https://open.spotify.com/playlist/7HnHpNGscFRHf5A9eYEJTE"}
{"genre": "bisaya worship", "spotify_playlist_url": "https://open.spotify.com/playlist/5dtZGNx5IeTjAl5IYXRPje"}
{"genre": "rap catarinense", "spotify_playlist_url": "https://open.spotify.com/playlist/3QdHMGxBUKu2uGZFDLEdwn"}
{"genre": "electronica peruana", "spotify_playlist_url": "https://open.spotify.com/playlist/57FYqlZy1HQtyNT739WL67"}
{"genre": "ukrainian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/3U4NUWEMSqoTI0TBcD0QHU"}
{"genre": "nordic classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/0SETcL76TBGpA8SNODzRTI"}
{"genre": "florida hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0TnfKtQvtS8fcWUgXXBj8w"}
{"genre": "traditional ska", "spotify_playlist_url": "https://open.spotify.com/playlist/0anECACKGfUiaTd2ILI4NO"}
{"genre": "thai metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4zkz0xTiMoXFzbpTz112Rr"}
{"genre": "franco-flemish school", "spotify_playlist_url": "https://open.spotify.com/playlist/2xtljicTTSctDvj5UUlWCJ"}
{"genre": "dutch experimental electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6iYnCaLRzrWmM2UyrkXEIA"}
{"genre": "finnish doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4PjGW8CyIEts0ZsMkVWou9"}
{"genre": "traditional english folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2Ss6FIh8uCehUwRQrm7CKg"}
{"genre": "canadian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/69aXiyCYRhFqDvHCwuxXEV"}
{"genre": "musica pernambucana", "spotify_playlist_url": "https://open.spotify.com/playlist/7uu3HVwevNc15mSUJiwblO"}
{"genre": "kalmar indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1FICcWbkaEb3ofxlFws1oO"}
{"genre": "norwegian prog", "spotify_playlist_url": "https://open.spotify.com/playlist/3vvcydnbjOAGsRtkfLCVON"}
{"genre": "ukrainian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/65oQYtlHy7Z886NlG6zdwM"}
{"genre": "zim gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/1EfJDym7urLaa1hpi6TFwr"}
{"genre": "narodnozabavna", "spotify_playlist_url": "https://open.spotify.com/playlist/67IwqJrkdRkQSjyFXdFTpd"}
{"genre": "croatian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4iIMSWO9QrrcUE8SQEdBcA"}
{"genre": "bachchon ke geet", "spotify_playlist_url": "https://open.spotify.com/playlist/4oOHs2OLSeyda5vL75yylW"}
{"genre": "russian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/7tgHKaqrxEJdesPpK8pVY2"}
{"genre": "new england metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7JhbNOJCU67Zo0IHs9plfD"}
{"genre": "komedi", "spotify_playlist_url": "https://open.spotify.com/playlist/2oTOp4JbYmmQke4KRt7fxj"}
{"genre": "czsk hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/7w7v2NkPKP2EYL17Czpc3D"}
{"genre": "rock gotico", "spotify_playlist_url": "https://open.spotify.com/playlist/67RTyiGWF3L5AoVZTlRqOk"}
{"genre": "deep folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1yPm6jjucp6JfQfglsZKfj"}
{"genre": "canberra indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6NtolKQzqsuJxnDi5NgBkH"}
{"genre": "blues mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/7C8OEv2qzaLl7hhU5EIrCJ"}
{"genre": "hip hop boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/7vROhIhlDwmMJPbu0iy6Gc"}
{"genre": "balfolk", "spotify_playlist_url": "https://open.spotify.com/playlist/5QRpaFbeggej6goP5CPeMX"}
{"genre": "jewish a capella", "spotify_playlist_url": "https://open.spotify.com/playlist/1Xi5KEHqUQjAtHF1BOqfX8"}
{"genre": "japanese house", "spotify_playlist_url": "https://open.spotify.com/playlist/2Na5b8ZZxpBRZqZXFZGhl2"}
{"genre": "sesotho pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6JJz3RoxI7VUDx2IHgOGNr"}
{"genre": "musica mexiquense", "spotify_playlist_url": "https://open.spotify.com/playlist/16FbPVim8wS4OYDV05upzG"}
{"genre": "musica valenciana", "spotify_playlist_url": "https://open.spotify.com/playlist/409FnGPho9uuF3kuESudPh"}
{"genre": "modern jangle pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7EOgfsmPHIL1axw7Y9ojZK"}
{"genre": "dark ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/1mhHpC0idew8lgWQkEJnOL"}
{"genre": "faroese indie", "spotify_playlist_url": "https://open.spotify.com/playlist/54r2OpIsl3hhvSpEDIZesr"}
{"genre": "greek black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5G5uiaaU1lfD7ztyzQfGKs"}
{"genre": "deep freestyle", "spotify_playlist_url": "https://open.spotify.com/playlist/0Dsgav1Lw24dGSajhPlDrs"}
{"genre": "noisecore", "spotify_playlist_url": "https://open.spotify.com/playlist/5wltFiP60TnGuOwmR8R0Th"}
{"genre": "american oi", "spotify_playlist_url": "https://open.spotify.com/playlist/0QrUMIfELgl7gi1zYcCgq4"}
{"genre": "balkan post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2vAFuLRjqWAba8iL4IiIYS"}
{"genre": "grenada soca", "spotify_playlist_url": "https://open.spotify.com/playlist/2OEuDHDJWjSAoiGkpT79Sc"}
{"genre": "dainuojamoji poezija", "spotify_playlist_url": "https://open.spotify.com/playlist/4vs5oVyprUnwwcueOZ9ked"}
{"genre": "military cadence", "spotify_playlist_url": "https://open.spotify.com/playlist/5djDoYnkBPwUsyCmfZPhso"}
{"genre": "bodo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/18gwmAWHFq8flv45o2BmlC"}
{"genre": "musique touareg", "spotify_playlist_url": "https://open.spotify.com/playlist/7L6dt5tqw1XTbf5ez1b76m"}
{"genre": "myanmar hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7HAvXnynEl18Ay6mabzRRF"}
{"genre": "emoviolence", "spotify_playlist_url": "https://open.spotify.com/playlist/77u4SHd1TQSIMa3rtGFr6O"}
{"genre": "azeri alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/11C13gCiR7UoigFIboXDHr"}
{"genre": "indie tico", "spotify_playlist_url": "https://open.spotify.com/playlist/1F5H1ZPM8evRVyRP7Mufo9"}
{"genre": "musique mariage algerien", "spotify_playlist_url": "https://open.spotify.com/playlist/4lSVAANT2LfdYn6UxvtKsy"}
{"genre": "lithuanian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7rZpex2Aw8cxcBFVYXRLds"}
{"genre": "indie campechano", "spotify_playlist_url": "https://open.spotify.com/playlist/3Vj7mQtbuQNH8urnTsidXe"}
{"genre": "albanian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4QzAu8shfIvzsvhJiAVI2K"}
{"genre": "punk galego", "spotify_playlist_url": "https://open.spotify.com/playlist/14JdnNWjAC67mTeMtQvVQU"}
{"genre": "massage", "spotify_playlist_url": "https://open.spotify.com/playlist/2LzMNx1bNYPyEmqtLnu0t0"}
{"genre": "italian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/78Pqr3lS2uzNDowQRsFbau"}
{"genre": "virginia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7HNMH4CFBhGLmxnlO9eOCI"}
{"genre": "french hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1Sk5IqSLHTu67qMC0g0fsw"}
{"genre": "maine hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3olMGtyLXcjiZhcO1CZPi4"}
{"genre": "taraneem", "spotify_playlist_url": "https://open.spotify.com/playlist/7BLKSzIiVrkhVe0tQFTtJg"}
{"genre": "tibetan mantra", "spotify_playlist_url": "https://open.spotify.com/playlist/6I5ckRacpJhSB8WYWEA8NT"}
{"genre": "bangladeshi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6PbOwNcgDKomwkNOzpiA3M"}
{"genre": "estonian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/015hxpj9Ds4ixai2HxN0h7"}
{"genre": "pune indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2VTqYOL0UbNT0lMwi8vTNH"}
{"genre": "italian post-hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/19ZnuasPeaxJLHb42DRONl"}
{"genre": "iowa hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/2CCFjSEgiXofou5h3azRa0"}
{"genre": "musica antigua", "spotify_playlist_url": "https://open.spotify.com/playlist/0cBZNnEFHoynI0VCas1c4P"}
{"genre": "swiss worship", "spotify_playlist_url": "https://open.spotify.com/playlist/7bbNyU2ArtAlvyXRglev4y"}
{"genre": "lagu manado", "spotify_playlist_url": "https://open.spotify.com/playlist/4k2MgmvYXkWUxLwMrp863V"}
{"genre": "tijuana electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZW1osX8j6S1znByXhkxAF"}
{"genre": "xinyao", "spotify_playlist_url": "https://open.spotify.com/playlist/3OdedP3CjT68YpId2B1BFk"}
{"genre": "japanese classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/2xCFXS4di9R2XWQebiA5lv"}
{"genre": "swedish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0vMO95PHDDpR99ysMzuxj5"}
{"genre": "russian emo", "spotify_playlist_url": "https://open.spotify.com/playlist/56MKvHNKAAYAVB3s24AyZz"}
{"genre": "swiss black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3es9dCYSTrK0eqLSTOP2QM"}
{"genre": "russian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/771SM1pTZn9UnCESjwHmmE"}
{"genre": "swedish underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/6IOOniQzgJeOfvfRmnRBGq"}
{"genre": "winnipeg hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3jJdVfjC6emcsncxWd16Ud"}
{"genre": "avant-garde black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/57Ns5VoHxZQPQ374ebMZf5"}
{"genre": "classic tollywood", "spotify_playlist_url": "https://open.spotify.com/playlist/5ZgJICrSp7QESzvjgwfVey"}
{"genre": "knoxville indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5wdAc7wJflfos2mRKL0K71"}
{"genre": "mincecore", "spotify_playlist_url": "https://open.spotify.com/playlist/7fZMosrOXsQybJ3hReyvPV"}
{"genre": "musica sammarinese", "spotify_playlist_url": "https://open.spotify.com/playlist/1zq0vRjcCYrP2R2d5FOmEO"}
{"genre": "australian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2rC5y63rN8vpDKbYSD8ykd"}
{"genre": "forro instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/3zLoWBeQkil0PcY4oFndPa"}
{"genre": "bajan soca", "spotify_playlist_url": "https://open.spotify.com/playlist/1m3bBRIdm9WbACj6hcVpKk"}
{"genre": "bosnian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7p9LTCdkoZNL24GHLExbSA"}
{"genre": "louisville underground", "spotify_playlist_url": "https://open.spotify.com/playlist/0WEcr0KepcAho5Wu3vAbXE"}
{"genre": "czech alternative rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3QY81cbRYFXTHdTBNVVVb2"}
{"genre": "korean bl ost", "spotify_playlist_url": "https://open.spotify.com/playlist/2M3L8vM7lYRSzDtDu8zv3z"}
{"genre": "bangalore indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0yw568vk1Hhi2A0HoV6SqX"}
{"genre": "chimurenga", "spotify_playlist_url": "https://open.spotify.com/playlist/5hJ9vZCBgVcxrXxg90kTv9"}
{"genre": "trash rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7g97O2qHKYa3VZxOKMmyiL"}
{"genre": "togolese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1QX521nM9wFdrp8J8p3YyM"}
{"genre": "uk diy punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6m7ilZfojjvq5MaPmDOoDp"}
{"genre": "cornwall indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0GZ2auTLjgUx1BsffudAh4"}
{"genre": "montana roots", "spotify_playlist_url": "https://open.spotify.com/playlist/5fcYFvhlE6Yf4yKQTHwC0f"}
{"genre": "brasilia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5xmiJMw9B5JlgiM4Ew47cL"}
{"genre": "canadian comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/7JncFH6GAjyAobbWbIF2Qh"}
{"genre": "electronica cristiana", "spotify_playlist_url": "https://open.spotify.com/playlist/5mjuQcRp84oImUOJp5Pnwz"}
{"genre": "deep dance pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2FTKXAfnRZlKfOSPQnvc2O"}
{"genre": "yemeni pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5YFUtJgAy2Xfly9whFZrz2"}
{"genre": "modern big band", "spotify_playlist_url": "https://open.spotify.com/playlist/5zbyDiu9Z44EfBNA6D7X6q"}
{"genre": "bagpipe marching band", "spotify_playlist_url": "https://open.spotify.com/playlist/41iWMc04NJfguWYm2r00Sc"}
{"genre": "gospel soul", "spotify_playlist_url": "https://open.spotify.com/playlist/5wyVpRvSVAziVVGjJEyFS6"}
{"genre": "muzica usoara", "spotify_playlist_url": "https://open.spotify.com/playlist/5b8gIRFCYqWVuOyRqfJnAZ"}
{"genre": "brazilian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2cnwzTMVQuEALb2Ekj3Gjf"}
{"genre": "krajiska muzika", "spotify_playlist_url": "https://open.spotify.com/playlist/5AUR7uvz1rrrJWuNzzw5uA"}
{"genre": "spanish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/5NInEvlgKr6MTytu7av3e3"}
{"genre": "tribute", "spotify_playlist_url": "https://open.spotify.com/playlist/4w3F7UV3j9j696HYl16IsU"}
{"genre": "german classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/2kmpwFIajNRGX0F4s4TnaX"}
{"genre": "musica paranaense", "spotify_playlist_url": "https://open.spotify.com/playlist/0IDNHZwGpqlZShbrtCiw2F"}
{"genre": "london on indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2b1a66G3u1GA6SrCYrR70S"}
{"genre": "japanese bedroom pop", "spotify_playlist_url": "https://open.spotify.com/playlist/79aMbziSfGAzNl7LirfdoR"}
{"genre": "kannada bhava geethe", "spotify_playlist_url": "https://open.spotify.com/playlist/2syATVbS3of0GlG6crdmu4"}
{"genre": "german hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6mNVIQaCsSfctLelEZBRJz"}
{"genre": "dresden indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1YzrgJGO5xdUd6oMPcpjqq"}
{"genre": "hi-tech", "spotify_playlist_url": "https://open.spotify.com/playlist/0PvoMMVwV0x5pSJMHXkiRE"}
{"genre": "psychedelic space rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2dyY1R7Q8AwJZLJrczjVhn"}
{"genre": "australian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/38AKUxCXckgIaEY0QwDj1q"}
{"genre": "pre-war blues", "spotify_playlist_url": "https://open.spotify.com/playlist/0vFJAnZTtSZ6LoIKoH0sBl"}
{"genre": "polka nortena", "spotify_playlist_url": "https://open.spotify.com/playlist/14AuPcOD14ycw1O9xHKmax"}
{"genre": "slovak electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6yDWNVWstrSIYI1m4KHSUS"}
{"genre": "hausa pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5K7XuuLr2WNf6sSWo9yiUx"}
{"genre": "indonesian hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/64CA2fIgmgmp8YiYjMOgEl"}
{"genre": "oslo indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2gMywPXdnscHLNTDLoMbJC"}
{"genre": "college marching band", "spotify_playlist_url": "https://open.spotify.com/playlist/5OKeXMU4U3u4NkPA1XqsUD"}
{"genre": "black death", "spotify_playlist_url": "https://open.spotify.com/playlist/2uFx2M1ms8TSWx6r2ARRrq"}
{"genre": "cascadian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5VvAAHLsQdsqkBGrGV5IsO"}
{"genre": "latino comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/2CKj3hTGepAg0wJJ3N2q0a"}
{"genre": "classical trumpet", "spotify_playlist_url": "https://open.spotify.com/playlist/36YH1VI2xPJsg3pwCxr4Hl"}
{"genre": "raspe", "spotify_playlist_url": "https://open.spotify.com/playlist/5Zd8bsx2I4OuO9VK9wSD5q"}
{"genre": "beach music", "spotify_playlist_url": "https://open.spotify.com/playlist/2NsX3CredBVJ5wAZcIs3U4"}
{"genre": "italian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4HoT33OJOwvMElhB4xEeFs"}
{"genre": "polyphonies corses", "spotify_playlist_url": "https://open.spotify.com/playlist/1w1dhVUAY2xFWTEQh97Lrx"}
{"genre": "dikir barat", "spotify_playlist_url": "https://open.spotify.com/playlist/10xJpOLtAcFLVA7ewURbGa"}
{"genre": "icelandic post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1HgonOzDQPP1RZZjetDXFb"}
{"genre": "second line", "spotify_playlist_url": "https://open.spotify.com/playlist/6icf0lvA7l4phncVp98zg0"}
{"genre": "finnish metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4E95uV8A7beH7t5SolOBjX"}
{"genre": "stuttgart indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2FTHQAv97DfQoQx9kd2UU9"}
{"genre": "cascadia psych", "spotify_playlist_url": "https://open.spotify.com/playlist/6Lop6DyaZNvkZHLcHgaYBW"}
{"genre": "texas death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3RtxqtzThZ2JbmBVuX5kRq"}
{"genre": "deep melodic death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4RJgpX5hWvmuNw45qr2mxL"}
{"genre": "bornehistorier", "spotify_playlist_url": "https://open.spotify.com/playlist/1dGDueP3SFulSK9torTpli"}
{"genre": "hjemmesnekk", "spotify_playlist_url": "https://open.spotify.com/playlist/4tFdfzu1PtgfCswieM6Qlv"}
{"genre": "canadian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/688ZLt1Od5gnavxSBSNifA"}
{"genre": "polish thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/73F0Ck1aBETZBJzIEg0leI"}
{"genre": "seattle metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4GugHUuQDpDCk9tHJzE2QS"}
{"genre": "muzica moldoveneasca", "spotify_playlist_url": "https://open.spotify.com/playlist/2szZV2Nyo3sO9Ne5iHjhsj"}
{"genre": "d-beat", "spotify_playlist_url": "https://open.spotify.com/playlist/6BOkFgQ7RfunKTZFHP9fNW"}
{"genre": "nyc metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5W4PrzMTHEQRQRADJ94nMZ"}
{"genre": "finnish electro", "spotify_playlist_url": "https://open.spotify.com/playlist/6kWL50uF6lux1Jiw9M5yhW"}
{"genre": "acousmatic", "spotify_playlist_url": "https://open.spotify.com/playlist/3OrDWwOHM2iQCwi5vIxlMJ"}
{"genre": "backing track", "spotify_playlist_url": "https://open.spotify.com/playlist/0OntTiyGzKP5yAqKhvmPXB"}
{"genre": "mindfulness", "spotify_playlist_url": "https://open.spotify.com/playlist/0Q3p2ozB9LNh4MgJtTlrXh"}
{"genre": "traditional funk", "spotify_playlist_url": "https://open.spotify.com/playlist/0NpqTKn410dMNKF5PV7I6r"}
{"genre": "michigan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3XHB7IQFe3UmJ2H803w8Ms"}
{"genre": "breaks", "spotify_playlist_url": "https://open.spotify.com/playlist/3sY5WhiXGA6c0l7TCOETnJ"}
{"genre": "dessin anime", "spotify_playlist_url": "https://open.spotify.com/playlist/63VSjPh2b1FV5zGlFkQhxb"}
{"genre": "irish banjo", "spotify_playlist_url": "https://open.spotify.com/playlist/2wL2qCBk0diEm7vQEEx9Qa"}
{"genre": "ukrainian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/67IEX5Nrgs7UQFhETcFZtK"}
{"genre": "igbo traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7pSvV59D4TlOOcPkGWSpZZ"}
{"genre": "malmo indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1v6HfvoEOSjwAyo1XsiQlu"}
{"genre": "latvian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6Wc5d03C3fyD4oXEeclMEE"}
{"genre": "finnish worship", "spotify_playlist_url": "https://open.spotify.com/playlist/4uYiWvGxE9KuBnhBGiaiKF"}
{"genre": "german stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3xB2NMC66RiBCfk1St2d5x"}
{"genre": "deep funk", "spotify_playlist_url": "https://open.spotify.com/playlist/4isjLiafpzMJZPYQ6Roww6"}
{"genre": "musica de intervencao", "spotify_playlist_url": "https://open.spotify.com/playlist/16cFXoE6JGTkzoOhsdg22j"}
{"genre": "rap gaucho", "spotify_playlist_url": "https://open.spotify.com/playlist/1eTqeJPyDOv3O44cMPOp7Y"}
{"genre": "danish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6BjJc4ZLAzVIRzsMnyEefc"}
{"genre": "mexican death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6uSUiQmSbBy83KifaDfCKq"}
{"genre": "dub metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0JAXi2lxjxMJQeP4iw9bxD"}
{"genre": "milwaukee indie", "spotify_playlist_url": "https://open.spotify.com/playlist/08AHYrQ9Og6ZuhJtEFbtyv"}
{"genre": "cantonese worship", "spotify_playlist_url": "https://open.spotify.com/playlist/2fUWsMkJfqdfuCoPEMnL21"}
{"genre": "lasten satuja", "spotify_playlist_url": "https://open.spotify.com/playlist/4RhupISMLdVdHZoCJFhWCt"}
{"genre": "musique nigerienne", "spotify_playlist_url": "https://open.spotify.com/playlist/3S0yyrqZAIXvLhT02kfkYQ"}
{"genre": "indonesian deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/10PT5OvCyg3tkZarwaKpuQ"}
{"genre": "kabyle moderne", "spotify_playlist_url": "https://open.spotify.com/playlist/3HUr4QyGI5W6iuK9enJBRq"}
{"genre": "russian old school hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4eai54AwLT60J1i2SKOHsz"}
{"genre": "street punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2tlqYCJJmhwvxLrW2agDk1"}
{"genre": "algerian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2dTrKvcQZORH6t99jDV4Pn"}
{"genre": "underground grunge", "spotify_playlist_url": "https://open.spotify.com/playlist/3T1K4FeI0RPR88YWm85NYy"}
{"genre": "japanese classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/77tNMX6jFAGi94LSDEfsbM"}
{"genre": "classical soprano", "spotify_playlist_url": "https://open.spotify.com/playlist/1lqcHNoMZon8Vw4ajBVHgd"}
{"genre": "ua trap", "spotify_playlist_url": "https://open.spotify.com/playlist/2cTycvm3KsyhG7khw9zu91"}
{"genre": "sevilla indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3HfxvJRQRL9VfuDq4Pw2w2"}
{"genre": "reggae tico", "spotify_playlist_url": "https://open.spotify.com/playlist/2qJGd86E5serYYcbu5zMHL"}
{"genre": "zenonesque", "spotify_playlist_url": "https://open.spotify.com/playlist/1RbpXfjqUTf9iKExXjr2jp"}
{"genre": "old school nederhop", "spotify_playlist_url": "https://open.spotify.com/playlist/6UoGOaO66dBAVTxz5PWa3I"}
{"genre": "pinoy edm", "spotify_playlist_url": "https://open.spotify.com/playlist/2U0GhswEX2FGGE6tITJg66"}
{"genre": "cymraeg", "spotify_playlist_url": "https://open.spotify.com/playlist/1u9ozOcFTFQkjwhczh5zoC"}
{"genre": "slovak indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1E8vQ9Bt4bRKWm0NTzSMt2"}
{"genre": "afrikaans gqom", "spotify_playlist_url": "https://open.spotify.com/playlist/4kD9Yb4dISZMwIsftsFKqk"}
{"genre": "noel quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/5Chjl8czlf7DntIDZJXgSv"}
{"genre": "odia bhajan", "spotify_playlist_url": "https://open.spotify.com/playlist/4y5XC6IboulSyeN4WntFSp"}
{"genre": "turkish classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/3YB2rIYxSoAgs3WsgCFVOj"}
{"genre": "rwandan gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/1wlvNtLn6q3SJ0whSvnCyK"}
{"genre": "kuduro antigo", "spotify_playlist_url": "https://open.spotify.com/playlist/01glKSMaMIShSMgPwkVD3p"}
{"genre": "swedish blues", "spotify_playlist_url": "https://open.spotify.com/playlist/2EFrUVussxCgKmqowB6BmS"}
{"genre": "turkish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/508OlaD8prowe8kNe3TFYu"}
{"genre": "rap abc paulista", "spotify_playlist_url": "https://open.spotify.com/playlist/2oytQAEGwy9vh8hbGj1xba"}
{"genre": "polish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4E7Z0VZyLAY2U5Z4AqJwJr"}
{"genre": "rock campineiro", "spotify_playlist_url": "https://open.spotify.com/playlist/0VmoyqrenVov0RIbYRkcp1"}
{"genre": "italian jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/3Qz6ukyPREhIPinAnPsAIW"}
{"genre": "neo grime", "spotify_playlist_url": "https://open.spotify.com/playlist/3Xb1CTuAvYH2xYTVUVpOdT"}
{"genre": "algorave", "spotify_playlist_url": "https://open.spotify.com/playlist/5iHmEAbbx6ALaG7R1TNiRs"}
{"genre": "canadian rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/3vrzz6K23Zlcm0oTLtCmy3"}
{"genre": "cardiff indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1zXe0mjyaG0vcnVqC1NrLX"}
{"genre": "zambian gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/2KMOd9KmWLeUbbRySGHN5j"}
{"genre": "cornish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/15rvzJq4AVJG8s5S7HfDqy"}
{"genre": "japanese post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6ori9ZbkjwEVOs1ZccBq0W"}
{"genre": "hard rock mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/08K9iOQkGaqkaVjaHxMYS8"}
{"genre": "kansas hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6l0T3BkqjNXmCCqCNYqJoE"}
{"genre": "spanish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4sff5BasdWwxgAW2B6pW0U"}
{"genre": "south dakota indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0KQrvXqaLBkDJg7mzkShgY"}
{"genre": "adivasi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0PmKwn4PMi0zCeOSMhBxSm"}
{"genre": "kokborok pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3cFGm0rRa0Up9AFXKZ5JHq"}
{"genre": "fuji", "spotify_playlist_url": "https://open.spotify.com/playlist/2dSueCb8JMaLfE3GQvIz6w"}
{"genre": "historic piano performance", "spotify_playlist_url": "https://open.spotify.com/playlist/5MXw4i9pRhleia2mDgrnbu"}
{"genre": "melbourne hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0P2DCD9GpYL4UCnepHIIGj"}
{"genre": "portuguese indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0RcObnwNtF2QxFx5hFSLJv"}
{"genre": "malagasy folk", "spotify_playlist_url": "https://open.spotify.com/playlist/77xnC6OXjoE0Zlccj5ujd9"}
{"genre": "french oi", "spotify_playlist_url": "https://open.spotify.com/playlist/2PtDS8FDWNsuHmiJZhjY66"}
{"genre": "arizona punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1vGiXnMDGlF1e9NooVtDWq"}
{"genre": "musica colombiana instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/1G2wEAoTNmKc75PoOvV0P7"}
{"genre": "russian romance", "spotify_playlist_url": "https://open.spotify.com/playlist/480M6DJCRmLEARYupW8Rdi"}
{"genre": "japanese death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4BU0x01AGsuI2YyONYmJtN"}
{"genre": "rautalanka", "spotify_playlist_url": "https://open.spotify.com/playlist/7aRjOmjIA4T4AIvRyI1xeI"}
{"genre": "gabonese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4BZEjr7tcmpmeRtnRAPEfN"}
{"genre": "rock cearense", "spotify_playlist_url": "https://open.spotify.com/playlist/2xtnkiIc0EBB8Tgb1XW4Kw"}
{"genre": "heligonka", "spotify_playlist_url": "https://open.spotify.com/playlist/0wVIDHmrIRCptOzMvVq6nK"}
{"genre": "greek folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6QmEJ46xBnlEcm4k9CstVu"}
{"genre": "lounge house", "spotify_playlist_url": "https://open.spotify.com/playlist/01rNJ4ySEztGmhSevXtjVk"}
{"genre": "mexican experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0E4isSxspV6ey8CoOXeL7Y"}
{"genre": "northwest china indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4bZvft7DVkJCAslix0FqWj"}
{"genre": "mexican hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6x09BnasLdoGcIA2pGqMfT"}
{"genre": "singaporean indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5BJ5rG6hFaItN8dIfZukGM"}
{"genre": "baja indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7brR2dtt87902qmMJAu08D"}
{"genre": "jazz flute", "spotify_playlist_url": "https://open.spotify.com/playlist/0MpkUjSC9rzQSS6VHML3pD"}
{"genre": "liechtenstein", "spotify_playlist_url": "https://open.spotify.com/playlist/3AxSX3HPwdYS7HWJOlTUnt"}
{"genre": "german post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5oz3BWXPGFwtM02PQxYVXt"}
{"genre": "native american hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1pLIhrmDfoUGF3cAAa0aMd"}
{"genre": "deep psychobilly", "spotify_playlist_url": "https://open.spotify.com/playlist/29bqhWU5jZPLXuk160CNWs"}
{"genre": "classical jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/55N6txn5KNGrxoWcelkVOu"}
{"genre": "go-go", "spotify_playlist_url": "https://open.spotify.com/playlist/1NbSSG8t5uCu4rXC9Z1ZIm"}
{"genre": "sesotho hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1C3oYxpDKj4OHf4sB2gQQ5"}
{"genre": "uzbek hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0SaL0xWgNtVPrgomKIlLX0"}
{"genre": "muzica populara", "spotify_playlist_url": "https://open.spotify.com/playlist/3Nowur2XueyjlPEFZ2oQVA"}
{"genre": "perth hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6wU8jyRbuYpm5SlKrH1kQF"}
{"genre": "anthem", "spotify_playlist_url": "https://open.spotify.com/playlist/38rbQIxZrNYvaTjlm1z6TM"}
{"genre": "bulgarian r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/1VyGrIxu31o7efsCAqfubh"}
{"genre": "lawrence ks indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0g7XBWmSd7Bm9dLP04dbhm"}
{"genre": "death doom", "spotify_playlist_url": "https://open.spotify.com/playlist/6jPRKDy83GFbWLU3csEycu"}
{"genre": "bal-musette", "spotify_playlist_url": "https://open.spotify.com/playlist/2qBRZvImPQjF7KXej3YmHz"}
{"genre": "dutch death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2Rgdp2J6IIrc45k9CCGRPo"}
{"genre": "deep darkpsy", "spotify_playlist_url": "https://open.spotify.com/playlist/6imJTb1hGPtOB9RJFAIxT5"}
{"genre": "rock paraibano", "spotify_playlist_url": "https://open.spotify.com/playlist/2YHUuKlIBzNF6xj4ELC20x"}
{"genre": "balinese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/46bmK7CFBoQjguGbziZgub"}
{"genre": "kritika", "spotify_playlist_url": "https://open.spotify.com/playlist/1TLrPhznn7bQFSuUAF2u82"}
{"genre": "doomcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3OFavLb9tW7gAThaWdthHx"}
{"genre": "ugandan gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/25AUCNKrUS4XYwvGD3zYLL"}
{"genre": "australian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5Eavu4IrTnwmZZQbAM18KO"}
{"genre": "metal catala", "spotify_playlist_url": "https://open.spotify.com/playlist/6Cn5vRU5a4k86RkDUAFQiH"}
{"genre": "musica eletronica brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/2iIvmLhYQN1NvazT3SiEMJ"}
{"genre": "native american spiritual", "spotify_playlist_url": "https://open.spotify.com/playlist/0q8tZkSf7dCPWPyrGsDsNt"}
{"genre": "schwyzerorgeli", "spotify_playlist_url": "https://open.spotify.com/playlist/5X9EYWYljr2BUBQy4mdIgI"}
{"genre": "khmer", "spotify_playlist_url": "https://open.spotify.com/playlist/1Cr2fJmkdikZdux7SXq3Tv"}
{"genre": "italian pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4QeDsh5JaGusYsFQHEBobD"}
{"genre": "canadian drill", "spotify_playlist_url": "https://open.spotify.com/playlist/7angZSrbo9ShAe1q06i2OG"}
{"genre": "old school uk hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZtDa9oO5dpvF5L5dE977c"}
{"genre": "indian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5keiITeMvrPlxQvpRScbjy"}
{"genre": "ethiopian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5DuLi0To9tbwZDum6RDEcH"}
{"genre": "murga", "spotify_playlist_url": "https://open.spotify.com/playlist/5dEmoAzfG8Ln1HXvSJ5LPx"}
{"genre": "tigrigna pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1T35MTE40rPXbmU0O0Hgyv"}
{"genre": "hull indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0IO0gpqCNRyp1tawpP9YSN"}
{"genre": "grunneger muziek", "spotify_playlist_url": "https://open.spotify.com/playlist/6df6TceBOi5yfpogHq8Man"}
{"genre": "power noise", "spotify_playlist_url": "https://open.spotify.com/playlist/23j3NLoqFN0Z7z3rsCZH7Q"}
{"genre": "musica etnica", "spotify_playlist_url": "https://open.spotify.com/playlist/7IBJdQWrD4mmMEIr8bnpFK"}
{"genre": "norwegian doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3yZztAT95es1S7UQZ89Pnz"}
{"genre": "whale song", "spotify_playlist_url": "https://open.spotify.com/playlist/7fCUoC8KHIPl8KGkot7B3h"}
{"genre": "danish punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2xoMr4AFEWPA5kYWSzjxfY"}
{"genre": "hardcore breaks", "spotify_playlist_url": "https://open.spotify.com/playlist/3Xf5DQq60Gssc5ccah89wW"}
{"genre": "ostschlager", "spotify_playlist_url": "https://open.spotify.com/playlist/61zHBuk35iVMrausi25n3g"}
{"genre": "new tejano", "spotify_playlist_url": "https://open.spotify.com/playlist/1fGvJcDIWbvTKNFhiKvKdA"}
{"genre": "beninese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5qMUzoMITcF88UypoWTaAB"}
{"genre": "prog quebec", "spotify_playlist_url": "https://open.spotify.com/playlist/38aa26lM0hNnfD09Yjk84t"}
{"genre": "black speed metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5EDwrXzHRKVIlwdXHMV7cT"}
{"genre": "japanese techno", "spotify_playlist_url": "https://open.spotify.com/playlist/1PdqHeY878X3TfBwXSS7LF"}
{"genre": "swedish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0spsvp2NNHMXDezns2YSGt"}
{"genre": "prepared piano", "spotify_playlist_url": "https://open.spotify.com/playlist/0KecgPjeyjAn9T2d5PNTwN"}
{"genre": "norman ok indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1Z1VmZkX0MLoSJXD9Jve5r"}
{"genre": "australian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4qIzqV9I7DTV6uWxeqNUDC"}
{"genre": "german renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/337hCRFLjygh0JPpHZ80GM"}
{"genre": "brass ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/5gi35SWBRo7VuSZeZ3es2A"}
{"genre": "dundee indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7wdeJT4Fj1ZTBqiHeuEdiA"}
{"genre": "taiwanese indigenous music", "spotify_playlist_url": "https://open.spotify.com/playlist/1uBO9XBBQE2fkXNjD0Zllm"}
{"genre": "deep punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1YhJWPt44wBUVMiioF1G4i"}
{"genre": "classic sudanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/23eURZ5FEalyPiEXsNc0Ir"}
{"genre": "rap sureno chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/4UxMq2zQDwCFwmDgws3FqT"}
{"genre": "estonian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3KsDNETNZ38sktwgKwlkWB"}
{"genre": "chaabi algerien", "spotify_playlist_url": "https://open.spotify.com/playlist/1gzF6wXH6kATo88gihfcjl"}
{"genre": "balkan folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6F0DBsxGTwJ2nysdf3t2ka"}
{"genre": "hypnosis", "spotify_playlist_url": "https://open.spotify.com/playlist/4EEpArVS7GF1eE4BGzOGvN"}
{"genre": "fado antigo", "spotify_playlist_url": "https://open.spotify.com/playlist/6kMd7pDwtSA0F7b0RrvsSe"}
{"genre": "comptine africaine", "spotify_playlist_url": "https://open.spotify.com/playlist/7zC8y6bSAPAgorCGTJUuVo"}
{"genre": "argentine jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5wSUmSyg6fkQqIhuEWGcp9"}
{"genre": "finnish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4whPdnPMrHNeuHtDyyNWjY"}
{"genre": "xhosa hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/03gnvuMqmf0w2E5qv4bHsy"}
{"genre": "goa hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0vAUr3shpn27PP5YckHSrf"}
{"genre": "jumptek", "spotify_playlist_url": "https://open.spotify.com/playlist/6FAmZHdawJ1xkJWc4psWCk"}
{"genre": "musique mahoraise", "spotify_playlist_url": "https://open.spotify.com/playlist/5ySmBKFuuAazwoX8YefEQV"}
{"genre": "surinamese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5QVCFHi3JSGOzmHXSArH5S"}
{"genre": "serbian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1QZmeNOqh6BmKkJltGq5m0"}
{"genre": "medieval black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/11PrZxDi2KqPruwPVOqgAc"}
{"genre": "punk mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/6PZxkPpTt3Keio3aMLwJC4"}
{"genre": "meenawati", "spotify_playlist_url": "https://open.spotify.com/playlist/0FlH2wbT43vzXI3FHijISI"}
{"genre": "mongolian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/22sJydhixCcmC9b2cu5Y6b"}
{"genre": "persian neo-traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7vmAOYPv79aEKthR81JQgR"}
{"genre": "swedish pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4Icn89sdB2RaEILOgMxyON"}
{"genre": "russian experimental electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1ozxaOoXCqpoeAXfw2XuMa"}
{"genre": "jazz accordion", "spotify_playlist_url": "https://open.spotify.com/playlist/2hrdgsVUHsepTX13wWziDC"}
{"genre": "australian post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1TTeHpttiwkV4CRbU3lDxr"}
{"genre": "hampton roads indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5YlKVBQiPIlV4uxyQVNmWm"}
{"genre": "indie salvadoreno", "spotify_playlist_url": "https://open.spotify.com/playlist/7kVFp5nMo1YkcjxU2Vw2aU"}
{"genre": "saraiki pop", "spotify_playlist_url": "https://open.spotify.com/playlist/198sP5On6NnvbwsTpN9KDz"}
{"genre": "contemporary choir", "spotify_playlist_url": "https://open.spotify.com/playlist/2nPM54EqadWdH5z9DjwxT8"}
{"genre": "norwegian psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/2Hww6gHd4rDRxhD9pKDgZP"}
{"genre": "west yorkshire indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1SznnEayFyHbJ7rGI2XjIi"}
{"genre": "uk rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/2Irmgvta0tsUY1iKDxLrlq"}
{"genre": "cambodian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1LWJWwk9c4RDbyhqXWySH4"}
{"genre": "harmonica jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ngk0xBx3586LQXH1fS6h5"}
{"genre": "chilean metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6YlhnR407LgZfCOOGHZfiv"}
{"genre": "nisiotika", "spotify_playlist_url": "https://open.spotify.com/playlist/26N3SL5RS848I3VFg6co75"}
{"genre": "kerkkoor", "spotify_playlist_url": "https://open.spotify.com/playlist/6f8oAWcmpEcXrbnbOpnfqT"}
{"genre": "scottish indie folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1bhivX7hCIUM7hiYlkn6Fp"}
{"genre": "deep vocal jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2Dsz5JxEeRz0nAC0plSEMF"}
{"genre": "juju", "spotify_playlist_url": "https://open.spotify.com/playlist/1HiPI15vZXijzGPvapis1A"}
{"genre": "japanese progressive house", "spotify_playlist_url": "https://open.spotify.com/playlist/2Z3QlVfnnWJMxseVVlPCAw"}
{"genre": "czech electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/2tOnLiRR4UNjLEewu0OEYC"}
{"genre": "orquesta tropical", "spotify_playlist_url": "https://open.spotify.com/playlist/4NCTzrcXK5FNg1mCOTvk8c"}
{"genre": "czsk electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/2pIs3tMAUzFEoS30WyUHEG"}
{"genre": "mexican classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6Hw8HTpwKJqXpS7zjSQ0EM"}
{"genre": "cocuk masallari", "spotify_playlist_url": "https://open.spotify.com/playlist/5q4rTwMeNVX8aSaVzig01o"}
{"genre": "rap salvadoreno", "spotify_playlist_url": "https://open.spotify.com/playlist/31U0LiD36ruLhG73us9ild"}
{"genre": "symphonic melodic death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/41CIPcZqdtvb5gm5J5RPk7"}
{"genre": "experimental psych", "spotify_playlist_url": "https://open.spotify.com/playlist/7d4A45WwlxWLN2E0LIrUxE"}
{"genre": "icelandic jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5eZfux6hlisXkE1rC4a6mR"}
{"genre": "bloco", "spotify_playlist_url": "https://open.spotify.com/playlist/1jzzzEuEkAoffrhTAJN4bH"}
{"genre": "dansk lovsang", "spotify_playlist_url": "https://open.spotify.com/playlist/6PtT6ZnKDSmeaczTMZV7dl"}
{"genre": "musiikkia lapista", "spotify_playlist_url": "https://open.spotify.com/playlist/1ivpRrAa7wWR9bOcNzVr7g"}
{"genre": "neo soul-jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7kQQGS5m9U07fe7CPWiql7"}
{"genre": "indie michoacano", "spotify_playlist_url": "https://open.spotify.com/playlist/0q1UNHBbjcqP218qGxXxXC"}
{"genre": "bulgarian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/2t1WqQPQV53p3b807i2IHv"}
{"genre": "turkmen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5WCnM8GlDTRtbqK9q5xwPt"}
{"genre": "carnatic instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/520PdmxBhzhsOIfR0lAMth"}
{"genre": "baltic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3rMsoAdNblV0mrCX8wxEcB"}
{"genre": "icelandic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7KvHsZlWBcDNpi5eaZkijY"}
{"genre": "rock goiano", "spotify_playlist_url": "https://open.spotify.com/playlist/4ONNYwN5t3xizFyFKmAsSn"}
{"genre": "chinese electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6y8Q7oaqi56xodW4PIu9fP"}
{"genre": "konkani pop", "spotify_playlist_url": "https://open.spotify.com/playlist/04WqP7v7DfZphdiqdDZU8x"}
{"genre": "chennai indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2Z6IXUd05BP2kdkUtMfjxD"}
{"genre": "chant basque", "spotify_playlist_url": "https://open.spotify.com/playlist/0Oqn4J5BKH3kedUtGR6iUv"}
{"genre": "christian deathcore", "spotify_playlist_url": "https://open.spotify.com/playlist/59bdZN6IStGCb7z18SiCmD"}
{"genre": "lao hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0yVmsZK4AtiNMpby2WqLZY"}
{"genre": "classic tunisian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0PAK2TYrXeQBrXCMzSELCH"}
{"genre": "maltese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZxlPDRLLKikTjXeQApbWR"}
{"genre": "blackened hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6OJxYPaWAtdmVajGo8UZlJ"}
{"genre": "scottish gaelic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/460OzdtRygFt2sDZYDIlxC"}
{"genre": "steel guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZOdyb8AvqZ451nHJNFZdC"}
{"genre": "chabad niggunim", "spotify_playlist_url": "https://open.spotify.com/playlist/5iIjnHvG1FZpz4QWo7InVE"}
{"genre": "norwegian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/6MjHKjWZs7OgrZne7lq5yY"}
{"genre": "slovenian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2N7V4CUBhDSqEm5mawSLz1"}
{"genre": "coventry indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2AoRjKBw2syzqKgDJ4Z6gQ"}
{"genre": "quarteto gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/5ec1UjNmJJQXIMzksIuXZT"}
{"genre": "arpa grande", "spotify_playlist_url": "https://open.spotify.com/playlist/6i0BYvfWOJqInADYJ5s28g"}
{"genre": "musica sul-mato-grossense", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZbHMh1injVPBZTXnDKnYp"}
{"genre": "nz jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2L0gq2kqdjwz3mmE6Mhbvd"}
{"genre": "string quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/6S3nHApTBJETaDMv7Bz8ZM"}
{"genre": "burundian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4K4MjKuhjuDfuvl7XFoJzj"}
{"genre": "malaysian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3WESokAhiJymMBjplSo0LK"}
{"genre": "free folk", "spotify_playlist_url": "https://open.spotify.com/playlist/63PEOiPwgBRps6iW2emDAl"}
{"genre": "honky-tonk piano", "spotify_playlist_url": "https://open.spotify.com/playlist/5GoMuz5RLIBWPsb8NExeYc"}
{"genre": "musica andorra", "spotify_playlist_url": "https://open.spotify.com/playlist/4h0jGZdu6jRk57JFmWX98e"}
{"genre": "britcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3Ku6x4O3yZobgHR8y6KSnq"}
{"genre": "mezwed", "spotify_playlist_url": "https://open.spotify.com/playlist/5sxMBsJijInJ3Ijwo8PouD"}
{"genre": "modular techno", "spotify_playlist_url": "https://open.spotify.com/playlist/11INHOoPSND6WHVKGucguA"}
{"genre": "gotlandsk musik", "spotify_playlist_url": "https://open.spotify.com/playlist/35me371XCaMkaF5kBfqoZv"}
{"genre": "meyxana", "spotify_playlist_url": "https://open.spotify.com/playlist/5LDGgFnGejn6vPTytuc82L"}
{"genre": "sean-nos singing", "spotify_playlist_url": "https://open.spotify.com/playlist/5h3UFJ2jRZG2vF5eVGaNGq"}
{"genre": "old school ebm", "spotify_playlist_url": "https://open.spotify.com/playlist/2Hi38LsUPYuB3jM1oyS9Mk"}
{"genre": "mluvene slovo", "spotify_playlist_url": "https://open.spotify.com/playlist/4SIr7n8YCW0B6cKMdc3x4h"}
{"genre": "skinhead oi", "spotify_playlist_url": "https://open.spotify.com/playlist/60pHTeWKuQrILfPD3MIbkr"}
{"genre": "basque folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0hO9RR41kv0bwGywHy4qfR"}
{"genre": "igbo worship", "spotify_playlist_url": "https://open.spotify.com/playlist/3jojSk2sHeRxKPbgMIA8mT"}
{"genre": "gospel blues", "spotify_playlist_url": "https://open.spotify.com/playlist/5DO4LMun9Ri03W5bvBQ6Av"}
{"genre": "deep sunset lounge", "spotify_playlist_url": "https://open.spotify.com/playlist/2OJDZ45jalVIEf5AIlkfev"}
{"genre": "detski pesnichki", "spotify_playlist_url": "https://open.spotify.com/playlist/4AD52qozQj9sn1u5OSrECm"}
{"genre": "ukrainian ccm", "spotify_playlist_url": "https://open.spotify.com/playlist/1AsNZ2csoPw2IHm0XLRFrx"}
{"genre": "musique mandingue", "spotify_playlist_url": "https://open.spotify.com/playlist/1VnuSBQ2H3KMRLGVTpUqk6"}
{"genre": "nueva ola peruana", "spotify_playlist_url": "https://open.spotify.com/playlist/2tdLlmejILqEA0HR2yqcVV"}
{"genre": "scottish fiddle", "spotify_playlist_url": "https://open.spotify.com/playlist/7gG8yw7JGFr2o9BeWIXZ5t"}
{"genre": "welsh folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2rtvIsY21G4H85kAUU3kjv"}
{"genre": "weightless", "spotify_playlist_url": "https://open.spotify.com/playlist/2xsh3XQTK8Dsi1rIu7vvi2"}
{"genre": "spanish renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/5eFPh3ZaaYwaUFQsZ5sioE"}
{"genre": "danish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0SUatsZp7U7k1VgYcY1j5K"}
{"genre": "portuguese black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4PKY5a2HVsjJDCJ6nbT3k0"}
{"genre": "swiss jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0qP3XxRkbgMXA62pA1N0oR"}
{"genre": "nu electro", "spotify_playlist_url": "https://open.spotify.com/playlist/0lcI32pCLNqSkd5KwhxUpY"}
{"genre": "heavy gothic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4cJaiQ3OSsF2kxYbPJZkQc"}
{"genre": "lao pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6O63cFOsWByxmtFy8vPUmr"}
{"genre": "tavern", "spotify_playlist_url": "https://open.spotify.com/playlist/3SRTDyQmSdCF3oVfCbsq02"}
{"genre": "iowa indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1ACo2WIQsolnvZj3UhHTuC"}
{"genre": "north alabama indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0G2EPzlGrzZRU16dSySxys"}
{"genre": "bohemian baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/4WkhsYSDRiInX4Ij8SMQI9"}
{"genre": "banjara pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7ilAAMYcfRcnI4C72lPocd"}
{"genre": "dubstep product", "spotify_playlist_url": "https://open.spotify.com/playlist/6D2PZcS7TfFrgqSBowm3Ds"}
{"genre": "rap norteno chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/3ySZupq3ek5CtxVh8BUOgM"}
{"genre": "japanoise", "spotify_playlist_url": "https://open.spotify.com/playlist/5EVoGPRq1fYIcLhFCUiydQ"}
{"genre": "uae indie", "spotify_playlist_url": "https://open.spotify.com/playlist/10pLstNFIIkLZD0o7R8TAx"}
{"genre": "indie cantabria", "spotify_playlist_url": "https://open.spotify.com/playlist/7Di7BrqhUMymNRdAYbGE99"}
{"genre": "epic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6QktX5Zs5mYhB9ckTVAlY5"}
{"genre": "israeli metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3tB6NrKiyxGGwmze1JhAaM"}
{"genre": "inuit pop", "spotify_playlist_url": "https://open.spotify.com/playlist/71EGWTV6P9kEV3mfunfSs4"}
{"genre": "nz hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6tbp4GXPsNQpI6PooJ0oVI"}
{"genre": "spanish electropop", "spotify_playlist_url": "https://open.spotify.com/playlist/5mfWjY87onijayclKZSR6l"}
{"genre": "yorkshire folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2mVv3SQVPJ38r4zEHm68Jy"}
{"genre": "georgian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7IrSsJZdbHtpLGG18YLvPV"}
{"genre": "drikkelek", "spotify_playlist_url": "https://open.spotify.com/playlist/4vPcZDTDM5ZPZOhJExl3n6"}
{"genre": "geinin song", "spotify_playlist_url": "https://open.spotify.com/playlist/6K8iYZzfvl4aEZFN0WWBww"}
{"genre": "japanese prog", "spotify_playlist_url": "https://open.spotify.com/playlist/7BHUefATXVfT9WNqcSBIra"}
{"genre": "garage rock mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/4bLGhvzA5nZGS6gxwRWtZt"}
{"genre": "progressive black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1iPn7sRGKkXcqfeTf4Y5kL"}
{"genre": "korean metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7JMWNzG2Av3PkWgZmUO5x9"}
{"genre": "classic afrobeat", "spotify_playlist_url": "https://open.spotify.com/playlist/1pkTiB2M94dKQLcG3K5z4t"}
{"genre": "boston electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/2dgamvBCHU1vE95dsKgZxE"}
{"genre": "brazilian lo-fi rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0MgTVZhnxixIfszqQRnx6v"}
{"genre": "cambridge choir", "spotify_playlist_url": "https://open.spotify.com/playlist/1FVYfon8yQdDTp2SHy0IJD"}
{"genre": "haur kantak", "spotify_playlist_url": "https://open.spotify.com/playlist/3lAIZ4JewsZAnJGgKhTObh"}
{"genre": "afrikaans gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/3VyEuBwkKxwaAd3NhzGefv"}
{"genre": "musica purepecha", "spotify_playlist_url": "https://open.spotify.com/playlist/7Lvy5MKsWrKAhenQZtPGH3"}
{"genre": "albanian alternative", "spotify_playlist_url": "https://open.spotify.com/playlist/1J9QrpzZIqiVPFCyp6YKEj"}
{"genre": "birthday", "spotify_playlist_url": "https://open.spotify.com/playlist/5RB5A4Syq4hnEof8q1Hn71"}
{"genre": "wind symphony", "spotify_playlist_url": "https://open.spotify.com/playlist/63wX5h9bggwGr0q0AgdLk6"}
{"genre": "italian stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1wf6Z3Rb1Djl8GZdDMc7Ec"}
{"genre": "kaseko", "spotify_playlist_url": "https://open.spotify.com/playlist/1q9jLOn2OGV1MwugzYHKSj"}
{"genre": "taiwan metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1Q9cpdmMDXzc76i8nFbNTS"}
{"genre": "serbian alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/717ElBQx6j6dWCk95V65An"}
{"genre": "chinese metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7DXmRDKwSNv3RB2NuYIfL7"}
{"genre": "sebene", "spotify_playlist_url": "https://open.spotify.com/playlist/5M3z7g9MELB0WS7Q4qLUyo"}
{"genre": "sulawesi indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6ww5wJjqXcuh7PVeAF84Pk"}
{"genre": "japanese choir", "spotify_playlist_url": "https://open.spotify.com/playlist/5LZfqXZsE5H6YGkV2X3Q39"}
{"genre": "barnasogur", "spotify_playlist_url": "https://open.spotify.com/playlist/6R3LwBUTmiLahlJGUAHHVI"}
{"genre": "slaskie piosenki", "spotify_playlist_url": "https://open.spotify.com/playlist/5b5lszUTvnII9ZRsF8478s"}
{"genre": "funeral doom", "spotify_playlist_url": "https://open.spotify.com/playlist/1v1cvGLu2qZlFWiK2B8s5V"}
{"genre": "swedish rock-and-roll", "spotify_playlist_url": "https://open.spotify.com/playlist/4v8JY0sgEEtXgp4bpq64w3"}
{"genre": "duduk", "spotify_playlist_url": "https://open.spotify.com/playlist/6pj10f5j0g9gjfnJnOVgH9"}
{"genre": "musica wixarika", "spotify_playlist_url": "https://open.spotify.com/playlist/28OtIBYwNTMWc1P3HIizQH"}
{"genre": "industrial black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Iq7OIw7e1FzmKXPGJrhOU"}
{"genre": "polka", "spotify_playlist_url": "https://open.spotify.com/playlist/21NKqoIPor61ETw5GBvowf"}
{"genre": "screamocore", "spotify_playlist_url": "https://open.spotify.com/playlist/1lGi0fM0NsvSHTRIZjqcqL"}
{"genre": "comfy synth", "spotify_playlist_url": "https://open.spotify.com/playlist/62RjkTlibTin8zoqgdktfc"}
{"genre": "fado de coimbra", "spotify_playlist_url": "https://open.spotify.com/playlist/24ThUsj0I1BHKdVe0oIbJS"}
{"genre": "university choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4geurSHVDIGoWaPQw6L8Mc"}
{"genre": "classical saxophone", "spotify_playlist_url": "https://open.spotify.com/playlist/57HjZBESViQapJ1pkHFGh5"}
{"genre": "banda de viento", "spotify_playlist_url": "https://open.spotify.com/playlist/3wiB79MfBWu8I63xNXEWOU"}
{"genre": "georgian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/4vrCM6ykBa5FfejfaPpTEs"}
{"genre": "psytech", "spotify_playlist_url": "https://open.spotify.com/playlist/17Vxg2BYsmGNc3SVxs54G3"}
{"genre": "bleakgaze", "spotify_playlist_url": "https://open.spotify.com/playlist/3n0cDB9weAiKtsTDXDayb5"}
{"genre": "finnish idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2XFcxayFDZXADbCqlSfSjK"}
{"genre": "taiwanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6b7wTToYe47ONWngJFcHwF"}
{"genre": "guam indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5VhS3i3cBW0RdGQU6nqGf7"}
{"genre": "galician jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/7iDIPfDUgSE0pHSngz8wsf"}
{"genre": "musica guineense", "spotify_playlist_url": "https://open.spotify.com/playlist/2kAaI38zh1c9oyzpoQUZiv"}
{"genre": "nova musica amazonense", "spotify_playlist_url": "https://open.spotify.com/playlist/4RwE62FqRp8gLKq8UrJy2b"}
{"genre": "swansea indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4nSrizFStxySLAXtAkJlkd"}
{"genre": "rap guineen", "spotify_playlist_url": "https://open.spotify.com/playlist/0pTqRAJ9YaeKXUNil5e2O3"}
{"genre": "seggae", "spotify_playlist_url": "https://open.spotify.com/playlist/0oRWlvK03L1chDnWkXWckh"}
{"genre": "maracatu", "spotify_playlist_url": "https://open.spotify.com/playlist/12BZfgEyxaotoT2ND1thrh"}
{"genre": "pohadky", "spotify_playlist_url": "https://open.spotify.com/playlist/2LWCWNdVk4bfLaaVMZVh6z"}
{"genre": "vintage taiwan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0lXwRRAsp3EUFdH5ynbVZc"}
{"genre": "old-time fiddle", "spotify_playlist_url": "https://open.spotify.com/playlist/272JEE1LOwGe3QjMOo59IX"}
{"genre": "psicodelia mexicana", "spotify_playlist_url": "https://open.spotify.com/playlist/6jVhvQipHoULFT0ioiQh7c"}
{"genre": "deep discofox", "spotify_playlist_url": "https://open.spotify.com/playlist/3pXHKCiWtjJj9q0fEaIA27"}
{"genre": "maloya", "spotify_playlist_url": "https://open.spotify.com/playlist/34Co5PeMuUQjCqP8s2c8sZ"}
{"genre": "afro-cuban traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1x7ttJPXcB6jJM51MRiG4I"}
{"genre": "musica brasiliense", "spotify_playlist_url": "https://open.spotify.com/playlist/1cAFBWUGxXphtu1uhf0WDT"}
{"genre": "telugu hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5o64kEr05AdJJYJHQXZRBb"}
{"genre": "slovenian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7Ha0CDWQegOljuglwjaq6u"}
{"genre": "south carolina metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5QvlUWldsaXIVHUzTmbhDx"}
{"genre": "rondalla", "spotify_playlist_url": "https://open.spotify.com/playlist/16DzCxbwc8oa5M9Vn7DTuA"}
{"genre": "choro contemporaneo", "spotify_playlist_url": "https://open.spotify.com/playlist/5q1J1NDNRmql9eRdW2FFOY"}
{"genre": "siberian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4yNDcPd0nDsvsVfbV1aWAY"}
{"genre": "polish ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/7pG25ZvJoouVIKkbGoA4kT"}
{"genre": "heavy psych", "spotify_playlist_url": "https://open.spotify.com/playlist/3nbLTvtWKV1z0vmY1ampJb"}
{"genre": "russian folk metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0FwI8YSp47qXoeuxJChIfC"}
{"genre": "cajun", "spotify_playlist_url": "https://open.spotify.com/playlist/56Ans10K2OrCDU63QQTHre"}
{"genre": "irish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4DQTzDMn0qfHZRt1NMk5A3"}
{"genre": "experimental black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2cEb7MiAT7Zml7vizxftJm"}
{"genre": "wellington indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2dKpz0qiy9g7MuP3qLNpRB"}
{"genre": "shakuhachi", "spotify_playlist_url": "https://open.spotify.com/playlist/7v6C5Eq5kz3YbqUyq490j8"}
{"genre": "muzica lautareasca", "spotify_playlist_url": "https://open.spotify.com/playlist/0uuJenmr9LuyismjkDaFd6"}
{"genre": "kinderliedjies", "spotify_playlist_url": "https://open.spotify.com/playlist/1YTbPotJq6t9xtCPWbsxs4"}
{"genre": "hammered dulcimer", "spotify_playlist_url": "https://open.spotify.com/playlist/7xCQgIZOLanZADeIagOOx7"}
{"genre": "faroese rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4MdZYecJOgWqR3vkRl6Fvy"}
{"genre": "belgian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/458j2uOah9F6jTXzX0xLtE"}
{"genre": "korean hyperpop", "spotify_playlist_url": "https://open.spotify.com/playlist/41BSPX8BOIC56WbTjJc06M"}
{"genre": "icelandic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4jfHKgbEhoROTsvGffMoMq"}
{"genre": "ambient fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/1kb290FxS2RxqU3ynl1X47"}
{"genre": "classical organ", "spotify_playlist_url": "https://open.spotify.com/playlist/56PPF7Jg6OuDFZtC5gSCSI"}
{"genre": "finnish blues", "spotify_playlist_url": "https://open.spotify.com/playlist/2MZlB7n6QqUMbSTne8xIxM"}
{"genre": "hot jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/35mjfFhJRcNTS9GpbmdOIW"}
{"genre": "starogradska", "spotify_playlist_url": "https://open.spotify.com/playlist/4yAZkbRWxLUEqjoFfxF6wq"}
{"genre": "war metal", "spotify_playlist_url": "https://open.spotify.com/playlist/18d9p6GrJV8IZRrZCwr5XM"}
{"genre": "adelaide punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7htXvrm3IoLgJGcmoTSE28"}
{"genre": "kashmiri hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5kJv7j4sS87iZsckrB4qMa"}
{"genre": "progressive technical death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2qKl9xYWzXTM65TG3PFmMc"}
{"genre": "traditional bluegrass", "spotify_playlist_url": "https://open.spotify.com/playlist/2imk6p7ApJgnOSuEs1Znn9"}
{"genre": "tennessee experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/2yZaGhmtFyRYuCHG8P2hyX"}
{"genre": "khasi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1MGNT653BMPq26C5RwlAtA"}
{"genre": "panamanian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5zOMhOIxrxt9ImR2I9q06R"}
{"genre": "jazzcore", "spotify_playlist_url": "https://open.spotify.com/playlist/52s2NxPEN2eTcR7Tx1CJLE"}
{"genre": "oriental classical", "spotify_playlist_url": "https://open.spotify.com/playlist/0grTiL0EW85nP5udOaUBxl"}
{"genre": "yu-mex", "spotify_playlist_url": "https://open.spotify.com/playlist/1Frk27X8mA30Oc4wxwHDT8"}
{"genre": "musica chiapaneca", "spotify_playlist_url": "https://open.spotify.com/playlist/0fCh9tw4GqocItKt88EB6v"}
{"genre": "musica indigena brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/5XKUixyz4Zt5HwsIKmJU52"}
{"genre": "austrian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/2RzvBAsSztYg07TK5XRiTB"}
{"genre": "scottish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/39BNzr8nfjiDxsByHyXnIG"}
{"genre": "goa trance", "spotify_playlist_url": "https://open.spotify.com/playlist/7iuklwaJAAJFkN7FEGPDvo"}
{"genre": "sludgecore", "spotify_playlist_url": "https://open.spotify.com/playlist/79xPl8AGKBVxYsdMUToAzR"}
{"genre": "atmospheric post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2sTxdHJ1Nf5vve4zmir510"}
{"genre": "mexican thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5q3keTqdsaQpOk6qHSf6nl"}
{"genre": "mevlevi sufi", "spotify_playlist_url": "https://open.spotify.com/playlist/6IIzecv9ksn3wZtoYUxwue"}
{"genre": "hard glam", "spotify_playlist_url": "https://open.spotify.com/playlist/7yKWB5C29XF5slfGSOA8kw"}
{"genre": "burkinabe pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1f3EkWxQLUCTXMNfSkqCWa"}
{"genre": "musica otavalena", "spotify_playlist_url": "https://open.spotify.com/playlist/4mpWT8u17Lpi7bMOrXPiJJ"}
{"genre": "indian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/30bNP7XBbpyF8Krpe3sgVi"}
{"genre": "nova musica maranhense", "spotify_playlist_url": "https://open.spotify.com/playlist/3ejnp6KkIXiZBWsCzujQ6K"}
{"genre": "acid idm", "spotify_playlist_url": "https://open.spotify.com/playlist/4yc86ER1kfXDvnKVEA7gKT"}
{"genre": "polish modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/178sTCIthFi5cU2KQNK4QD"}
{"genre": "mexican post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4iOtD7jyevmz37g72AcSnm"}
{"genre": "hazaragi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6gvKkBrQQqdP8gsJCT30Vw"}
{"genre": "estonian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5bi3LFgROReB9Pj4x6MfTj"}
{"genre": "pittsburgh indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5YLwbQ51ZpX888YWodZpv2"}
{"genre": "chamorro pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1g46wpqkCFpu3AIaJqRUzt"}
{"genre": "aggro chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/52JflXcdQmrfRhl97MT1O2"}
{"genre": "melodic doom", "spotify_playlist_url": "https://open.spotify.com/playlist/1MPMGTQ2WctsqYgtaI7AkF"}
{"genre": "greek indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZZhBbWXrnDizlASsfDH1N"}
{"genre": "french stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2xTOmn6xG4eR2nns5GE1Iy"}
{"genre": "lapland hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1f8Bn97KgjFabZaAYf15Vd"}
{"genre": "italian emo", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZdTFWf2Mn6XcII1FwSf9G"}
{"genre": "rap mocambicana", "spotify_playlist_url": "https://open.spotify.com/playlist/2EBFceCfnsuTzrVopJyGWG"}
{"genre": "native american metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0vG94HgHG3UD4kmxft0uMe"}
{"genre": "hypnotic techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0AMKoVVpxXFatz3BJwtdfz"}
{"genre": "vietnamese electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6LuWh1x0fOIdgftSeHlR7g"}
{"genre": "dambora", "spotify_playlist_url": "https://open.spotify.com/playlist/4ox171vaVWhPnEnsAYRhIi"}
{"genre": "shanghai indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1CKDPAYPv9QeMgLD8nmWhz"}
{"genre": "viola da gamba", "spotify_playlist_url": "https://open.spotify.com/playlist/7trkrHnBsGGGaQm3KJgVKP"}
{"genre": "convent", "spotify_playlist_url": "https://open.spotify.com/playlist/144rcyx6aMneSeqsoIaBOx"}
{"genre": "deep psytrance", "spotify_playlist_url": "https://open.spotify.com/playlist/0vGULw3evyLe96gOsFOmFT"}
{"genre": "poznan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3EFKSGzCh0NNWHWqs0lXsH"}
{"genre": "serbian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5RiI52cOum1hvPA7ktnrOR"}
{"genre": "surabaya indie", "spotify_playlist_url": "https://open.spotify.com/playlist/77zQ2lZmAeGFNHQAw2jWzQ"}
{"genre": "triangle indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1AkiJzybsK9zKc7m11lohJ"}
{"genre": "french emo", "spotify_playlist_url": "https://open.spotify.com/playlist/1d6f6Y2mLEgdYGIS1z7daV"}
{"genre": "portuguese jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2NXy82Atoz6QzvmxQ0rir3"}
{"genre": "slovenian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/60RyIsR1wt8rPHLilITQ6e"}
{"genre": "haryanvi ragni", "spotify_playlist_url": "https://open.spotify.com/playlist/5fr1qPUgDNqwwwOwUKegyP"}
{"genre": "indie canario", "spotify_playlist_url": "https://open.spotify.com/playlist/70C6u0olQKvzu0wTCul2dj"}
{"genre": "son jarocho", "spotify_playlist_url": "https://open.spotify.com/playlist/7m4rhZGOMq1x4FGZjF9oy1"}
{"genre": "japanese concert band", "spotify_playlist_url": "https://open.spotify.com/playlist/3gMqSTa0UJO6c8CQDtQ2OL"}
{"genre": "lovecraftian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3XiUfGn0daCb4CnghKUSCO"}
{"genre": "classic psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6QKAxYKU56FgMWM63OXa0f"}
{"genre": "reading", "spotify_playlist_url": "https://open.spotify.com/playlist/06jaFdgGApTdAScZ5FggYC"}
{"genre": "deep downtempo fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/5eS2fQlgTYZR6nMAkuKl5L"}
{"genre": "ngoni", "spotify_playlist_url": "https://open.spotify.com/playlist/2R0igwJVO0cZqjpLsiS7WY"}
{"genre": "dicsoites", "spotify_playlist_url": "https://open.spotify.com/playlist/5lnN5oU8PRwBjmgAJRLnya"}
{"genre": "austrian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0l7VGsrww9cdIVKWMqwhf2"}
{"genre": "cape breton folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1huHCOijpUblke7NFBgbvM"}
{"genre": "ambient industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/6SjDZKf8ke13f8E3v1XAQ8"}
{"genre": "guzheng", "spotify_playlist_url": "https://open.spotify.com/playlist/62YmdQvGERgbmh7j13RIxB"}
{"genre": "namibian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0jNjcxddxqe6vP1SSljXlA"}
{"genre": "latin shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/2c18XJtmWR962C1qAM6HAN"}
{"genre": "rap euskera", "spotify_playlist_url": "https://open.spotify.com/playlist/5ebuevcL5O3MAsu80HzDWn"}
{"genre": "dutch classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/3V8nD3NiWXtxPsaUhquOhC"}
{"genre": "german post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1zF0LnCMxw340KfckveaGM"}
{"genre": "bosnian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6A5yoV5rTi1YV0T1jWWQnX"}
{"genre": "banda militar", "spotify_playlist_url": "https://open.spotify.com/playlist/2mgpUBKjC5UMpf1sJip82u"}
{"genre": "protest folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1nc42Vh2sJrPr4iJtc9ebe"}
{"genre": "belgian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7s30KDxEKODMhyy7rkDmCt"}
{"genre": "classical mandolin", "spotify_playlist_url": "https://open.spotify.com/playlist/6VvLvmAEDn7AlNaYmtHfoE"}
{"genre": "bluegrass fiddle", "spotify_playlist_url": "https://open.spotify.com/playlist/2DOzLv2V28INol2KQFiI33"}
{"genre": "belgian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3vN5OnVDvYnm8F2taNk0LL"}
{"genre": "modern string quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/6rVc38cX36vBYPg4r4EYt9"}
{"genre": "free improvisation", "spotify_playlist_url": "https://open.spotify.com/playlist/2NMVEGeiUeIosCna7tcMUp"}
{"genre": "maltese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3IFbYkEU8E9etsAjTz5a1y"}
{"genre": "melodic progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6fvk63guE3C9CwuBHTnELe"}
{"genre": "nordnorsk rap", "spotify_playlist_url": "https://open.spotify.com/playlist/2qfvgK4Dgzyn2yXtdqYNhT"}
{"genre": "trap boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/0tonvjfHndaLNjlEfuMpXs"}
{"genre": "lastelaulud", "spotify_playlist_url": "https://open.spotify.com/playlist/6EGPEBVVMs1EgT7PuKitD0"}
{"genre": "icelandic punk", "spotify_playlist_url": "https://open.spotify.com/playlist/5fYzZTS6KvemIcfMTE5dhw"}
{"genre": "deep classic garage rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1u2o0fjATgppCGkkIRDyc8"}
{"genre": "chapman stick", "spotify_playlist_url": "https://open.spotify.com/playlist/00hzOt3QX6S2FEJZUokusO"}
{"genre": "gumbe", "spotify_playlist_url": "https://open.spotify.com/playlist/6W7VSK5UoZfdvmuebJOlMd"}
{"genre": "norwegian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4IJ1EV8PM6CfcpvorkQACQ"}
{"genre": "women's choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4vsDauJPmHBEIigU2GnY2p"}
{"genre": "koledy", "spotify_playlist_url": "https://open.spotify.com/playlist/5yypyMHNDrV74CIs4YpY39"}
{"genre": "polish psychedelia", "spotify_playlist_url": "https://open.spotify.com/playlist/0HoVEyV8Ywr90Wysl8PGJP"}
{"genre": "italian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/5IWPEblkRFpFY7hVDfi97O"}
{"genre": "musica queretana", "spotify_playlist_url": "https://open.spotify.com/playlist/1Q3zVmWcowTPxtSlY6Mvbr"}
{"genre": "australian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3u2VWLXqFGfp3YHZNsFZvn"}
{"genre": "norwegian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/6fGhwNDQy2BlYeoWGK4Akf"}
{"genre": "concertina", "spotify_playlist_url": "https://open.spotify.com/playlist/10tlXnx4tbeuzOacWhqx8Y"}
{"genre": "bandolim", "spotify_playlist_url": "https://open.spotify.com/playlist/1YyjDXxLn1KPLHMnN3B1F5"}
{"genre": "sacred steel", "spotify_playlist_url": "https://open.spotify.com/playlist/582CSS08pv0fDNkbzOjkXN"}
{"genre": "metal ecuatoriano", "spotify_playlist_url": "https://open.spotify.com/playlist/4cR1c9NaieHXwFyHA6LlpR"}
{"genre": "dusseldorf indie", "spotify_playlist_url": "https://open.spotify.com/playlist/38sXr5Q1jLp8tHt6FFOF7q"}
{"genre": "downtempo fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/7zD2SAStNfZ8oaEKfWe8gF"}
{"genre": "marathi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4O8R7oee0PTMSPVSJd8zFX"}
{"genre": "swedish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3Q8FKBZzN91orolWx5NalN"}
{"genre": "macedonian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/224aeR2sxjOgNyUWDyGtcw"}
{"genre": "boeremusiek", "spotify_playlist_url": "https://open.spotify.com/playlist/3WbtZlOoR4T1XmEcHhUJan"}
{"genre": "forest black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1dYuF5eAwrYfg7j9Z7Cmk0"}
{"genre": "swiss country", "spotify_playlist_url": "https://open.spotify.com/playlist/5fkSaHCkIJjZxl14up4NSh"}
{"genre": "full on groove", "spotify_playlist_url": "https://open.spotify.com/playlist/2lbHERHD6RghHnEbEORx67"}
{"genre": "haitian dance", "spotify_playlist_url": "https://open.spotify.com/playlist/1jQvTlkNbsXJfrvRG5jlEC"}
{"genre": "finnish modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0347Gq2PVivirfybqYlvcf"}
{"genre": "vocal ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/06lR5Yw2iNduDqRouzJgJK"}
{"genre": "chechen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/596RquQ1kpgCyJaDYZEKmC"}
{"genre": "arpa paraguaya", "spotify_playlist_url": "https://open.spotify.com/playlist/18ZywYbrAISwG84Hubuj5y"}
{"genre": "merida indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2X8MrKHJ9IwS4nIg2K4NTl"}
{"genre": "latvian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0hAZ6i8FsZikvHCAMfqvhN"}
{"genre": "hawaiian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0jFvYjzBeEgvfwJ0TSTNVm"}
{"genre": "sunset lounge", "spotify_playlist_url": "https://open.spotify.com/playlist/36rl8fYkSJS6szi6ZYezk4"}
{"genre": "tibetan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6NL5rfmN2Of7THQ68CEe9m"}
{"genre": "deep g funk", "spotify_playlist_url": "https://open.spotify.com/playlist/5aZ4lZlDtOUrxAOipWB3r8"}
{"genre": "new hampshire indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3EGkQbWSsyiWq4iDcNeMv8"}
{"genre": "vaikiskos dainos", "spotify_playlist_url": "https://open.spotify.com/playlist/5Wa6334bix3KvCzwThgNYR"}
{"genre": "italian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1Om5aoyuE7hxi1UVxcjffn"}
{"genre": "thai shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/4o4ELCTe2irPh64KDFzy9p"}
{"genre": "spanish progressive rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6YG4bN7FzZ562wTF5Cx0zC"}
{"genre": "slovenske chvaly", "spotify_playlist_url": "https://open.spotify.com/playlist/6yqR5Ss9IcNYzE5jVPgWyN"}
{"genre": "indiana indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0qAABudocDOtIevxGfCdgJ"}
{"genre": "early american folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2H7ENwdHUCEAdQuEYWSy9a"}
{"genre": "rap ecuatoguineano", "spotify_playlist_url": "https://open.spotify.com/playlist/0tg3I66mLBQgIf8DtKrfwZ"}
{"genre": "basel indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4nwdZdimMWgw2evDDGtQ6I"}
{"genre": "brazilian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0Q1Bwu1jOnw7Nob2UXWgEu"}
{"genre": "lowercase", "spotify_playlist_url": "https://open.spotify.com/playlist/0X48ayqAs9PQ2Z4wRe2YBb"}
{"genre": "rap malien", "spotify_playlist_url": "https://open.spotify.com/playlist/0sgOpFhZzxGQVvvxZei6fH"}
{"genre": "korean jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/0s5kSVps4n8Gxi1I4444LZ"}
{"genre": "scottish americana", "spotify_playlist_url": "https://open.spotify.com/playlist/3N5aACQHuW5K3DVecXbhnB"}
{"genre": "rap nica", "spotify_playlist_url": "https://open.spotify.com/playlist/0MR0ywJFvcXGzopwtW4Fg0"}
{"genre": "dark minimal techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0Y4FAiSXVLZms2IDy7BdsU"}
{"genre": "arab metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6GIfItyTdvjxKVVxkqfVpc"}
{"genre": "rotterdam indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2dvRnpJXpUnZYZ3Ufq7mAe"}
{"genre": "death industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/5Wh6LBCI5BX6VVLfkcJ1g6"}
{"genre": "musica tradicional dominicana", "spotify_playlist_url": "https://open.spotify.com/playlist/7ttM7mbHnvZkHxX8Ogi1ot"}
{"genre": "indonesian shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/0cpgslNIkmPPcHzZcSHrLE"}
{"genre": "finnish post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/72rILJ1Fw18i5bRYWoOuhd"}
{"genre": "lagu iban", "spotify_playlist_url": "https://open.spotify.com/playlist/7y00fhiUdviML8AhwU7NUL"}
{"genre": "south african modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6IJFcwLq8F7ZXUXhgARazn"}
{"genre": "british classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/1B6F2FbtDNniCVjROeU0ga"}
{"genre": "viet instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/21wDGffpNPXROzcaqp3Y0a"}
{"genre": "combos nacionales", "spotify_playlist_url": "https://open.spotify.com/playlist/1IZ5CRB42uic6y9nalS8MP"}
{"genre": "benga", "spotify_playlist_url": "https://open.spotify.com/playlist/7jAbh7lCrzQWvRguJ3cjWn"}
{"genre": "rock caipira", "spotify_playlist_url": "https://open.spotify.com/playlist/3WBAHOaeWC5YPm6x72cfpv"}
{"genre": "medway sound", "spotify_playlist_url": "https://open.spotify.com/playlist/0lkaBqKBytY4HfdLupBYbL"}
{"genre": "edo old school", "spotify_playlist_url": "https://open.spotify.com/playlist/4GP7nQoyicnQKufo2XZ9yp"}
{"genre": "karbi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/1j6LkgdM5WA4Gc6mjrkrE8"}
{"genre": "techno argentina", "spotify_playlist_url": "https://open.spotify.com/playlist/04dSMOnptctsP9ssfQK01z"}
{"genre": "ukrainian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0W9zWriThPyQw3kmq6xJ1e"}
{"genre": "folk siciliana", "spotify_playlist_url": "https://open.spotify.com/playlist/02bWbrKu0xnt5nt1S6xCCU"}
{"genre": "nyckelharpa", "spotify_playlist_url": "https://open.spotify.com/playlist/3LnGqeSqeeFXTuKb9SPWsV"}
{"genre": "malang punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2CZdtxWA0si9PFhWl51h7C"}
{"genre": "noise", "spotify_playlist_url": "https://open.spotify.com/playlist/2LEnJ6o2VPcB8R7jGfZuNJ"}
{"genre": "via", "spotify_playlist_url": "https://open.spotify.com/playlist/7jQOGlnJXVTaq3NW9Z6Pdp"}
{"genre": "cuban funk", "spotify_playlist_url": "https://open.spotify.com/playlist/2HM8sYzrJuQiQktMmkJRUA"}
{"genre": "british brass band", "spotify_playlist_url": "https://open.spotify.com/playlist/0ccmoySgXs0AELQNSidOup"}
{"genre": "sufi chant", "spotify_playlist_url": "https://open.spotify.com/playlist/3Beo8BxMMRYA8knDzzz5H4"}
{"genre": "brazilian metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2lybnXPgntmfOoxDm31UQR"}
{"genre": "experimental dub", "spotify_playlist_url": "https://open.spotify.com/playlist/0iV2b6EaTAeHyUnZkCRVDc"}
{"genre": "greek punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1Hi36iC4WJj9tr7pqGUvp0"}
{"genre": "vintage reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/25CjEWHDPPGlQGFikVAGzO"}
{"genre": "contemporary classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/5ouCntxKITX88EkEogQZjz"}
{"genre": "dutch punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4ugRlcdNbQyQ295ckN6ZPx"}
{"genre": "finnish tango", "spotify_playlist_url": "https://open.spotify.com/playlist/3UKdkSRc7cRlLvSH9EPyC2"}
{"genre": "salzburg indie", "spotify_playlist_url": "https://open.spotify.com/playlist/56bVlmhPJ7OfRjMIfA2TBQ"}
{"genre": "musica cearense", "spotify_playlist_url": "https://open.spotify.com/playlist/1JuNWLFhawInDMeE6ZNsEG"}
{"genre": "irish accordion", "spotify_playlist_url": "https://open.spotify.com/playlist/2YLa9JlRnHaBVG5cSWxdyY"}
{"genre": "mathgrind", "spotify_playlist_url": "https://open.spotify.com/playlist/3SbmBdyPiGj7fBc36n7BxE"}
{"genre": "canti alpini", "spotify_playlist_url": "https://open.spotify.com/playlist/4Vv4phL116mpFgpLRb5BVV"}
{"genre": "bhutanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3DdlWboehKDjvM688R25I3"}
{"genre": "frankfurt indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0Av2pdWJqTIoVGKEVQjojm"}
{"genre": "barrelhouse piano", "spotify_playlist_url": "https://open.spotify.com/playlist/7FdGVAxDb8iB96NFXOiVMe"}
{"genre": "tongan pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6YfW0Ao3gHA2b7G27fhpKj"}
{"genre": "black sludge", "spotify_playlist_url": "https://open.spotify.com/playlist/0fe5Mzpe1pImBgYciFmiYo"}
{"genre": "shoegaze chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/0ESFh6xLpxYJiZydexEieU"}
{"genre": "peruvian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3CDvBbpv7CfiK7V7hxeHBd"}
{"genre": "math rock latinoamericano", "spotify_playlist_url": "https://open.spotify.com/playlist/2Cc6vHEUJZBHAyoeepJZzY"}
{"genre": "c64", "spotify_playlist_url": "https://open.spotify.com/playlist/7xVNaEai3Tk9uOZ2p3sdg5"}
{"genre": "fado instrumental", "spotify_playlist_url": "https://open.spotify.com/playlist/2w0tfXHDvjHmSqZ3Pi1OuJ"}
{"genre": "danish classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3u0sfPBO7pfMn3FKWPWAKq"}
{"genre": "rap gabonais", "spotify_playlist_url": "https://open.spotify.com/playlist/2DgfeiusWLK3thQY0IkNop"}
{"genre": "rwandan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/3v28ubcYwgljeOpgMDV6zm"}
{"genre": "demoscene", "spotify_playlist_url": "https://open.spotify.com/playlist/41x6s1VU0XUKV4TlvB7dEn"}
{"genre": "tajik pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4mh0GeHzEkgPkVrCxsKQpM"}
{"genre": "rez country", "spotify_playlist_url": "https://open.spotify.com/playlist/2t478T5CCDyRz9IwV8mE4V"}
{"genre": "veena", "spotify_playlist_url": "https://open.spotify.com/playlist/6GRRlIuSXWKDB2uVxCTLaT"}
{"genre": "power electronics", "spotify_playlist_url": "https://open.spotify.com/playlist/5kAulE1JAusA4SlfP0OjYG"}
{"genre": "musica morelense", "spotify_playlist_url": "https://open.spotify.com/playlist/5nXWnOztmVjLqGV57VBk6F"}
{"genre": "russian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6M7wIo9NQLnHAnSVcnwwyd"}
{"genre": "south african metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1VdhLpUxXQT2SN1Vnum7Eu"}
{"genre": "leon gto indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4Aq9WJgae8vjDQWFMiJsLM"}
{"genre": "indie fuzzpop", "spotify_playlist_url": "https://open.spotify.com/playlist/0gg6YYDoengmalHZ8mnHAP"}
{"genre": "oeteldonk", "spotify_playlist_url": "https://open.spotify.com/playlist/3LhAq4OTC09y9SsmoZFkx2"}
{"genre": "chamber choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4AJt3YNYYGQiRKEHzXVv7w"}
{"genre": "seychelles pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3z3rD6dF7UJPNeYmRBDetF"}
{"genre": "german rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/36XpvcXMR4i1VeKqRaHjOF"}
{"genre": "djecje pjesme", "spotify_playlist_url": "https://open.spotify.com/playlist/6OmE8oewLNTyLZu7CfpEtz"}
{"genre": "folk metal latinoamericano", "spotify_playlist_url": "https://open.spotify.com/playlist/1dB6n4Nqw4Di2OseuSOFuA"}
{"genre": "baps", "spotify_playlist_url": "https://open.spotify.com/playlist/6xPSm4RMB2hFf2IPsicWdI"}
{"genre": "steelpan", "spotify_playlist_url": "https://open.spotify.com/playlist/4sJZ53JDyryVhDLcUFARLL"}
{"genre": "sda choir", "spotify_playlist_url": "https://open.spotify.com/playlist/33fTpOhYOi1MfQXXAvqomk"}
{"genre": "rio grande do sul indie", "spotify_playlist_url": "https://open.spotify.com/playlist/34WeHDUbOzCgLD3ahlQwEN"}
{"genre": "illbient", "spotify_playlist_url": "https://open.spotify.com/playlist/1Me0qExIlbW7FgONEbkZE4"}
{"genre": "ryukoka", "spotify_playlist_url": "https://open.spotify.com/playlist/5qDufC8I9t3EVumsy0ZRAR"}
{"genre": "occult black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6gvTpjogFak3cTvAe2UcPO"}
{"genre": "lesotho traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/4G7wNUIVBC5vUk7aWdbIcn"}
{"genre": "denver rap", "spotify_playlist_url": "https://open.spotify.com/playlist/21XPGPsghJTjnFvzVX8wUe"}
{"genre": "sundanese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/739Ostt8uJHEesGujUjoh1"}
{"genre": "coptic hymn", "spotify_playlist_url": "https://open.spotify.com/playlist/2aSLhgGabkzY9488onYezH"}
{"genre": "marrabenta", "spotify_playlist_url": "https://open.spotify.com/playlist/2TX3gfOXHHoHZiMLK0SVmq"}
{"genre": "belgian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5knZIAyIrFjOBLaqaLa5AN"}
{"genre": "irish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3vtNM3t1XaVyyu38aY7r8m"}
{"genre": "latvian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/511jonbPzmVIAWUgH3PzCw"}
{"genre": "cuatro puertorriqueno", "spotify_playlist_url": "https://open.spotify.com/playlist/2LLPME17PY6gYqDY8Rfvr8"}
{"genre": "spanish post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6G9ArXMsllECGSMB2BuG5Y"}
{"genre": "italian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/2fwbem3okAolbotKZaFsk2"}
{"genre": "deep hardtechno", "spotify_playlist_url": "https://open.spotify.com/playlist/4c48q14BOjzJoT1sYigoIQ"}
{"genre": "tuna universitaria", "spotify_playlist_url": "https://open.spotify.com/playlist/2qY73DcwMKoAV4JAfyXgD0"}
{"genre": "neo-manele", "spotify_playlist_url": "https://open.spotify.com/playlist/0xqiGIJFLCENmI5hSxuFdI"}
{"genre": "finnish choir", "spotify_playlist_url": "https://open.spotify.com/playlist/1o2j62emAHuERgjPZaI362"}
{"genre": "greek techno", "spotify_playlist_url": "https://open.spotify.com/playlist/7chfLI5b4xLB4V1JWaDKv7"}
{"genre": "uk post-metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5ls1UJ1dPxJh3t0W7C8m6R"}
{"genre": "vintage country folk", "spotify_playlist_url": "https://open.spotify.com/playlist/34X13zwfKF95I5PKO6GEKk"}
{"genre": "japanese dub", "spotify_playlist_url": "https://open.spotify.com/playlist/1VlLDwrmsHR9hVjN2jroDJ"}
{"genre": "qanun", "spotify_playlist_url": "https://open.spotify.com/playlist/2F5lFpyiAqk9JmhCnA5DHr"}
{"genre": "trikiti", "spotify_playlist_url": "https://open.spotify.com/playlist/3afEVFqOSkek2AWlSPK9Mo"}
{"genre": "latin surf rock", "spotify_playlist_url": "https://open.spotify.com/playlist/78zBtTmgkplb8MUI3Fijek"}
{"genre": "japanese orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/01Bay8ZGqdAWbrmLhilR3s"}
{"genre": "alternative metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1K1miemY3uR2aCmNhNHCqd"}
{"genre": "italogaze", "spotify_playlist_url": "https://open.spotify.com/playlist/2NBLHCkoQ4r1KBgc5gOe8J"}
{"genre": "australian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/5C9kvuGBcAUNipqfGNmq83"}
{"genre": "nz alternative rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3A7CVlw4TJfIFZ9PVREXu2"}
{"genre": "guitar case", "spotify_playlist_url": "https://open.spotify.com/playlist/0ZEV56fLOnyx0lWRueQwhO"}
{"genre": "metal gaucho", "spotify_playlist_url": "https://open.spotify.com/playlist/4IPVfom5hEdsiEVGp98Khr"}
{"genre": "derry indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4AM0E5leywuFaBMUmKlo4N"}
{"genre": "lowlands hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4rSQrZ0wzYg0caXe7mcFqU"}
{"genre": "chamame brasilero", "spotify_playlist_url": "https://open.spotify.com/playlist/7FGwrNTrJMkxQk3Q19lTKt"}
{"genre": "ritual ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/7hba9sj7V4V5XJed89pVrU"}
{"genre": "chinese post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5L5KQye8CH1VgsYwmTTAxg"}
{"genre": "french post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/66GxbkUX9OZikMgn338pz6"}
{"genre": "classic australian country", "spotify_playlist_url": "https://open.spotify.com/playlist/3s3zindCeXj6wbEpjlP6xX"}
{"genre": "yoik", "spotify_playlist_url": "https://open.spotify.com/playlist/53pmQn6lXF6m5WViERilQF"}
{"genre": "german orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/4T0zoIQXRtYSYnT32DCoPW"}
{"genre": "classical clarinet", "spotify_playlist_url": "https://open.spotify.com/playlist/5hFhIObUIeucCv8VHhF1hT"}
{"genre": "russian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/0MPcCFrxUzQasz99MPXfBf"}
{"genre": "galician indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1nJv9YpODF9VdIg4zpHPGl"}
{"genre": "dub poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/35N5o8M6G8REBIlKI2rIni"}
{"genre": "dortmund indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5laz28pNMW5qnvxtOGDjgP"}
{"genre": "brno indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2R43pT4MhjcaNqZPilGtkI"}
{"genre": "myanmar gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/63JBbm0yTIZ9k1cjZRfmCw"}
{"genre": "ugandan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7osrkj0fpqswzvJuTvhpLF"}
{"genre": "pops orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/4lsam4Ai2qBD2z5c48CJc5"}
{"genre": "belgian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5JtBncEEG7c7v61vzjlyuW"}
{"genre": "baroque ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/0xStZ7FTPxyUc7wuj8MkLW"}
{"genre": "norwegian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/69pKDUYxS5H6u2xFsvHTvg"}
{"genre": "russian orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/6qvDzwwyh61Er42eBjFVeK"}
{"genre": "gaita", "spotify_playlist_url": "https://open.spotify.com/playlist/0QOMzxeAATjlhQSckJMqhR"}
{"genre": "mexican techno", "spotify_playlist_url": "https://open.spotify.com/playlist/0mLv4jNcPg09rJfLfhblHS"}
{"genre": "swedish fiddle", "spotify_playlist_url": "https://open.spotify.com/playlist/7KqcX5BTL17wPsP7Aq0rN3"}
{"genre": "macedonian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6QhGqu20k2xKLxKDMft5H1"}
{"genre": "italian doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3bIr8LlEXo2Qg2efV91gRF"}
{"genre": "yakut pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3H2aC6nJR4L39KCCI0Pcg8"}
{"genre": "brockton hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0QXxPjOe7pTq0MQdanjWrx"}
{"genre": "nz punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4SWc6Jiz6Tf6Oi48LjJomU"}
{"genre": "irish fiddle", "spotify_playlist_url": "https://open.spotify.com/playlist/2xqUVVwHeAeyl8PvtPPcFm"}
{"genre": "finnish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/3jyyfQn4I5SOTmaOZQ1NSK"}
{"genre": "coldwave", "spotify_playlist_url": "https://open.spotify.com/playlist/2KpqbUyQjQOcbISiQmUm4s"}
{"genre": "portsmouth indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0FjKERsuGxPRoHKcyILePB"}
{"genre": "romanian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/69gDbw6nnW6DRhaCmsNwQf"}
{"genre": "french renaissance", "spotify_playlist_url": "https://open.spotify.com/playlist/495wgS8hTHf6bcIVjOdClc"}
{"genre": "sarod", "spotify_playlist_url": "https://open.spotify.com/playlist/0LB5NqzX7GPgyTd6T1rxaw"}
{"genre": "fort wayne indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0H95fS5W9aklfBdcfmysVU"}
{"genre": "turkish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0Nq3VKfylddr8Ujj7sOvY8"}
{"genre": "volkstumliche musik", "spotify_playlist_url": "https://open.spotify.com/playlist/6rjQwc6Gy9e0MLYZKOs6yr"}
{"genre": "firenze indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6Lf0nQTwJHF2BIqZWI1KST"}
{"genre": "canadian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/5U3GNko34JUJg2j4sTQpGb"}
{"genre": "musica sergipana", "spotify_playlist_url": "https://open.spotify.com/playlist/3aR3QARYr1vxrp9hQlfOEq"}
{"genre": "indonesian neo-psychedelia", "spotify_playlist_url": "https://open.spotify.com/playlist/77YVm5eFKT8llUPNQoFnhW"}
{"genre": "keller synth", "spotify_playlist_url": "https://open.spotify.com/playlist/2fYiU3k0BbJEyIYro4tbOJ"}
{"genre": "cifteli", "spotify_playlist_url": "https://open.spotify.com/playlist/10639MF2wMXj5N2VtUjLSa"}
{"genre": "gothic doom", "spotify_playlist_url": "https://open.spotify.com/playlist/1rpCUMoi2C2YUe67ZPSdC4"}
{"genre": "tarantella", "spotify_playlist_url": "https://open.spotify.com/playlist/35YknEfHHGIYnFZ8IU5pu5"}
{"genre": "drama", "spotify_playlist_url": "https://open.spotify.com/playlist/6vx1kgPpIzxF492o7ShEvf"}
{"genre": "finnish hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6WlczMff7aDWRAux11Pj9M"}
{"genre": "quebec hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5QfnA78JvJkwlV0IHJSYrA"}
{"genre": "swedish emo", "spotify_playlist_url": "https://open.spotify.com/playlist/2aIwwGSay614PUmlynXBt1"}
{"genre": "swedish contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6a9wcpR5AqYMVe1bNO2LP9"}
{"genre": "rap toscana", "spotify_playlist_url": "https://open.spotify.com/playlist/24R9qi4ZTmvnCGJnjg3eqn"}
{"genre": "sotalaulut", "spotify_playlist_url": "https://open.spotify.com/playlist/1PcchmaFs6UcnBY3lNpcZU"}
{"genre": "deep filthstep", "spotify_playlist_url": "https://open.spotify.com/playlist/1gId0ogv6JOy3be2t736DE"}
{"genre": "deep eurodance", "spotify_playlist_url": "https://open.spotify.com/playlist/2xuduhoWA5fxvaeYjuvcBk"}
{"genre": "brass band brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/1KED9gpGOnUAKU9ChGCekB"}
{"genre": "modern chamber music", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZSIOKuqBJaJz1MEniEaSv"}
{"genre": "south african punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7iWaRvvdUdD9fOWXkbuRlZ"}
{"genre": "medimeisterschaften", "spotify_playlist_url": "https://open.spotify.com/playlist/5XYIViN8Qtf4fGLwU6Bb5q"}
{"genre": "indie poblano", "spotify_playlist_url": "https://open.spotify.com/playlist/5wHyXAhiWuSn3kfR6lMxUC"}
{"genre": "trondheim indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1KO29VXKVt1zMzch57JlRU"}
{"genre": "israeli punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZwZOvNwDT4ctrht4TiYAp"}
{"genre": "dutch underground hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6XAxPvvQuPY8Jvnym6dbga"}
{"genre": "chinese reggae", "spotify_playlist_url": "https://open.spotify.com/playlist/3OSFhi0ovn7gMQ1Q4dcIjz"}
{"genre": "isle of man indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4JlP9kDXVaSJwZx4noq3Zf"}
{"genre": "magyar musicalek", "spotify_playlist_url": "https://open.spotify.com/playlist/0WQJSIKafYcOm9LQCMEWZR"}
{"genre": "bernu dziesmas", "spotify_playlist_url": "https://open.spotify.com/playlist/42dGKCvDkq9aLYNzKwatSu"}
{"genre": "radio symphony", "spotify_playlist_url": "https://open.spotify.com/playlist/1xIrUwLiU9RkiEDACmlVip"}
{"genre": "decije pesme", "spotify_playlist_url": "https://open.spotify.com/playlist/0fMppBnnpTyT9yQVqRG2q2"}
{"genre": "re:techno", "spotify_playlist_url": "https://open.spotify.com/playlist/3EBxpq1yqXbPgYmmnLyJxg"}
{"genre": "raw black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/30JRpbUft5atDSyBhiolPZ"}
{"genre": "metal paranaense", "spotify_playlist_url": "https://open.spotify.com/playlist/0p7jyBh26hLVzUkGvPuRzZ"}
{"genre": "oulu indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0c63TNJqqGvaYq5VxndOAQ"}
{"genre": "ancient mediterranean", "spotify_playlist_url": "https://open.spotify.com/playlist/3NOxMf5RZTnCXdC3qrqCxB"}
{"genre": "ohangla", "spotify_playlist_url": "https://open.spotify.com/playlist/2Y1P5x9JbzVwBLeVrb7ucR"}
{"genre": "idol game", "spotify_playlist_url": "https://open.spotify.com/playlist/5c0efazHur2H93z7zI5tl1"}
{"genre": "cello ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/45XLPAnCVQkyaMPDzvu734"}
{"genre": "indie paraense", "spotify_playlist_url": "https://open.spotify.com/playlist/7j7BJ4le34bKBYM4lJYJFe"}
{"genre": "rap alagoano", "spotify_playlist_url": "https://open.spotify.com/playlist/0kTYWMdOnfg1y8KFA5c5Vn"}
{"genre": "musica prehispanica", "spotify_playlist_url": "https://open.spotify.com/playlist/0eG7lHRXnfTMVTSYwdkFhw"}
{"genre": "taiwan classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/69Vpu8wWrHTQvBA1hzndZW"}
{"genre": "clawhammer banjo", "spotify_playlist_url": "https://open.spotify.com/playlist/5b3ce3FIod5FdBxsshVYIV"}
{"genre": "romanian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4V4SQib4kWQwGzPfZ8BV27"}
{"genre": "missouri indie", "spotify_playlist_url": "https://open.spotify.com/playlist/79BDtjelsQijccPGnV7tGT"}
{"genre": "spanish classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/22p4K2fHv3OEmaAQeXFs8y"}
{"genre": "polish experimental electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/7C8E5QgIfbJXb55XOrhe3b"}
{"genre": "italian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5jsIFtPehy6NQmbRMwVyD3"}
{"genre": "classic latvian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2vatjytJmQE3r4SDyWi8hV"}
{"genre": "jazz dominicano", "spotify_playlist_url": "https://open.spotify.com/playlist/0JHJOUHisdPrMnMbQqPLZ6"}
{"genre": "botswana hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/1wtr5dUZ2Fwc4D3Iu1DCdp"}
{"genre": "shib", "spotify_playlist_url": "https://open.spotify.com/playlist/1yy0pwB6W2vuRBuIG6cLQt"}
{"genre": "electroacoustic improvisation", "spotify_playlist_url": "https://open.spotify.com/playlist/2jGo6vr6swUBugWe7n2bzj"}
{"genre": "west virginia metal", "spotify_playlist_url": "https://open.spotify.com/playlist/51Rs3akj3hc4c8XClo8LMK"}
{"genre": "lute", "spotify_playlist_url": "https://open.spotify.com/playlist/52VptovPDaoqCMZm1dzIcP"}
{"genre": "indie boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/3nrjV5WWz2wYMDb965XxQa"}
{"genre": "oratory", "spotify_playlist_url": "https://open.spotify.com/playlist/7bTaT6ImEJpkPb3OzYzk2Z"}
{"genre": "austrian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/3suLYeJHg2ANaSgtN0PnAA"}
{"genre": "karen pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6g7ZllHKFKiJWlE8O3wUhR"}
{"genre": "syro-aramaic chant", "spotify_playlist_url": "https://open.spotify.com/playlist/6zYwJZgdonpz6IfOM0LJos"}
{"genre": "chill-out trance", "spotify_playlist_url": "https://open.spotify.com/playlist/2TZYaVQjU4v0HIzwOsgo0E"}
{"genre": "balalaika", "spotify_playlist_url": "https://open.spotify.com/playlist/66zlv1OjzOvFp5Keh7eflO"}
{"genre": "vintage norwegian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2CyDpwN7rYjdYcExg1pEho"}
{"genre": "kompa chretien", "spotify_playlist_url": "https://open.spotify.com/playlist/3y2utCl5HkIG1gegMzoJGp"}
{"genre": "instrumental death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6BTRm34kIuBgr2YtPKVDtO"}
{"genre": "mizo gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/0qlsMDZIWNe3hWflzP6oVh"}
{"genre": "bern indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3MT6eictU27U5iyC5zX8d2"}
{"genre": "san antonio indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3FJZxcUxT0pnCRNeFoO84k"}
{"genre": "rap sergipano", "spotify_playlist_url": "https://open.spotify.com/playlist/3Sh4VMQ9nxOjw2EWn4omoa"}
{"genre": "japanese melodic hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5my2tRvZRn2bjVMsWtZmuG"}
{"genre": "fisarmonica", "spotify_playlist_url": "https://open.spotify.com/playlist/3NN5dcWIgMWa2pz4hhubJb"}
{"genre": "jug band", "spotify_playlist_url": "https://open.spotify.com/playlist/1JEkVeDauPlvYRDE6sOcGJ"}
{"genre": "drone rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6LBhebheTgp2kzcOJhHsuP"}
{"genre": "post-punk brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/7AUHk8lhB0F5FdLw4afbHz"}
{"genre": "musica folk asturiana", "spotify_playlist_url": "https://open.spotify.com/playlist/6f7Oxx42lZDo9zQlKS2xWp"}
{"genre": "swedish ebm", "spotify_playlist_url": "https://open.spotify.com/playlist/5Cc9X1cxRIn1WJuLTGrcju"}
{"genre": "french rock-and-roll", "spotify_playlist_url": "https://open.spotify.com/playlist/7rgZxT8hUhdyyhHSPjOiwx"}
{"genre": "oxford choir", "spotify_playlist_url": "https://open.spotify.com/playlist/6BuTzpsrq8QUS1vI0HiEVc"}
{"genre": "lombok indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4q1x2DRR89SHVqxkRqSyvY"}
{"genre": "tamburica", "spotify_playlist_url": "https://open.spotify.com/playlist/72YvCUCAsq0K5WD114It0J"}
{"genre": "austrian stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4ex3MtrvMThnpygNXuecbS"}
{"genre": "luxembourgian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0LSkh5924Qd0PihnyVM3v0"}
{"genre": "modern mod", "spotify_playlist_url": "https://open.spotify.com/playlist/4sW1wJHqw9ji6cJ3dAs1vZ"}
{"genre": "reggae boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/0dElcVhTqRMLQjtlAOMJ3u"}
{"genre": "tuvan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/23UmyAFS2tQ8P5QWAXo6wn"}
{"genre": "canadian shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/3htnWU03tCAZxRKAo5EUqR"}
{"genre": "hong kong tv drama", "spotify_playlist_url": "https://open.spotify.com/playlist/3LM0Q5NZLXlRvGRtLl4hFz"}
{"genre": "chinese new year", "spotify_playlist_url": "https://open.spotify.com/playlist/3mGatBOEASsNJvNPI3Penj"}
{"genre": "skweee", "spotify_playlist_url": "https://open.spotify.com/playlist/35woouyNDBZLI0bKnZmE3s"}
{"genre": "diy pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/7f3xtPzz6uvPzsgMSMGgdB"}
{"genre": "italian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/0TwTZK6NU4aTwNvDYGePPN"}
{"genre": "swedish choir", "spotify_playlist_url": "https://open.spotify.com/playlist/03Kzx4JpyGKAbhmLSF96Kk"}
{"genre": "muzica bisericeasca", "spotify_playlist_url": "https://open.spotify.com/playlist/5K4tFipiw5jFc3RQgB57jO"}
{"genre": "galway indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4O98ez3C25Ot2ZjA0J540a"}
{"genre": "new england hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5m2WE1PHyGsVMnGP6Gvdpb"}
{"genre": "rock catracho", "spotify_playlist_url": "https://open.spotify.com/playlist/6LnVOuVEY0M8zOYUkZDmAz"}
{"genre": "chinese metal", "spotify_playlist_url": "https://open.spotify.com/playlist/56w4CTZ5B1kCuJfw0IEmrk"}
{"genre": "neo-trad prog", "spotify_playlist_url": "https://open.spotify.com/playlist/2jjhSbwhv2gNJh0ARmW0A2"}
{"genre": "iraqi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/39W41IKr0qeGfHkMGZRgUz"}
{"genre": "jazz chileno", "spotify_playlist_url": "https://open.spotify.com/playlist/0NTwRY6l0oyeMVA6pAuq7G"}
{"genre": "bosstown sound", "spotify_playlist_url": "https://open.spotify.com/playlist/2rhVyRH4zucYiCMBlayKY8"}
{"genre": "japanese black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6tPZbh64wYuxEKSynffYk2"}
{"genre": "rominimal", "spotify_playlist_url": "https://open.spotify.com/playlist/6tbzdys5a2LP2dKaCaIvAB"}
{"genre": "ohio hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/356WDTnHgMReMxZpjAA1FC"}
{"genre": "hungarian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3PQxBteiuz7OJGOvjjj7Lb"}
{"genre": "finnish psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3YYCtoClqVQZxgvG3nzVLH"}
{"genre": "rap paraguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/6gw9Xl5YY0F6wh6stb2uMZ"}
{"genre": "hypertrance", "spotify_playlist_url": "https://open.spotify.com/playlist/3O5yTBh7Y28RTYRWqqv9eg"}
{"genre": "canzone siciliane", "spotify_playlist_url": "https://open.spotify.com/playlist/4uoEHkaVhlvgoCTF5PFJMg"}
{"genre": "christian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1hZEnZ5B3e9W5btI9zC4Fk"}
{"genre": "irish contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/69AS6y3vT3IRvzBiPwvqP9"}
{"genre": "swazi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/5F1lc49YcCuT6fEQsgv8lw"}
{"genre": "australian shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/4SraIxQeuuXNWKokMAZvhl"}
{"genre": "nubian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/2fv5wnCHoqJtxmaq9IAsiV"}
{"genre": "classic ukrainian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/0J0tDTwFnu3cY1nz5HyjkE"}
{"genre": "staff band", "spotify_playlist_url": "https://open.spotify.com/playlist/398I0lLuTptOpaf2ak03Az"}
{"genre": "traditional southern folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5bzKsMKgIihhxD41MaKpno"}
{"genre": "rock alagoano", "spotify_playlist_url": "https://open.spotify.com/playlist/3T48egMTtOU0rArLRiuw4W"}
{"genre": "indie sudcaliforniano", "spotify_playlist_url": "https://open.spotify.com/playlist/3mJlrxwg9yquqVhNbn0Wy3"}
{"genre": "trap kreyol", "spotify_playlist_url": "https://open.spotify.com/playlist/4NGiic0EBZXngL8QOk9JKs"}
{"genre": "catalan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5u9pZQoofDO0UjHvSplvoO"}
{"genre": "jazz tico", "spotify_playlist_url": "https://open.spotify.com/playlist/3vwdMfg3WDnvKceVdxToTZ"}
{"genre": "russian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Vmrzb8WLxoZzUX7pQ5SRX"}
{"genre": "ringtone", "spotify_playlist_url": "https://open.spotify.com/playlist/24nFbemYXcm4Ep56SCHQdR"}
{"genre": "danish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0WVDWzuPGZQCeFZ1DDMDN6"}
{"genre": "singaporean metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0TmeJxeWPan6welHARw9FS"}
{"genre": "muzica ardeleneasca", "spotify_playlist_url": "https://open.spotify.com/playlist/3pouQuoUV0BHp6yMFYq3iH"}
{"genre": "russian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/6PoVHvnlFi25tA4wKlqnDN"}
{"genre": "cuban electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/6mfmE5J5KZqQpFnpOnBlcA"}
{"genre": "austrian orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/1IOnsLx8RVuGwGVvOZIXhJ"}
{"genre": "icelandic traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/0AfJlTZlS2vAljOovY9Fag"}
{"genre": "bulgarian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6tQ9lxPQZazIl7NzChB3Ad"}
{"genre": "kannada indie", "spotify_playlist_url": "https://open.spotify.com/playlist/64jM5U2bmNPbAkjZnS9DQv"}
{"genre": "musica piauiense", "spotify_playlist_url": "https://open.spotify.com/playlist/5i7C215uzusGrLt4aopH3q"}
{"genre": "kol isha", "spotify_playlist_url": "https://open.spotify.com/playlist/1tbSAdjTEHbpLzFoam6IJI"}
{"genre": "terrorcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0dsJzRtGo230e23L34hllR"}
{"genre": "lagu maluku", "spotify_playlist_url": "https://open.spotify.com/playlist/7CCAguYh80dpcFURxzwzQ8"}
{"genre": "houston indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6UfbwvRitXs5YLmPg8prFL"}
{"genre": "rap nortista", "spotify_playlist_url": "https://open.spotify.com/playlist/55x8ZVtEKgpOHmLbidRFeh"}
{"genre": "cathedral choir", "spotify_playlist_url": "https://open.spotify.com/playlist/000JNk5oR24GsGgz1XXtif"}
{"genre": "folclore portugues", "spotify_playlist_url": "https://open.spotify.com/playlist/3weJSiTAEBXFb2GGzQdzDH"}
{"genre": "croatian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2gQSoiXsgD9wpAp9aSdfMd"}
{"genre": "svensk indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2QOZ1b1IpsYufy9bQgrpLP"}
{"genre": "paraguayan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2Kig10nWiTUVz0WxAaUF3d"}
{"genre": "musique urbaine brazzaville", "spotify_playlist_url": "https://open.spotify.com/playlist/6dyVV8d7TTJmws5jFNJHX9"}
{"genre": "cumbia funk", "spotify_playlist_url": "https://open.spotify.com/playlist/2iwEKZJ9FRQMGTU9cn131i"}
{"genre": "industrial hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4SuEoxbyTWZvBG1cmnp2mq"}
{"genre": "pilates", "spotify_playlist_url": "https://open.spotify.com/playlist/46V58h9Hgc5WFavtjhNCvR"}
{"genre": "armenian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1DCp7zp3cZWGzFFlj7xsGJ"}
{"genre": "zarzuela", "spotify_playlist_url": "https://open.spotify.com/playlist/0pMsLV9uQUZtDGyPYVIeAt"}
{"genre": "korean musicals", "spotify_playlist_url": "https://open.spotify.com/playlist/2cmWfmFv9yR7BDVhoKPZGZ"}
{"genre": "faroese folk", "spotify_playlist_url": "https://open.spotify.com/playlist/09doQtFZ7g2HTJzmGEYC9l"}
{"genre": "libyan hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4Ix9jeNGBuEhyUAbGzEY9w"}
{"genre": "russian power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2GvYCSgXhZ0UnUpNDZRJZF"}
{"genre": "tibetan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7vqxEJr0lrlXrI8lrlhRaM"}
{"genre": "viet edm", "spotify_playlist_url": "https://open.spotify.com/playlist/2ue7mRobKgve30zMintxMN"}
{"genre": "chamber ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/4ddNv006w0q43fibFKQVW6"}
{"genre": "polish post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/2zPhIrBINowwbkxiGkdrec"}
{"genre": "indian ambient", "spotify_playlist_url": "https://open.spotify.com/playlist/1AhkVbfxPtgV5wJhtOAvM7"}
{"genre": "deep hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1zBf0K5DerTUDg21eRayd0"}
{"genre": "belgian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4sLca0JgChDj5bhtfPXejv"}
{"genre": "new jack smooth", "spotify_playlist_url": "https://open.spotify.com/playlist/38Yp2bVRIO1ER4zEFlhyk0"}
{"genre": "mountain dulcimer", "spotify_playlist_url": "https://open.spotify.com/playlist/4VSoA0XmpkUnxEu7Vy6Dqk"}
{"genre": "pontian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3fMdIXXACP0QsnDHT8Ctfy"}
{"genre": "musica campista", "spotify_playlist_url": "https://open.spotify.com/playlist/3JVMCNDPkh4UfEBnj8obiI"}
{"genre": "turkish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/45AtGBDEqhtRHNflon49pO"}
{"genre": "deep melodic metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0mkpZNuKedVZrRUsJVLNar"}
{"genre": "arkansas metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5rgedt6jlpITOP31Nm1I7n"}
{"genre": "japanese hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1LPg7FVcDkLiDiEP3YcClc"}
{"genre": "wisconsin metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1lqi7FwBarJhtKW82nUz4Q"}
{"genre": "paracana", "spotify_playlist_url": "https://open.spotify.com/playlist/0Qduod6rNuqHldiz0DiixT"}
{"genre": "italo beats", "spotify_playlist_url": "https://open.spotify.com/playlist/0lBzrIF31FmXrVkv7u5LlM"}
{"genre": "dub product", "spotify_playlist_url": "https://open.spotify.com/playlist/4r1LGRBKB5vqUSxxWtUSnN"}
{"genre": "pinoy shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/0jm5fk2JbnfgdpwWuQmc40"}
{"genre": "prague indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1cTndib7E5OWbLeESOqBTJ"}
{"genre": "jazz tuba", "spotify_playlist_url": "https://open.spotify.com/playlist/7I4tjXKOxF4nvPoiyBfXbL"}
{"genre": "norwegian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/6bOsuV6PvVwM3dzA7AKTtx"}
{"genre": "native american black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/11T12xBrL6y7iPW3YUYfFm"}
{"genre": "irish flute", "spotify_playlist_url": "https://open.spotify.com/playlist/2jZIFXAzpHGKquLdfC7bs3"}
{"genre": "baton rouge indie", "spotify_playlist_url": "https://open.spotify.com/playlist/68QwIrQ7rDd6xoII3bLf52"}
{"genre": "guitarra portuguesa", "spotify_playlist_url": "https://open.spotify.com/playlist/0kxFR8tp2YZ8BsAvRpaSDl"}
{"genre": "tabla", "spotify_playlist_url": "https://open.spotify.com/playlist/0KLre7dpWZtErBod0KsUYk"}
{"genre": "wuhan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4r4pYMCxqiOW9L7f8xzQXY"}
{"genre": "indian violin", "spotify_playlist_url": "https://open.spotify.com/playlist/3Aong678PTMX9pH7U2Bd0P"}
{"genre": "dansk comedy", "spotify_playlist_url": "https://open.spotify.com/playlist/7aMTZp4Gq1sLx0dhz4Vi32"}
{"genre": "colombian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3scCe8r2msxJjBVS8aI1Km"}
{"genre": "horror punk brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/0rQNHkmdv2pLgSc98wcYvt"}
{"genre": "colorado hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4YtIsxBbysyEZeIeXIELWq"}
{"genre": "new brunswick indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3F82ezKwcNctesxcgvlL5x"}
{"genre": "chinese post-punk", "spotify_playlist_url": "https://open.spotify.com/playlist/4YUp9F2OYkScNE65mZRlU5"}
{"genre": "grisly death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3Af7O9uoRW1gGNpFMliq8p"}
{"genre": "indie psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/59nqFLwBBdIucneCNJoCXJ"}
{"genre": "dungeon rap", "spotify_playlist_url": "https://open.spotify.com/playlist/291irwRFCeO61Grgph6FWr"}
{"genre": "swedish grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/4CaaYZw34flhRgIUy2JPpl"}
{"genre": "avant-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1PWAjHtcfiRUh9OtmHhvGt"}
{"genre": "colombian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/5v6BrHHEjpkk9GP9J2OfpN"}
{"genre": "vintage french psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/7Jzn2v33l8RYaSkbg5zS3g"}
{"genre": "bulgarian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1lHoOhw2kbYv0614Wj72AM"}
{"genre": "animegrind", "spotify_playlist_url": "https://open.spotify.com/playlist/7lLpF2YbjDoMsnWWOuSGd8"}
{"genre": "musique mauritanienne", "spotify_playlist_url": "https://open.spotify.com/playlist/6tgiE2xPOzneF0huD1G1eu"}
{"genre": "hungarian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/5rZ75TobmwrURStRuCfugO"}
{"genre": "neo-industrial rock", "spotify_playlist_url": "https://open.spotify.com/playlist/76yP8tntlsX9RDgjcAfa53"}
{"genre": "goa psytrance", "spotify_playlist_url": "https://open.spotify.com/playlist/5bTmOsC15wxJWZozRrKqZG"}
{"genre": "finnish electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1thKr5e2Vm58eAyvPU6Uoh"}
{"genre": "modern electroacoustic", "spotify_playlist_url": "https://open.spotify.com/playlist/3VtSSUplPtTQYR8rTEGkLG"}
{"genre": "chinese classical", "spotify_playlist_url": "https://open.spotify.com/playlist/30sre1XG3IKvRYM6q0rBdE"}
{"genre": "guatemalan metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0FwDEXzENm5BE6jhL7LWgC"}
{"genre": "musica menorquina", "spotify_playlist_url": "https://open.spotify.com/playlist/0DF5YOQ38PrgsvT0whSbEH"}
{"genre": "indie hidalguense", "spotify_playlist_url": "https://open.spotify.com/playlist/0xip3bjOqyAivbjOgXDLDo"}
{"genre": "poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/7f1rBV6PnRYeBkrZKRcgCj"}
{"genre": "kinderchor", "spotify_playlist_url": "https://open.spotify.com/playlist/49BlLjNkElJlX41Di10qql"}
{"genre": "tar", "spotify_playlist_url": "https://open.spotify.com/playlist/1i9zTcQqWUBTgIuCgxDW3S"}
{"genre": "deep jazz fusion", "spotify_playlist_url": "https://open.spotify.com/playlist/5aYcWZehrK6hKtR3EiWdqb"}
{"genre": "nagaland indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7ESzcC991XGq6of64Sjy0m"}
{"genre": "australian thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4vQygUErCC4v1vBZ5zkxvN"}
{"genre": "italian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5qOoAhdQmwETfh50C30ICF"}
{"genre": "hardingfele", "spotify_playlist_url": "https://open.spotify.com/playlist/01YOtJuHGWRr2MlQebKDbi"}
{"genre": "vintage spanish pop", "spotify_playlist_url": "https://open.spotify.com/playlist/74D9iMeeq2odsGd6r6i68D"}
{"genre": "dechovka", "spotify_playlist_url": "https://open.spotify.com/playlist/3dr6t9aPVYHCv0lZjTu8r2"}
{"genre": "trekkspill", "spotify_playlist_url": "https://open.spotify.com/playlist/3s3pJrjR5muJh69yXzuHXM"}
{"genre": "south sudanese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2domD3pH2tbubm1FwhJVw9"}
{"genre": "musica ecuatoguineana", "spotify_playlist_url": "https://open.spotify.com/playlist/30MMwWvx5adbiticp8pEzz"}
{"genre": "irish underground rap", "spotify_playlist_url": "https://open.spotify.com/playlist/49HaUMpoVqCFErbqVmiiLU"}
{"genre": "japanese buddhist chant", "spotify_playlist_url": "https://open.spotify.com/playlist/5eV5TVtfKb5XlszSppEAs4"}
{"genre": "christian thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/06SnywJrDVSDAyzCIBGYnq"}
{"genre": "botswana pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4iCWu56IaaF1zfz7HLX4hN"}
{"genre": "historically informed performance", "spotify_playlist_url": "https://open.spotify.com/playlist/4j8LWu769e0bze06dcZV7W"}
{"genre": "spanish blues", "spotify_playlist_url": "https://open.spotify.com/playlist/0dRQr3bESvbQL1opUmEXlY"}
{"genre": "american early music", "spotify_playlist_url": "https://open.spotify.com/playlist/1RatTJrho9K5z9OVCqeU7Z"}
{"genre": "baithak gana", "spotify_playlist_url": "https://open.spotify.com/playlist/7mkbVjaHNgs9uBOfzRKGYm"}
{"genre": "xenharmonic", "spotify_playlist_url": "https://open.spotify.com/playlist/31vMSXGJYkMnYVfP4MVUMB"}
{"genre": "neo honky tonk", "spotify_playlist_url": "https://open.spotify.com/playlist/7MFj9QO8OjHAULmCOlredr"}
{"genre": "indie trujillano", "spotify_playlist_url": "https://open.spotify.com/playlist/1J0BSHkrlVDOI7MD4xKhw1"}
{"genre": "utah metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Q9FHmEw5bl6tB3L8jHOMO"}
{"genre": "oromo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4jMyEE7KJvYFS2SWxBfEWj"}
{"genre": "german shoegaze", "spotify_playlist_url": "https://open.spotify.com/playlist/32AohcWAUkkSw3GkAdbdD8"}
{"genre": "metal tico", "spotify_playlist_url": "https://open.spotify.com/playlist/0xXjHgogk3WKOvzdCK2zDx"}
{"genre": "rock progresivo mexicano", "spotify_playlist_url": "https://open.spotify.com/playlist/4diVi2jC7STpTqUBLWjvbG"}
{"genre": "bahamian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0GqkGs9QSKFwUAku4VMj3v"}
{"genre": "eastern bloc groove", "spotify_playlist_url": "https://open.spotify.com/playlist/7cRvna6ANChqeWWkVyaRN5"}
{"genre": "greek jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4oHKn8uS4GzQIpUAgJNP78"}
{"genre": "afghan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/2umt4HDr7N53azdCC5YM1i"}
{"genre": "gotico brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/4qQv74zGdUv910pI2WMrF4"}
{"genre": "musica rapa nui", "spotify_playlist_url": "https://open.spotify.com/playlist/1JCJyK0FDa2l3Xvy2E5Z4u"}
{"genre": "deep full on", "spotify_playlist_url": "https://open.spotify.com/playlist/7rtjYFALpN7Fr7GDep1nVp"}
{"genre": "vintage swing", "spotify_playlist_url": "https://open.spotify.com/playlist/4v2xTCDjMAWwXw1jvUahtv"}
{"genre": "bengali folk", "spotify_playlist_url": "https://open.spotify.com/playlist/1c2Js6bZrTdxqRK0AISLuk"}
{"genre": "candombe", "spotify_playlist_url": "https://open.spotify.com/playlist/6Rm0X40eYTZ64DJQmiPUIO"}
{"genre": "covertrance", "spotify_playlist_url": "https://open.spotify.com/playlist/0bHOelJ0VL9QgC3c1UIoJM"}
{"genre": "spanish psychedelic rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3c509AUJy6c6iovHuRcffO"}
{"genre": "indonesian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/4PYAgOlnw0hnRkuNT1lLN6"}
{"genre": "santoor", "spotify_playlist_url": "https://open.spotify.com/playlist/3JUgBXSO7fLZj0G34eijv1"}
{"genre": "belgian stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6tYftF6cXhtb2UbjhMy2Ad"}
{"genre": "arab experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/77lhjovotRh2w54Eqznx2H"}
{"genre": "dragspel", "spotify_playlist_url": "https://open.spotify.com/playlist/2MmOxyg27Johuy1EaTrgAU"}
{"genre": "abstractro", "spotify_playlist_url": "https://open.spotify.com/playlist/3WkjlWImZ936rGAeweH93i"}
{"genre": "caucasian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/4KFZyroHoCu4C8Dd4dRhM4"}
{"genre": "irish gaelic folk", "spotify_playlist_url": "https://open.spotify.com/playlist/4T7aBqQkKYQesg9BiDG0FD"}
{"genre": "balafon", "spotify_playlist_url": "https://open.spotify.com/playlist/151LvuVlFGqjjS4uQKHd4T"}
{"genre": "unblack metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2hdg7RPQwGanRABvjHuppV"}
{"genre": "chinese experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/6Vwjb4YyR3ckQXU2k6cf6k"}
{"genre": "javanese gamelan", "spotify_playlist_url": "https://open.spotify.com/playlist/1nvXMQtdBuflS4IrG5WqRH"}
{"genre": "garifuna folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3GpHWrVtzJ9AxWgzoOYqmX"}
{"genre": "lai hla", "spotify_playlist_url": "https://open.spotify.com/playlist/5nv4lr6p6likzx61NLCQEY"}
{"genre": "marcha funebre", "spotify_playlist_url": "https://open.spotify.com/playlist/3IsyKdJIgFYSE3Ay66tKa3"}
{"genre": "indie hidrocalido", "spotify_playlist_url": "https://open.spotify.com/playlist/3wzXQnhHVjc6F96gmxGWLp"}
{"genre": "totalism", "spotify_playlist_url": "https://open.spotify.com/playlist/5tkbtAUDPnLNzP9yxcIlhe"}
{"genre": "spanish baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/0VnmxIGhsByRdLmRtRaOus"}
{"genre": "classic konkani pop", "spotify_playlist_url": "https://open.spotify.com/playlist/32n9cJWxwCLy9bXykIu2xp"}
{"genre": "norwegian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/3qPQzzlC675NSo7v6pNeyi"}
{"genre": "streichquartett", "spotify_playlist_url": "https://open.spotify.com/playlist/2uf3rUJPdy2piLDJXzVLWH"}
{"genre": "yuri", "spotify_playlist_url": "https://open.spotify.com/playlist/0BYoEJVB9xZjjsKMNnujN7"}
{"genre": "belarusian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4CVeMaTHVqnDs13oYp0Hs6"}
{"genre": "st petersburg fl indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1ZwK04RuimtSyAshuai8Al"}
{"genre": "musique concrete", "spotify_playlist_url": "https://open.spotify.com/playlist/1G3qplfcVYzG0Z4XRASdks"}
{"genre": "rajasthani folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3AQTwSrkyEbZBguO5TbFlV"}
{"genre": "swiss punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1ylxNfVL2l80wWwdnhcGLQ"}
{"genre": "mainland se asia metal", "spotify_playlist_url": "https://open.spotify.com/playlist/665CMYY9uSX9PEACXwQuXY"}
{"genre": "circassian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/38YBtxlHopZHNyAWtqWmH2"}
{"genre": "taiko", "spotify_playlist_url": "https://open.spotify.com/playlist/1n6OWTFzNIgrLhgdxuft3M"}
{"genre": "canadian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/1qxy2wp8KHkhXHoKLSyfDF"}
{"genre": "jazz colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/1mvrm0uKYoDivIpWYMQWLH"}
{"genre": "medieval ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/511MabrP35Zp3tqYh2G4iJ"}
{"genre": "scottish drill", "spotify_playlist_url": "https://open.spotify.com/playlist/2uSc99NGvlJbvXZcXhNBCS"}
{"genre": "indie arequipeno", "spotify_playlist_url": "https://open.spotify.com/playlist/3UHmPNB7DlSJyACGW9jIxT"}
{"genre": "minimal synth", "spotify_playlist_url": "https://open.spotify.com/playlist/180rnfqAvF7yGyTSb4I3QH"}
{"genre": "classical flute", "spotify_playlist_url": "https://open.spotify.com/playlist/7MIRjDJ7QqxwOY1E9DIVIt"}
{"genre": "latin american heavy psych", "spotify_playlist_url": "https://open.spotify.com/playlist/5xoQJ99HdfiyskuR1M0n8V"}
{"genre": "lithuanian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5DWQbOTFXIjbekyTkPUsFU"}
{"genre": "irish trap", "spotify_playlist_url": "https://open.spotify.com/playlist/1u5mmyg0iXNefdvJnyYxR1"}
{"genre": "molam", "spotify_playlist_url": "https://open.spotify.com/playlist/2MIOy48SbJgw7ODUAyIR6Y"}
{"genre": "bolivian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/11lrjbxHzrFU0Y100KdT5g"}
{"genre": "grunge revival", "spotify_playlist_url": "https://open.spotify.com/playlist/50e1qdtZjfVotGxeCjxm0A"}
{"genre": "classic female blues", "spotify_playlist_url": "https://open.spotify.com/playlist/52nQxDR1zNIqABK751NZz4"}
{"genre": "batswana traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/3IISB2NSN868y1XbxBA2SR"}
{"genre": "jugendchor", "spotify_playlist_url": "https://open.spotify.com/playlist/0HbEsUZEhUiNZwMPzzMk5u"}
{"genre": "alandsk musik", "spotify_playlist_url": "https://open.spotify.com/playlist/7z1k2PAmyE2gSuR0fQMDjF"}
{"genre": "muzica maramureseana", "spotify_playlist_url": "https://open.spotify.com/playlist/4vgUfOZiXDM5lWyueaR0tk"}
{"genre": "duhovne pjesme", "spotify_playlist_url": "https://open.spotify.com/playlist/3NBwTY4MhsesrRaS4JrfT0"}
{"genre": "gaddiyali pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3llIhUs8JPnAYcworuBO7L"}
{"genre": "min'yo", "spotify_playlist_url": "https://open.spotify.com/playlist/2Mx4YLohU7qwzOlZbQeWrK"}
{"genre": "rap gasy", "spotify_playlist_url": "https://open.spotify.com/playlist/1qyvdaplBJgvGGUbNaiaUo"}
{"genre": "korean experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/3ld6kktsIosfOrMt3AVPiU"}
{"genre": "australian rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/1EuHYJcuErzxWqILkcK3Sq"}
{"genre": "aberdeen indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4JaG749wpqi42yvjyRDvrU"}
{"genre": "romanian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7gT5cBwsoy4EkaHNtxLKRt"}
{"genre": "thai worship", "spotify_playlist_url": "https://open.spotify.com/playlist/4RpaBSDiEn9gO3VxsQrUod"}
{"genre": "israeli traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1Jx5CGej1OsvnPEQ1niZWp"}
{"genre": "christian symphonic metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7qaB6v3tN8aZIrEk3bkA1i"}
{"genre": "andalusian classical", "spotify_playlist_url": "https://open.spotify.com/playlist/473HE9tKctd1WfOJl8DlKx"}
{"genre": "folclore castilla y leon", "spotify_playlist_url": "https://open.spotify.com/playlist/6pLovvr2TYx2A5LR0bkFh7"}
{"genre": "folk cantabria", "spotify_playlist_url": "https://open.spotify.com/playlist/6HWRCXOfkaPlg51mhlJZTC"}
{"genre": "men's choir", "spotify_playlist_url": "https://open.spotify.com/playlist/5ch48RZxz8d9yx6R6BSIKj"}
{"genre": "marinera", "spotify_playlist_url": "https://open.spotify.com/playlist/0qaiRSwJmpfpB1wcMPbh2m"}
{"genre": "himalayan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/3ASk6PZhXeRDblTYHeannL"}
{"genre": "luxembourgian hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6rUSUvFHUYFDKq7zdv4tXT"}
{"genre": "raga rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5J5tRxNdnxGhZPPYsGCySd"}
{"genre": "trio cubano", "spotify_playlist_url": "https://open.spotify.com/playlist/1S961pBNDi5wvBim1dcxiq"}
{"genre": "classical mezzo-soprano", "spotify_playlist_url": "https://open.spotify.com/playlist/05DpybdRcuOBYXdjsvQnMk"}
{"genre": "brazilian rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/1qFGMmJE3ks2kMWwvwNbSb"}
{"genre": "russian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2mkZK1x9xqySv82Bx6pw4i"}
{"genre": "italian screamo", "spotify_playlist_url": "https://open.spotify.com/playlist/6YjmqzGNyxujj54DF5sZPp"}
{"genre": "kosovan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7dzIBliY2jynLBf27YChrK"}
{"genre": "brazilian stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3WINZ8hNPKCwu0BfDcr0GY"}
{"genre": "macedonian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/7MRwqEjIGniaqkhLGedmJP"}
{"genre": "garo pop", "spotify_playlist_url": "https://open.spotify.com/playlist/34zyWkoihYrprsqXEhysBK"}
{"genre": "nhac thieu nhi", "spotify_playlist_url": "https://open.spotify.com/playlist/1gR0ICNJHA2gYvV8X57ktc"}
{"genre": "dutch folk", "spotify_playlist_url": "https://open.spotify.com/playlist/06dBdsfZUXHNheFpuDrA24"}
{"genre": "cape breton indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0tyTYAV1KWFMOjAL7EJWpy"}
{"genre": "classical percussion", "spotify_playlist_url": "https://open.spotify.com/playlist/1LCGVLfROniWAIoSSAEKEE"}
{"genre": "rock potiguar", "spotify_playlist_url": "https://open.spotify.com/playlist/5GO9B22PvAEtZQPT3QUBTR"}
{"genre": "pinoy traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZRXeCFgXctoDbkp02G6Ry"}
{"genre": "senegalese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/03Mf30p0BCtJuzdN9NfxaR"}
{"genre": "classical countertenor", "spotify_playlist_url": "https://open.spotify.com/playlist/1QzYdN21I99ZaGL4USSVBv"}
{"genre": "brazilian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/61shI6mTi5fmb4S9CZFq55"}
{"genre": "koto", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZrBy8XJhh2lEyXK1jXJ6n"}
{"genre": "bangla gojol", "spotify_playlist_url": "https://open.spotify.com/playlist/4l9Au9k4gNnPq5curJUKRz"}
{"genre": "korean punk", "spotify_playlist_url": "https://open.spotify.com/playlist/2P0CxBuS2D0BuqbEIrvvAV"}
{"genre": "croatian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0L2bKJfUZ2qyl3rpWtckuv"}
{"genre": "dombra", "spotify_playlist_url": "https://open.spotify.com/playlist/0N0ulKJ2oY3YjckMYMqyJn"}
{"genre": "rap potiguar", "spotify_playlist_url": "https://open.spotify.com/playlist/7fhMsL9VrGfy1j5nIRk0vh"}
{"genre": "sindhi", "spotify_playlist_url": "https://open.spotify.com/playlist/0DvEtBkGlk4X1bEweH0X7s"}
{"genre": "hula", "spotify_playlist_url": "https://open.spotify.com/playlist/0J6SPSO12FYJt55acGJW2y"}
{"genre": "grim death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/05zx5BP5cdqnZrDWA6GE70"}
{"genre": "prank", "spotify_playlist_url": "https://open.spotify.com/playlist/7gMN44gKyJeABIt5tc34tA"}
{"genre": "neo-proto", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZInSdk8VMhCM6WmRmfy9w"}
{"genre": "danish electro", "spotify_playlist_url": "https://open.spotify.com/playlist/4rXWPJ6CfNeKj2MrXcsACW"}
{"genre": "novos talentos brasileiros", "spotify_playlist_url": "https://open.spotify.com/playlist/1HGdDFrmuZ9cfLJwJ7Eb3s"}
{"genre": "israeli classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6pxnBx9LGcdAaOAP0s1YPA"}
{"genre": "classical baritone", "spotify_playlist_url": "https://open.spotify.com/playlist/0iWlJqpbaegQTyyYdjVRCV"}
{"genre": "rhythm rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3LHV3K48mTlH9VhbGgFTMn"}
{"genre": "colombian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6TW50etX8zrpUNH7OOMHnf"}
{"genre": "german choir", "spotify_playlist_url": "https://open.spotify.com/playlist/3xHTWU84NchwmVpoOHdiyC"}
{"genre": "classic assamese pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2fWmReMY5MbDcS2mNKOwK7"}
{"genre": "finnish techno", "spotify_playlist_url": "https://open.spotify.com/playlist/5HV5mTZCAuvBlRKvuNxAFu"}
{"genre": "zeuhl", "spotify_playlist_url": "https://open.spotify.com/playlist/2PvNMMgIu3xbKLuMBU8RlE"}
{"genre": "colombian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4wAAoGyd29TOmWniPBSvcH"}
{"genre": "portuguese contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6VoRk8kuJy99zXhIxdjwqt"}
{"genre": "lagu betawi", "spotify_playlist_url": "https://open.spotify.com/playlist/6TN46YwH8yprurqRB4lQ9l"}
{"genre": "kinnauri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/041X4tACONQ0uO3KxBzcvh"}
{"genre": "korean classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/4ILgcuCSyGWNY1RejVHgiN"}
{"genre": "rock nica", "spotify_playlist_url": "https://open.spotify.com/playlist/6V1OoZoGu0pyd5qezkgGZk"}
{"genre": "french classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/2KkLEZecIyFOblj7RdJQDI"}
{"genre": "otroske pesmice", "spotify_playlist_url": "https://open.spotify.com/playlist/0wCLfTeI6aOieQnDUmu9Ix"}
{"genre": "dutch punk rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0PNIW4MlH8AmkxbODzDOfg"}
{"genre": "umea indie", "spotify_playlist_url": "https://open.spotify.com/playlist/5yVWA6mgrbN3iVxSvftCbk"}
{"genre": "cantonese opera", "spotify_playlist_url": "https://open.spotify.com/playlist/53vAv9tBLW9wx94WtVl1ax"}
{"genre": "dutch contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/53bSSfavddJaaL8DMdriRJ"}
{"genre": "sinhala edm", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZkLhOcmoFAzSGx5WMiU0I"}
{"genre": "metal noir quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/74dQ0Y7bPu5J1PCKmdJNWN"}
{"genre": "danish hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1lZ2ChtHbod1f4N78xULHb"}
{"genre": "mising pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6jv8rWhwZ3a4FKZj9fWWON"}
{"genre": "polynesian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/4vO3Vvrd8i0blcpXf7SpRd"}
{"genre": "deep free jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4kG2qiyLY2O24LPEYMv6vf"}
{"genre": "glitter trance", "spotify_playlist_url": "https://open.spotify.com/playlist/6dHwd8PSz0phwZkwBRLMm1"}
{"genre": "scottish smallpipe", "spotify_playlist_url": "https://open.spotify.com/playlist/3VDnnFwHwWhIf3N9yHpi1m"}
{"genre": "deep vocal house", "spotify_playlist_url": "https://open.spotify.com/playlist/7iPFuDAoW20OY5LNTDtK1h"}
{"genre": "post-punk colombiano", "spotify_playlist_url": "https://open.spotify.com/playlist/0n1bX9oQZk5d9kHokmG78N"}
{"genre": "brass quintet", "spotify_playlist_url": "https://open.spotify.com/playlist/0k0wYWN9getqOUOgswJU03"}
{"genre": "canadian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/2gG8QC6Ussvl4gYskxRN8y"}
{"genre": "maghreb", "spotify_playlist_url": "https://open.spotify.com/playlist/3oXuillWzrOI7COGBWgO5g"}
{"genre": "musique peule", "spotify_playlist_url": "https://open.spotify.com/playlist/3PyovaGk3JYKMA4cwp2ppU"}
{"genre": "indonesian bamboo", "spotify_playlist_url": "https://open.spotify.com/playlist/5TDA5AEIBeLtwA6zpETBe9"}
{"genre": "slc hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3aiXtpkV1kcvmLaMyNahH2"}
{"genre": "rock sergipano", "spotify_playlist_url": "https://open.spotify.com/playlist/2AoKghrJnnRjjIoGNXtJX4"}
{"genre": "malawian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0hUQCA7l8f9FUSN4cMyjg6"}
{"genre": "finnish rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/0NpfMj7fmwjbNa3DBI7zIg"}
{"genre": "hakkapop", "spotify_playlist_url": "https://open.spotify.com/playlist/1xILuchXsXTUjhl9HVPnDP"}
{"genre": "portuguese death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0LcFA2C9lH8yfRXt8S2N3R"}
{"genre": "dutch stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/5gql4TGO6qwkrztG2hFFBd"}
{"genre": "saxophone trio", "spotify_playlist_url": "https://open.spotify.com/playlist/7ugZZo3hjrJW3r90wGmJBR"}
{"genre": "marimba", "spotify_playlist_url": "https://open.spotify.com/playlist/5LwgLsVuf83oZ4KM77Olxp"}
{"genre": "vintage finnish jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/6QTnfYqEOcwk1sMqp2lRIY"}
{"genre": "dhrupad", "spotify_playlist_url": "https://open.spotify.com/playlist/00x9xMs3caQUh0YV9iXVoG"}
{"genre": "western ny metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1S0H6VFAEH8VVmnCtkXr2s"}
{"genre": "euro hi-nrg", "spotify_playlist_url": "https://open.spotify.com/playlist/3aT99aG5pTpyttveznrzIj"}
{"genre": "russian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/79Rqfgj6ClXaEAR3ED5i0E"}
{"genre": "musica colimense", "spotify_playlist_url": "https://open.spotify.com/playlist/208LoDD8kGkmEGriiVHLf2"}
{"genre": "deep northern soul", "spotify_playlist_url": "https://open.spotify.com/playlist/7ajTsnmCl0uAFRvLWo6Ga7"}
{"genre": "indian instrumental rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0gbdE14EHL2dqs40VHEeyC"}
{"genre": "minnesota metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0p6Ynzdgfa3fJDV4KDBE3X"}
{"genre": "northamptonshire indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3kaNivwkj4h3ceMQRnwLYQ"}
{"genre": "canadian stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7cxq7g4KHWS9lalpMowhEJ"}
{"genre": "epic collage", "spotify_playlist_url": "https://open.spotify.com/playlist/6RYGqT1H88p3UT5gJdnbjr"}
{"genre": "ho munda", "spotify_playlist_url": "https://open.spotify.com/playlist/7nUEhWR2oTMecIiDlJNsdH"}
{"genre": "nyahbinghi", "spotify_playlist_url": "https://open.spotify.com/playlist/3pHXSNDTpgSD6wWoxjjEqK"}
{"genre": "kentucky mountain folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5akdeWIPyZlIYz23s861Fn"}
{"genre": "mento", "spotify_playlist_url": "https://open.spotify.com/playlist/37tpe7yDWnfu2clBqtvMxI"}
{"genre": "irish ballad", "spotify_playlist_url": "https://open.spotify.com/playlist/5FDzNJpE1HyIV5Q5AqVvCR"}
{"genre": "italian blues", "spotify_playlist_url": "https://open.spotify.com/playlist/5OE7ILV3uCBLU4vRbuOm74"}
{"genre": "estonian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3YU0yEYcmTV7U4urOabDi9"}
{"genre": "muzica banateana", "spotify_playlist_url": "https://open.spotify.com/playlist/33n5C5ZVYLStV3Kzg3inHh"}
{"genre": "piada", "spotify_playlist_url": "https://open.spotify.com/playlist/7hc9ogiNnd0EIvckgjRbjP"}
{"genre": "dytyachi pisni", "spotify_playlist_url": "https://open.spotify.com/playlist/0XD8IH8ubDqGa3Dk4duanQ"}
{"genre": "classical trombone", "spotify_playlist_url": "https://open.spotify.com/playlist/0M6CLMVZxMl6YJAbka4D2n"}
{"genre": "italian progressive metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1mteRepMdleAEulhDVGhI4"}
{"genre": "appalachian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/33k10UO6WCSEyCOdIkRbn4"}
{"genre": "zither", "spotify_playlist_url": "https://open.spotify.com/playlist/6bpwGHlRRLkVqfmOpqfmvx"}
{"genre": "hangoskonyvek", "spotify_playlist_url": "https://open.spotify.com/playlist/2BiLkczPTyfOtJx04FCdKn"}
{"genre": "swiss experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/7d9YLozBOYeouQ0UyKPUpZ"}
{"genre": "metal salvadoreno", "spotify_playlist_url": "https://open.spotify.com/playlist/7bQHO6kuIOQROJVnFukGXL"}
{"genre": "guggenmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/0UeXiI7e0dcdSvOdgowvm4"}
{"genre": "izvorna muzika", "spotify_playlist_url": "https://open.spotify.com/playlist/0FfUqDxjstCrw4NNmVjuA1"}
{"genre": "experimental percussion", "spotify_playlist_url": "https://open.spotify.com/playlist/0dVEVtMAMauolhaE2hgnNZ"}
{"genre": "dark black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Ajh5eG4ZlKrr1148nrB5m"}
{"genre": "bikutsi", "spotify_playlist_url": "https://open.spotify.com/playlist/0Qvvs6Pba0ShqUEBzFyHXo"}
{"genre": "tanzorchester", "spotify_playlist_url": "https://open.spotify.com/playlist/5BMdrlJWc1MbHySNCNFHUU"}
{"genre": "lok dohori", "spotify_playlist_url": "https://open.spotify.com/playlist/7nu5BmQuFxYU7p0FE6GyLl"}
{"genre": "american classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/4bvyIQgxpp1YmiEUOvyFcL"}
{"genre": "singaporean punk", "spotify_playlist_url": "https://open.spotify.com/playlist/72JgUX20BlH6entpiEQcDx"}
{"genre": "anime game", "spotify_playlist_url": "https://open.spotify.com/playlist/0ycoVPkrIuTEU5agjtyrtx"}
{"genre": "eletronica underground brasileira", "spotify_playlist_url": "https://open.spotify.com/playlist/1bGcbgDWekEUouQhyNwHrA"}
{"genre": "italian modern prog", "spotify_playlist_url": "https://open.spotify.com/playlist/7IulbLvyD5OyBPani09FNT"}
{"genre": "salon music", "spotify_playlist_url": "https://open.spotify.com/playlist/7ljrQj2akgkpUbpCd0XEoP"}
{"genre": "classical accordion", "spotify_playlist_url": "https://open.spotify.com/playlist/6QufKhhtnLpucZ0aFruw96"}
{"genre": "iranian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/6u5cs7trIBWbrSFplDuZo1"}
{"genre": "thrash-groove metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1ulrJ0uK6zy2P4bruCmiZ4"}
{"genre": "polish classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/2YxhESpDtgBdXr2AkOouvv"}
{"genre": "kikuyu pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4iZ0tP1VKBI4C1iC59Oe1N"}
{"genre": "chilean techno", "spotify_playlist_url": "https://open.spotify.com/playlist/3B1FqFqgfftpnARTDIybiF"}
{"genre": "hungarian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1QBLSc8zkQXQnYHGlGM1mS"}
{"genre": "kolo", "spotify_playlist_url": "https://open.spotify.com/playlist/5C0NAjg481sIrIAhDN8tfh"}
{"genre": "welsh choir", "spotify_playlist_url": "https://open.spotify.com/playlist/5f9nhNDqESbdULE6Ue2Lze"}
{"genre": "bulgarian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/444iyrQpCfopAxHXu3YtLF"}
{"genre": "edinburgh metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6g2ys3gdIubcz7auNWTC5l"}
{"genre": "dogri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6x6aopCKJ8xO5h7xzJbiDm"}
{"genre": "guatemalan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4XtadMrOYHCU5QTr0sNXP1"}
{"genre": "dutch baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/0F51Fqe9uBQUkVMXlpuVOW"}
{"genre": "czsk black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7c6gSnRdFCpm3G1VdYUTuR"}
{"genre": "quebec metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2t7PKO3CCmlch3IaqxUiKz"}
{"genre": "borneo traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/2DHlpfni3t0A0chd8sHb4C"}
{"genre": "rozpravky", "spotify_playlist_url": "https://open.spotify.com/playlist/0oTxFCoLhXUgpBWXncmpV9"}
{"genre": "vintage radio show", "spotify_playlist_url": "https://open.spotify.com/playlist/6iZjfdAaRSwpDCIkeamvX3"}
{"genre": "alabama hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/2hYrz7edKJ9l6OrY2bo6VM"}
{"genre": "kikuyu gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/0tB4W3LMq3w6RyWwRyvtP5"}
{"genre": "moravian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/2ToND5VV0VPagg4Nm2qTR5"}
{"genre": "experimental big band", "spotify_playlist_url": "https://open.spotify.com/playlist/2Xkgh1OTAgZuqnsnWb8QAe"}
{"genre": "macedonian rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0uho43Nzl9FrgUyhVDxXmz"}
{"genre": "dutch experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/2lme11IX1jmvadLWtDcxFv"}
{"genre": "norwegian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4xixii9fbVmUTiMikrqG8Y"}
{"genre": "musique soninke", "spotify_playlist_url": "https://open.spotify.com/playlist/74Us8kcNh8ptwnaieyKQua"}
{"genre": "orquesta cubana", "spotify_playlist_url": "https://open.spotify.com/playlist/5tQkIKal5i3lAl1pZ4Y3yK"}
{"genre": "chinese wind", "spotify_playlist_url": "https://open.spotify.com/playlist/7vd7ZntuBk9C5l1MMs5Cgm"}
{"genre": "pipa", "spotify_playlist_url": "https://open.spotify.com/playlist/5PieA5Xtecd3psusMgyvZb"}
{"genre": "cerkes muzikleri", "spotify_playlist_url": "https://open.spotify.com/playlist/3pqGb6Yg2wSDLTp0eddFlz"}
{"genre": "rakugo", "spotify_playlist_url": "https://open.spotify.com/playlist/2eRw9eqaDyvtlYq1y2RlxR"}
{"genre": "delaware indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1qjtO1mIllz0Ld4dBarI9y"}
{"genre": "sardinia indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3Hi1KsBX2EIFVINCAbcw8l"}
{"genre": "punk ecuatoriano", "spotify_playlist_url": "https://open.spotify.com/playlist/1frOhZBICOdl4gwwBtpscv"}
{"genre": "tulum", "spotify_playlist_url": "https://open.spotify.com/playlist/0n28qFv898oSU4ixRP8ejI"}
{"genre": "african metal", "spotify_playlist_url": "https://open.spotify.com/playlist/22Vw6zVm1ywaGcmSbbCJDe"}
{"genre": "autoharp", "spotify_playlist_url": "https://open.spotify.com/playlist/4pgTiBCem4FrZlZwolDKNI"}
{"genre": "assamese hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/06BsQjAXB9D2IT1T78k6Nh"}
{"genre": "musique ancienne", "spotify_playlist_url": "https://open.spotify.com/playlist/3dkvfaZqToI9kSpSDolutm"}
{"genre": "kapa haka", "spotify_playlist_url": "https://open.spotify.com/playlist/2zVryf7Hg7btu7fMo8cAaZ"}
{"genre": "classic nz country", "spotify_playlist_url": "https://open.spotify.com/playlist/4wQOyJ9wTOnLVQxIGPZReJ"}
{"genre": "croatian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/1CRcTyR3Pk8HHIpmuiUmTc"}
{"genre": "rock dominicano", "spotify_playlist_url": "https://open.spotify.com/playlist/1dOT5Lnx29cI7OKt6Fmltg"}
{"genre": "indie asturiana", "spotify_playlist_url": "https://open.spotify.com/playlist/4C0nRMvjDfbzWVNh2jXRGD"}
{"genre": "musica blumenauense", "spotify_playlist_url": "https://open.spotify.com/playlist/5Q21EJ3ftlQiKoof6SX42Q"}
{"genre": "stubenmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/53scIdMPn5Px3PdVOY1nC1"}
{"genre": "synthetic classical", "spotify_playlist_url": "https://open.spotify.com/playlist/5EK0YXw0YUsxEMsu3GGjbM"}
{"genre": "rock in opposition", "spotify_playlist_url": "https://open.spotify.com/playlist/4KaOUZ1sO1hPrftxSxQWd9"}
{"genre": "frafra", "spotify_playlist_url": "https://open.spotify.com/playlist/1rFCFsXPW2dQ7XdlskNYN0"}
{"genre": "field recording", "spotify_playlist_url": "https://open.spotify.com/playlist/2ftTVWxFD0bhsQq37jAk5D"}
{"genre": "ceske chvaly", "spotify_playlist_url": "https://open.spotify.com/playlist/0U6owTy68xweZvo0vPyKpj"}
{"genre": "middle eastern traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/5cE06uG59oxYp9v8hrffC1"}
{"genre": "albanian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/31OZWMJzxRZu6dwK0nhxY5"}
{"genre": "vintage hawaiian", "spotify_playlist_url": "https://open.spotify.com/playlist/26R9gGCsxKxvyGlOxS9mmB"}
{"genre": "deep indie singer-songwriter", "spotify_playlist_url": "https://open.spotify.com/playlist/16xRhhHGkwub8XbsIQOO9x"}
{"genre": "detskie rasskazy", "spotify_playlist_url": "https://open.spotify.com/playlist/4vCRbt59p7oHtBkwCzaX6b"}
{"genre": "chinese punk", "spotify_playlist_url": "https://open.spotify.com/playlist/370ziWDySqtFGSNQwJADo6"}
{"genre": "rock pernambucano", "spotify_playlist_url": "https://open.spotify.com/playlist/1QAkhfq1AQ5MjyhnRcrdjp"}
{"genre": "blues band", "spotify_playlist_url": "https://open.spotify.com/playlist/6lT1VFJWr2Lmo17Dfjsohk"}
{"genre": "christian doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/742lGGmiVn8lktCViYzcbc"}
{"genre": "spanish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4GYN0nIrGTKLWpPRnQ1ukH"}
{"genre": "santur", "spotify_playlist_url": "https://open.spotify.com/playlist/3BRya2QlUo0DeJ1MfA6MGD"}
{"genre": "folklore panameno", "spotify_playlist_url": "https://open.spotify.com/playlist/4BuZUQhlBoWtjHVGBI4vKJ"}
{"genre": "early french punk", "spotify_playlist_url": "https://open.spotify.com/playlist/1W3oo9Lkf6svTwBfijAQdK"}
{"genre": "italian soprano", "spotify_playlist_url": "https://open.spotify.com/playlist/5XrU9MtUKdlhdaeDe26yNG"}
{"genre": "mapouka", "spotify_playlist_url": "https://open.spotify.com/playlist/6V384enS3I948e5HdX5P5A"}
{"genre": "deep italo disco", "spotify_playlist_url": "https://open.spotify.com/playlist/42Tb1c0SQtcNQx1pfkWadp"}
{"genre": "rock catarinense", "spotify_playlist_url": "https://open.spotify.com/playlist/2RBleJBJJiqL7cZ80OatM7"}
{"genre": "french experimental rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1LIS1YWqU2NRSVl7aAINyv"}
{"genre": "serbian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7wTrCsonTWgiD38rsyTXc0"}
{"genre": "rongmei pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4U8Yn0s0wOtKxZ5GcDx3uh"}
{"genre": "black noise", "spotify_playlist_url": "https://open.spotify.com/playlist/03yCfbIgtHKu2DobuNgOqN"}
{"genre": "ceilidh", "spotify_playlist_url": "https://open.spotify.com/playlist/5E9RzzgZEIPkm0RBiU7fhM"}
{"genre": "caucasian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5b3YIpxXuCMM1NXvcoijD0"}
{"genre": "russian thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5G9AZ1XmZXIZofHotOQnB4"}
{"genre": "sound collage", "spotify_playlist_url": "https://open.spotify.com/playlist/3oQe51s7JnZnVSbZmMY21m"}
{"genre": "irish experimental electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/24RLueVXOuPDMBFnTTBogj"}
{"genre": "indonesian thrash metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3KyDIDKY4iu4EOPLbQyofU"}
{"genre": "haitian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZbPiBIy4lkcDi6c1cbCBe"}
{"genre": "slovak metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4N6AuY7JB8cQG9evwx6seu"}
{"genre": "gwoka", "spotify_playlist_url": "https://open.spotify.com/playlist/1j3z24pryCUnwo1vt2e88h"}
{"genre": "indie queretano", "spotify_playlist_url": "https://open.spotify.com/playlist/3y3qJxGmT31SY25Ucuo2jo"}
{"genre": "metalcore espanol", "spotify_playlist_url": "https://open.spotify.com/playlist/1Wnz6gX1qZXacmvCXX86xH"}
{"genre": "belgian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/5hne3nEjaQ0BLlU1cy1gSA"}
{"genre": "korean traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/52Z6bV877kg1F0DvGzmdAw"}
{"genre": "malaysian hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1nTIanII8KG8zCJnXYOOaM"}
{"genre": "lithuanian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/5gQcpV3OAkC7q9EvDBditZ"}
{"genre": "italian baritone", "spotify_playlist_url": "https://open.spotify.com/playlist/4zvEtjP1Ou5sGBVL9Z91y0"}
{"genre": "ukrainian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/7mSbJbQdcmQ1uLqsfKZyzy"}
{"genre": "shehnai", "spotify_playlist_url": "https://open.spotify.com/playlist/4cqMCSPLcPkwEkskZADlgG"}
{"genre": "german contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/5vZJbTAT5UlOVc0jhWT3ao"}
{"genre": "finnish contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6tDtq3CEyXbQVmJ5xaPHDC"}
{"genre": "musica mato-grossense", "spotify_playlist_url": "https://open.spotify.com/playlist/66nq68q3YG4Pp4N8CspccC"}
{"genre": "beat poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/5u4WtjzIuJgzX1B5s7DhVM"}
{"genre": "brazilian heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3NmBEW27cR3QZHMVIXRYAv"}
{"genre": "deep swedish rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1sJYqW3R1pN0urpF6BPDNj"}
{"genre": "belgian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/21rt1kGjzWvxHSnsrGVA88"}
{"genre": "macau pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3jBYlAqwWus0UdsNv44NHu"}
{"genre": "kosovan folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6ewrhTyrUB7Vh24nb9q6dR"}
{"genre": "djembe", "spotify_playlist_url": "https://open.spotify.com/playlist/5V4K0899rz3Tq7wbhl1XXn"}
{"genre": "instrumental black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/56fQFv3pWIlOrxfJ1wBDd0"}
{"genre": "alpenpanorama", "spotify_playlist_url": "https://open.spotify.com/playlist/0JXnDtaoCfX7Q6QC6Q8i0x"}
{"genre": "baroque singing", "spotify_playlist_url": "https://open.spotify.com/playlist/7F8uSkvkzO9Fhr525tcoHJ"}
{"genre": "slash punk", "spotify_playlist_url": "https://open.spotify.com/playlist/43fLb3KD8t3c7fghr7XlXO"}
{"genre": "musica amapaense", "spotify_playlist_url": "https://open.spotify.com/playlist/29mSwTOUCx0qir7FngxNJV"}
{"genre": "trombone brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/6GAmRuos60sSq3VACPGhwj"}
{"genre": "pontianak indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0ieIobWxRuLYalQz2WHKHR"}
{"genre": "african experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/48uCDGE2YYjZsPSyhZXGP5"}
{"genre": "suomisaundi", "spotify_playlist_url": "https://open.spotify.com/playlist/2oDlfDr6DS4hmKtIkLjdTf"}
{"genre": "vapor house", "spotify_playlist_url": "https://open.spotify.com/playlist/5y8EoN232TP7tDMtavXRhQ"}
{"genre": "dweilorkest", "spotify_playlist_url": "https://open.spotify.com/playlist/02LAKfdJFyxjrm5g51Dwt4"}
{"genre": "indie nica", "spotify_playlist_url": "https://open.spotify.com/playlist/4gM9aDyGSr2FVAKAmehvRV"}
{"genre": "nordic orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/5ScPLFNE5pNS9P990RljvH"}
{"genre": "electroacoustic composition", "spotify_playlist_url": "https://open.spotify.com/playlist/03VBkbiDhkS0EVoFoKSe06"}
{"genre": "musica acoriana", "spotify_playlist_url": "https://open.spotify.com/playlist/2y4fCw6aa6zEmM77umG48B"}
{"genre": "saxony metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0PkAGge9ZxJLlJhQdzskPm"}
{"genre": "ladakhi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/7soq6Lz7g6PWvigWX3cVCn"}
{"genre": "normal indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1gGPDlhf1YsRNJhkQE7c4e"}
{"genre": "alaska hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/4mgB4LFKwuZYIuqFFTsrPW"}
{"genre": "mexican power metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4dOuUV8PDgcjacbQ3FPheh"}
{"genre": "musica campineira", "spotify_playlist_url": "https://open.spotify.com/playlist/2hmUr9SATE6SeyVgRe1Bfq"}
{"genre": "bandura", "spotify_playlist_url": "https://open.spotify.com/playlist/0Ot8AKx9vVxNhxy3yojdwZ"}
{"genre": "lincoln ne indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2DEoTCwNKhPrscHszesnoC"}
{"genre": "soda pop", "spotify_playlist_url": "https://open.spotify.com/playlist/47ZxmSDiMbeFBad2DWNxnl"}
{"genre": "danish choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4OiGOl4fr9CWcZnnYPZelX"}
{"genre": "guqin", "spotify_playlist_url": "https://open.spotify.com/playlist/59r5KTXDuXTXZcIKo2rHFH"}
{"genre": "recorder", "spotify_playlist_url": "https://open.spotify.com/playlist/0kOPCb8wKgaGA6kN3o6klO"}
{"genre": "vintage classical singing", "spotify_playlist_url": "https://open.spotify.com/playlist/5o74KZgxzQuz1dbOOtsyj5"}
{"genre": "british electroacoustic", "spotify_playlist_url": "https://open.spotify.com/playlist/1IxeQOKZy4mzWWSTyEIPAC"}
{"genre": "georgian polyphony", "spotify_playlist_url": "https://open.spotify.com/playlist/0rkUoC7hZugEv96Q8o1PSw"}
{"genre": "latin american classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/7u5l82eY5aEZ2WN4PMxJ6K"}
{"genre": "spanish stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/12fprWREYfIx1l0tG63nv4"}
{"genre": "humour francais", "spotify_playlist_url": "https://open.spotify.com/playlist/2LcJiLWvG8jBx0HTyMfLXY"}
{"genre": "chill groove", "spotify_playlist_url": "https://open.spotify.com/playlist/7wQsJI14eRUiBLMk65F8DS"}
{"genre": "historic classical performance", "spotify_playlist_url": "https://open.spotify.com/playlist/7aoyVc90BhK3uEuZQqiavW"}
{"genre": "antilliaanse folklore", "spotify_playlist_url": "https://open.spotify.com/playlist/3X2kDSCnsGUQ6BwrcUnr76"}
{"genre": "bohol indie", "spotify_playlist_url": "https://open.spotify.com/playlist/46kIIqkNXmvgL4U7XWGUtg"}
{"genre": "idaho hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/7K6Uhkl6fOVUOFSWuM6Iu8"}
{"genre": "cimbalova muzika", "spotify_playlist_url": "https://open.spotify.com/playlist/1yVqljQXnWccHrSeMUxZwd"}
{"genre": "theremin", "spotify_playlist_url": "https://open.spotify.com/playlist/5gQyJA5uWrGtqblgCuuQn8"}
{"genre": "deep surf music", "spotify_playlist_url": "https://open.spotify.com/playlist/7eJHJMWBGO4D26vybq8wWh"}
{"genre": "luxembourgian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6XJ2Qa8gDoXrT7tafPbwIj"}
{"genre": "dutch idol pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6TGOKSobwpEoOtx80edFyV"}
{"genre": "deep hardcore punk", "spotify_playlist_url": "https://open.spotify.com/playlist/46gHw9E8Oj5E7D3KzZaCAI"}
{"genre": "kantele", "spotify_playlist_url": "https://open.spotify.com/playlist/6Hq2IbgsGDBMUNJP0ksfVs"}
{"genre": "turkish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7CPFCGaO2YcRhD0707yyYM"}
{"genre": "french contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/1FYtDs08idk3VjvtgKRjZ7"}
{"genre": "modern performance", "spotify_playlist_url": "https://open.spotify.com/playlist/2XeJzzhlql6vgaARsBBFpl"}
{"genre": "brazilian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4SZH8SQnuslwyddvWjY2Lx"}
{"genre": "musica rondoniense", "spotify_playlist_url": "https://open.spotify.com/playlist/2OichSu1aZp6qBQ45C5BX3"}
{"genre": "deep space rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4sZuhwUI9TvkyVCNMYreKQ"}
{"genre": "charred death", "spotify_playlist_url": "https://open.spotify.com/playlist/7wp0iyiaAS55xDZB7ERVQD"}
{"genre": "rock sul-mato-grossense", "spotify_playlist_url": "https://open.spotify.com/playlist/2f6QGyAso6OlpaJhuGjopB"}
{"genre": "moorish traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7khkEkukvAQWdDapKh1lVt"}
{"genre": "organetto", "spotify_playlist_url": "https://open.spotify.com/playlist/1H1fjUqS8T70STFOb1Psyu"}
{"genre": "punk tico", "spotify_playlist_url": "https://open.spotify.com/playlist/6axTSLEMCgsU2LWhux4t4l"}
{"genre": "bury st edmunds indie", "spotify_playlist_url": "https://open.spotify.com/playlist/3hUSSC8liqZwkDkAKoXEmK"}
{"genre": "orkney and shetland folk", "spotify_playlist_url": "https://open.spotify.com/playlist/43kNzpeexrUOm37vMwtGmR"}
{"genre": "string orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/0ISHRIOFoODGE7tErYG7CD"}
{"genre": "h8000", "spotify_playlist_url": "https://open.spotify.com/playlist/6AGFqnZa2nHdGuLeLneupc"}
{"genre": "latin american baroque", "spotify_playlist_url": "https://open.spotify.com/playlist/2Y0PsfHwq4EAfoV2CGQI5t"}
{"genre": "tan co", "spotify_playlist_url": "https://open.spotify.com/playlist/3yV3iYsCwpOP45BXppVGkB"}
{"genre": "south borneo indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1m2owYzLqkOUoESCIRZRN3"}
{"genre": "modern free jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4g8jY2NYAlj7sBdFHtrgdF"}
{"genre": "italian rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/5INg0fRsoA1uYyyJwliHGS"}
{"genre": "classical bass", "spotify_playlist_url": "https://open.spotify.com/playlist/54TsuG15EGsexttVBHiKUD"}
{"genre": "russian modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/45mfvpuFsZDNadXvLLXV50"}
{"genre": "taiwan graduation song", "spotify_playlist_url": "https://open.spotify.com/playlist/1bjImUCghMROYHtjnUTi66"}
{"genre": "brazilian surf rock", "spotify_playlist_url": "https://open.spotify.com/playlist/7Hbtyb8qY5vz3IBYDvypYg"}
{"genre": "czech classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/4SAT9xwBIpqrUb4s09qrwC"}
{"genre": "tibetan folk pop", "spotify_playlist_url": "https://open.spotify.com/playlist/65faCB9BE08hrJ3X21DCLx"}
{"genre": "aghani lil-atfal", "spotify_playlist_url": "https://open.spotify.com/playlist/6Wzlv3P5G9jIchHJWBcVJF"}
{"genre": "jazz composition", "spotify_playlist_url": "https://open.spotify.com/playlist/4yH9lNXRP4cFVJhVefAqpo"}
{"genre": "hip hop mauritanien", "spotify_playlist_url": "https://open.spotify.com/playlist/1sgENWusPCGzMiNWvl1P4f"}
{"genre": "classical bassoon", "spotify_playlist_url": "https://open.spotify.com/playlist/5vFY7PxDAkUMMDBXmxDG5V"}
{"genre": "karntner volksmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/5dXuunbECY9K8CP3otFqnf"}
{"genre": "gayageum", "spotify_playlist_url": "https://open.spotify.com/playlist/763GSASOYgfhcUcxqiklHL"}
{"genre": "gong", "spotify_playlist_url": "https://open.spotify.com/playlist/7luuOxRyl1SuTBxMo7DbTj"}
{"genre": "esperanto", "spotify_playlist_url": "https://open.spotify.com/playlist/6Hhf2afEqaDe0Vut2AtlYS"}
{"genre": "new england experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/1eE2MRCEWlqIKF1IGZFC2r"}
{"genre": "glass", "spotify_playlist_url": "https://open.spotify.com/playlist/6lxiTORjbiO6lYSldqNSt4"}
{"genre": "italian occult psychedelia", "spotify_playlist_url": "https://open.spotify.com/playlist/3YJtBiDoJrBD7HuJVSduNl"}
{"genre": "malaysian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1bFZpZYlrJQsDAMLGNSlwI"}
{"genre": "czech jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/4XDiTzSCiEBaGpL3haS8Il"}
{"genre": "indie catracho", "spotify_playlist_url": "https://open.spotify.com/playlist/45SpjOwyC6NQv0dCGnTQ6p"}
{"genre": "folclore extremeno", "spotify_playlist_url": "https://open.spotify.com/playlist/1AxYzZcSydLbVfJCceXqJl"}
{"genre": "brazilian grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0YE2Cngaa0qD0vM3VgEL2A"}
{"genre": "italian baroque ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/5izK80MaWIg2px59tE5CL4"}
{"genre": "extratone", "spotify_playlist_url": "https://open.spotify.com/playlist/6xQmgTM4atbKMcjHlnKuXS"}
{"genre": "indie tucumano", "spotify_playlist_url": "https://open.spotify.com/playlist/4G03ku5lPidQGSfH7uR9No"}
{"genre": "naturjodel", "spotify_playlist_url": "https://open.spotify.com/playlist/3mSQTZ0cXmrZNKdLvyVgQf"}
{"genre": "rock abc paulista", "spotify_playlist_url": "https://open.spotify.com/playlist/3zg3QbALwaqxVGMuEgSHnL"}
{"genre": "neo-trad doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3XgFJ8rlTnzqDdNxcc3oWN"}
{"genre": "austrian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/28XWNsMFftUZX8IdXdustD"}
{"genre": "musica londrinense", "spotify_playlist_url": "https://open.spotify.com/playlist/05SeBe6b4cU4jUSmdZScc3"}
{"genre": "rabm", "spotify_playlist_url": "https://open.spotify.com/playlist/7DuGt7mnzXQBmJgCe6WBun"}
{"genre": "polish noise rock", "spotify_playlist_url": "https://open.spotify.com/playlist/6rV941EQPPJiWJiMbEIXUB"}
{"genre": "jazz caraibes", "spotify_playlist_url": "https://open.spotify.com/playlist/1CLuRPl2GVoKX0D5LVq3rg"}
{"genre": "marsmuziek", "spotify_playlist_url": "https://open.spotify.com/playlist/7vpR9aJNqeF7FYnSIbhcdc"}
{"genre": "musica caririense", "spotify_playlist_url": "https://open.spotify.com/playlist/5OXdeWcY5kynPjDIsAcwvJ"}
{"genre": "lithuanian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/32189ym3b8UZkpus5l7mYM"}
{"genre": "metal galego", "spotify_playlist_url": "https://open.spotify.com/playlist/5JlAxfks8WrtOW60uXc5Nj"}
{"genre": "russian screamo", "spotify_playlist_url": "https://open.spotify.com/playlist/24dPdOLQ5vnvCWyTukxqKx"}
{"genre": "somatik techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4A7SzxjmpFO4E0H4BGT4p4"}
{"genre": "icelandic choir", "spotify_playlist_url": "https://open.spotify.com/playlist/1OmDM5DGkAOXJcJTX9oHaf"}
{"genre": "belfast metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1YoMpI53tJdZYGpjplRNhC"}
{"genre": "chaotic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3faHorqT0w0y69cZBrfVkh"}
{"genre": "zohioliin duu", "spotify_playlist_url": "https://open.spotify.com/playlist/7HNLEMjbJjqPCGK6AXxAqa"}
{"genre": "greek clarinet", "spotify_playlist_url": "https://open.spotify.com/playlist/75AdiuZcTyPaChb4c6BH5G"}
{"genre": "gospel papiamento", "spotify_playlist_url": "https://open.spotify.com/playlist/7mBz3DA4Lt7Bsbtr5TxklP"}
{"genre": "classical oboe", "spotify_playlist_url": "https://open.spotify.com/playlist/5lTiuwy0WagaU6DlDtiKqX"}
{"genre": "vintage old-time", "spotify_playlist_url": "https://open.spotify.com/playlist/4nY6eWfRNKtTzG1oZLer4I"}
{"genre": "italian bass", "spotify_playlist_url": "https://open.spotify.com/playlist/4nnzdeauDrOZv9WWKLctcl"}
{"genre": "proto-rap", "spotify_playlist_url": "https://open.spotify.com/playlist/3ZaC81nIFKE0zJphHSTnLq"}
{"genre": "jota aragonesa", "spotify_playlist_url": "https://open.spotify.com/playlist/5I8zMxeZZqqKS6eEcslf2z"}
{"genre": "liberian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2Uu1r2ra4Xjiweb2VjDkjl"}
{"genre": "vintage gospel", "spotify_playlist_url": "https://open.spotify.com/playlist/1nUeq2VFT7rDOsry1KD01T"}
{"genre": "jazz boliviano", "spotify_playlist_url": "https://open.spotify.com/playlist/2ZPfkZLq178AVQfRzL79jL"}
{"genre": "irish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/4iLweHFQ2lFWihZk6J22Na"}
{"genre": "danish contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4LmqkRtYmylQxZZbflivFF"}
{"genre": "german grindcore", "spotify_playlist_url": "https://open.spotify.com/playlist/60Nm3seat7622WhdnFlzIr"}
{"genre": "skiffle", "spotify_playlist_url": "https://open.spotify.com/playlist/5LZehZZegDGsQ51Fc6jedN"}
{"genre": "chakma pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2hGnBWrSDJp7q7BXukCsEc"}
{"genre": "polish metalcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7BbCYGsbE3F7stw0OOEVJM"}
{"genre": "taiwan experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/14iJpIFvqItkSS8jsq5sKB"}
{"genre": "hipco", "spotify_playlist_url": "https://open.spotify.com/playlist/35RzAOwDYt3IyNMfuotUfV"}
{"genre": "deep active rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4lNcZ9bBI5BHRTGaWUUBiv"}
{"genre": "turkmen hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/6JEhrtouAqMyKb9PQVONrL"}
{"genre": "indian techno", "spotify_playlist_url": "https://open.spotify.com/playlist/4dwOYXkXHmIht97nsgsHk1"}
{"genre": "egyptian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1F1I7b5oK13ta5H3uhqrz9"}
{"genre": "folclore navarra", "spotify_playlist_url": "https://open.spotify.com/playlist/0uLPqu4EhudWJADwbdrltv"}
{"genre": "romanian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/7jYbs20YAENXHIfySdJrdg"}
{"genre": "cimbalom", "spotify_playlist_url": "https://open.spotify.com/playlist/0XTK7eBNmxIP5aVMmqOiiC"}
{"genre": "belfast indie", "spotify_playlist_url": "https://open.spotify.com/playlist/2yCU7LgE1wtFLeAyXMpN8v"}
{"genre": "historic orchestral performance", "spotify_playlist_url": "https://open.spotify.com/playlist/3gwOJdannyNpzpyl6MyNb1"}
{"genre": "contra dance", "spotify_playlist_url": "https://open.spotify.com/playlist/1Q3GggwlxAbMZmH5kmaXYJ"}
{"genre": "flashcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6qovw3cxQkd56G3MWoAThC"}
{"genre": "czech swing", "spotify_playlist_url": "https://open.spotify.com/playlist/5jGdQxtYegtKRvGJqo8315"}
{"genre": "austrian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/7henJ3D2euaPqsF2zGnkiS"}
{"genre": "mexican electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZOAblnxBTxXgyCSEOvGDl"}
{"genre": "latvian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6B1R2NhaSBVDEuKRDqhjAo"}
{"genre": "folklore quebecois", "spotify_playlist_url": "https://open.spotify.com/playlist/1dYPwHG9KYpf9sYClhTC2k"}
{"genre": "french orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/6tdOM6oZTKZc3vYXEtqNlA"}
{"genre": "lion city hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/7tiDQk0zN2A7jATyNBJ8aT"}
{"genre": "zomi pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6OIvf4qxX3DEeobwlpRBHq"}
{"genre": "orkiestra symfoniczna", "spotify_playlist_url": "https://open.spotify.com/playlist/1nQQau2qrarcK8gCZNIwia"}
{"genre": "landler", "spotify_playlist_url": "https://open.spotify.com/playlist/6yZn81v1jP6Phi9S0tm4At"}
{"genre": "hard chime", "spotify_playlist_url": "https://open.spotify.com/playlist/2NN4wFIfrIkZ4cBYnYArvz"}
{"genre": "metal cristao", "spotify_playlist_url": "https://open.spotify.com/playlist/7BAkBfgas8V5uEHj5laJGI"}
{"genre": "magyar kabare", "spotify_playlist_url": "https://open.spotify.com/playlist/1dDJAUMo7nJlS3NWZbRIUo"}
{"genre": "thai traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/2VSIQI5C1eGnLNeS0XRqHm"}
{"genre": "swazi hip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/5oD5WfeP8RCrGlORerVp8o"}
{"genre": "deep pop emo", "spotify_playlist_url": "https://open.spotify.com/playlist/6O0YqAnrB1YHt2SbwD28fD"}
{"genre": "cante alentejano", "spotify_playlist_url": "https://open.spotify.com/playlist/6gbXFwyN4DFGTeFysOYiCn"}
{"genre": "cryptic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4P9bwV4vyjup4LWUj2iMUc"}
{"genre": "czech psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/2Jk2MxqakxUysaelPI07vv"}
{"genre": "spanish black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0vcTxhqUCmJxMUGcEmyubI"}
{"genre": "italian industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/6MCiWpvpGO4vHkMjOf9FGI"}
{"genre": "band organ", "spotify_playlist_url": "https://open.spotify.com/playlist/3epCXOPh4FT9jniV2noOHq"}
{"genre": "afrikaans folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6YcVrEYohgdJDds0SJ70CM"}
{"genre": "moroccan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/65oDfp1E9qx1WvIvPAPUwK"}
{"genre": "rock paraense", "spotify_playlist_url": "https://open.spotify.com/playlist/19Ba0QokQccfJ4PhGlIVVl"}
{"genre": "thai psychedelic", "spotify_playlist_url": "https://open.spotify.com/playlist/5AwY5kfvipRIDTcdL1NvGA"}
{"genre": "ethnomusicology", "spotify_playlist_url": "https://open.spotify.com/playlist/2mit5jMcQWc1aDvjBCZtO7"}
{"genre": "ainu folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6cNmRcp1nt8UisO8Emiido"}
{"genre": "northumbrian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/0FtAetIsq3mJuD7MaPPnDH"}
{"genre": "deep orgcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0nrk7jkdovzoJbERrBi9uN"}
{"genre": "karelian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7H2ToS5d4VMHNV4uzomEH0"}
{"genre": "italian classical guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/2pUIRmPkTWfyaFrpGy61mk"}
{"genre": "mexican black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2WEeEjUJTQJn0lYhjqJUyJ"}
{"genre": "portuguese post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/31adiB2neUkKBC43IBDeXA"}
{"genre": "rap paraense", "spotify_playlist_url": "https://open.spotify.com/playlist/4VB6UDGvpH4DxITKZti5Kq"}
{"genre": "viola", "spotify_playlist_url": "https://open.spotify.com/playlist/7uh6d2qXu4kltMx24JV7Vr"}
{"genre": "nadaswaram", "spotify_playlist_url": "https://open.spotify.com/playlist/3B79JUWNRAEFiKJO8LijQR"}
{"genre": "italian heavy metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0vOzJN3JrGoaDCj5HP0Zjo"}
{"genre": "korean minyo", "spotify_playlist_url": "https://open.spotify.com/playlist/06btQ33Qu07ozASdizbTkO"}
{"genre": "gypsy", "spotify_playlist_url": "https://open.spotify.com/playlist/7lqKESEBuOaNuquLaHdKrO"}
{"genre": "classical piano trio", "spotify_playlist_url": "https://open.spotify.com/playlist/4hW3PF8Guu6YsdiZoAE2Oi"}
{"genre": "minnesang", "spotify_playlist_url": "https://open.spotify.com/playlist/0AVJ1UKXMQf244cvu4np0k"}
{"genre": "classical tuba", "spotify_playlist_url": "https://open.spotify.com/playlist/7has518kIeS5AkHVY0gnNz"}
{"genre": "rap burkinabe", "spotify_playlist_url": "https://open.spotify.com/playlist/2xpbfhM49fx4F2LpYAy2yQ"}
{"genre": "baltic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2OePO9GaqliMNHU4npmPs4"}
{"genre": "maldivian pop", "spotify_playlist_url": "https://open.spotify.com/playlist/4I4FoywGhUAfNLgDkfC8UQ"}
{"genre": "czech hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/0NIUQZCng8iw1JLyT9loOf"}
{"genre": "musica piemonteisa", "spotify_playlist_url": "https://open.spotify.com/playlist/0msVvCOGK0MZKvnDX6PsLW"}
{"genre": "indonesian black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/4bm3WkkXKyxMfcLOEht3mk"}
{"genre": "musique traditionnelle congolaise", "spotify_playlist_url": "https://open.spotify.com/playlist/0rvR2tjFUlz37sgKpbbkpd"}
{"genre": "metal paraguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/4RV4TSk6uaR4URwZMaA4Pa"}
{"genre": "french rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/6l73EcAEl0oEthiybGL7Gz"}
{"genre": "portuguese hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1Rcb7ssxQppghsnMG37D8s"}
{"genre": "palm wine guitar", "spotify_playlist_url": "https://open.spotify.com/playlist/2dGXJ3KpdWfcgfvNAb8QPc"}
{"genre": "frevo", "spotify_playlist_url": "https://open.spotify.com/playlist/1Qc7lRgdYegu5Cjz1XAX5x"}
{"genre": "korean hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/6eJzG35mKPGsGvFcZJ39rP"}
{"genre": "experimental dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/0yrnPLt9UfINwPvCLw9M25"}
{"genre": "baltic choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4GJRH5oAmoRw170RSXR4HZ"}
{"genre": "musica roraimense", "spotify_playlist_url": "https://open.spotify.com/playlist/4YN86Zcl3BVaTEAxT6IfUl"}
{"genre": "baoule", "spotify_playlist_url": "https://open.spotify.com/playlist/0pI6WrHCq5oRYSoCwMJkqi"}
{"genre": "metal uruguayo", "spotify_playlist_url": "https://open.spotify.com/playlist/62PHV1LLPUMERqxHsti032"}
{"genre": "ethiopian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/6pwxXxDllzVgmynD4Xr0kh"}
{"genre": "post-rock latinoamericano", "spotify_playlist_url": "https://open.spotify.com/playlist/7wiuy5iEdMLPlkxAZ1Xag6"}
{"genre": "fife and drum", "spotify_playlist_url": "https://open.spotify.com/playlist/47qloHCA0Ygkm4Jn1pOYNt"}
{"genre": "metal balear", "spotify_playlist_url": "https://open.spotify.com/playlist/4tQLejuIwBey0NjUpLxPwb"}
{"genre": "classical guitar duo", "spotify_playlist_url": "https://open.spotify.com/playlist/62soEe3oHcs4AwY063pK6B"}
{"genre": "troubadour", "spotify_playlist_url": "https://open.spotify.com/playlist/5WjxMg3QfWAmDH7I2MpMoT"}
{"genre": "spoken word", "spotify_playlist_url": "https://open.spotify.com/playlist/7BvhYqKX9xCjKKkvsiowo3"}
{"genre": "portuguese early music", "spotify_playlist_url": "https://open.spotify.com/playlist/2WWDUDxy1PCo3bonaDqe6A"}
{"genre": "persian poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/2iTSvBWEZCUzalvlFHlcab"}
{"genre": "italian orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/0fXHa2e5eKbz5s0xuAX8li"}
{"genre": "song poem", "spotify_playlist_url": "https://open.spotify.com/playlist/3HHAx6vVncsuqKj6pn2yfe"}
{"genre": "boy soprano", "spotify_playlist_url": "https://open.spotify.com/playlist/29oFVjFjwV3667JJYStR6m"}
{"genre": "korean contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3BD1sI4da2uZZd2uQ90Ttk"}
{"genre": "deep indie rock", "spotify_playlist_url": "https://open.spotify.com/playlist/4MSw2GXv0DXXfY0bjfFqEI"}
{"genre": "appenzeller folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6AJz1kzYw4LXTrZhWRyARO"}
{"genre": "indie nordeste argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/4jPaRv9ZvejfMNNMsKidlZ"}
{"genre": "deep neo-synthpop", "spotify_playlist_url": "https://open.spotify.com/playlist/2mb1CA8bzqttQcD1HJaPyn"}
{"genre": "kadongo kamu", "spotify_playlist_url": "https://open.spotify.com/playlist/3hJoRP8bV5pbXa2AienPS5"}
{"genre": "irish death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1l68udGkykRW1ROitwX0DZ"}
{"genre": "metal catarinense", "spotify_playlist_url": "https://open.spotify.com/playlist/6ShxMeq3GHXvCtK5QU7f7R"}
{"genre": "central american metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6f5qv22lxPOYrTcRW65JxX"}
{"genre": "turkish hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/1oTfnmfJwvQT8CEk8kEkxR"}
{"genre": "animal singing", "spotify_playlist_url": "https://open.spotify.com/playlist/1eyCjFAnmJxBnrXvLndyOE"}
{"genre": "trombone ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/6rsfvvXeh1DJVM8JoPp1jK"}
{"genre": "tatar folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7xJ9QkDPqpIQioFw54cDDQ"}
{"genre": "metal cearense", "spotify_playlist_url": "https://open.spotify.com/playlist/4hh3UwCf9VmecijXT3YTLS"}
{"genre": "baltic classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/3ocwYOhhO6ayIfYSHDvMfF"}
{"genre": "marathi balgeet", "spotify_playlist_url": "https://open.spotify.com/playlist/5aKBUG0lkBg6cz6mF4sErZ"}
{"genre": "deep southern soul", "spotify_playlist_url": "https://open.spotify.com/playlist/5x4b61pvg45R2O5LHFBjOH"}
{"genre": "balochi folk", "spotify_playlist_url": "https://open.spotify.com/playlist/428nFFSl6VXYheqlggxyvJ"}
{"genre": "pansori", "spotify_playlist_url": "https://open.spotify.com/playlist/66mvG8zBoANW9zDeyidSOO"}
{"genre": "dizi", "spotify_playlist_url": "https://open.spotify.com/playlist/6QE53B7NfNuEJ8ZlwJMEA3"}
{"genre": "brazilian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/6c2XUzTGkczJ3WZ6e3uvbL"}
{"genre": "musique traditionnelle comorienne", "spotify_playlist_url": "https://open.spotify.com/playlist/7ksXAyS1ZxTrof1TxTF6wZ"}
{"genre": "inuit traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7dAnb4clKDtv2ETIFAuXsA"}
{"genre": "south african techno", "spotify_playlist_url": "https://open.spotify.com/playlist/2DXNp8u6CzE9koDhaBYM6N"}
{"genre": "lagu jambi", "spotify_playlist_url": "https://open.spotify.com/playlist/1Qw878bmGXb4ZvjHdvThZW"}
{"genre": "sarangi", "spotify_playlist_url": "https://open.spotify.com/playlist/00BUG5gWzo4yU1M6F9Y4TC"}
{"genre": "euphonium", "spotify_playlist_url": "https://open.spotify.com/playlist/1xdLdgcB08v8hlQt8qRbU1"}
{"genre": "spanish contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/3R0cCFr2WTRnMH63bYR1qM"}
{"genre": "experimental poetry", "spotify_playlist_url": "https://open.spotify.com/playlist/0RO8YBtv36PJFXHS6ohiYP"}
{"genre": "rock nacional feminino", "spotify_playlist_url": "https://open.spotify.com/playlist/10qF5DmqSyMx7ZoC7Qvw9X"}
{"genre": "yiddish folk", "spotify_playlist_url": "https://open.spotify.com/playlist/5vKOWKIkiwTjrRpRrM96qw"}
{"genre": "accordion band", "spotify_playlist_url": "https://open.spotify.com/playlist/4uyu1mcpvAixF1jhrCYM0P"}
{"genre": "musica sinfonica", "spotify_playlist_url": "https://open.spotify.com/playlist/63FqUIxVo1KigavsVaoVnZ"}
{"genre": "trecento", "spotify_playlist_url": "https://open.spotify.com/playlist/6zc2HFPnDWeqqsBHhYEQER"}
{"genre": "sacred harp", "spotify_playlist_url": "https://open.spotify.com/playlist/2Qli8L6XitwVn4o4loA3RL"}
{"genre": "portuguese experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0ju49bDfuL4CUqVhqna7s8"}
{"genre": "deep r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/3htJqjjCUIndBa8q3ngCUL"}
{"genre": "polish experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/5mJMwtywZacymdtdT21ABQ"}
{"genre": "grunge argentina", "spotify_playlist_url": "https://open.spotify.com/playlist/0mjeWAXewFCtNv29zmHSzs"}
{"genre": "akordeon", "spotify_playlist_url": "https://open.spotify.com/playlist/4qCSRPZbygT5GSSuli9gUL"}
{"genre": "hard dance", "spotify_playlist_url": "https://open.spotify.com/playlist/1OaA4XBHa4LnyOOrBOAaqE"}
{"genre": "metal baiano", "spotify_playlist_url": "https://open.spotify.com/playlist/00sZtA0R30VPBaErSDJrNf"}
{"genre": "harmonikka", "spotify_playlist_url": "https://open.spotify.com/playlist/2sW6afZsyQD7wQKS7hMrkK"}
{"genre": "black metal argentino", "spotify_playlist_url": "https://open.spotify.com/playlist/7mO5q3hzRCrtC8HKPsitzQ"}
{"genre": "kamba pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3GPnlDr6QUwAM4LW4gGOqy"}
{"genre": "ghanaian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/3IzGDWlfu7VTZEK9Cnadyf"}
{"genre": "taarab", "spotify_playlist_url": "https://open.spotify.com/playlist/4FAhZsNGKjPEGw68w0K9Q9"}
{"genre": "nordnorsk ponk", "spotify_playlist_url": "https://open.spotify.com/playlist/0IX8lhBXTLOfuBixiqlAqI"}
{"genre": "industrial noise", "spotify_playlist_url": "https://open.spotify.com/playlist/0jiK6wprtcZIx6LJv3SYfx"}
{"genre": "hard stoner rock", "spotify_playlist_url": "https://open.spotify.com/playlist/1D7jPq4bYfm26hI4qkol1A"}
{"genre": "venezuelan metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3dcYLsaZ5ZrjU7BCYa84zW"}
{"genre": "traditional irish singing", "spotify_playlist_url": "https://open.spotify.com/playlist/2psBm18i8yELM0SUBhYLJL"}
{"genre": "luxembourgian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/0S5jjWoTd7P8avvYWHbTAP"}
{"genre": "malaysian post-rock", "spotify_playlist_url": "https://open.spotify.com/playlist/48ZKoNQTnoGPADU2Eed2Ge"}
{"genre": "chinese black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0L7bHV0lbJioaqp5SuHPrc"}
{"genre": "santa fe indie", "spotify_playlist_url": "https://open.spotify.com/playlist/1M4EoB5Qh8GbHN3oGbWcKc"}
{"genre": "malian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/0Ibhnj2z9ZVtpQcSopEhD8"}
{"genre": "grunge brasileiro", "spotify_playlist_url": "https://open.spotify.com/playlist/5wFCPsNw0Bzh1Hhw3Lpdym"}
{"genre": "kazakh traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1qAgKdCyu4Hw4dViqFc2od"}
{"genre": "vietnamese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1mvtazNJybNmsRmeTNjdEf"}
{"genre": "tanzanian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/4CaDH8L1J3Pi3QECNbkI55"}
{"genre": "classical guitar quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/5rMf64nAGUwqxV9R63o5jW"}
{"genre": "deep delta blues", "spotify_playlist_url": "https://open.spotify.com/playlist/6un2az3FWRdGCUdnl8DGeQ"}
{"genre": "ethereal gothic", "spotify_playlist_url": "https://open.spotify.com/playlist/6iwDMCdMvLI3ACfh5UWXlB"}
{"genre": "maltese metal", "spotify_playlist_url": "https://open.spotify.com/playlist/27zKNtgJLmUeuFNdyY1TVI"}
{"genre": "estonian jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2vhnckZPFBK0SqIC2aqnja"}
{"genre": "historical keyboard", "spotify_playlist_url": "https://open.spotify.com/playlist/1DIyRhN8JzZ1Y54dAJp8HC"}
{"genre": "jaw harp", "spotify_playlist_url": "https://open.spotify.com/playlist/2ACIH5Dey91mwax5lQOvER"}
{"genre": "irish hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/3I1xZDsmVVyEVV0Qe9HiqG"}
{"genre": "musica puntana", "spotify_playlist_url": "https://open.spotify.com/playlist/7nwt8W3rxIONVDsEEaZk0V"}
{"genre": "alphorn", "spotify_playlist_url": "https://open.spotify.com/playlist/74m3dVjqQ3WVDIFu0mpqks"}
{"genre": "alternative hardcore", "spotify_playlist_url": "https://open.spotify.com/playlist/18rkg4zW2Xuo6RQCZjoq10"}
{"genre": "deep latin jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/62h3iZoEvjJrmy42ucMytJ"}
{"genre": "classical contralto", "spotify_playlist_url": "https://open.spotify.com/playlist/5eIm2TCJuRuogOrorWsBVy"}
{"genre": "bulgarian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/6kWfC5lHYMJFMHVC22pkFX"}
{"genre": "trouvere", "spotify_playlist_url": "https://open.spotify.com/playlist/0nqJegaRD3nkCjyIwg7mry"}
{"genre": "classical piano duo", "spotify_playlist_url": "https://open.spotify.com/playlist/0U3TK5FgP7SbKWePe8OSKP"}
{"genre": "deep chill-out", "spotify_playlist_url": "https://open.spotify.com/playlist/4KQJnPNAZPb94t5bKQmHCY"}
{"genre": "punk ska", "spotify_playlist_url": "https://open.spotify.com/playlist/4ZSoFyrjgbCFyQssGk1HmV"}
{"genre": "police band", "spotify_playlist_url": "https://open.spotify.com/playlist/5PUxbB9Jk47DOKdYKMoYQs"}
{"genre": "czech contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6ScV4ZrFoaQtvw05But2sB"}
{"genre": "balkan classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/0mR6UfEMka4Lr5lodu6mUK"}
{"genre": "uyghur folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6BaqvoDbTvFKSsozDIRG8I"}
{"genre": "swedish jazz orkester", "spotify_playlist_url": "https://open.spotify.com/playlist/2lsqobg83L55zSnJ8z7MuV"}
{"genre": "jewish cantorial", "spotify_playlist_url": "https://open.spotify.com/playlist/2S05LDuOXuV9m0OI1ttTrd"}
{"genre": "musica urbana oaxaquena", "spotify_playlist_url": "https://open.spotify.com/playlist/5SsbRkqorBXT5Rlz5YJ9fJ"}
{"genre": "school choir", "spotify_playlist_url": "https://open.spotify.com/playlist/7MohyJQ5hB3cKpcyka02Rb"}
{"genre": "ars subtilior", "spotify_playlist_url": "https://open.spotify.com/playlist/2UKjnmVx8ROXrNxIAeaE7M"}
{"genre": "necrogrind", "spotify_playlist_url": "https://open.spotify.com/playlist/61AYZjaNq8JoheU3TCuoXw"}
{"genre": "musique tchadienne", "spotify_playlist_url": "https://open.spotify.com/playlist/4id4jU46jt19nZAiUoM24X"}
{"genre": "montana metal", "spotify_playlist_url": "https://open.spotify.com/playlist/2PIImwYRHiczMTYmHXmBcz"}
{"genre": "irish modern jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5cCSALXlXRj6q2FO947V8m"}
{"genre": "cypriot metal", "spotify_playlist_url": "https://open.spotify.com/playlist/01xZc008FGqP87lMtOoVu0"}
{"genre": "portuguese classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6fFdKNug4QTsmBT6vX8Axr"}
{"genre": "australian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/4IYqxUG3ZZ5bWN2WxEZ7cp"}
{"genre": "ghoststep", "spotify_playlist_url": "https://open.spotify.com/playlist/7gi5t2s5uIXVG61zCt5lmk"}
{"genre": "new zealand classical", "spotify_playlist_url": "https://open.spotify.com/playlist/4iRVszozo0kiDmgIqzmZxY"}
{"genre": "iranian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/3DcaooMgdPz0sO6hPGsepj"}
{"genre": "puerto rican metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6NC5Dmw1bDL1pNHw9O4fK1"}
{"genre": "indonesian electronic", "spotify_playlist_url": "https://open.spotify.com/playlist/0Hy9rITSl0a8n2bNBbFcta"}
{"genre": "canto a tenore", "spotify_playlist_url": "https://open.spotify.com/playlist/0Pg8lDo46YYTaEAdiskop8"}
{"genre": "chilean black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7B4zWgQlQykf68FE3hPeK9"}
{"genre": "lagu lampung", "spotify_playlist_url": "https://open.spotify.com/playlist/3wTmRDseZi0s4Q0OpBUg4q"}
{"genre": "bells", "spotify_playlist_url": "https://open.spotify.com/playlist/1y6yh0oYnU38wZsGARkcnX"}
{"genre": "south african dnb", "spotify_playlist_url": "https://open.spotify.com/playlist/47IgaJIbWVutbBYD8JZRTZ"}
{"genre": "jangle rock", "spotify_playlist_url": "https://open.spotify.com/playlist/3h4Un5qa5d7s4dAnqiEN6M"}
{"genre": "huqin", "spotify_playlist_url": "https://open.spotify.com/playlist/41ekhxR27rg6HNG3c6GGaP"}
{"genre": "romanian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/6JO6Yci8XeTZKmiMigOgXY"}
{"genre": "peruvian death metal", "spotify_playlist_url": "https://open.spotify.com/playlist/7wMWNsPIQQ5VBxuErPgZiv"}
{"genre": "brazilian doom metal", "spotify_playlist_url": "https://open.spotify.com/playlist/45hFa5uFEeE5MMWJ6ycGzL"}
{"genre": "deep indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/6hAm3o8x05IwzZg7bqHI6y"}
{"genre": "art song", "spotify_playlist_url": "https://open.spotify.com/playlist/7o2ox25eVd11xFrymrFO9j"}
{"genre": "metis fiddle", "spotify_playlist_url": "https://open.spotify.com/playlist/5IbOdfnqpUIOnO0xdH11pQ"}
{"genre": "classical horn", "spotify_playlist_url": "https://open.spotify.com/playlist/7DX0z0GOvOetSofH5LFl02"}
{"genre": "central asian folk", "spotify_playlist_url": "https://open.spotify.com/playlist/6zZc6904zlMlWQqH16hjlx"}
{"genre": "rock cristao fluminense", "spotify_playlist_url": "https://open.spotify.com/playlist/144jJIiJ1sVSlU1anED49d"}
{"genre": "pygmy music", "spotify_playlist_url": "https://open.spotify.com/playlist/15Z8LOfK9D6jDGd5yQ1rLQ"}
{"genre": "shantykoren", "spotify_playlist_url": "https://open.spotify.com/playlist/5bCUY6kzLTiW6elvotxQt9"}
{"genre": "cosmic uplifting trance", "spotify_playlist_url": "https://open.spotify.com/playlist/4if8aqDg8kCV1ReeSGvILy"}
{"genre": "hawaiian punk", "spotify_playlist_url": "https://open.spotify.com/playlist/0zze9184q29H3oVTZgODXf"}
{"genre": "deep motown", "spotify_playlist_url": "https://open.spotify.com/playlist/0um0xWckHN9oUTnMuxYD01"}
{"genre": "pibroch", "spotify_playlist_url": "https://open.spotify.com/playlist/1VUKmy5qSzD3KJQU0SA3ku"}
{"genre": "russian oi", "spotify_playlist_url": "https://open.spotify.com/playlist/3wnphCCCvxV0jO3rFtiLQB"}
{"genre": "caribbean metal", "spotify_playlist_url": "https://open.spotify.com/playlist/0QGrJitFBXUOFPICc94OlJ"}
{"genre": "school ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/4O7HgjcUApuayvJrKPz4yJ"}
{"genre": "twee indie pop", "spotify_playlist_url": "https://open.spotify.com/playlist/3MUIfb3RPGe0QwBAae3B3R"}
{"genre": "vanuatu music", "spotify_playlist_url": "https://open.spotify.com/playlist/7inTFRfISVdiJzduMwRw5X"}
{"genre": "horo", "spotify_playlist_url": "https://open.spotify.com/playlist/5UeLoZ6L5G1oflpuvYE7um"}
{"genre": "tahitian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/0TsFa6aPE0KgPXUT6kTFKk"}
{"genre": "metal nortista", "spotify_playlist_url": "https://open.spotify.com/playlist/2t0N1GoTz1iVDEIUjk9C8n"}
{"genre": "handbells", "spotify_playlist_url": "https://open.spotify.com/playlist/6exyTPIT1Q2zH4eCwRutmF"}
{"genre": "polish early music", "spotify_playlist_url": "https://open.spotify.com/playlist/1ii48Dby3vvKXtswT9sRjA"}
{"genre": "musica ponta-grossense", "spotify_playlist_url": "https://open.spotify.com/playlist/5C7yvtFPo6zeLkS4jzfJWP"}
{"genre": "schrammelmusik", "spotify_playlist_url": "https://open.spotify.com/playlist/3XUIqz03fTousjsdEDhQOS"}
{"genre": "indie tabasqueno", "spotify_playlist_url": "https://open.spotify.com/playlist/6Eji2sbOvPKXBQfUmNI9PZ"}
{"genre": "metal pernambucano", "spotify_playlist_url": "https://open.spotify.com/playlist/66vH732A5RHBhtfEZHbxa1"}
{"genre": "classical saxophone quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/2NorvvPMx9T36Y8X0vtMR5"}
{"genre": "czech experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0425SqjE9dL7IryiNmSnkp"}
{"genre": "deep symphonic black metal", "spotify_playlist_url": "https://open.spotify.com/playlist/6U3JRL2usBO9nbexBtxitf"}
{"genre": "musica mogiana", "spotify_playlist_url": "https://open.spotify.com/playlist/79MRsgrRBZM0beXu7KGgO3"}
{"genre": "opera chorus", "spotify_playlist_url": "https://open.spotify.com/playlist/4JFFwII9VfLC2TCBDS9XvD"}
{"genre": "albanian iso polyphony", "spotify_playlist_url": "https://open.spotify.com/playlist/756UroBW6f0FT3UapavnwM"}
{"genre": "drone psych", "spotify_playlist_url": "https://open.spotify.com/playlist/4ysJLFPAYAt4Uqyzo7OasJ"}
{"genre": "draaiorgel", "spotify_playlist_url": "https://open.spotify.com/playlist/4Jw47hdV6OqSfXh5z0HvZJ"}
{"genre": "sirmauri pop", "spotify_playlist_url": "https://open.spotify.com/playlist/2ibgkpk536pS68WQhmIE5I"}
{"genre": "twin cities indie", "spotify_playlist_url": "https://open.spotify.com/playlist/0iFWhOagWgnXvcPhbb63qn"}
{"genre": "austrian contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/1JnRJniVHBZsxaxIvmZLad"}
{"genre": "clarinet ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/3okkVrmRdBFlzg24ksMB3i"}
{"genre": "baroque woodwind", "spotify_playlist_url": "https://open.spotify.com/playlist/5Ct4UnnGmDiXOXUhZ6QYGG"}
{"genre": "indonesian indigenous traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/3rn0ycZKmc0TMthQMvBvCN"}
{"genre": "burkinabe traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/0FDqAqhTKhwFOLFcOxJKRR"}
{"genre": "musica maringaense", "spotify_playlist_url": "https://open.spotify.com/playlist/6N3Txa5NqvAjRsZIolwaXo"}
{"genre": "harsh noise wall", "spotify_playlist_url": "https://open.spotify.com/playlist/3xKq0XOlYIDqRaMz9q1QYv"}
{"genre": "chip hop", "spotify_playlist_url": "https://open.spotify.com/playlist/0gesCL9ngS2rsRN9fFyt6U"}
{"genre": "swiss contemporary classical", "spotify_playlist_url": "https://open.spotify.com/playlist/6WerM05v6Nw7rAFpjWRk7C"}
{"genre": "modern downshift", "spotify_playlist_url": "https://open.spotify.com/playlist/1LwkgEPHJYlvhv1YjwVGY2"}
{"genre": "polish choir", "spotify_playlist_url": "https://open.spotify.com/playlist/0wSQP0F0vvybBZ279QaVur"}
{"genre": "baroque violin", "spotify_playlist_url": "https://open.spotify.com/playlist/51IvzHND37F9uEN264qhe2"}
{"genre": "lagu madura", "spotify_playlist_url": "https://open.spotify.com/playlist/734X09F97uQg7AWgeNQGGt"}
{"genre": "deep smooth r&b", "spotify_playlist_url": "https://open.spotify.com/playlist/7K7eQm5eNmjvR1avm2Uikd"}
{"genre": "trad jazz catala", "spotify_playlist_url": "https://open.spotify.com/playlist/0Xml88s6LENWLR7I7lSGs2"}
{"genre": "dark electro-industrial", "spotify_playlist_url": "https://open.spotify.com/playlist/2DmqZ2vZQNftNYjlMiL13d"}
{"genre": "kaba gaida", "spotify_playlist_url": "https://open.spotify.com/playlist/6JtXP51dXNDWrlqblBzHzj"}
{"genre": "rock noise", "spotify_playlist_url": "https://open.spotify.com/playlist/6jPTE8wgwi7jsQJ7DoD8Zj"}
{"genre": "wagnerian singing", "spotify_playlist_url": "https://open.spotify.com/playlist/0qBkqNDoaEnhwGazeovqLP"}
{"genre": "indie emo rock", "spotify_playlist_url": "https://open.spotify.com/playlist/0QkBGZO2RKrPN3kfiGCIkW"}
{"genre": "peruvian experimental", "spotify_playlist_url": "https://open.spotify.com/playlist/0gsDmsRdnzAyOje1xsgIP2"}
{"genre": "musique alsacienne", "spotify_playlist_url": "https://open.spotify.com/playlist/6goepZdjv42VpwbyXIlCYr"}
{"genre": "cantonese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/6Nb8qxJ50HhjrYweWfE8It"}
{"genre": "belgian classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/4UQti246d8vnBvGLBCaJ2o"}
{"genre": "deep power-pop punk", "spotify_playlist_url": "https://open.spotify.com/playlist/61uUE9vhMYIZ7tUMGTrziq"}
{"genre": "deep deep tech house", "spotify_playlist_url": "https://open.spotify.com/playlist/6dL5fRHzNCWVxneaFru8h4"}
{"genre": "rwandan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7LtrvBG4VNrlWRP4nW0jwT"}
{"genre": "kyrgyz traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/6U2VlV0LIvYuU7XNHFycqA"}
{"genre": "burmese traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/0FemlmnruZEJogqocbcZ7e"}
{"genre": "chinese opera", "spotify_playlist_url": "https://open.spotify.com/playlist/3ueKGpM7H6yOxXaawk7yeD"}
{"genre": "burundian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1M7XycuFu8GTTCZ4SwPRBB"}
{"genre": "baroque cello", "spotify_playlist_url": "https://open.spotify.com/playlist/3EBMrwEeXilTkGsBB2g9AZ"}
{"genre": "cambodian traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/5onpMVKnthMnM0uCN5k2jY"}
{"genre": "vintage swoon", "spotify_playlist_url": "https://open.spotify.com/playlist/1woPxeegfDWfKwxbBIRApW"}
{"genre": "musique centrafricaine", "spotify_playlist_url": "https://open.spotify.com/playlist/0Wd7ru6M2A4bqzvCTUtQ3Z"}
{"genre": "faroese jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/2cEtqSZ5rvZH6yvzqyLgFE"}
{"genre": "bruneian indie", "spotify_playlist_url": "https://open.spotify.com/playlist/6ZQxOyGxVqXgamO6o8v8z0"}
{"genre": "korean classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/3Bb1Rfc7TbQOHCMm4MHgCj"}
{"genre": "vintage rockabilly", "spotify_playlist_url": "https://open.spotify.com/playlist/4cKSNfXpPF8S8u9ElShWi3"}
{"genre": "rhythm and boogie", "spotify_playlist_url": "https://open.spotify.com/playlist/2P5HTtUzsv4lDR0rOYgyUT"}
{"genre": "marci brijuzi", "spotify_playlist_url": "https://open.spotify.com/playlist/4gLqgkEOzR2IMIqts0jbBT"}
{"genre": "papuan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7LpTz3Uzb23hZ41ODZkKlB"}
{"genre": "macedonian metal", "spotify_playlist_url": "https://open.spotify.com/playlist/1WAWqDllwggTmkFnnBPB0X"}
{"genre": "lao traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/6PIhwFYl5paNWQ0UxMN2Ys"}
{"genre": "gay chorus", "spotify_playlist_url": "https://open.spotify.com/playlist/7CdZu3q1tMEAVI915Mquxf"}
{"genre": "wind quintet", "spotify_playlist_url": "https://open.spotify.com/playlist/2X6s7tN8lCBZRgSkPLFApt"}
{"genre": "polish free jazz", "spotify_playlist_url": "https://open.spotify.com/playlist/5scILYXkjOSPXJVC494rCD"}
{"genre": "deep breakcore", "spotify_playlist_url": "https://open.spotify.com/playlist/58ienfUL0jy1I5EeZootxl"}
{"genre": "tanci", "spotify_playlist_url": "https://open.spotify.com/playlist/7ratOul7KberTWrn86l4O7"}
{"genre": "balikpapan indie", "spotify_playlist_url": "https://open.spotify.com/playlist/4xHYQJKvXQOORHG2Vn3g3V"}
{"genre": "uzbek traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7lD1z1eJX5htOF3koYxdnY"}
{"genre": "musica timor-leste", "spotify_playlist_url": "https://open.spotify.com/playlist/7nxGrqThvp577vV0oVgf3F"}
{"genre": "italian violin", "spotify_playlist_url": "https://open.spotify.com/playlist/6Vf6P26sYyUqljb9e8Jy5b"}
{"genre": "wandelweiser", "spotify_playlist_url": "https://open.spotify.com/playlist/33oGvjtMTi5BUCp7suPnkc"}
{"genre": "bothy ballad", "spotify_playlist_url": "https://open.spotify.com/playlist/4VIb2spYu2TVsYw9FmWne6"}
{"genre": "metal piauiense", "spotify_playlist_url": "https://open.spotify.com/playlist/7ag1VL5wW9kzU3HNakBCNe"}
{"genre": "kenyan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7AJynlDk1ALWIWobcKFPyL"}
{"genre": "quatuor a cordes", "spotify_playlist_url": "https://open.spotify.com/playlist/2LxiSYEJRCTiv0TE0K3ljN"}
{"genre": "italian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/3FmmWyUC2kd2Mt73H5LcDg"}
{"genre": "zampogna", "spotify_playlist_url": "https://open.spotify.com/playlist/6egS6vpB5c6raIlw1v0Nx2"}
{"genre": "ugandan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/59TVx2MmmBfg0BqRc7CvqM"}
{"genre": "yemeni traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1DWET41vcTWLJFAnYJHUp0"}
{"genre": "tajik traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/7GmKZthF6bYPWlhFBTQ3Ef"}
{"genre": "wind ensemble", "spotify_playlist_url": "https://open.spotify.com/playlist/3cANCffSWFKbBFnMpDmsnj"}
{"genre": "hungarian choir", "spotify_playlist_url": "https://open.spotify.com/playlist/2duCf3u7U1iW5LSwQKwwTc"}
{"genre": "swiss classical piano", "spotify_playlist_url": "https://open.spotify.com/playlist/38R6g7ojpzP4weT7JspODa"}
{"genre": "mazandarani folk", "spotify_playlist_url": "https://open.spotify.com/playlist/7duuLur49tAfIJBp03Upi9"}
{"genre": "historic string quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/1uFomERyvA3TJOSYHQYgup"}
{"genre": "italian mezzo-soprano", "spotify_playlist_url": "https://open.spotify.com/playlist/124Hts37YwwD2DIV1PmpPI"}
{"genre": "swazi traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/1vSYauLcP94YFZ2JniVyUQ"}
{"genre": "trallalero", "spotify_playlist_url": "https://open.spotify.com/playlist/6PJCol5gHpuhFsPNKBsbuD"}
{"genre": "baroque brass", "spotify_playlist_url": "https://open.spotify.com/playlist/0BpOGipPzdkgJomyZXLxYl"}
{"genre": "himene tarava", "spotify_playlist_url": "https://open.spotify.com/playlist/6N3gRB6GTGmmLAAYe86ntl"}
{"genre": "vintage western", "spotify_playlist_url": "https://open.spotify.com/playlist/3CAXrvHsac1eF7IAXqBMTR"}
{"genre": "classical string trio", "spotify_playlist_url": "https://open.spotify.com/playlist/4DtLydGf8lRtpnC38sI410"}
{"genre": "cinematic dubstep", "spotify_playlist_url": "https://open.spotify.com/playlist/1gix2teoZioMus8kRecMUH"}
{"genre": "quartetto d'archi", "spotify_playlist_url": "https://open.spotify.com/playlist/1kps7K1T21QuwQUHaotbmj"}
{"genre": "yunnan traditional", "spotify_playlist_url": "https://open.spotify.com/playlist/19q2gA3eWnQO5eTOD6aTYv"}
{"genre": "classical piano quartet", "spotify_playlist_url": "https://open.spotify.com/playlist/3o54yxPRl7qCZhZKGpp5IE"}
{"genre": "string quintet", "spotify_playlist_url": "https://open.spotify.com/playlist/4LbFpoidoVmFpQNN0BZUYA"}
{"genre": "youth orchestra", "spotify_playlist_url": "https://open.spotify.com/playlist/4SNnzqfxrI1Uh1HpOctFTT"}
